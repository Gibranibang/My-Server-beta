"""
Configuration Module for MyServer Native Backend
"""

import os
import secrets
from pathlib import Path
from typing import Optional

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = os.getenv("MYSERVER_DATA_DIR", str(BASE_DIR / "data"))
STORAGE_DIR = os.getenv("MYSERVER_STORAGE_DIR", str(BASE_DIR / "storage"))
TEMP_DIR = os.path.join(DATA_DIR, "temp_chunks")

# Database Path
DB_PATH = os.getenv("MYSERVER_DB_PATH", os.path.join(DATA_DIR, "backup_meta.db"))

# Server Parameters
PORT = int(os.getenv("MYSERVER_PORT", "8080"))
HOST = os.getenv("MYSERVER_HOST", "0.0.0.0")
def _load_or_create_jwt_secret() -> str:
    env_secret = os.getenv("MYSERVER_JWT_SECRET", "").strip()
    if env_secret:
        return env_secret
    secret_file = os.path.join(DATA_DIR, ".jwt_secret")
    if os.path.isfile(secret_file):
        try:
            with open(secret_file, "r", encoding="utf-8") as f:
                existing = f.read().strip()
        except OSError as exc:
            raise RuntimeError(
                f"Gagal membaca JWT secret persisten di '{secret_file}': {exc}"
            ) from exc
        if not existing:
            raise RuntimeError(
                f"File JWT secret persisten di '{secret_file}' kosong dan tidak dapat digunakan."
            )
        return existing
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        generated = secrets.token_hex(32)
        with open(secret_file, "w", encoding="utf-8") as f:
            f.write(generated)
        try:
            os.chmod(secret_file, 0o600)
        except OSError:
            pass
        return generated
    except OSError as exc:
        raise RuntimeError(
            f"Gagal menyimpan JWT secret persisten di '{secret_file}': {exc}"
        ) from exc


def get_admin_usernames() -> set:
    raw = os.getenv("MYSERVER_ADMIN_USERS", "")
    extra = {u.strip().lower() for u in raw.split(",") if u.strip()}
    return {"admin", "root"} | extra


def is_admin_username(username: Optional[str]) -> bool:
    if not username:
        return False
    return username.strip().lower() in get_admin_usernames()


JWT_SECRET = _load_or_create_jwt_secret()
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = int(os.getenv("MYSERVER_JWT_EXPIRE_HOURS", "720"))  # 30 days

# Backup Engine Parameters
CHUNK_SIZE_BYTES = int(os.getenv("MYSERVER_CHUNK_SIZE_MB", "4")) * 1024 * 1024  # Default 4MB
MAX_PARALLEL_CHUNKS = int(os.getenv("MYSERVER_MAX_PARALLEL_CHUNKS", "4"))
MAX_UPLOAD_SIZE_BYTES = int(os.getenv("MYSERVER_MAX_UPLOAD_SIZE_MB", "4096")) * 1024 * 1024
MAX_OTA_SIZE_BYTES = int(os.getenv("MYSERVER_MAX_OTA_SIZE_MB", "256")) * 1024 * 1024
SERVER_VERSION = "2.2.0"
UPDATE_REPO_SLUG = os.environ.get("MYSERVER_UPDATE_REPO", "Gibranibang/My-Server-beta").strip()

# Ensure directories exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(STORAGE_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)
