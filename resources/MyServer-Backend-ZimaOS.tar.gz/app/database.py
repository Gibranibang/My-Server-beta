"""
Database Manager for MyServer Native Backend
SQLite Schema & Data Access Layer (WAL mode enabled)
"""

import sqlite3
import os
import json
import logging
import threading
import time
import hashlib
import hmac
import secrets
import base64
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Optional, Tuple
import app.config as _app_config
from app.config import DB_PATH

_INITIAL_DB_PATH = DB_PATH
logger = logging.getLogger("myserver.database")
_USER_CACHE_LOCK = threading.RLock()
_USER_CACHE_BY_ID: Dict[Tuple[str, int], Tuple[float, Dict[str, Any]]] = {}
_USER_CACHE_BY_NAME: Dict[Tuple[str, str], Tuple[float, Dict[str, Any]]] = {}
_USER_CACHE_TTL_SEC = 5.0

SCHEMA_SQL = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA temp_store = MEMORY;
PRAGMA cache_size = -16384;
PRAGMA foreign_keys = ON;

-- 1. Tabel Pengguna (Users)
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT DEFAULT '',
    smb_password_enc TEXT DEFAULT '',
    role TEXT DEFAULT 'user',
    allowed_disks TEXT DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabel Perangkat Klien (Devices: Desktop Windows, Mobile Android/iOS)
CREATE TABLE IF NOT EXISTS devices (
    device_id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    device_name TEXT NOT NULL,
    device_type TEXT NOT NULL, -- 'windows', 'android', 'ios', 'linux'
    app_version TEXT NOT NULL,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

-- 3. Tabel Tugas Cadangan (Backup Tasks)
CREATE TABLE IF NOT EXISTS backup_tasks (
    task_id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    task_name TEXT NOT NULL,
    target_folder TEXT NOT NULL,
    sync_mode TEXT DEFAULT 'one_way', -- 'one_way', 'mirror'
    username TEXT DEFAULT 'admin',
    status TEXT DEFAULT 'idle', -- 'idle', 'syncing', 'completed', 'error'
    total_files INTEGER DEFAULT 0,
    total_bytes INTEGER DEFAULT 0,
    last_run TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices (device_id) ON DELETE CASCADE
);

-- 4. Tabel Berkas Tercatat (Files Registry)
CREATE TABLE IF NOT EXISTS files (
    file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_hash TEXT NOT NULL, -- SHA-256 berkas utuh
    modified_time INTEGER NOT NULL, -- Client timestamp (epoch seconds)
    storage_path TEXT NOT NULL, -- Lokasi fisik relatif di HDD server
    status TEXT DEFAULT 'active', -- 'active', 'deleted', 'archived'
    version INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES backup_tasks (task_id) ON DELETE CASCADE,
    UNIQUE(task_id, relative_path)
);

-- 5. Tabel Sesi Unggah Potongan (Upload Sessions)
CREATE TABLE IF NOT EXISTS upload_sessions (
    upload_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_hash TEXT NOT NULL,
    total_chunks INTEGER NOT NULL,
    chunks_received INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending', -- 'pending', 'uploading', 'merging', 'completed', 'failed'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES backup_tasks (task_id) ON DELETE CASCADE
);

-- 6. Tabel Potongan Berkas (Chunks)
CREATE TABLE IF NOT EXISTS chunks (
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
    upload_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    chunk_hash TEXT NOT NULL,
    chunk_size INTEGER NOT NULL,
    is_uploaded BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (upload_id) REFERENCES upload_sessions (upload_id) ON DELETE CASCADE,
    UNIQUE(upload_id, chunk_index)
);

-- 7. Tabel Log Aktivitas (Activity Logs)
CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT,
    task_id TEXT,
    action TEXT NOT NULL, -- 'DEVICE_REGISTERED', 'BACKUP_STARTED', 'FILE_UPLOADED', 'ERROR'
    message TEXT NOT NULL,
    details TEXT, -- JSON string
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Tabel Multi-Akun Cloud Storage (Google Drive / OneDrive per Akun)
CREATE TABLE IF NOT EXISTS cloud_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    provider TEXT DEFAULT 'gdrive', -- 'gdrive', 'onedrive', 'dropbox'
    email TEXT NOT NULL,
    display_name TEXT,
    access_token TEXT,
    refresh_token TEXT,
    token_expiry TIMESTAMP,
    quota_total INTEGER DEFAULT 0,
    quota_used INTEGER DEFAULT 0,
    status TEXT DEFAULT 'connected', -- 'connected', 'expired', 'disconnected'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    UNIQUE(user_id, provider, email)
);

-- 9. Tabel Virtual Machine Terkelola (Managed VMs & 24/7 Server Automation - v1.2.0)
CREATE TABLE IF NOT EXISTS managed_vms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT 'instabox',
    status TEXT NOT NULL DEFAULT 'sleeping',
    ssh_host TEXT DEFAULT '',
    ssh_port INTEGER DEFAULT 22,
    ssh_user TEXT DEFAULT '',
    token_expiry TEXT DEFAULT '',
    web_port INTEGER,
    web_url TEXT,
    screen_url TEXT,
    screen_target TEXT DEFAULT 'ask',
    api_key TEXT,
    machine_id TEXT,
    keep_alive_enabled BOOLEAN DEFAULT 0,
    auto_on_enabled BOOLEAN DEFAULT 0,
    auto_on_mode TEXT DEFAULT 'clock',
    auto_on_time TEXT DEFAULT '07:00',
    auto_on_delay_min INTEGER DEFAULT 60,
    auto_on_delay_unit TEXT DEFAULT 'minutes',
    auto_on_days TEXT DEFAULT '["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]',
    auto_restart_enabled BOOLEAN DEFAULT 0,
    auto_restart_mode TEXT DEFAULT 'interval',
    auto_restart_val INTEGER DEFAULT 7,
    auto_restart_unit TEXT DEFAULT 'hours',
    auto_restart_time TEXT DEFAULT '03:00',
    smart_reset_cycle TEXT DEFAULT 'sleep_2s',
    runtime_limit_hours INTEGER DEFAULT 8,
    max_runtime_minutes INTEGER,
    runtime_minutes INTEGER DEFAULT 0,
    schedule_timezone TEXT DEFAULT '',
    tz_offset_minutes INTEGER,
    last_runtime_check TIMESTAMP,
    last_wake_time TIMESTAMP,
    last_sleep_time TIMESTAMP,
    last_reset_time TIMESTAMP,
    telemetry TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 10. Tabel Pengaturan Sistem (System Settings)
CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT DEFAULT '',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. Tabel Tautan Berbagi Publik (Public Share Links)
CREATE TABLE IF NOT EXISTS public_shares (
    token TEXT PRIMARY KEY,
    owner_user_id INTEGER,
    owner_username TEXT NOT NULL,
    target_path TEXT NOT NULL,
    is_dir INTEGER DEFAULT 0,
    label TEXT DEFAULT '',
    expires_at TEXT,
    password_hash TEXT,
    revoked INTEGER DEFAULT 0,
    download_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indeks Performa Tinggi
CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_device ON backup_tasks(device_id);
CREATE INDEX IF NOT EXISTS idx_files_lookup ON files(task_id, relative_path);
CREATE INDEX IF NOT EXISTS idx_files_hash ON files(file_hash);
CREATE INDEX IF NOT EXISTS idx_upload_sessions_task ON upload_sessions(task_id);
CREATE INDEX IF NOT EXISTS idx_chunks_session ON chunks(upload_id, chunk_index);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON activity_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_cloud_accounts_user ON cloud_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_managed_vms_provider ON managed_vms(provider);
CREATE INDEX IF NOT EXISTS idx_managed_vms_status ON managed_vms(status);
CREATE INDEX IF NOT EXISTS idx_public_shares_owner ON public_shares(owner_username);
CREATE INDEX IF NOT EXISTS idx_public_shares_path ON public_shares(target_path);
"""


def _resolve_db_path(db_path: Optional[str] = None) -> str:
    """Resolve active SQLite DB path dynamically when app.config.DB_PATH or app.database.DB_PATH is patched."""
    if db_path and db_path != _INITIAL_DB_PATH:
        return db_path
    if DB_PATH != _INITIAL_DB_PATH:
        return DB_PATH
    cfg_db = getattr(_app_config, "DB_PATH", DB_PATH)
    if cfg_db != _INITIAL_DB_PATH:
        return str(cfg_db)
    return str(db_path or DB_PATH)


@contextmanager
def get_db(db_path: str = DB_PATH):
    """Context manager untuk koneksi SQLite yang thread-safe & auto-commit."""
    resolved = _resolve_db_path(db_path)
    conn = sqlite3.connect(resolved, timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA busy_timeout = 10000;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA temp_store = MEMORY;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: str = DB_PATH):
    """Inisialisasi tabel dan indeks database jika belum ada."""
    db_path = _resolve_db_path(db_path)
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    with get_db(db_path) as conn:
        conn.executescript(SCHEMA_SQL)
        # Migrasi otomatis multi-user isolation
        cols = [r["name"] for r in conn.execute("PRAGMA table_info(backup_tasks)").fetchall()]
        if "username" not in cols:
            conn.execute("ALTER TABLE backup_tasks ADD COLUMN username TEXT DEFAULT 'admin'")
        
        # Migrasi otomatis tabel users untuk custom account & RBAC
        user_cols = [r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
        if "password_hash" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN password_hash TEXT DEFAULT ''")
        if "role" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'")
        if "allowed_disks" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN allowed_disks TEXT DEFAULT '[]'")
        if "smb_password_enc" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN smb_password_enc TEXT DEFAULT ''")
        if "token_version" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN token_version INTEGER DEFAULT 1")
        conn.execute(
            "UPDATE users SET role = 'user' WHERE role IS NULL OR LOWER(TRIM(role)) IN ('', 'staff')"
        )
        conn.execute("UPDATE users SET token_version = 1 WHERE token_version IS NULL")

        # Migrasi otomatis tabel managed_vms untuk kolom jadwal & reset
        vm_cols = [r["name"] for r in conn.execute("PRAGMA table_info(managed_vms)").fetchall()]
        if "auto_on_delay_unit" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN auto_on_delay_unit TEXT DEFAULT 'minutes'")
        if "last_reset_time" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN last_reset_time TIMESTAMP")
        if "schedule_timezone" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN schedule_timezone TEXT DEFAULT ''")
        if "tz_offset_minutes" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN tz_offset_minutes INTEGER")
        if "max_runtime_minutes" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN max_runtime_minutes INTEGER")
    logger.info(f"Database initialized successfully at: {db_path}")


# ==============================================================================
# DATA ACCESS HELPERS: AUTH & USER MANAGEMENT
# ==============================================================================

def _derive_smb_master_key() -> bytes:
    """Derive master secret bytes dynamically from app.config.JWT_SECRET."""
    import app.config as _cfg
    secret = str(getattr(_cfg, "JWT_SECRET", "") or "").strip()
    if not secret:
        raise RuntimeError("JWT_SECRET tidak tersedia untuk derivasi kunci enkripsi SMB.")
    return hashlib.sha256(f"myserver-smb-enc-v1:{secret}".encode("utf-8")).digest()


def _derive_smb_subkeys() -> Tuple[bytes, bytes]:
    """Derive independent encryption and MAC subkeys via domain-separated KDF labels."""
    master_key = _derive_smb_master_key()
    enc_key = hashlib.sha256(master_key + b":enc").digest()
    mac_key = hashlib.sha256(master_key + b":mac").digest()
    return enc_key, mac_key


def _smb_keystream(enc_key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        block = hashlib.sha256(enc_key + nonce + counter.to_bytes(4, "big")).digest()
        out.extend(block)
        counter += 1
    return bytes(out[:length])


def encrypt_smb_password(plain: str) -> str:
    """Encrypt SMB password using independent enc_key/mac_key + 16-byte nonce + HMAC tag (enc1:)."""
    if not plain:
        return ""
    enc_key, mac_key = _derive_smb_subkeys()
    nonce = secrets.token_bytes(16)
    plain_bytes = plain.encode("utf-8")
    stream = _smb_keystream(enc_key, nonce, len(plain_bytes))
    cipher = bytes(a ^ b for a, b in zip(plain_bytes, stream))
    mac = hmac.new(mac_key, nonce + cipher, hashlib.sha256).digest()[:16]
    payload = base64.urlsafe_b64encode(nonce + mac + cipher).decode("ascii")
    return f"enc1:{payload}"


def decrypt_smb_password(stored: str) -> str:
    """Decrypt enc1:-prefixed SMB password back to plaintext (supports legacy single-key payloads)."""
    if not stored or not isinstance(stored, str) or not stored.startswith("enc1:"):
        return ""
    try:
        raw = base64.urlsafe_b64decode(stored[5:].encode("ascii"))
        if len(raw) < 32:
            return ""
        nonce = raw[:16]
        mac = raw[16:32]
        cipher = raw[32:]
        enc_key, mac_key = _derive_smb_subkeys()
        expected_mac = hmac.new(mac_key, nonce + cipher, hashlib.sha256).digest()[:16]
        if hmac.compare_digest(mac, expected_mac):
            stream = _smb_keystream(enc_key, nonce, len(cipher))
            plain_bytes = bytes(a ^ b for a, b in zip(cipher, stream))
            return plain_bytes.decode("utf-8")

        legacy_key = _derive_smb_master_key()
        legacy_mac = hmac.new(legacy_key, nonce + cipher, hashlib.sha256).digest()[:16]
        if hmac.compare_digest(mac, legacy_mac):
            stream = _smb_keystream(legacy_key, nonce, len(cipher))
            plain_bytes = bytes(a ^ b for a, b in zip(cipher, stream))
            return plain_bytes.decode("utf-8")
        return ""
    except Exception:
        return ""


def hash_password(password: str, salt: bytes = None) -> str:
    """Hash password menggunakan PBKDF2-HMAC-SHA256 (100.000 iterasi)."""
    if not salt:
        salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
    return f"{salt.hex()}:{key.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verifikasi kecocokan password dengan hash tersimpan (timing-attack resistant)."""
    if not stored_hash or ":" not in stored_hash:
        return False
    try:
        salt_hex, key_hex = stored_hash.split(":", 1)
        salt = bytes.fromhex(salt_hex)
        key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
        return hmac.compare_digest(key.hex(), key_hex)
    except Exception:
        return False


def normalize_user_role(role: Optional[str]) -> str:
    """Menormalkan peran pengguna ke nilai kanonik ('admin', 'root', atau 'user')."""
    cleaned = str(role or "").strip().lower()
    if cleaned in ("admin", "root"):
        return cleaned
    return "user"


def _invalidate_user_cache(db_path: Optional[str] = None, user_id: Optional[int] = None, username: Optional[str] = None) -> None:
    resolved = _resolve_db_path(db_path)
    with _USER_CACHE_LOCK:
        if user_id is None and username is None:
            _USER_CACHE_BY_ID.clear()
            _USER_CACHE_BY_NAME.clear()
            return
        if user_id is not None:
            cached = _USER_CACHE_BY_ID.pop((resolved, int(user_id)), None)
            if cached and cached[1].get("username"):
                _USER_CACHE_BY_NAME.pop((resolved, str(cached[1]["username"]).strip().lower()), None)
        if username is not None:
            uname_key = str(username).strip().lower()
            cached = _USER_CACHE_BY_NAME.pop((resolved, uname_key), None)
            if cached and cached[1].get("id") is not None:
                _USER_CACHE_BY_ID.pop((resolved, int(cached[1]["id"])), None)


def encrypt_sensitive_secret(plain: Optional[str]) -> Optional[str]:
    """Mengenkripsi token/API key sensitif (idempoten jika sudah berprefix enc1:)."""
    if plain is None:
        return None
    s = str(plain)
    if not s or s.startswith("enc1:"):
        return s
    return encrypt_smb_password(s)


def decrypt_sensitive_secret(stored: Optional[str]) -> Optional[str]:
    """Mendekripsi token/API key berprefix enc1: atau mengembalikan plaintext legacy."""
    if stored is None:
        return None
    s = str(stored)
    if not s:
        return s
    if s.startswith("enc1:"):
        return decrypt_smb_password(s)
    return s


def get_user_by_username(username: str, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data lengkap pengguna berdasarkan username."""
    resolved = _resolve_db_path(db_path)
    uname_clean = str(username or "").strip().lower()
    if not uname_clean:
        return None
    with get_db(resolved) as conn:
        row = conn.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", (uname_clean,)).fetchone()
        if not row:
            return None
        res = dict(row)
        res["role"] = normalize_user_role(res.get("role"))
        res["token_version"] = int(res.get("token_version") or 1)
    return res


def get_user_by_id(user_id: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data lengkap pengguna berdasarkan user_id."""
    resolved = _resolve_db_path(db_path)
    with get_db(resolved) as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return None
        res = dict(row)
        res["role"] = normalize_user_role(res.get("role"))
        res["token_version"] = int(res.get("token_version") or 1)
    return res


def list_all_users(db_path: str = DB_PATH, include_unprovisioned: bool = False) -> List[Dict[str, Any]]:
    """Daftar seluruh pengguna terdaftar untuk manajemen akun administrator."""
    where_clause = (
        ""
        if include_unprovisioned
        else "WHERE (COALESCE(password_hash, '') != '' OR COALESCE(smb_password_enc, '') != '') "
    )
    with get_db(db_path) as conn:
        rows = conn.execute(
            f"SELECT id, username, role, allowed_disks, created_at FROM users {where_clause}ORDER BY id ASC"
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["role"] = normalize_user_role(d.get("role"))
            try:
                d["allowed_disks"] = json.loads(d["allowed_disks"]) if d.get("allowed_disks") else []
            except Exception:
                d["allowed_disks"] = []
            result.append(d)
        return result


def list_users_with_smb_secrets(
    db_path: str = DB_PATH, include_unprovisioned: bool = False
) -> List[Dict[str, Any]]:
    """Daftar internal pengguna beserta smb_password_enc untuk sinkronisasi Samba (jangan diekspos ke API publik)."""
    where_clause = (
        ""
        if include_unprovisioned
        else "WHERE (COALESCE(password_hash, '') != '' OR COALESCE(smb_password_enc, '') != '') "
    )
    with get_db(db_path) as conn:
        rows = conn.execute(
            f"SELECT id, username, role, allowed_disks, password_hash, smb_password_enc, created_at FROM users {where_clause}ORDER BY id ASC"
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["role"] = normalize_user_role(d.get("role"))
            try:
                d["allowed_disks"] = json.loads(d["allowed_disks"]) if d.get("allowed_disks") else []
            except Exception:
                d["allowed_disks"] = []
            result.append(d)
        return result


def create_or_update_user(
    username: str,
    password: Optional[str] = None,
    role: str = "user",
    allowed_disks: Optional[List[str]] = None,
    db_path: str = DB_PATH
) -> Dict[str, Any]:
    """Membuat pengguna baru atau memperbarui role/allowed_disks/password pengguna eksisting."""
    u_clean = username.strip().lower()
    norm_role = normalize_user_role(role)
    disks_json = json.dumps(allowed_disks if allowed_disks is not None else [])
    
    with get_db(db_path) as conn:
        existing = conn.execute("SELECT * FROM users WHERE LOWER(username) = ?", (u_clean,)).fetchone()
        if existing:
            updates = ["role = ?", "allowed_disks = ?"]
            params = [norm_role, disks_json]
            if password:
                pwd_h = hash_password(password)
                smb_enc = encrypt_smb_password(password)
                updates.append("password_hash = ?")
                params.append(pwd_h)
                updates.append("smb_password_enc = ?")
                params.append(smb_enc)
                updates.append("token_version = COALESCE(token_version, 1) + 1")
            params.append(existing["id"])
            conn.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", params)
            user_id = existing["id"]
        else:
            pwd_h = hash_password(password) if password else ""
            smb_enc = encrypt_smb_password(password) if password else ""
            cursor = conn.execute("""
                INSERT INTO users (username, password_hash, smb_password_enc, role, allowed_disks, token_version)
                VALUES (?, ?, ?, ?, ?, 1)
            """, (u_clean, pwd_h, smb_enc, norm_role, disks_json))
            user_id = cursor.lastrowid

        row = conn.execute("SELECT id, username, role, allowed_disks, created_at FROM users WHERE id = ?", (user_id,)).fetchone()
        res = dict(row)
        res["role"] = normalize_user_role(res.get("role"))
        try:
            res["allowed_disks"] = json.loads(res["allowed_disks"])
        except Exception:
            res["allowed_disks"] = []
    _invalidate_user_cache(db_path, user_id=user_id, username=u_clean)
    return res


def update_user_smb_password(username: str, password: str, db_path: str = DB_PATH) -> bool:
    """Memperbarui smb_password_enc pengguna untuk sinkronisasi Samba tanpa mengubah password_hash."""
    if not username or not password:
        return False
    u_clean = username.strip().lower()
    smb_enc = encrypt_smb_password(password)
    with get_db(db_path) as conn:
        cursor = conn.execute(
            "UPDATE users SET smb_password_enc = ? WHERE LOWER(username) = ?",
            (smb_enc, u_clean),
        )
        updated = cursor.rowcount > 0
    _invalidate_user_cache(db_path, username=u_clean)
    return updated


def bump_user_token_version(user_id: int, db_path: str = DB_PATH) -> int:
    """Menaikkan token_version pengguna agar seluruh JWT lama otomatis tercabut."""
    with get_db(db_path) as conn:
        conn.execute(
            "UPDATE users SET token_version = COALESCE(token_version, 1) + 1 WHERE id = ?",
            (int(user_id),),
        )
        row = conn.execute("SELECT token_version FROM users WHERE id = ?", (int(user_id),)).fetchone()
        new_ver = int(row["token_version"] or 1) if row else 1
    _invalidate_user_cache(db_path, user_id=user_id)
    return new_ver


def delete_user_by_id(user_id: int, db_path: str = DB_PATH) -> bool:
    """Menghapus akun pengguna dari database."""
    with get_db(db_path) as conn:
        cursor = conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        deleted = cursor.rowcount > 0
    _invalidate_user_cache(db_path, user_id=user_id)
    return deleted


def get_system_setting(key: str, default: str = "", db_path: str = DB_PATH) -> str:
    """Mengambil nilai pengaturan sistem dari tabel system_settings."""
    try:
        with get_db(db_path) as conn:
            row = conn.execute("SELECT value FROM system_settings WHERE key = ?", (key,)).fetchone()
            if row and row["value"] is not None:
                return str(row["value"])
    except Exception:
        pass
    return default


def set_system_setting(key: str, value: str, db_path: str = DB_PATH) -> None:
    """Menyimpan atau memperbarui nilai pengaturan sistem pada tabel system_settings."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO system_settings (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = CURRENT_TIMESTAMP
        """, (key, str(value)))


def has_password_configured_users(db_path: str = DB_PATH) -> bool:
    """Memeriksa apakah minimal 1 akun ber-password telah terdaftar di SQLite."""
    try:
        with get_db(db_path) as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS cnt FROM users WHERE TRIM(COALESCE(password_hash, '')) != ''"
            ).fetchone()
            return bool(row and int(row["cnt"]) > 0)
    except Exception:
        return False


# ==============================================================================
# DATA ACCESS HELPERS: CLOUD / GOOGLE DRIVE MULTI-ACCOUNT
# ==============================================================================

def create_or_update_cloud_account(
    user_id: int,
    email: str,
    provider: str = "gdrive",
    display_name: Optional[str] = None,
    access_token: Optional[str] = None,
    refresh_token: Optional[str] = None,
    token_expiry: Optional[str] = None,
    quota_total: int = 0,
    quota_used: int = 0,
    status: str = "connected",
    db_path: str = DB_PATH
) -> Dict[str, Any]:
    """Menyimpan atau memperbarui akun Google Drive / Cloud storage untuk user tertentu."""
    with get_db(db_path) as conn:
        existing = conn.execute(
            "SELECT id FROM cloud_accounts WHERE user_id = ? AND provider = ? AND LOWER(email) = ?",
            (user_id, provider, email.lower().strip())
        ).fetchone()

        enc_access = encrypt_sensitive_secret(access_token)
        enc_refresh = encrypt_sensitive_secret(refresh_token)
        if existing:
            account_id = existing["id"]
            conn.execute("""
                UPDATE cloud_accounts 
                SET display_name = COALESCE(?, display_name),
                    access_token = COALESCE(?, access_token),
                    refresh_token = COALESCE(?, refresh_token),
                    token_expiry = COALESCE(?, token_expiry),
                    quota_total = ?,
                    quota_used = ?,
                    status = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (display_name, enc_access, enc_refresh, token_expiry, quota_total, quota_used, status, account_id))
        else:
            cursor = conn.execute("""
                INSERT INTO cloud_accounts (
                    user_id, provider, email, display_name, access_token, refresh_token,
                    token_expiry, quota_total, quota_used, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, provider, email.lower().strip(), display_name or email, enc_access, enc_refresh,
                  token_expiry, quota_total, quota_used, status))
            account_id = cursor.lastrowid

        row = conn.execute("SELECT * FROM cloud_accounts WHERE id = ?", (account_id,)).fetchone()
        out = dict(row)
        out["access_token"] = decrypt_sensitive_secret(out.get("access_token"))
        out["refresh_token"] = decrypt_sensitive_secret(out.get("refresh_token"))
        return out


def get_cloud_accounts_by_user(user_id: int, provider: Optional[str] = None, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil daftar akun cloud storage milik seorang user."""
    with get_db(db_path) as conn:
        if provider:
            rows = conn.execute(
                "SELECT id, user_id, provider, email, display_name, quota_total, quota_used, status, created_at, updated_at "
                "FROM cloud_accounts WHERE user_id = ? AND provider = ? ORDER BY created_at ASC",
                (user_id, provider)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, user_id, provider, email, display_name, quota_total, quota_used, status, created_at, updated_at "
                "FROM cloud_accounts WHERE user_id = ? ORDER BY created_at ASC",
                (user_id,)
            ).fetchall()
        return [dict(r) for r in rows]


def get_cloud_account_by_id(account_id: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil detail akun cloud berdasarkan ID."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT * FROM cloud_accounts WHERE id = ?", (account_id,)).fetchone()
        if not row:
            return None
        out = dict(row)
        out["access_token"] = decrypt_sensitive_secret(out.get("access_token"))
        out["refresh_token"] = decrypt_sensitive_secret(out.get("refresh_token"))
        return out


def delete_cloud_account(account_id: int, user_id: Optional[int] = None, db_path: str = DB_PATH) -> bool:
    """Menghapus akun cloud storage."""
    with get_db(db_path) as conn:
        if user_id is not None:
            cursor = conn.execute("DELETE FROM cloud_accounts WHERE id = ? AND user_id = ?", (account_id, user_id))
        else:
            cursor = conn.execute("DELETE FROM cloud_accounts WHERE id = ?", (account_id,))
        return cursor.rowcount > 0


# ==============================================================================
# DATA ACCESS HELPERS
# ==============================================================================

def get_or_create_user(username: str, db_path: str = DB_PATH) -> int:
    """Mengambil atau membuat entri pengguna baru."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        if row:
            return row["id"]
        cursor = conn.execute("INSERT INTO users (username) VALUES (?)", (username,))
        return cursor.lastrowid


def upsert_device(device_id: str, user_id: int, device_name: str, device_type: str, app_version: str, db_path: str = DB_PATH) -> Dict[str, Any]:
    """Registrasi atau perbarui status perangkat klien."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO devices (device_id, user_id, device_name, device_type, app_version, last_seen)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(device_id) DO UPDATE SET
                user_id = excluded.user_id,
                device_name = excluded.device_name,
                device_type = excluded.device_type,
                app_version = excluded.app_version,
                last_seen = CURRENT_TIMESTAMP;
        """, (device_id, user_id, device_name, device_type, app_version))
        row = conn.execute("""
            SELECT d.*, u.username 
            FROM devices d 
            LEFT JOIN users u ON d.user_id = u.id 
            WHERE d.device_id = ?
        """, (device_id,)).fetchone()
        return dict(row) if row else {}


def update_device_heartbeat(device_id: str, db_path: str = DB_PATH) -> bool:
    """Perbarui waktu aktif perangkat terakhir."""
    with get_db(db_path) as conn:
        cursor = conn.execute("UPDATE devices SET last_seen = CURRENT_TIMESTAMP WHERE device_id = ?", (device_id,))
        return cursor.rowcount > 0


def upsert_task(task_id: str, device_id: str, task_name: str, target_folder: str, sync_mode: str = "one_way", username: str = "admin", db_path: str = DB_PATH) -> Dict[str, Any]:
    """Registrasi atau perbarui definisi tugas backup."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO backup_tasks (task_id, device_id, task_name, target_folder, sync_mode, username)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(task_id) DO UPDATE SET
                task_name = excluded.task_name,
                target_folder = excluded.target_folder,
                sync_mode = excluded.sync_mode,
                username = excluded.username;
        """, (task_id, device_id, task_name, target_folder, sync_mode, username))
        row = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
        return dict(row) if row else {}


def check_hashes_bulk(task_id: str, file_entries: List[Dict[str, Any]], db_path: str = DB_PATH) -> Dict[str, Any]:
    """
    Deduplikasi Cerdas: Membandingkan daftar hash berkas klien dengan yang ada di server.
    Mengembalikan daftar berkas yang sudah ada (skip) dan yang harus diunggah (needed).
    """
    with get_db(db_path) as conn:
        existing_rows = conn.execute(
            "SELECT relative_path, file_hash, file_size FROM files WHERE task_id = ? AND status = 'active'",
            (task_id,)
        ).fetchall()
        
        server_files = {row["relative_path"]: row["file_hash"] for row in existing_rows}
        
        needed = []
        up_to_date = []
        
        for entry in file_entries:
            rel_path = entry.get("relative_path")
            client_hash = entry.get("file_hash")
            
            if rel_path in server_files and server_files[rel_path] == client_hash:
                up_to_date.append(rel_path)
            else:
                needed.append(entry)
                
        return {
            "needed_files": needed,
            "existing_files": up_to_date,
            "total_checked": len(file_entries),
            "skipped_count": len(up_to_date)
        }


def create_upload_session(upload_id: str, task_id: str, relative_path: str, file_size: int, file_hash: str, total_chunks: int, db_path: str = DB_PATH) -> Dict[str, Any]:
    """Inisialisasi sesi unggah bertahap untuk berkas baru/berubah."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO upload_sessions (upload_id, task_id, relative_path, file_size, file_hash, total_chunks, status)
            VALUES (?, ?, ?, ?, ?, ?, 'uploading')
            ON CONFLICT(upload_id) DO UPDATE SET
                status = 'uploading',
                updated_at = CURRENT_TIMESTAMP;
        """, (upload_id, task_id, relative_path, file_size, file_hash, total_chunks))
        
        # Cari chunk yang sudah pernah terunggah jika sesi di-resume
        uploaded = conn.execute("SELECT chunk_index FROM chunks WHERE upload_id = ? AND is_uploaded = 1", (upload_id,)).fetchall()
        uploaded_indices = [r["chunk_index"] for r in uploaded]
        missing_indices = [i for i in range(total_chunks) if i not in uploaded_indices]
        
        return {
            "upload_id": upload_id,
            "total_chunks": total_chunks,
            "uploaded_chunks": uploaded_indices,
            "missing_chunks": missing_indices
        }


def save_chunk_record(upload_id: str, chunk_index: int, chunk_hash: str, chunk_size: int, db_path: str = DB_PATH) -> bool:
    """Mencatat potongan berkas yang berhasil diterima."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO chunks (upload_id, chunk_index, chunk_hash, chunk_size, is_uploaded)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(upload_id, chunk_index) DO UPDATE SET
                chunk_hash = excluded.chunk_hash,
                chunk_size = excluded.chunk_size,
                is_uploaded = 1;
        """, (upload_id, chunk_index, chunk_hash, chunk_size))
        
        conn.execute("""
            UPDATE upload_sessions
            SET chunks_received = (SELECT COUNT(*) FROM chunks WHERE upload_id = ? AND is_uploaded = 1),
                updated_at = CURRENT_TIMESTAMP
            WHERE upload_id = ?;
        """, (upload_id, upload_id))
        return True


def commit_file_record(upload_id: str, storage_path: str, modified_time: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Finalisasi berkas setelah seluruh chunk berhasil digabungkan."""
    with get_db(db_path) as conn:
        session = conn.execute("SELECT * FROM upload_sessions WHERE upload_id = ?", (upload_id,)).fetchone()
        if not session:
            return None
            
        task_id = session["task_id"]
        relative_path = session["relative_path"]
        file_size = session["file_size"]
        file_hash = session["file_hash"]
        
        # Simpan atau update berkas ke tabel files
        conn.execute("""
            INSERT INTO files (task_id, relative_path, file_size, file_hash, modified_time, storage_path, status, version, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'active', 1, CURRENT_TIMESTAMP)
            ON CONFLICT(task_id, relative_path) DO UPDATE SET
                file_size = excluded.file_size,
                file_hash = excluded.file_hash,
                modified_time = excluded.modified_time,
                storage_path = excluded.storage_path,
                status = 'active',
                version = files.version + 1,
                updated_at = CURRENT_TIMESTAMP;
        """, (task_id, relative_path, file_size, file_hash, modified_time, storage_path))
        
        # Tandai sesi selesai
        conn.execute("UPDATE upload_sessions SET status = 'completed', updated_at = CURRENT_TIMESTAMP WHERE upload_id = ?", (upload_id,))
        
        # Perbarui total file & byte pada task
        conn.execute("""
            UPDATE backup_tasks
            SET total_files = (SELECT COUNT(*) FROM files WHERE task_id = ? AND status = 'active'),
                total_bytes = (SELECT COALESCE(SUM(file_size), 0) FROM files WHERE task_id = ? AND status = 'active'),
                last_run = CURRENT_TIMESTAMP
            WHERE task_id = ?;
        """, (task_id, task_id, task_id))
        
        row = conn.execute("SELECT * FROM files WHERE task_id = ? AND relative_path = ?", (task_id, relative_path)).fetchone()
        return dict(row) if row else None


def log_activity(device_id: Optional[str], task_id: Optional[str], action: str, message: str, details: Optional[Dict[str, Any]] = None, db_path: str = DB_PATH):
    """Mencatat aktivitas dan riwayat transaksi ke database."""
    details_str = json.dumps(details or {})
    try:
        with get_db(db_path) as conn:
            conn.execute("""
                INSERT INTO activity_logs (device_id, task_id, action, message, details)
                VALUES (?, ?, ?, ?, ?)
            """, (device_id, task_id, action, message, details_str))
    except Exception as e:
        logger.error(f"Gagal mencatat log aktivitas: {e}")


_active_sessions: Dict[str, Dict[str, Any]] = {}
_sessions_lock = threading.Lock()


def track_session(session_id: str, username: str, path: str, client_ip: str, session_type: str = "stream") -> Dict[str, Any]:
    """Mencatat atau memperbarui sesi streaming/akses berkas aktif."""
    now_iso = datetime.utcnow().isoformat() + "Z"
    with _sessions_lock:
        if session_id in _active_sessions:
            _active_sessions[session_id]["last_active"] = now_iso
        else:
            _active_sessions[session_id] = {
                "session_id": session_id,
                "username": username or "anonymous",
                "path": path,
                "client_ip": client_ip or "unknown",
                "session_type": session_type,
                "started_at": now_iso,
                "last_active": now_iso
            }
        return dict(_active_sessions[session_id])


def get_active_sessions(timeout_seconds: int = 300) -> List[Dict[str, Any]]:
    """Mengambil daftar sesi aktif yang belum kedaluwarsa."""
    now = datetime.utcnow()
    with _sessions_lock:
        expired = []
        for sid, sess in _active_sessions.items():
            try:
                last_dt = datetime.fromisoformat(sess["last_active"].replace("Z", "+00:00")).replace(tzinfo=None)
                if (now - last_dt).total_seconds() > timeout_seconds:
                    expired.append(sid)
            except Exception:
                pass
        for sid in expired:
            _active_sessions.pop(sid, None)
        return list(_active_sessions.values())


def get_activity_logs(limit: int = 50, username: Optional[str] = None, action: Optional[str] = None, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil daftar riwayat log aktivitas dari database."""
    query = "SELECT * FROM activity_logs"
    params = []
    conditions = []
    if action:
        conditions.append("action LIKE ?")
        params.append(f"%{action}%")
    if username:
        conditions.append("(message LIKE ? OR details LIKE ?)")
        params.extend([f"%{username}%", f"%{username}%"])
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(max(1, min(limit, 500)))

    logs = []
    try:
        with get_db(db_path) as conn:
            rows = conn.execute(query, params).fetchall()
            for r in rows:
                item = dict(r)
                if item.get("details"):
                    try:
                        item["details"] = json.loads(item["details"])
                    except Exception:
                        pass
                logs.append(item)
    except Exception as e:
        logger.error(f"Gagal mengambil log aktivitas: {e}")
    return logs


# ==============================================================================
# 9. MANAGED VMS & 24/7 AUTOMATION DATA ACCESS METHODS (v1.4.1)
# ==============================================================================

import time as _time


def _resolve_runtime_limit_pair(vm: Dict[str, Any], snap: Optional[Dict[str, Any]] = None) -> tuple:
    """Mengembalikan pasangan (runtime_limit_hours, max_runtime_minutes) tanpa merusak nilai -1 (unlimited)."""
    snap_dict = snap if isinstance(snap, dict) else {}
    candidates_mrm = [
        (vm, "max_runtime_minutes", snap_dict.get("max_runtime_minutes")),
        (vm, "maxRuntimeMinutes", snap_dict.get("maxRuntimeMinutes")),
    ]
    candidates_rlh = [
        (vm, "runtime_limit_hours", snap_dict.get("runtime_limit_hours")),
    ]

    raw_mrm = None
    if snap_dict:
        for src, key, s_val in candidates_mrm:
            if key in src and src[key] is not None and src[key] != s_val:
                raw_mrm = src[key]
                break
    raw_rlh = None
    if snap_dict and raw_mrm is None:
        for src, key, s_val in candidates_rlh:
            if key in src and src[key] is not None and src[key] != s_val:
                raw_rlh = src[key]
                break

    if raw_mrm is None:
        if vm.get("max_runtime_minutes") is not None:
            raw_mrm = vm.get("max_runtime_minutes")
        elif vm.get("maxRuntimeMinutes") is not None:
            raw_mrm = vm.get("maxRuntimeMinutes")

    if raw_mrm is not None:
        try:
            mrm = int(raw_mrm)
            if mrm < 0:
                return -1, -1
            if mrm > 0:
                return max(1, mrm // 60), mrm
        except Exception:
            pass

    if raw_rlh is None:
        raw_rlh = vm.get("runtime_limit_hours")

    if raw_rlh is not None:
        try:
            rlh = int(raw_rlh)
            if rlh < 0:
                return -1, -1
            if rlh > 0:
                return rlh, rlh * 60
        except Exception:
            pass

    return 8, 480

_deleted_vms_tombstone: Dict[tuple, float] = {}
_deleted_vms_lock = threading.Lock()
_TOMBSTONE_TTL_SEC = 60.0


def is_vm_tombstoned(vm_id: str, db_path: str = DB_PATH) -> bool:
    """Mengecek apakah VM baru saja dihapus (mencegah zombie resurrection dari request paralel)."""
    key = (os.path.abspath(db_path), str(vm_id))
    now = _time.time()
    with _deleted_vms_lock:
        ts = _deleted_vms_tombstone.get(key)
        if ts is not None:
            if now - ts < _TOMBSTONE_TTL_SEC:
                return True
            _deleted_vms_tombstone.pop(key, None)
    return False


def clear_vm_tombstone(vm_id: str, db_path: str = DB_PATH) -> None:
    """Menghapus tombstone VM jika ingin dibuat ulang secara eksplisit."""
    key = (os.path.abspath(db_path), str(vm_id))
    with _deleted_vms_lock:
        _deleted_vms_tombstone.pop(key, None)


def _row_to_vm_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Helper untuk mengonversi row database managed_vms menjadi dict terstruktur."""
    item = dict(row)
    # Parse JSON fields
    if item.get("auto_on_days"):
        try:
            item["auto_on_days"] = json.loads(item["auto_on_days"])
        except Exception:
            item["auto_on_days"] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    else:
        item["auto_on_days"] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    if item.get("telemetry"):
        try:
            item["telemetry"] = json.loads(item["telemetry"])
        except Exception:
            item["telemetry"] = None

    # Cast boolean fields
    item["keep_alive_enabled"] = bool(item.get("keep_alive_enabled", 0))
    item["auto_on_enabled"] = bool(item.get("auto_on_enabled", 0))
    item["auto_restart_enabled"] = bool(item.get("auto_restart_enabled", 0))

    # v1.2.1+: Properti camelCase untuk kompatibilitas penuh MyServer Desktop Companion
    item["keepAliveEnabled"] = item["keep_alive_enabled"]
    item["autoOnEnabled"] = item["auto_on_enabled"]
    item["autoRestartEnabled"] = item["auto_restart_enabled"]
    item["api_key"] = decrypt_sensitive_secret(item.get("api_key"))
    item["apiKey"] = item.get("api_key")
    item["machineId"] = item.get("machine_id")
    item["sshHost"] = item.get("ssh_host")
    item["sshUser"] = item.get("ssh_user")
    item["sshPort"] = item.get("ssh_port")
    item["webPort"] = item.get("web_port")
    item["webUrl"] = item.get("web_url")
    item["screenUrl"] = item.get("screen_url")
    item["screenOpenTarget"] = item.get("screen_target")
    item["runtimeMinutes"] = int(item.get("runtime_minutes") or 0)
    limit_hours, max_runtime_mins = _resolve_runtime_limit_pair(item)
    item["runtime_limit_hours"] = limit_hours
    item["max_runtime_minutes"] = max_runtime_mins
    item["maxRuntimeMinutes"] = max_runtime_mins
    item["schedule_timezone"] = item.get("schedule_timezone") or ""
    item["scheduleTimezone"] = item["schedule_timezone"]
    item["tz_offset_minutes"] = item.get("tz_offset_minutes")
    item["tzOffsetMinutes"] = item["tz_offset_minutes"]

    delay_unit = item.get("auto_on_delay_unit") or "minutes"

    # Rekonstruksi struktur nested autoRestart & autoOn untuk sinkronisasi sempurna
    item["autoRestart"] = {
        "enabled": item["auto_restart_enabled"],
        "mode": item.get("auto_restart_mode", "interval"),
        "intervalValue": int(item.get("auto_restart_val") or 7),
        "intervalUnit": item.get("auto_restart_unit", "hours"),
        "clockTime": item.get("auto_restart_time", "03:00"),
        "resetCycleMode": item.get("smart_reset_cycle", "sleep_2s"),
    }
    item["autoOn"] = {
        "enabled": item["auto_on_enabled"],
        "mode": item.get("auto_on_mode", "clock"),
        "clockTime": item.get("auto_on_time", "07:00"),
        "delayValue": int(item.get("auto_on_delay_min") or 60),
        "delayUnit": delay_unit,
        "days": list(item.get("auto_on_days") or []),
    }

    # Snapshot nilai asli row agar shallow merge {**existing, **update_data}
    # dapat mendeteksi secara akurat field mana yang baru diubah (snake_case vs camelCase vs nested).
    item["_db_snapshot"] = {
        "keep_alive_enabled": item["keep_alive_enabled"],
        "keepAliveEnabled": item["keepAliveEnabled"],
        "auto_on_enabled": item["auto_on_enabled"],
        "autoOnEnabled": item["autoOnEnabled"],
        "auto_on_mode": item.get("auto_on_mode", "clock"),
        "auto_on_time": item.get("auto_on_time", "07:00"),
        "auto_on_delay_min": int(item.get("auto_on_delay_min") or 60),
        "auto_on_delay_unit": delay_unit,
        "auto_on_days": list(item.get("auto_on_days") or []),
        "auto_restart_enabled": item["auto_restart_enabled"],
        "autoRestartEnabled": item["autoRestartEnabled"],
        "auto_restart_mode": item.get("auto_restart_mode", "interval"),
        "auto_restart_val": int(item.get("auto_restart_val") or 7),
        "auto_restart_unit": item.get("auto_restart_unit", "hours"),
        "auto_restart_time": item.get("auto_restart_time", "03:00"),
        "smart_reset_cycle": item.get("smart_reset_cycle", "sleep_2s"),
        "autoRestart": dict(item["autoRestart"]),
        "autoOn": dict(item["autoOn"]),
        "runtime_minutes": item["runtimeMinutes"],
        "runtimeMinutes": item["runtimeMinutes"],
        "runtime_limit_hours": limit_hours,
        "max_runtime_minutes": max_runtime_mins,
        "maxRuntimeMinutes": max_runtime_mins,
        "schedule_timezone": item["schedule_timezone"],
        "scheduleTimezone": item["scheduleTimezone"],
        "tz_offset_minutes": item["tz_offset_minutes"],
        "tzOffsetMinutes": item["tzOffsetMinutes"],
    }
    return item


def get_all_managed_vms(db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil seluruh daftar VM yang dikelola oleh server ZimaOS."""
    vms = []
    try:
        with get_db(db_path) as conn:
            rows = conn.execute("SELECT * FROM managed_vms ORDER BY created_at ASC").fetchall()
            for r in rows:
                vid = r["id"]
                if is_vm_tombstoned(vid, db_path=db_path):
                    continue
                vms.append(_row_to_vm_dict(r))
    except Exception as e:
        logger.error(f"Gagal mengambil daftar VM: {e}")
    return vms


def get_managed_vm(vm_id: str, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data detail satu VM berdasarkan ID."""
    if is_vm_tombstoned(vm_id, db_path=db_path):
        return None
    try:
        with get_db(db_path) as conn:
            row = conn.execute("SELECT * FROM managed_vms WHERE id = ?", (vm_id,)).fetchone()
            if row:
                return _row_to_vm_dict(row)
    except Exception as e:
        logger.error(f"Gagal mengambil VM {vm_id}: {e}")
    return None


def _resolve_aliased_field(vm: Dict[str, Any], snap: Dict[str, Any], candidates: List[tuple], default: Any) -> Any:
    """
    Memilih nilai terbaru dari daftar kandidat (source_dict, key, snap_key).
    Jika vm memiliki _db_snapshot (hasil merge dengan existing), kandidat yang nilainya
    berubah dibanding snapshot diprioritaskan agar nilai lama di alias lain tidak menimpa update baru.
    """
    if snap:
        for src, key, snap_val in candidates:
            if isinstance(src, dict) and key in src and src[key] is not None:
                if src[key] != snap_val:
                    return src[key]
    for src, key, _ in candidates:
        if isinstance(src, dict) and key in src and src[key] is not None:
            return src[key]
    return default


def upsert_managed_vm(vm: Dict[str, Any], db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Menyimpan atau memperbarui data VM ke dalam database SQLite server."""
    vm_id = vm.get("id")
    if not vm_id:
        raise ValueError("VM ID wajib ada")

    # Cegah zombie resurrection jika ada request save in-flight untuk VM yang baru dihapus
    force_recreate = bool(vm.get("force_recreate") or vm.get("forceRecreate") or vm.get("_force_recreate"))
    if force_recreate:
        clear_vm_tombstone(vm_id, db_path=db_path)
    elif is_vm_tombstoned(vm_id, db_path=db_path):
        logger.info(f"[database] Mengabaikan upsert untuk VM {vm_id} karena berstatus tombstoned (baru dihapus).")
        return None

    snap = vm.get("_db_snapshot") if isinstance(vm.get("_db_snapshot"), dict) else {}
    snap_ar = snap.get("autoRestart") if isinstance(snap.get("autoRestart"), dict) else {}
    snap_ao = snap.get("autoOn") if isinstance(snap.get("autoOn"), dict) else {}

    # Ekstrak autoRestart nested jika ada
    ar = vm.get("autoRestart") if isinstance(vm.get("autoRestart"), dict) else {}
    ar_enabled = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_enabled", snap.get("auto_restart_enabled")),
            (vm, "autoRestartEnabled", snap.get("autoRestartEnabled")),
            (ar, "enabled", snap_ar.get("enabled")),
        ],
        False,
    ))
    ar_mode = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_mode", snap.get("auto_restart_mode")),
            (ar, "mode", snap_ar.get("mode")),
        ],
        "interval",
    ) or "interval")
    ar_val = int(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_val", snap.get("auto_restart_val")),
            (ar, "intervalValue", snap_ar.get("intervalValue")),
        ],
        7,
    ) or 7)
    ar_unit = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_unit", snap.get("auto_restart_unit")),
            (ar, "intervalUnit", snap_ar.get("intervalUnit")),
        ],
        "hours",
    ) or "hours")
    ar_time = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_time", snap.get("auto_restart_time")),
            (ar, "clockTime", snap_ar.get("clockTime")),
        ],
        "03:00",
    ) or "03:00")
    ar_cycle = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "smart_reset_cycle", snap.get("smart_reset_cycle")),
            (ar, "resetCycleMode", snap_ar.get("resetCycleMode")),
        ],
        "sleep_2s",
    ) or "sleep_2s")

    # Ekstrak autoOn nested jika ada
    ao = vm.get("autoOn") if isinstance(vm.get("autoOn"), dict) else {}
    ao_enabled = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_enabled", snap.get("auto_on_enabled")),
            (vm, "autoOnEnabled", snap.get("autoOnEnabled")),
            (ao, "enabled", snap_ao.get("enabled")),
        ],
        False,
    ))
    ao_mode = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_mode", snap.get("auto_on_mode")),
            (ao, "mode", snap_ao.get("mode")),
        ],
        "clock",
    ) or "clock")
    ao_time = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_time", snap.get("auto_on_time")),
            (ao, "clockTime", snap_ao.get("clockTime")),
        ],
        "07:00",
    ) or "07:00")
    ao_delay = int(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_delay_min", snap.get("auto_on_delay_min")),
            (ao, "delayValue", snap_ao.get("delayValue")),
        ],
        60,
    ) or 60)
    ao_delay_unit = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_delay_unit", snap.get("auto_on_delay_unit")),
            (ao, "delayUnit", snap_ao.get("delayUnit")),
        ],
        "minutes",
    ) or "minutes")

    # Konversi hari jika array integer [0, 1, 2, ...] atau string
    DAY_NUM_TO_STR = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}
    raw_days = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_days", snap.get("auto_on_days")),
            (ao, "days", snap_ao.get("days")),
        ],
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    )
    converted_days = []
    if isinstance(raw_days, list):
        for d in raw_days:
            if isinstance(d, int) and d in DAY_NUM_TO_STR:
                converted_days.append(DAY_NUM_TO_STR[d])
            elif str(d).strip().isdigit() and int(str(d).strip()) in DAY_NUM_TO_STR:
                converted_days.append(DAY_NUM_TO_STR[int(str(d).strip())])
            elif str(d).strip():
                converted_days.append(str(d).strip())
    if not converted_days:
        converted_days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    auto_on_days = json.dumps(converted_days)

    keep_alive = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "keep_alive_enabled", snap.get("keep_alive_enabled")),
            (vm, "keepAliveEnabled", snap.get("keepAliveEnabled")),
        ],
        False,
    ))
    api_key_val = encrypt_sensitive_secret(vm.get("api_key") or vm.get("apiKey"))
    machine_id_val = vm.get("machine_id") or vm.get("machineId")
    ssh_host_val = vm.get("ssh_host") or vm.get("sshHost") or ""
    ssh_port_val = int(vm.get("ssh_port") or vm.get("sshPort") or 22)
    ssh_user_val = vm.get("ssh_user") or vm.get("sshUser") or ""
    screen_url_val = vm.get("screen_url") or vm.get("screenUrl")
    screen_target_val = vm.get("screen_target") or vm.get("screenOpenTarget") or "ask"
    raw_runtime = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "runtime_minutes", snap.get("runtime_minutes")),
            (vm, "runtimeMinutes", snap.get("runtimeMinutes")),
        ],
        0,
    )
    runtime_mins_val = int(raw_runtime or 0)
    runtime_limit_val, max_runtime_val = _resolve_runtime_limit_pair(vm, snap)
    tz_name_val = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "schedule_timezone", snap.get("schedule_timezone")),
            (vm, "scheduleTimezone", snap.get("scheduleTimezone")),
            (vm, "timezone", snap.get("timezone")),
        ],
        "",
    ) or "").strip()
    raw_tz_offset = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "tz_offset_minutes", snap.get("tz_offset_minutes")),
            (vm, "tzOffsetMinutes", snap.get("tzOffsetMinutes")),
        ],
        None,
    )
    tz_offset_val = int(raw_tz_offset) if raw_tz_offset is not None and str(raw_tz_offset).strip() != "" else None
    reset_sleep_timer = (
        ao_enabled
        and ao_mode == "after_off"
        and (
            not bool(snap.get("auto_on_enabled"))
            or snap.get("auto_on_mode") != "after_off"
            or int(snap.get("auto_on_delay_min") or 60) != ao_delay
            or str(snap.get("auto_on_delay_unit") or "minutes") != ao_delay_unit
        )
    )

    telemetry = json.dumps(vm.get("telemetry")) if vm.get("telemetry") else None

    query = """
    INSERT INTO managed_vms (
        id, name, provider, status, ssh_host, ssh_port, ssh_user, token_expiry,
        web_port, web_url, screen_url, screen_target, api_key, machine_id,
        keep_alive_enabled, auto_on_enabled, auto_on_mode, auto_on_time, auto_on_delay_min, auto_on_delay_unit, auto_on_days,
        auto_restart_enabled, auto_restart_mode, auto_restart_val, auto_restart_unit, auto_restart_time,
        smart_reset_cycle, runtime_limit_hours, max_runtime_minutes, runtime_minutes, schedule_timezone, tz_offset_minutes, telemetry,
        last_wake_time, last_sleep_time, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?,
        CASE WHEN ? = 'running' THEN CURRENT_TIMESTAMP ELSE NULL END,
        CASE WHEN ? != 'running' THEN CURRENT_TIMESTAMP ELSE NULL END,
        CURRENT_TIMESTAMP
    )
    ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        provider = excluded.provider,
        status = excluded.status,
        ssh_host = CASE WHEN excluded.ssh_host != '' THEN excluded.ssh_host ELSE managed_vms.ssh_host END,
        ssh_port = excluded.ssh_port,
        ssh_user = CASE WHEN excluded.ssh_user != '' THEN excluded.ssh_user ELSE managed_vms.ssh_user END,
        token_expiry = excluded.token_expiry,
        web_port = COALESCE(excluded.web_port, managed_vms.web_port),
        web_url = COALESCE(excluded.web_url, managed_vms.web_url),
        screen_url = COALESCE(excluded.screen_url, managed_vms.screen_url),
        screen_target = excluded.screen_target,
        api_key = COALESCE(excluded.api_key, managed_vms.api_key),
        machine_id = COALESCE(excluded.machine_id, managed_vms.machine_id),
        keep_alive_enabled = excluded.keep_alive_enabled,
        auto_on_enabled = excluded.auto_on_enabled,
        auto_on_mode = excluded.auto_on_mode,
        auto_on_time = excluded.auto_on_time,
        auto_on_delay_min = excluded.auto_on_delay_min,
        auto_on_delay_unit = excluded.auto_on_delay_unit,
        auto_on_days = excluded.auto_on_days,
        auto_restart_enabled = excluded.auto_restart_enabled,
        auto_restart_mode = excluded.auto_restart_mode,
        auto_restart_val = excluded.auto_restart_val,
        auto_restart_unit = excluded.auto_restart_unit,
        auto_restart_time = excluded.auto_restart_time,
        smart_reset_cycle = excluded.smart_reset_cycle,
        runtime_limit_hours = excluded.runtime_limit_hours,
        max_runtime_minutes = COALESCE(excluded.max_runtime_minutes, managed_vms.max_runtime_minutes),
        runtime_minutes = CASE
            WHEN excluded.status != 'running' THEN 0
            WHEN excluded.runtime_minutes > 0 THEN excluded.runtime_minutes
            ELSE managed_vms.runtime_minutes
        END,
        schedule_timezone = CASE WHEN excluded.schedule_timezone != '' THEN excluded.schedule_timezone ELSE managed_vms.schedule_timezone END,
        tz_offset_minutes = COALESCE(excluded.tz_offset_minutes, managed_vms.tz_offset_minutes),
        last_wake_time = CASE
            WHEN excluded.status = 'running' AND (managed_vms.status != 'running' OR managed_vms.last_wake_time IS NULL) THEN CURRENT_TIMESTAMP
            ELSE managed_vms.last_wake_time
        END,
        last_sleep_time = CASE
            WHEN excluded.status != 'running' AND (managed_vms.status = 'running' OR managed_vms.last_sleep_time IS NULL OR ?) THEN CURRENT_TIMESTAMP
            ELSE managed_vms.last_sleep_time
        END,
        telemetry = COALESCE(excluded.telemetry, managed_vms.telemetry),
        updated_at = CURRENT_TIMESTAMP
    """

    status_val = str(vm.get("status", "sleeping") or "sleeping").lower()
    if status_val not in ("running", "sleeping", "stopped"):
        status_val = "sleeping"

    params = (
        vm_id,
        vm.get("name", "Unnamed VM"),
        vm.get("provider", "instabox"),
        status_val,
        ssh_host_val,
        ssh_port_val,
        ssh_user_val,
        vm.get("token_expiry", ""),
        vm.get("web_port") if vm.get("web_port") is not None else vm.get("webPort"),
        vm.get("web_url") if vm.get("web_url") is not None else vm.get("webUrl"),
        screen_url_val,
        screen_target_val,
        api_key_val,
        machine_id_val,
        1 if keep_alive else 0,
        1 if ao_enabled else 0,
        ao_mode,
        ao_time,
        ao_delay,
        ao_delay_unit,
        auto_on_days,
        1 if ar_enabled else 0,
        ar_mode,
        ar_val,
        ar_unit,
        ar_time,
        ar_cycle,
        runtime_limit_val,
        max_runtime_val,
        runtime_mins_val,
        tz_name_val,
        tz_offset_val,
        telemetry,
        status_val,
        status_val,
        1 if reset_sleep_timer else 0,
    )

    with get_db(db_path) as conn:
        conn.execute(query, params)

    return get_managed_vm(vm_id, db_path=db_path)


def delete_managed_vm(vm_id: str, db_path: str = DB_PATH) -> bool:
    """Menghapus data VM dari database server dan mencatat tombstone anti-zombie."""
    key = (os.path.abspath(db_path), str(vm_id))
    with _deleted_vms_lock:
        _deleted_vms_tombstone[key] = _time.time()
    try:
        with get_db(db_path) as conn:
            cur = conn.execute("DELETE FROM managed_vms WHERE id = ?", (vm_id,))
            return cur.rowcount > 0
    except Exception as e:
        logger.error(f"Gagal menghapus VM {vm_id}: {e}")
        return False


def update_vm_runtime_and_status(
    vm_id: str,
    status: Optional[str] = None,
    runtime_minutes: Optional[int] = None,
    telemetry: Optional[dict] = None,
    machine_id: Optional[str] = None,
    ssh_host: Optional[str] = None,
    ssh_port: Optional[int] = None,
    ssh_user: Optional[str] = None,
    runtime_limit_hours: Optional[int] = None,
    max_runtime_minutes: Optional[int] = None,
    mark_reset: bool = False,
    db_path: str = DB_PATH
) -> bool:
    """Memperbarui status runtime, waktu aktif, metrik telemetri, dan koneksi VM."""
    if is_vm_tombstoned(vm_id, db_path=db_path):
        return False

    sets = ["updated_at = CURRENT_TIMESTAMP"]
    params = []

    if status is not None:
        if status == "running":
            sets.append("last_wake_time = CASE WHEN status != 'running' OR last_wake_time IS NULL THEN CURRENT_TIMESTAMP ELSE last_wake_time END")
        elif status in ("sleeping", "stopped"):
            sets.append("last_sleep_time = CASE WHEN status NOT IN ('sleeping', 'stopped') OR last_sleep_time IS NULL THEN CURRENT_TIMESTAMP ELSE last_sleep_time END")
        sets.append("status = ?")
        params.append(status)

    if mark_reset:
        sets.append("last_reset_time = CURRENT_TIMESTAMP")

    if runtime_minutes is not None:
        sets.append("runtime_minutes = ?")
        params.append(runtime_minutes)
        sets.append("last_runtime_check = CURRENT_TIMESTAMP")

    if telemetry is not None:
        sets.append("telemetry = ?")
        params.append(json.dumps(telemetry))

    if machine_id:
        sets.append("machine_id = ?")
        params.append(machine_id)

    if ssh_host:
        sets.append("ssh_host = ?")
        params.append(ssh_host)

    if ssh_port:
        sets.append("ssh_port = ?")
        params.append(int(ssh_port))

    if ssh_user:
        sets.append("ssh_user = ?")
        params.append(ssh_user)

    if runtime_limit_hours is not None:
        sets.append("runtime_limit_hours = ?")
        params.append(int(runtime_limit_hours))

    if max_runtime_minutes is not None:
        sets.append("max_runtime_minutes = ?")
        params.append(int(max_runtime_minutes))

    params.append(vm_id)
    query = f"UPDATE managed_vms SET {', '.join(sets)} WHERE id = ?"

    try:
        with get_db(db_path) as conn:
            cur = conn.execute(query, params)
            return cur.rowcount > 0
    except Exception as e:
        logger.error(f"Gagal memperbarui status VM {vm_id}: {e}")
        return False


# ==============================================================================
# 11. PUBLIC SHARE LINKS DATA ACCESS METHODS (SHL-01)
# ==============================================================================

def generate_share_token() -> str:
    """Menghasilkan token berbagi publik URL-safe 24 karakter (144-bit entropy)."""
    return secrets.token_urlsafe(18)


def get_public_base_url(db_path: str = DB_PATH) -> str:
    """Mengambil pengaturan domain/URL publik (public_base_url) dari system_settings."""
    raw = get_system_setting("public_base_url", "", db_path=db_path)
    return str(raw or "").strip().rstrip("/")


def set_public_base_url(url: str, db_path: str = DB_PATH) -> str:
    """Memvalidasi dan menyimpan pengaturan public_base_url ke system_settings."""
    clean = str(url or "").strip().rstrip("/")
    if clean:
        lower = clean.lower()
        if not (lower.startswith("http://") or lower.startswith("https://")):
            raise ValueError("Format Public Base URL tidak valid. Gunakan awalan http:// atau https://.")
        if any(ch in clean for ch in ("<", ">", '"', "'", "\r", "\n")) or any(ch.isspace() for ch in clean):
            raise ValueError("Format Public Base URL tidak valid. Gunakan awalan http:// atau https://.")
    set_system_setting("public_base_url", clean, db_path=db_path)
    return clean


def is_share_expired(expires_at: Optional[str]) -> bool:
    """Memeriksa apakah waktu kedaluwarsa tautan publik (ISO-8601 UTC) telah terlewati."""
    if not expires_at:
        return False
    raw = str(expires_at).strip()
    if not raw:
        return False
    try:
        iso_str = raw[:-1] + "+00:00" if raw.endswith("Z") else raw
        dt = datetime.fromisoformat(iso_str)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return datetime.now(timezone.utc).replace(tzinfo=None) >= dt
    except Exception:
        return True


def _format_share_row(
    row: sqlite3.Row,
    public_base_url: str = "",
    include_secret: bool = False,
) -> Dict[str, Any]:
    """Mengonversi baris public_shares menjadi dict respons terstruktur."""
    token = str(row["token"])
    target_path = str(row["target_path"] or "")
    raw_label = str(row["label"] or "").strip()
    label = raw_label or os.path.basename(target_path.rstrip("/")) or target_path
    revoked = bool(row["revoked"])
    expires_at = row["expires_at"]
    expired = is_share_expired(expires_at)
    status = "revoked" if revoked else ("expired" if expired else "active")
    pwd_hash = str(row["password_hash"] or "").strip()
    pub_base = str(public_base_url or "").strip().rstrip("/")
    share_path = f"/s/{token}"
    share_url = f"{pub_base}{share_path}" if pub_base else share_path

    res: Dict[str, Any] = {
        "token": token,
        "owner_user_id": row["owner_user_id"],
        "owner_username": str(row["owner_username"] or ""),
        "target_path": target_path,
        "is_dir": bool(row["is_dir"]),
        "label": label,
        "expires_at": expires_at,
        "revoked": revoked,
        "is_expired": expired,
        "status": status,
        "password_protected": bool(pwd_hash),
        "download_count": int(row["download_count"] or 0),
        "created_at": str(row["created_at"] or ""),
        "share_path": share_path,
        "public_base_url": pub_base,
        "share_url": share_url,
    }
    if include_secret:
        res["password_hash"] = row["password_hash"]
    return res


def create_public_share(
    owner_username: str,
    target_path: str,
    is_dir: bool = False,
    owner_user_id: Optional[int] = None,
    label: Optional[str] = None,
    expires_at: Optional[str] = None,
    password: Optional[str] = None,
    token: Optional[str] = None,
    db_path: str = DB_PATH,
) -> Dict[str, Any]:
    """Membuat entri tautan berbagi publik baru di tabel public_shares."""
    clean_path = str(target_path or "").strip().replace("\\", "/").strip("/")
    if not clean_path:
        raise ValueError("Path berkas atau folder tidak boleh kosong.")
    clean_owner = str(owner_username or "").strip().lower()
    if not clean_owner:
        raise ValueError("Owner username tidak boleh kosong.")

    share_token = str(token or "").strip() or generate_share_token()
    clean_label = str(label or "").strip() or os.path.basename(clean_path) or clean_path
    clean_expires = str(expires_at).strip() if (expires_at and str(expires_at).strip()) else None
    pwd_hash = hash_password(str(password)) if (password and str(password).strip()) else None

    with get_db(db_path) as conn:
        conn.execute(
            """
            INSERT INTO public_shares (
                token, owner_user_id, owner_username, target_path,
                is_dir, label, expires_at, password_hash, revoked, download_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0)
            """,
            (
                share_token,
                owner_user_id,
                clean_owner,
                clean_path,
                1 if is_dir else 0,
                clean_label,
                clean_expires,
                pwd_hash,
            ),
        )
    rec = get_public_share(share_token, db_path=db_path, include_secret=False)
    if not rec:
        raise RuntimeError("Gagal membaca tautan berbagi yang baru dibuat.")
    return rec


def get_public_share(
    token: str,
    db_path: str = DB_PATH,
    include_secret: bool = False,
) -> Optional[Dict[str, Any]]:
    """Mengambil detail satu tautan berbagi publik berdasarkan token."""
    clean_token = str(token or "").strip()
    if not clean_token:
        return None
    pub_base = get_public_base_url(db_path=db_path)
    with get_db(db_path) as conn:
        row = conn.execute(
            "SELECT * FROM public_shares WHERE token = ?",
            (clean_token,),
        ).fetchone()
        if not row:
            return None
        return _format_share_row(row, public_base_url=pub_base, include_secret=include_secret)


def list_public_shares(
    owner_username: Optional[str] = None,
    is_admin: bool = False,
    include_revoked: bool = False,
    db_path: str = DB_PATH,
) -> List[Dict[str, Any]]:
    """Mengambil daftar tautan berbagi publik (milik user atau seluruhnya untuk admin)."""
    pub_base = get_public_base_url(db_path=db_path)
    conditions: List[str] = []
    params: List[Any] = []
    if not is_admin and owner_username:
        conditions.append("LOWER(owner_username) = LOWER(?)")
        params.append(str(owner_username).strip())
    if not include_revoked:
        conditions.append("COALESCE(revoked, 0) = 0")

    where_sql = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    query = f"SELECT * FROM public_shares {where_sql} ORDER BY created_at DESC, rowid DESC"
    with get_db(db_path) as conn:
        rows = conn.execute(query, params).fetchall()
        return [_format_share_row(r, public_base_url=pub_base, include_secret=False) for r in rows]


def revoke_public_share(
    token: str,
    requester_username: str,
    is_admin: bool = False,
    db_path: str = DB_PATH,
) -> Tuple[bool, str]:
    """Mencabut tautan berbagi publik (hanya pemilik atau administrator)."""
    clean_token = str(token or "").strip()
    if not clean_token:
        return False, "not_found"
    req_u = str(requester_username or "").strip().lower()
    with get_db(db_path) as conn:
        row = conn.execute(
            "SELECT token, owner_username, revoked FROM public_shares WHERE token = ?",
            (clean_token,),
        ).fetchone()
        if not row:
            return False, "not_found"
        owner_u = str(row["owner_username"] or "").strip().lower()
        if not is_admin and owner_u != req_u:
            return False, "forbidden"
        conn.execute(
            "UPDATE public_shares SET revoked = 1 WHERE token = ?",
            (clean_token,),
        )
    return True, "revoked"


def increment_share_download_count(token: str, db_path: str = DB_PATH) -> int:
    """Menambah penghitung unduhan (download_count) secara atomik dan mengembalikan nilai terbaru."""
    clean_token = str(token or "").strip()
    if not clean_token:
        return 0
    with get_db(db_path) as conn:
        conn.execute(
            "UPDATE public_shares SET download_count = COALESCE(download_count, 0) + 1 WHERE token = ?",
            (clean_token,),
        )
        row = conn.execute(
            "SELECT download_count FROM public_shares WHERE token = ?",
            (clean_token,),
        ).fetchone()
        return int(row["download_count"] or 0) if row else 0


def cleanup_database_retention(
    db_path: str = DB_PATH,
    log_max_age_days: int = 30,
    upload_max_age_hours: int = 24,
) -> Dict[str, int]:
    """Memangkas baris usang activity_logs, upload_sessions/chunks tak selesai, dan _active_sessions."""
    log_cutoff = (datetime.now(timezone.utc) - timedelta(days=max(1, int(log_max_age_days)))).strftime("%Y-%m-%d %H:%M:%S")
    upload_cutoff = (datetime.now(timezone.utc) - timedelta(hours=max(1, int(upload_max_age_hours)))).strftime("%Y-%m-%d %H:%M:%S")
    deleted_logs = 0
    deleted_sessions = 0
    with get_db(db_path) as conn:
        cur1 = conn.execute("DELETE FROM activity_logs WHERE timestamp < ?", (log_cutoff,))
        deleted_logs = int(cur1.rowcount or 0)
        cur2 = conn.execute(
            "DELETE FROM upload_sessions WHERE status != 'committed' AND created_at < ?",
            (upload_cutoff,),
        )
        deleted_sessions = int(cur2.rowcount or 0)
    pruned_mem_sessions = 0
    cutoff_mem = datetime.now(timezone.utc).timestamp() - 900.0
    for sid in list(_active_sessions.keys()):
        try:
            if float(_active_sessions[sid].get("last_seen", 0)) < cutoff_mem:
                _active_sessions.pop(sid, None)
                pruned_mem_sessions += 1
        except Exception:
            pass
    return {
        "deleted_logs": deleted_logs,
        "deleted_upload_sessions": deleted_sessions,
        "pruned_active_sessions": pruned_mem_sessions,
    }


def backup_sqlite_database(
    dest_dir: Optional[str] = None,
    db_path: str = DB_PATH,
    keep_backups: int = 3,
) -> str:
    """Melakukan online hot-backup SQLite menggunakan Connection.backup() dan merotasi arsip lama."""
    resolved = _resolve_db_path(db_path)
    target_dir = dest_dir or os.path.join(os.path.dirname(os.path.abspath(resolved)), "db_backups")
    os.makedirs(target_dir, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    tmp_path = os.path.join(target_dir, f".backup_{ts}.db.tmp")
    final_path = os.path.join(target_dir, f"backup_meta_{ts}.db")
    src_conn = sqlite3.connect(resolved, timeout=15.0)
    dst_conn = sqlite3.connect(tmp_path, timeout=15.0)
    try:
        src_conn.backup(dst_conn)
        dst_conn.commit()
    finally:
        dst_conn.close()
        src_conn.close()
    os.replace(tmp_path, final_path)

    backups = sorted(
        [
            os.path.join(target_dir, fn)
            for fn in os.listdir(target_dir)
            if fn.startswith("backup_meta_") and fn.endswith(".db")
        ],
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )
    for stale in backups[max(1, int(keep_backups)):]:
        try:
            os.remove(stale)
        except OSError:
            pass
    return final_path





