"""
Authentication Router for MyServer Native Backend
Secure Multi-Tier Authentication with Local ZimaOS Password Forwarding
"""

import json
import logging
import os
import threading
import urllib.request
import urllib.error
from typing import Optional, Tuple, Dict, Any, List
from app.auth import create_access_token, get_current_user, HTTPException, status
from app.config import is_admin_username
try:
    from fastapi import APIRouter, Depends
except ImportError:
    Depends = lambda fn=None: fn
    class APIRouter:
        def __init__(self, **kw): pass
        def get(self, *a, **kw): return lambda f: f
        def post(self, *a, **kw): return lambda f: f
        def put(self, *a, **kw): return lambda f: f
        def delete(self, *a, **kw): return lambda f: f
try:
    from app.models import (
        AuthVerifyRequest, AuthResponse,
        UserCreateRequest, UserUpdateRequest, UserItemResponse, UserListResponse,
        BootstrapStatusResponse, BootstrapAdminRequest,
    )
except ImportError:
    class _SimpleModel:
        def __init__(self, **kw):
            self.username = kw.get("username", "")
            self.password = kw.get("password")
            self.zimaos_token = kw.get("zimaos_token")
            self.role = kw.get("role", "staff")
            self.allowed_disks = kw.get("allowed_disks", [])
            for k, v in kw.items():
                setattr(self, k, v)
    AuthVerifyRequest = AuthResponse = UserCreateRequest = UserUpdateRequest = UserItemResponse = UserListResponse = BootstrapStatusResponse = BootstrapAdminRequest = _SimpleModel
from app.database import (
    get_or_create_user, get_user_by_username, get_user_by_id, list_all_users,
    create_or_update_user, update_user_smb_password, delete_user_by_id,
    verify_password, log_activity, has_password_configured_users, decrypt_smb_password,
)
from app.config import JWT_EXPIRE_HOURS
from app.services.smb_manager import (
    sync_unix_and_samba_user,
    sync_samba_configuration,
    remove_unix_and_samba_user,
    validate_smb_username,
)

logger = logging.getLogger("myserver.auth")
router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])
_BOOTSTRAP_LOCK = threading.Lock()


@router.get("/bootstrap-status", response_model=BootstrapStatusResponse)
def get_bootstrap_status():
    """Memeriksa apakah server memerlukan inisialisasi akun admin pertama (first-run bootstrap)."""
    return BootstrapStatusResponse(
        needs_bootstrap=not has_password_configured_users(),
        total_users=len(list_all_users()),
    )


@router.post("/bootstrap", response_model=AuthResponse)
def bootstrap_admin(req: BootstrapAdminRequest):
    """
    Membuat akun administrator pertama saat database belum memiliki akun ber-password.
    Terkunci atomik (HTTP 403 Forbidden) segera setelah minimal 1 user ber-password terdaftar.
    """
    with _BOOTSTRAP_LOCK:
        if has_password_configured_users():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bootstrap admin sudah terkunci karena akun telah terdaftar.",
            )

        try:
            u_clean = validate_smb_username(getattr(req, "username", "") or "")
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            )

        password = getattr(req, "password", None) or ""
        if len(password) < 4:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kata sandi admin minimal 4 karakter.",
            )

        created = create_or_update_user(
            username=u_clean,
            password=password,
            role="admin",
            allowed_disks=[],
        )
        try:
            sync_unix_and_samba_user(u_clean, password=password, uid_hint=created["id"])
            sync_samba_configuration()
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba pasca-bootstrap gagal (non-fatal): {exc}")

    token = create_access_token(u_clean, created["id"], role="admin")
    log_activity(
        device_id=None,
        task_id=None,
        action="ADMIN_BOOTSTRAPPED",
        message=f"Akun administrator pertama '{u_clean}' berhasil dibuat via bootstrap.",
        details={"user_id": created["id"], "role": "admin"},
    )
    return AuthResponse(
        success=True,
        access_token=token,
        token_type="bearer",
        user_id=created["id"],
        username=u_clean,
        expires_in_hours=JWT_EXPIRE_HOURS,
        role="admin",
        allowed_disks=[],
    )

ZIMAOS_LOGIN_CANDIDATES = [
    "http://172.17.0.1:80/v1/users/login",
    "http://127.0.0.1:80/v1/users/login",
    "http://localhost:80/v1/users/login",
]


def verify_with_zimaos(username: str, password: str) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
    """
    Verifikasi username & password langsung ke daemon ZimaOS lokal (Port 80).
    Returns: (is_valid, error_detail, user_info)
    """
    payload = json.dumps({"username": username, "password": password}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "MyServer-Backend-Gateway/1.1.0"
    }

    connected_at_least_once = False
    for url in ZIMAOS_LOGIN_CANDIDATES:
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                connected_at_least_once = True
                if resp.status in (200, 201):
                    res_data = json.loads(resp.read().decode("utf-8"))
                    return True, None, res_data
        except urllib.error.HTTPError as e:
            connected_at_least_once = True
            err_body = e.read().decode("utf-8", errors="ignore")
            logger.warning(f"ZimaOS menolak login pengguna '{username}' (HTTP {e.code}): {err_body}")
            return False, "Nama pengguna atau kata sandi tidak valid.", None
        except Exception:
            # Gagal konek ke URL kandidat ini, coba kandidat berikutnya
            continue

    if not connected_at_least_once:
        if os.getenv("MYSERVER_DEV_MODE", "").lower() in ("1", "true", "yes"):
            logger.info("Host ZimaOS port 80 tidak dapat dihubungi (MYSERVER_DEV_MODE aktif). Mengizinkan login dev.")
            return True, None, {"dev_mode": True}
        return False, "Daemon ZimaOS lokal (port 80) tidak dapat dihubungi untuk verifikasi kata sandi.", None

    return False, "Gagal memverifikasi akun ke daemon ZimaOS.", None


@router.post("/verify", response_model=AuthResponse)
@router.post("/login-app", response_model=AuthResponse)
def verify_auth(req: AuthVerifyRequest):
    """
    Verifikasi autentikasi multi-tier mandiri:
    1. Cek database SQLite lokal (mendukung unlimited user & staff mandiri).
    2. Fallback verifikasi ke daemon ZimaOS lokal (port 80) jika belum terdaftar lokal.
    """
    if not req.username or not req.username.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username tidak boleh kosong"
        )

    username = req.username.strip().lower()
    user_rec = get_user_by_username(username)
    role = "staff"
    allowed_disks = []
    authenticated = False

    # 1. Cek apakah pengguna memiliki kredensial lokal di database SQLite MyServer
    if user_rec and user_rec.get("password_hash"):
        if req.password and verify_password(req.password, user_rec["password_hash"]):
            authenticated = True
            role = user_rec.get("role", "staff")
            try:
                allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
            except Exception:
                allowed_disks = []
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Nama pengguna atau kata sandi tidak valid."
            )
    else:
        # 2. Fallback: Verifikasi kata sandi ke backend ZimaOS lokal (port 80)
        if req.password:
            is_valid, err_msg, z_info = verify_with_zimaos(username, req.password)
            if not is_valid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=err_msg or "Nama pengguna atau kata sandi tidak valid."
                )
            authenticated = True
            if is_admin_username(username):
                role = "admin"
        elif req.zimaos_token:
            authenticated = True
            if is_admin_username(username):
                role = "admin"
        else:
            logger.warning(f"Request verify ditolak: tanpa password/token untuk pengguna '{username}'")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kata sandi atau token autentikasi wajib diisi."
            )

    user_id = user_rec["id"] if user_rec else get_or_create_user(username)
    if user_rec and not user_rec.get("password_hash"):
        if user_rec.get("role"):
            role = user_rec.get("role", role)
        try:
            allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            allowed_disks = []

    if req.password:
        try:
            existing_enc = user_rec.get("smb_password_enc", "") if user_rec else ""
            if not existing_enc or decrypt_smb_password(existing_enc) != req.password:
                update_user_smb_password(username, req.password)
            sync_unix_and_samba_user(username, password=req.password, uid_hint=user_id)
            sync_samba_configuration()
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba saat login '{username}' gagal (non-fatal): {exc}")

    token = create_access_token(username, user_id, role=role)

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_AUTHENTICATED",
        message=f"Pengguna '{username}' (role: {role}) berhasil diautentikasi.",
        details={"user_id": user_id, "role": role}
    )

    return AuthResponse(
        success=True,
        access_token=token,
        token_type="bearer",
        user_id=user_id,
        username=username,
        expires_in_hours=JWT_EXPIRE_HOURS,
        role=role,
        allowed_disks=allowed_disks
    )


def _require_admin_user(current_user: Any, error_detail: str) -> str:
    if not isinstance(current_user, dict):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Autentikasi JWT diperlukan.",
        )
    sub = str(current_user.get("sub") or "").strip().lower()
    caller_rec = get_user_by_username(sub) if sub else None
    eff_role = str(
        (caller_rec.get("role") if caller_rec else None)
        or current_user.get("role")
        or "staff"
    ).strip().lower()
    if eff_role not in ("admin", "root") and not is_admin_username(sub):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=error_detail,
        )
    return sub


@router.get("/me")
def get_my_profile(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil informasi profil akun yang sedang login."""
    if not isinstance(current_user, dict):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Autentikasi JWT diperlukan.")
    username = current_user.get("sub", "")
    user_rec = get_user_by_username(username)
    role = current_user.get("role", "staff")
    allowed_disks = []
    if user_rec:
        role = user_rec.get("role", role)
        try:
            allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            allowed_disks = []

    return {
        "status": "ok",
        "username": username,
        "user_id": current_user.get("uid"),
        "role": role,
        "is_admin": role in ("admin", "root") or is_admin_username(username),
        "allowed_disks": allowed_disks
    }


# ==============================================================================
# ADMIN USER MANAGEMENT ENDPOINTS
# ==============================================================================

@router.get("/users", response_model=UserListResponse)
def get_users_list(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil seluruh daftar akun pengguna (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan mengelola daftar pengguna.")

    users = list_all_users()
    items = []
    for u in users:
        items.append(UserItemResponse(
            id=u["id"],
            username=u["username"],
            role=u["role"],
            allowed_disks=u["allowed_disks"],
            created_at=str(u.get("created_at") or "")
        ))

    return UserListResponse(users=items, total=len(items))


@router.post("/users", response_model=UserItemResponse)
def create_new_user(req: UserCreateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Membuat akun pengguna/staff baru dengan filter allowed_disks (Hanya Administrator)."""
    admin_sub = _require_admin_user(current_user, "Hanya administrator yang diizinkan membuat pengguna baru.")

    try:
        u_clean = validate_smb_username(req.username or "")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    existing = get_user_by_username(u_clean)
    if existing and existing.get("password_hash"):
        raise HTTPException(status_code=400, detail=f"Pengguna '{u_clean}' sudah terdaftar.")

    created = create_or_update_user(
        username=u_clean,
        password=req.password,
        role=req.role or "staff",
        allowed_disks=req.allowed_disks or []
    )
    try:
        if req.password:
            sync_unix_and_samba_user(u_clean, password=req.password, uid_hint=created["id"])
        sync_samba_configuration()
    except Exception as exc:
        logger.warning(f"Sinkronisasi Samba setelah membuat user '{u_clean}' gagal: {exc}")

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_CREATED",
        message=f"Administrator '{admin_sub}' membuat akun '{u_clean}' (role: {req.role}).",
        details={"created_user": u_clean, "allowed_disks": req.allowed_disks}
    )

    return UserItemResponse(
        id=created["id"],
        username=created["username"],
        role=created["role"],
        allowed_disks=created["allowed_disks"],
        created_at=str(created.get("created_at") or "")
    )


@router.put("/users/{user_id}", response_model=UserItemResponse)
def update_user_details(user_id: int, req: UserUpdateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memperbarui role, allowed_disks, atau password akun pengguna (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan mengedit pengguna.")

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    role_to_set = req.role if req.role is not None else user_rec.get("role", "staff")
    disks_to_set = req.allowed_disks
    if disks_to_set is None:
        try:
            disks_to_set = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            disks_to_set = []

    updated = create_or_update_user(
        username=user_rec["username"],
        password=req.password,
        role=role_to_set,
        allowed_disks=disks_to_set
    )
    try:
        if req.password:
            sync_unix_and_samba_user(updated["username"], password=req.password, uid_hint=updated["id"])
        sync_samba_configuration()
    except Exception as exc:
        logger.warning(f"Sinkronisasi Samba setelah memperbarui user '{updated['username']}' gagal: {exc}")

    return UserItemResponse(
        id=updated["id"],
        username=updated["username"],
        role=updated["role"],
        allowed_disks=updated["allowed_disks"],
        created_at=str(updated.get("created_at") or "")
    )


@router.delete("/users/{user_id}")
def delete_user_account(user_id: int, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Menghapus akun pengguna dari database (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan menghapus pengguna.")

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    if is_admin_username(user_rec["username"]):
        raise HTTPException(status_code=400, detail="Akun administrator utama tidak dapat dihapus.")

    success = delete_user_by_id(user_id)
    if success:
        try:
            remove_unix_and_samba_user(user_rec["username"])
            sync_samba_configuration()
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba setelah menghapus user '{user_rec['username']}' gagal: {exc}")
    return {"status": "ok", "message": f"Pengguna '{user_rec['username']}' berhasil dihapus."}
