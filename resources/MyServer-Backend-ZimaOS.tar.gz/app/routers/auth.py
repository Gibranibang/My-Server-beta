"""
Authentication Router for MyServer Native Backend
Secure Multi-Tier Authentication with Local ZimaOS Password Forwarding
"""

import json
import logging
import os
import threading
import urllib.request
import urllib.error
from typing import Optional, Tuple, Dict, Any, List
import app.config as _app_config
from app.auth import (
    create_access_token,
    create_stream_token,
    get_current_user,
    verify_active_jwt_user,
    HTTPException,
    status,
)
from app.config import is_admin_username, JWT_EXPIRE_HOURS
try:
    from fastapi import APIRouter, Depends
except ImportError:
    Depends = lambda fn=None: fn

    class APIRouter:
        def __init__(self, **kw): pass
        def get(self, *a, **kw): return lambda f: f
        def post(self, *a, **kw): return lambda f: f
        def put(self, *a, **kw): return lambda f: f
        def delete(self, *a, **kw): return lambda f: f
try:
    from app.models import (
        AuthVerifyRequest, AuthResponse,
        UserCreateRequest, UserUpdateRequest, UserItemResponse, UserListResponse,
        BootstrapStatusResponse, BootstrapAdminRequest,
        StreamTokenRequest, StreamTokenResponse,
    )
except ImportError:
    class _SimpleModel:
        def __init__(self, **kw):
            self.username = kw.get("username", "")
            self.password = kw.get("password")
            self.zimaos_token = kw.get("zimaos_token")
            self.role = kw.get("role", "user")
            self.allowed_disks = kw.get("allowed_disks", [])
            self.path = kw.get("path", "")
            for k, v in kw.items():
                setattr(self, k, v)
    AuthVerifyRequest = AuthResponse = UserCreateRequest = UserUpdateRequest = UserItemResponse = UserListResponse = BootstrapStatusResponse = BootstrapAdminRequest = StreamTokenRequest = StreamTokenResponse = _SimpleModel
from app.database import (
    get_or_create_user, get_user_by_username, get_user_by_id, list_all_users,
    create_or_update_user, update_user_smb_password, delete_user_by_id,
    verify_password, log_activity, has_password_configured_users, decrypt_smb_password,
    normalize_user_role,
)
from app.services.smb_manager import (
    get_samba_paths,
    is_storage_path_forbidden,
    resolve_safe_storage_target,
    sync_unix_and_samba_user,
    sync_samba_configuration,
    remove_unix_and_samba_user,
    validate_smb_username,
)

logger = logging.getLogger("myserver.auth")
router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])
_BOOTSTRAP_LOCK = threading.Lock()
_VALID_USER_ROLES = {"admin", "user"}


@router.get("/bootstrap-status", response_model=BootstrapStatusResponse)
def get_bootstrap_status():
    """Memeriksa apakah server memerlukan inisialisasi akun admin pertama (first-run bootstrap)."""
    return BootstrapStatusResponse(
        needs_bootstrap=not has_password_configured_users(),
        total_users=len(list_all_users()),
    )


@router.post("/bootstrap", response_model=AuthResponse)
def bootstrap_admin(req: BootstrapAdminRequest):
    """
    Membuat akun administrator pertama saat database belum memiliki akun ber-password.
    Terkunci atomik (HTTP 403 Forbidden) segera setelah minimal 1 user ber-password terdaftar.
    """
    with _BOOTSTRAP_LOCK:
        if has_password_configured_users():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bootstrap admin sudah terkunci karena akun telah terdaftar.",
            )

        try:
            u_clean = validate_smb_username(getattr(req, "username", "") or "")
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            )

        password = getattr(req, "password", None) or ""
        if len(password) < 4:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kata sandi admin minimal 4 karakter.",
            )

        created = create_or_update_user(
            username=u_clean,
            password=password,
            role="admin",
            allowed_disks=[],
        )
        try:
            sync_unix_and_samba_user(u_clean, password=password, uid_hint=created["id"])
            sync_samba_configuration()
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba pasca-bootstrap gagal (non-fatal): {exc}")

    token = create_access_token(u_clean, created["id"], role="admin")
    log_activity(
        device_id=None,
        task_id=None,
        action="ADMIN_BOOTSTRAPPED",
        message=f"Akun administrator pertama '{u_clean}' berhasil dibuat via bootstrap.",
        details={"user_id": created["id"], "role": "admin"},
    )
    return AuthResponse(
        success=True,
        access_token=token,
        token_type="bearer",
        user_id=created["id"],
        username=u_clean,
        expires_in_hours=JWT_EXPIRE_HOURS,
        role="admin",
        allowed_disks=[],
    )


ZIMAOS_LOGIN_CANDIDATES = [
    "http://172.17.0.1:80/v1/users/login",
    "http://127.0.0.1:80/v1/users/login",
    "http://localhost:80/v1/users/login",
]

ZIMAOS_CURRENT_USER_CANDIDATES = [
    "http://172.17.0.1:80/v1/users/current",
    "http://127.0.0.1:80/v1/users/current",
    "http://localhost:80/v1/users/current",
]


def verify_zimaos_token(zimaos_token: Optional[str]) -> Tuple[bool, Optional[str]]:
    """
    Verifikasi zimaos_token langsung ke endpoint /v1/users/current daemon ZimaOS lokal (Port 80).
    Tidak pernah mempercayai token mentah secara buta, termasuk saat MYSERVER_DEV_MODE aktif.
    Returns: (is_valid, active_zimaos_username)
    """
    tok = str(zimaos_token or "").strip()
    if tok.lower().startswith("bearer "):
        tok = tok[7:].strip()
    if not tok:
        return False, None

    headers = {
        "Authorization": f"Bearer {tok}",
        "User-Agent": "MyServer-Backend-Gateway/1.4.6",
    }
    for url in ZIMAOS_CURRENT_USER_CANDIDATES:
        req = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                if resp.status in (200, 201):
                    res_data = json.loads(resp.read().decode("utf-8"))
                    if isinstance(res_data, dict):
                        succ = res_data.get("success")
                        if succ is not None and succ not in (200, True):
                            return False, None
                        c_data = res_data.get("data", res_data)
                        if isinstance(c_data, dict):
                            z_user = str(c_data.get("username") or "").strip().lower()
                            if z_user:
                                return True, z_user
                    return False, None
        except urllib.error.HTTPError as e:
            logger.warning(f"ZimaOS menolak zimaos_token (HTTP {e.code})")
            return False, None
        except Exception:
            continue
    return False, None


def verify_with_zimaos(username: str, password: str) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
    """
    Verifikasi username & password langsung ke daemon ZimaOS lokal (Port 80).
    Returns: (is_valid, error_detail, user_info)
    """
    payload = json.dumps({"username": username, "password": password}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "MyServer-Backend-Gateway/1.4.6"
    }

    connected_at_least_once = False
    for url in ZIMAOS_LOGIN_CANDIDATES:
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                connected_at_least_once = True
                if resp.status in (200, 201):
                    res_data = json.loads(resp.read().decode("utf-8"))
                    return True, None, res_data
        except urllib.error.HTTPError as e:
            connected_at_least_once = True
            err_body = e.read().decode("utf-8", errors="ignore")
            logger.warning(f"ZimaOS menolak login pengguna '{username}' (HTTP {e.code}): {err_body}")
            return False, "Nama pengguna atau kata sandi tidak valid.", None
        except Exception:
            continue

    if not connected_at_least_once:
        if os.getenv("MYSERVER_DEV_MODE", "").lower() in ("1", "true", "yes"):
            logger.info("Host ZimaOS port 80 tidak dapat dihubungi (MYSERVER_DEV_MODE aktif). Mengizinkan login dev.")
            return True, None, {"dev_mode": True}
        return False, "Daemon ZimaOS lokal (port 80) tidak dapat dihubungi untuk verifikasi kata sandi.", None

    return False, "Gagal memverifikasi akun ke daemon ZimaOS.", None


@router.post("/verify", response_model=AuthResponse)
@router.post("/login-app", response_model=AuthResponse)
def verify_auth(req: AuthVerifyRequest):
    """
    Verifikasi autentikasi multi-tier mandiri:
    1. Cek database SQLite lokal (mendukung unlimited user mandiri).
    2. Fallback verifikasi ke daemon ZimaOS lokal (port 80) jika belum terdaftar lokal.
    """
    if not req.username or not req.username.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username tidak boleh kosong"
        )

    username = req.username.strip().lower()
    user_rec = get_user_by_username(username)
    role = "user"
    allowed_disks = []

    # 1. Cek apakah pengguna memiliki kredensial lokal di database SQLite MyServer
    if user_rec and user_rec.get("password_hash"):
        if req.password and verify_password(req.password, user_rec["password_hash"]):
            role = normalize_user_role(user_rec.get("role"))
            try:
                allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
            except Exception:
                allowed_disks = []
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Nama pengguna atau kata sandi tidak valid."
            )
    else:
        # 2. Fallback: Verifikasi kata sandi atau token ZimaOS terverifikasi ke backend ZimaOS lokal (port 80)
        if req.password:
            is_valid, err_msg, z_info = verify_with_zimaos(username, req.password)
            if not is_valid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=err_msg or "Nama pengguna atau kata sandi tidak valid."
                )
            if is_admin_username(username):
                role = "admin"
        elif req.zimaos_token:
            z_ok, z_user = verify_zimaos_token(req.zimaos_token)
            if not z_ok or not z_user or z_user.strip().lower() != username:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token ZimaOS tidak valid atau tidak sesuai dengan pengguna."
                )
            if is_admin_username(username):
                role = "admin"
        else:
            logger.warning(f"Request verify ditolak: tanpa password/token untuk pengguna '{username}'")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kata sandi atau token autentikasi wajib diisi."
            )

    user_id = user_rec["id"] if user_rec else get_or_create_user(username)
    if user_rec and not user_rec.get("password_hash"):
        if user_rec.get("role"):
            role = normalize_user_role(user_rec.get("role"))
        try:
            allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            allowed_disks = []

    if req.password:
        try:
            is_new_user = user_rec is None
            existing_enc = user_rec.get("smb_password_enc", "") if user_rec else ""
            pw_changed = (not existing_enc) or (decrypt_smb_password(existing_enc) != req.password)
            conf_missing = not os.path.isfile(get_samba_paths()["conf"])
            if pw_changed:
                update_user_smb_password(username, req.password)
            if is_new_user or pw_changed:
                sync_unix_and_samba_user(username, password=req.password, uid_hint=user_id)
            if is_new_user or pw_changed or conf_missing:
                sync_samba_configuration(force_reload=False)
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba saat login '{username}' gagal (non-fatal): {exc}")

    token = create_access_token(username, user_id, role=role)

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_AUTHENTICATED",
        message=f"Pengguna '{username}' (role: {role}) berhasil diautentikasi.",
        details={"user_id": user_id, "role": role}
    )

    return AuthResponse(
        success=True,
        access_token=token,
        token_type="bearer",
        user_id=user_id,
        username=username,
        expires_in_hours=JWT_EXPIRE_HOURS,
        role=role,
        allowed_disks=allowed_disks
    )


def _require_admin_user(current_user: Any, error_detail: str) -> str:
    caller_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    sub = str(caller_rec.get("username") or "").strip().lower()
    eff_role = normalize_user_role(caller_rec.get("role"))
    if eff_role not in ("admin", "root") and not is_admin_username(sub):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=error_detail,
        )
    return sub


def _parse_user_allowed_disks(raw: Any) -> List[str]:
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(x).strip() for x in parsed if str(x).strip()]
        except Exception:
            pass
    return []


@router.get("/me")
def get_my_profile(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil informasi profil akun yang sedang login (fail-closed terhadap akun terhapus)."""
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    username = str(user_rec.get("username") or "").strip().lower()
    role = normalize_user_role(user_rec.get("role"))
    allowed_disks = _parse_user_allowed_disks(user_rec.get("allowed_disks", "[]"))

    return {
        "status": "ok",
        "username": username,
        "user_id": user_rec["id"],
        "role": role,
        "is_admin": role in ("admin", "root") or is_admin_username(username),
        "allowed_disks": allowed_disks
    }


@router.post("/stream-token", response_model=StreamTokenResponse)
def issue_scoped_stream_token(
    req: StreamTokenRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menerbitkan token streaming jangka pendek (300 detik) yang terikat hanya pada satu path berkas."""
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    username = str(user_rec.get("username") or "").strip().lower()
    role = normalize_user_role(user_rec.get("role"))
    is_admin = bool(role in ("admin", "root") or is_admin_username(username))
    allowed_disks = None if is_admin else _parse_user_allowed_disks(user_rec.get("allowed_disks", "[]"))

    storage_root = str(getattr(_app_config, "STORAGE_DIR", _app_config.STORAGE_DIR))
    try:
        canonical_rel, _ = resolve_safe_storage_target(storage_root, getattr(req, "path", ""))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    if not canonical_rel:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Path berkas tidak boleh kosong.")

    if not is_admin and is_storage_path_forbidden(canonical_rel, username, allowed_disks, is_admin=is_admin):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan membuat tautan streaming untuk berkas di luar otorisasi Anda.",
        )

    stream_tok = create_stream_token(
        username=username,
        user_id=int(user_rec["id"]),
        path=canonical_rel,
        ttl_seconds=300,
    )
    return StreamTokenResponse(
        success=True,
        stream_token=stream_tok,
        token_type="stream",
        path=canonical_rel,
        expires_in=300,
    )


# ==============================================================================
# ADMIN USER MANAGEMENT ENDPOINTS
# ==============================================================================

def _count_other_admins(exclude_user_id: int, db_path: Optional[str] = None) -> int:
    users = list_all_users(db_path) if db_path else list_all_users()
    count = 0
    for u in users:
        if u["id"] == exclude_user_id:
            continue
        r = normalize_user_role(u.get("role"))
        if r in ("admin", "root") or is_admin_username(u.get("username")):
            count += 1
    return count


@router.get("/users", response_model=UserListResponse)
def get_users_list(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil seluruh daftar akun pengguna (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan mengelola daftar pengguna.")

    users = list_all_users()
    items = []
    for u in users:
        items.append(UserItemResponse(
            id=u["id"],
            username=u["username"],
            role=normalize_user_role(u.get("role")),
            allowed_disks=u["allowed_disks"],
            created_at=str(u.get("created_at") or "")
        ))

    return UserListResponse(users=items, total=len(items))


@router.post("/users", response_model=UserItemResponse)
def create_new_user(req: UserCreateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Membuat akun pengguna baru dengan filter allowed_disks (Hanya Administrator)."""
    admin_sub = _require_admin_user(current_user, "Hanya administrator yang diizinkan membuat pengguna baru.")

    try:
        u_clean = validate_smb_username(req.username or "")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    raw_password = getattr(req, "password", None) or ""
    if len(raw_password) < 4:
        raise HTTPException(status_code=400, detail="Kata sandi akun minimal 4 karakter.")

    role_val = str(getattr(req, "role", None) or "user").strip().lower()
    if role_val == "staff":
        role_val = "user"
    if role_val not in _VALID_USER_ROLES:
        raise HTTPException(status_code=400, detail="Peran pengguna harus 'admin' atau 'user'.")

    existing = get_user_by_username(u_clean)
    if existing and existing.get("password_hash"):
        raise HTTPException(status_code=400, detail=f"Pengguna '{u_clean}' sudah terdaftar.")

    created = create_or_update_user(
        username=u_clean,
        password=raw_password,
        role=role_val,
        allowed_disks=req.allowed_disks or []
    )
    try:
        sync_unix_and_samba_user(u_clean, password=raw_password, uid_hint=created["id"])
        sync_samba_configuration()
    except Exception as exc:
        logger.warning(f"Sinkronisasi Samba setelah membuat user '{u_clean}' gagal: {exc}")

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_CREATED",
        message=f"Administrator '{admin_sub}' membuat akun '{u_clean}' (role: {role_val}).",
        details={"created_user": u_clean, "allowed_disks": req.allowed_disks}
    )

    return UserItemResponse(
        id=created["id"],
        username=created["username"],
        role=normalize_user_role(created.get("role")),
        allowed_disks=created["allowed_disks"],
        created_at=str(created.get("created_at") or "")
    )


@router.put("/users/{user_id}", response_model=UserItemResponse)
def update_user_details(user_id: int, req: UserUpdateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memperbarui role, allowed_disks, atau password akun pengguna (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan mengedit pengguna.")

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    if req.role is not None:
        role_to_set = str(req.role).strip().lower()
        if role_to_set == "staff":
            role_to_set = "user"
        if role_to_set not in _VALID_USER_ROLES:
            raise HTTPException(status_code=400, detail="Peran pengguna harus 'admin' atau 'user'.")
    else:
        role_to_set = normalize_user_role(user_rec.get("role"))

    cur_role = normalize_user_role(user_rec.get("role"))
    if (cur_role in ("admin", "root") or is_admin_username(user_rec["username"])) and role_to_set != "admin":
        if is_admin_username(user_rec["username"]) or _count_other_admins(user_id) == 0:
            raise HTTPException(
                status_code=400,
                detail="Tidak dapat menurunkan peran akun administrator utama atau administrator terakhir.",
            )

    new_password = req.password if req.password else None
    if new_password is not None and len(new_password) < 4:
        raise HTTPException(status_code=400, detail="Kata sandi akun minimal 4 karakter.")

    disks_to_set = req.allowed_disks
    if disks_to_set is None:
        disks_to_set = _parse_user_allowed_disks(user_rec.get("allowed_disks", "[]"))

    updated = create_or_update_user(
        username=user_rec["username"],
        password=new_password,
        role=role_to_set,
        allowed_disks=disks_to_set
    )
    try:
        if new_password:
            sync_unix_and_samba_user(updated["username"], password=new_password, uid_hint=updated["id"])
        sync_samba_configuration()
    except Exception as exc:
        logger.warning(f"Sinkronisasi Samba setelah memperbarui user '{updated['username']}' gagal: {exc}")

    return UserItemResponse(
        id=updated["id"],
        username=updated["username"],
        role=normalize_user_role(updated.get("role")),
        allowed_disks=updated["allowed_disks"],
        created_at=str(updated.get("created_at") or "")
    )


@router.delete("/users/{user_id}")
def delete_user_account(user_id: int, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Menghapus akun pengguna dari database (Hanya Administrator)."""
    _require_admin_user(current_user, "Hanya administrator yang diizinkan menghapus pengguna.")

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    if is_admin_username(user_rec["username"]):
        raise HTTPException(status_code=400, detail="Akun administrator utama tidak dapat dihapus.")

    target_role = normalize_user_role(user_rec.get("role"))
    if target_role in ("admin", "root") and _count_other_admins(user_id) == 0:
        raise HTTPException(
            status_code=400,
            detail="Administrator terakhir tidak dapat dihapus untuk mencegah penguncian sistem.",
        )

    success = delete_user_by_id(user_id)
    if success:
        try:
            remove_unix_and_samba_user(user_rec["username"])
            sync_samba_configuration()
        except Exception as exc:
            logger.warning(f"Sinkronisasi Samba setelah menghapus user '{user_rec['username']}' gagal: {exc}")
    return {"status": "ok", "message": f"Pengguna '{user_rec['username']}' berhasil dihapus."}


def authorize_system_update_request(
    current_user: Any = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    zimaos_token: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    """
    Otorisasi administrator fail-closed untuk OTA POST /api/v1/system/update:
    (a) Bearer JWT aktif milik administrator di SQLite (uid cocok, bukan scope='stream'), ATAU
    (b) Form username + password terverifikasi (SQLite PBKDF2 atau daemon ZimaOS) milik administrator, ATAU
    (c) Form username + zimaos_token terverifikasi melalui ZimaOS /v1/users/current milik administrator.
    """
    if isinstance(current_user, dict):
        user_rec = verify_active_jwt_user(
            current_user,
            allow_stream_scope=False,
            db_path=db_path,
        )
        eff_user = str(user_rec.get("username") or "").strip().lower()
        eff_role = normalize_user_role(user_rec.get("role"))
        if eff_role not in ("admin", "root") and not is_admin_username(eff_user):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Hanya pengguna administrator yang diizinkan memperbarui sistem backend.",
            )
        return eff_user

    u_clean = str(username or "").strip().lower()
    if not u_clean:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Autentikasi administrator diperlukan untuk memperbarui sistem backend.",
        )

    user_rec = get_user_by_username(u_clean, db_path=db_path) if db_path else get_user_by_username(u_clean)

    if password:
        if user_rec and user_rec.get("password_hash"):
            if not verify_password(password, user_rec["password_hash"]):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Kredensial administrator tidak valid untuk pembaruan OTA.",
                )
            eff_role = normalize_user_role(user_rec.get("role"))
        else:
            is_valid, err_msg, _ = verify_with_zimaos(u_clean, password)
            if not is_valid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=err_msg or "Kredensial tidak valid untuk pembaruan OTA.",
                )
            eff_role = normalize_user_role(
                (user_rec.get("role") if user_rec else None)
                or ("admin" if is_admin_username(u_clean) else "user")
            )

        if eff_role not in ("admin", "root") and not is_admin_username(u_clean):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Hanya pengguna administrator yang diizinkan memperbarui sistem backend.",
            )
        return u_clean

    if zimaos_token:
        z_ok, z_user = verify_zimaos_token(zimaos_token)
        if not z_ok or not z_user or z_user.strip().lower() != u_clean:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token ZimaOS tidak valid atau tidak sesuai dengan akun administrator.",
            )
        eff_role = normalize_user_role(
            (user_rec.get("role") if user_rec else None)
            or ("admin" if is_admin_username(u_clean) else "user")
        )
        if eff_role not in ("admin", "root") and not is_admin_username(u_clean):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Hanya pengguna administrator yang diizinkan memperbarui sistem backend.",
            )
        return u_clean

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Autentikasi administrator (Bearer JWT atau kata sandi/token ZimaOS) wajib disertakan.",
    )

