"""
Backup Engine Router for MyServer Native Backend
Core Endpoints: Deduplication, Chunked Streaming Upload, File Merge & Commit
"""

import asyncio
import os
import re
import shutil
import hashlib
import threading
import uuid
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, status, UploadFile, File, Form, Query, Depends
from fastapi.responses import FileResponse
from app.auth import get_current_user, verify_active_jwt_user
from app.database import normalize_user_role
from app.services.smb_manager import resolve_safe_storage_target

from app.models import (
    CheckHashesRequest, CheckHashesResponse,
    InitUploadRequest, InitUploadResponse,
    UploadChunkResponse,
    CommitFileRequest, CommitFileResponse,
    FileListResponse, FileItemResponse
)
from app.database import (
    check_hashes_bulk, create_upload_session, save_chunk_record,
    commit_file_record, get_db, log_activity, DB_PATH
)
from app.config import STORAGE_DIR, TEMP_DIR, MAX_UPLOAD_SIZE_BYTES, is_admin_username

router = APIRouter(prefix="/api/v1/backup", tags=["Backup Engine"])

_UPLOAD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
_UPLOAD_LOCKS_GUARD = threading.Lock()
_UPLOAD_LOCKS: Dict[str, threading.Lock] = {}


def _get_upload_lock(upload_id: str) -> threading.Lock:
    with _UPLOAD_LOCKS_GUARD:
        lock = _UPLOAD_LOCKS.get(upload_id)
        if lock is None:
            lock = threading.Lock()
            _UPLOAD_LOCKS[upload_id] = lock
        return lock


def _release_upload_lock(upload_id: str) -> None:
    with _UPLOAD_LOCKS_GUARD:
        lock = _UPLOAD_LOCKS.get(upload_id)
        if lock is not None and not lock.locked():
            _UPLOAD_LOCKS.pop(upload_id, None)


def _validate_upload_id_or_400(upload_id: str) -> str:
    clean = str(upload_id or "").strip()
    if not _UPLOAD_ID_RE.match(clean):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Format upload_id tidak valid.",
        )
    return clean


def _assert_task_ownership_or_403(task_id: str, user_rec: Dict[str, Any]) -> Dict[str, Any]:
    with get_db(DB_PATH) as conn:
        task = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
    if not task:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas backup terkait tidak ditemukan")
    t_dict = dict(task)
    uname = str(user_rec.get("username") or "").strip().lower()
    role = normalize_user_role(user_rec.get("role"))
    is_admin = role in ("admin", "root") or is_admin_username(uname)
    owner = str(t_dict.get("username") or "").strip().lower()
    if not is_admin and owner and owner != uname:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan mengakses tugas backup milik pengguna lain.",
        )
    return t_dict


@router.post("/check-hashes", response_model=CheckHashesResponse)
def check_hashes(req: CheckHashesRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Deduplikasi Berkas Cerdas (Smart Deduplication):
    Memeriksa batch hash SHA-256 berkas lokal klien terhadap database server.
    Berkas yang sudah ada dengan hash identik langsung diskip (hemat bandwidth & waktu).
    """
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    _assert_task_ownership_or_403(req.task_id, user_rec)
    entries = [f.model_dump() for f in req.files]
    result = check_hashes_bulk(req.task_id, entries)
    return CheckHashesResponse(**result)


@router.post("/init-upload", response_model=InitUploadResponse)
def init_upload(req: InitUploadRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Inisialisasi Sesi Unggah Potongan:
    Mempersiapkan server untuk menerima file berukuran besar dalam potongan (chunks).
    Mendukung resume upload jika sebelumnya sempat terputus.
    """
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    task = _assert_task_ownership_or_403(req.task_id, user_rec)
    if req.file_size < 0 or req.file_size > MAX_UPLOAD_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Ukuran berkas di luar batas yang diizinkan (maks {MAX_UPLOAD_SIZE_BYTES // (1024 * 1024)} MB).",
        )
    if req.total_chunks <= 0 or req.total_chunks > 100000:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Jumlah total chunk tidak valid.",
        )
    try:
        target_rel = os.path.normpath(req.relative_path).lstrip("/\\")
        resolve_safe_storage_target(STORAGE_DIR, os.path.join(task["target_folder"], target_rel))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    # Gunakan hash berkas + task_id sebagai upload_id unik stabil
    upload_id = hashlib.sha256(f"{req.task_id}:{req.relative_path}:{req.file_hash}".encode("utf-8")).hexdigest()[:32]
    
    session_data = create_upload_session(
        upload_id=upload_id,
        task_id=req.task_id,
        relative_path=req.relative_path,
        file_size=req.file_size,
        file_hash=req.file_hash,
        total_chunks=req.total_chunks
    )
    
    # Buat direktori temp untuk chunk upload_id ini
    session_temp_dir = os.path.join(TEMP_DIR, upload_id)
    os.makedirs(session_temp_dir, exist_ok=True)
    
    return InitUploadResponse(**session_data)


@router.post("/upload-chunk", response_model=UploadChunkResponse)
async def upload_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    chunk_hash: str = Form(...),
    file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Unggah Potongan Berkas (Chunk):
    Menerima potongan biner (misal 4MB) dan memverifikasi integritas hash SHA-256 chunk
    secara non-blocking dengan staging atomik + per-upload_id lock.
    """
    user_rec = await asyncio.to_thread(verify_active_jwt_user, current_user, False)
    clean_uid = _validate_upload_id_or_400(upload_id)

    def _load_and_authorize_session():
        with get_db(DB_PATH) as conn:
            s = conn.execute("SELECT * FROM upload_sessions WHERE upload_id = ?", (clean_uid,)).fetchone()
        if not s:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sesi unggah tidak ditemukan")
        s_dict = dict(s)
        _assert_task_ownership_or_403(s_dict["task_id"], user_rec)
        return s_dict

    session = await asyncio.to_thread(_load_and_authorize_session)
    total_chunks = int(session.get("total_chunks") or 0)
    if chunk_index < 0 or chunk_index >= total_chunks:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Indeks chunk {chunk_index} di luar rentang [0, {max(0, total_chunks - 1)}].",
        )

    session_temp_dir = os.path.join(TEMP_DIR, clean_uid)
    chunk_file_path = os.path.join(session_temp_dir, f"chunk_{chunk_index:06d}.part")
    tmp_chunk_path = f"{chunk_file_path}.tmp.{uuid.uuid4().hex[:8]}"

    sha = hashlib.sha256()
    bytes_count = 0
    chunks_buf: List[bytes] = []
    max_chunk_bytes = max(32 * 1024 * 1024, int(MAX_UPLOAD_SIZE_BYTES))

    while True:
        chunk_data = await file.read(65536)  # 64KB stream buffer
        if not chunk_data:
            break
        bytes_count += len(chunk_data)
        if bytes_count > max_chunk_bytes:
            raise HTTPException(
                status_code=getattr(status, "HTTP_413_REQUEST_ENTITY_TOO_LARGE", 413),
                detail="Ukuran chunk melebihi batas maksimal.",
            )
        sha.update(chunk_data)
        chunks_buf.append(chunk_data)

    calc_hash = sha.hexdigest()
    if calc_hash.lower() != chunk_hash.lower():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Hash chunk tidak cocok! Dikirim: {chunk_hash}, Dihitung: {calc_hash}"
        )

    def _persist_chunk_atomic():
        lock = _get_upload_lock(clean_uid)
        with lock:
            os.makedirs(session_temp_dir, exist_ok=True)
            try:
                with open(tmp_chunk_path, "wb") as f_out:
                    for part in chunks_buf:
                        f_out.write(part)
                    f_out.flush()
                    os.fsync(f_out.fileno())
                os.replace(tmp_chunk_path, chunk_file_path)
            except Exception:
                if os.path.exists(tmp_chunk_path):
                    try:
                        os.remove(tmp_chunk_path)
                    except OSError:
                        pass
                raise
            save_chunk_record(clean_uid, chunk_index, calc_hash, bytes_count)

    await asyncio.to_thread(_persist_chunk_atomic)

    return UploadChunkResponse(
        status="chunk_received",
        upload_id=clean_uid,
        chunk_index=chunk_index,
        bytes_received=bytes_count
    )


@router.post("/commit-file", response_model=CommitFileResponse)
def commit_file(req: CommitFileRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Penggabungan & Finalisasi Berkas (Merge & Commit):
    Menggabungkan seluruh potongan chunk yang tersimpan menjadi berkas utuh secara atomik
    (.tmp + fsync + os.replace) dengan proteksi path traversal & per-upload_id lock.
    """
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    clean_uid = _validate_upload_id_or_400(req.upload_id)
    lock = _get_upload_lock(clean_uid)

    try:
        with lock:
            with get_db(DB_PATH) as conn:
                session = conn.execute("SELECT * FROM upload_sessions WHERE upload_id = ?", (clean_uid,)).fetchone()
                if not session:
                    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sesi unggah tidak ditemukan")

            task = _assert_task_ownership_or_403(session["task_id"], user_rec)
            total_chunks = int(session["total_chunks"])
            session_temp_dir = os.path.join(TEMP_DIR, clean_uid)

            # Verifikasi seluruh chunk ada di disk
            for i in range(total_chunks):
                c_path = os.path.join(session_temp_dir, f"chunk_{i:06d}.part")
                if not os.path.exists(c_path):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Potongan chunk ke-{i} belum lengkap atau hilang!"
                    )

            # Tentukan jalur berkas final secara aman di dalam STORAGE_DIR
            target_rel = os.path.normpath(session["relative_path"]).lstrip("/\\")
            raw_storage_rel = os.path.join(task["target_folder"], target_rel)
            try:
                final_storage_rel, final_full_path = resolve_safe_storage_target(STORAGE_DIR, raw_storage_rel)
            except ValueError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

            os.makedirs(os.path.dirname(final_full_path), exist_ok=True)
            tmp_final_path = f"{final_full_path}.tmp.{uuid.uuid4().hex[:8]}"

            sha_total = hashlib.sha256()
            try:
                with open(tmp_final_path, "wb") as f_out:
                    for i in range(total_chunks):
                        c_path = os.path.join(session_temp_dir, f"chunk_{i:06d}.part")
                        with open(c_path, "rb") as f_in:
                            while True:
                                b = f_in.read(65536)
                                if not b:
                                    break
                                sha_total.update(b)
                                f_out.write(b)
                    f_out.flush()
                    os.fsync(f_out.fileno())

                final_hash = sha_total.hexdigest()
                if final_hash.lower() != session["file_hash"].lower():
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Hash berkas gabungan tidak cocok dengan ekspektasi sesi!"
                    )
                os.replace(tmp_final_path, final_full_path)
            except Exception:
                if os.path.exists(tmp_final_path):
                    try:
                        os.remove(tmp_final_path)
                    except OSError:
                        pass
                raise

            # Bersihkan folder chunks sementara & catat ke database
            shutil.rmtree(session_temp_dir, ignore_errors=True)
            committed = commit_file_record(clean_uid, final_storage_rel, req.modified_time)
            if not committed:
                raise HTTPException(status_code=500, detail="Gagal mencatat berkas ke katalog database")

            log_activity(
                device_id=task["device_id"],
                task_id=task["task_id"],
                action="FILE_COMMITTED",
                message=f"Berkas '{session['relative_path']}' ({session['file_size']} bytes) berhasil dicadangkan.",
                details={"storage_path": final_storage_rel}
            )

            return CommitFileResponse(
                status="file_committed",
                file_id=committed["file_id"],
                task_id=committed["task_id"],
                relative_path=committed["relative_path"],
                file_size=committed["file_size"],
                file_hash=committed["file_hash"],
                storage_path=committed["storage_path"],
                version=committed["version"]
            )
    finally:
        _release_upload_lock(clean_uid)


@router.get("/files", response_model=FileListResponse)
def list_files(task_id: str = Query(...), current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil daftar berkas yang telah berhasil dicadangkan untuk satu tugas."""
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    _assert_task_ownership_or_403(task_id, user_rec)
    with get_db(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT * FROM files WHERE task_id = ? AND status = 'active' ORDER BY relative_path ASC",
            (task_id,)
        ).fetchall()

        file_items = [FileItemResponse(**dict(r)) for r in rows]
        total_bytes = sum(f.file_size for f in file_items)

        return FileListResponse(
            task_id=task_id,
            total_files=len(file_items),
            total_bytes=total_bytes,
            files=file_items
        )


@router.get("/download-file")
def download_file(file_id: int = Query(...), current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengunduh berkas cadangan untuk proses restore."""
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    with get_db(DB_PATH) as conn:
        row = conn.execute("SELECT * FROM files WHERE file_id = ?", (file_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")

    _assert_task_ownership_or_403(row["task_id"], user_rec)
    try:
        _, full_path = resolve_safe_storage_target(STORAGE_DIR, row["storage_path"])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="Berkas fisik tidak ditemukan di media penyimpanan")

    filename = os.path.basename(row["relative_path"])
    return FileResponse(path=full_path, filename=filename, media_type="application/octet-stream")
