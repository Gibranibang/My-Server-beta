"""
Device Management Router for MyServer Native Backend
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from app.auth import get_control_plane_user
from app.models import DeviceRegisterRequest, DeviceResponse, DeviceHeartbeatRequest
from app.config import is_admin_username
from app.database import upsert_device, update_device_heartbeat, get_or_create_user, get_db, log_activity, DB_PATH

router = APIRouter(
    prefix="/api/v1/devices",
    tags=["Devices"],
    dependencies=[Depends(get_control_plane_user)],
)


@router.post("/register", response_model=DeviceResponse)
def register_device(
    req: DeviceRegisterRequest,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mendaftarkan atau memperbarui metadata perangkat klien dengan isolasi kepemilikan."""
    caller_name = str(caller["username"]).strip().lower()
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])

    fields_set = getattr(req, "model_fields_set", None) or getattr(req, "__fields_set__", None)
    raw_req_user = getattr(req, "username", None)
    req_user_clean = str(raw_req_user).strip().lower() if raw_req_user is not None else ""
    username_supplied = ("username" in fields_set) if fields_set is not None else (raw_req_user is not None)

    if not is_admin:
        if username_supplied and req_user_clean and req_user_clean != caller_name:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan mendaftarkan perangkat untuk pengguna lain.",
            )
        with get_db(DB_PATH) as conn:
            existing_dev = conn.execute(
                "SELECT user_id FROM devices WHERE device_id = ?",
                (req.device_id,),
            ).fetchone()
        if existing_dev is not None and int(existing_dev["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="ID perangkat sudah terdaftar milik pengguna lain.",
            )
        eff_username = caller_name
        user_id = caller_uid
    else:
        eff_username = req_user_clean or caller_name
        user_id = caller_uid if eff_username == caller_name else get_or_create_user(eff_username)

    device_data = upsert_device(
        device_id=req.device_id,
        user_id=user_id,
        device_name=req.device_name,
        device_type=req.device_type,
        app_version=req.app_version,
    )

    log_activity(
        device_id=req.device_id,
        task_id=None,
        action="DEVICE_REGISTERED",
        message=f"Perangkat '{req.device_name}' ({req.device_type}) terdaftar untuk user '{eff_username}'.",
        details={"version": req.app_version, "username": eff_username},
    )

    return DeviceResponse(**device_data)


@router.post("/heartbeat")
def heartbeat_device(
    req: DeviceHeartbeatRequest,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Memperbarui tanda waktu aktif terakhir perangkat (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (req.device_id,),
        ).fetchone()
    if not dev_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perangkat tidak ditemukan",
        )
    if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan memperbarui perangkat milik pengguna lain.",
        )
    update_device_heartbeat(req.device_id)
    return {"status": "ok", "device_id": req.device_id}


@router.get("", response_model=List[DeviceResponse])
def list_devices(
    username: Optional[str] = Query(None),
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mengambil daftar perangkat terhubung dengan isolasi multi-user."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        if not is_admin:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE d.user_id = ?
                ORDER BY d.last_seen DESC
                """,
                (caller_uid,),
            ).fetchall()
        elif username and username.strip():
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE LOWER(u.username) = LOWER(?)
                ORDER BY d.last_seen DESC
                """,
                (username.strip(),),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                ORDER BY d.last_seen DESC
                """
            ).fetchall()
        return [DeviceResponse(**dict(r)) for r in rows]


@router.delete("/{device_id}")
def delete_device(
    device_id: str,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Menghapus pendaftaran perangkat dan sesi terkait dari sistem (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (device_id,),
        ).fetchone()
        if not dev_row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perangkat tidak ditemukan")
        if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan menghapus perangkat milik pengguna lain.",
            )
        conn.execute("DELETE FROM devices WHERE device_id = ?", (device_id,))

    log_activity(
        device_id=device_id,
        task_id=None,
        action="DEVICE_DELETED",
        message=f"Perangkat '{device_id}' telah dihapus dari sistem.",
    )
    return {"status": "ok", "message": f"Perangkat {device_id} berhasil dihapus"}

