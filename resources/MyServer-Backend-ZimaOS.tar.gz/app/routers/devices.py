"""
Device Management Router for MyServer Native Backend
"""

from typing import List, Optional, Dict, Any
import hashlib
import re
import shutil
import subprocess
try:
    from fastapi import APIRouter, Depends, Query, Request
except ImportError:
    Depends = lambda fn=None: fn
    Query = lambda default=..., **kw: default
    Request = object

    class APIRouter:
        def __init__(self, **kw):
            pass

        def _reg(self, *args, **kwargs):
            return lambda fn: fn

        get = post = put = delete = patch = _reg

from app.auth import get_control_plane_user, HTTPException, status
from app.models import DeviceRegisterRequest, DeviceResponse, DeviceHeartbeatRequest
from app.config import is_admin_username, SERVER_VERSION
import app.database as _app_db
from app.database import upsert_device, update_device_heartbeat, deduplicate_devices_by_ip, get_or_create_user, get_db, log_activity, DB_PATH

_INITIAL_DB_PATH = DB_PATH


def _current_db_path() -> str:
    if DB_PATH != _INITIAL_DB_PATH:
        return DB_PATH
    return getattr(_app_db, "DB_PATH", DB_PATH)

router = APIRouter(
    prefix="/api/v1/devices",
    tags=["Devices"],
    dependencies=[Depends(get_control_plane_user)],
)


def _lookup_lan_mac_from_arp(ip: str, arp_path: str = "/proc/net/arp") -> str:
    """Mencari alamat MAC perangkat LAN dari tabel ARP kernel berdasarkan IP klien."""
    clean_ip = str(ip or "").strip()
    if clean_ip.startswith("::ffff:"):
        clean_ip = clean_ip[7:]
    if not clean_ip:
        return ""
    try:
        with open(arp_path, "r", encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()
        for line in lines[1:]:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == clean_ip:
                mac = parts[3].strip().upper()
                if mac and mac != "00:00:00:00:00:00":
                    return mac
    except Exception:
        pass
    return ""


def _resolve_client_ip(request: Optional[Any], fallback: Optional[str] = "") -> str:
    explicit = str(fallback or "").strip()
    if explicit:
        return explicit[7:] if explicit.startswith("::ffff:") else explicit
    if request is not None:
        try:
            headers = getattr(request, "headers", None)
            if headers is not None:
                for hdr_name in ("cf-connecting-ip", "CF-Connecting-IP", "x-real-ip", "X-Real-IP", "x-forwarded-for", "X-Forwarded-For"):
                    raw_hdr = headers.get(hdr_name) or ""
                    if raw_hdr:
                        first_ip = raw_hdr.split(",")[0].strip()
                        if first_ip:
                            return first_ip[7:] if first_ip.startswith("::ffff:") else first_ip
            client = getattr(request, "client", None)
            if client and getattr(client, "host", None):
                host = str(client.host).strip()
                return host[7:] if host.startswith("::ffff:") else host
        except Exception:
            pass
    return ""


def _parse_client_ua(ua: str) -> tuple:
    raw = str(ua or "")
    low = raw.lower()
    if "iphone" in low:
        os_name, dev_type = "iPhone", "ios"
    elif "ipad" in low:
        os_name, dev_type = "iPad", "ios"
    elif "android" in low:
        os_name, dev_type = "Android", "android"
    elif "windows" in low:
        os_name, dev_type = "Windows", "windows"
    elif "macintosh" in low or "mac os" in low:
        os_name, dev_type = "macOS", "macos"
    elif "linux" in low:
        os_name, dev_type = "Linux", "linux"
    else:
        os_name, dev_type = "Web", "web"

    if "edg/" in low:
        browser = "Edge"
    elif "chrome/" in low:
        browser = "Chrome"
    elif "firefox/" in low:
        browser = "Firefox"
    elif "safari/" in low:
        browser = "Safari"
    elif "myserver" in low:
        browser = "MyServer App"
    else:
        browser = "Client"
    return f"{browser} ({os_name})", dev_type


def record_authenticated_client_device(
    user_id: int,
    username: str,
    request: Optional[Any],
    db_path: Optional[str] = None,
) -> None:
    """Mencatat sesi perangkat & akun terautentikasi ke tabel devices untuk tampilan admin."""
    if request is None or not user_id:
        return
    try:
        headers = getattr(request, "headers", None)
        ua = ""
        if headers is not None:
            ua = str(headers.get("user-agent") or headers.get("User-Agent") or "").strip()
        client_ip = _resolve_client_ip(request, "")
        mac_addr = _lookup_lan_mac_from_arp(client_ip)
        dev_name, dev_type = _parse_client_ua(ua)
        fp_basis = f"{int(user_id)}|{client_ip.lower()}" if client_ip else f"{int(user_id)}|{dev_type}"
        fp = hashlib.sha256(fp_basis.encode("utf-8", "ignore")).hexdigest()[:12]
        dev_id = f"sess-{int(user_id)}-{fp}"
        upsert_device(
            device_id=dev_id,
            user_id=int(user_id),
            device_name=dev_name,
            device_type=dev_type,
            app_version=str(SERVER_VERSION or "2.2.12"),
            db_path=db_path or _current_db_path(),
            ip_address=client_ip,
            mac_address=mac_addr,
        )
    except Exception:
        pass


@router.post("/register", response_model=DeviceResponse)
def register_device(
    req: DeviceRegisterRequest,
    request: Request = None,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mendaftarkan atau memperbarui metadata perangkat klien dengan isolasi kepemilikan."""
    caller_name = str(caller["username"]).strip().lower()
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])

    fields_set = getattr(req, "model_fields_set", None) or getattr(req, "__fields_set__", None)
    raw_req_user = getattr(req, "username", None)
    req_user_clean = str(raw_req_user).strip().lower() if raw_req_user is not None else ""
    username_supplied = ("username" in fields_set) if fields_set is not None else (raw_req_user is not None)

    if not is_admin:
        if username_supplied and req_user_clean and req_user_clean != caller_name:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan mendaftarkan perangkat untuk pengguna lain.",
            )
        with get_db(_current_db_path()) as conn:
            existing_dev = conn.execute(
                "SELECT user_id FROM devices WHERE device_id = ?",
                (req.device_id,),
            ).fetchone()
        if existing_dev is not None and int(existing_dev["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="ID perangkat sudah terdaftar milik pengguna lain.",
            )
        eff_username = caller_name
        user_id = caller_uid
    else:
        eff_username = req_user_clean or caller_name
        user_id = caller_uid if eff_username == caller_name else get_or_create_user(eff_username, db_path=_current_db_path())

    client_ip = _resolve_client_ip(request, getattr(req, "ip_address", ""))
    mac_addr = str(getattr(req, "mac_address", "") or "").strip() or _lookup_lan_mac_from_arp(client_ip)
    device_data = upsert_device(
        device_id=req.device_id,
        user_id=user_id,
        device_name=req.device_name,
        device_type=req.device_type,
        app_version=req.app_version,
        db_path=_current_db_path(),
        ip_address=client_ip,
        mac_address=mac_addr,
    )

    log_activity(
        device_id=req.device_id,
        task_id=None,
        action="DEVICE_REGISTERED",
        message=f"Perangkat '{req.device_name}' ({req.device_type}) terdaftar untuk user '{eff_username}'.",
        details={"version": req.app_version, "username": eff_username},
        db_path=_current_db_path(),
    )

    return DeviceResponse(**device_data)


@router.post("/heartbeat")
def heartbeat_device(
    req: DeviceHeartbeatRequest,
    request: Request = None,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Memperbarui tanda waktu aktif terakhir perangkat (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(_current_db_path()) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (req.device_id,),
        ).fetchone()
    if not dev_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perangkat tidak ditemukan",
        )
    if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan memperbarui perangkat milik pengguna lain.",
        )
    client_ip = _resolve_client_ip(request, getattr(req, "ip_address", ""))
    mac_addr = str(getattr(req, "mac_address", "") or "").strip() or _lookup_lan_mac_from_arp(client_ip)
    update_device_heartbeat(req.device_id, db_path=_current_db_path(), ip_address=client_ip, mac_address=mac_addr)
    return {"status": "ok", "device_id": req.device_id}


_SMB_IP_RE = re.compile(r"\(ipv[46]:([^):]+):\d+\)", re.IGNORECASE)


def _parse_smbstatus_clients(raw_output: str) -> List[Dict[str, str]]:
    """Mem-parse output `smbstatus -b` menjadi daftar sesi klien SMB aktif."""
    clients: List[Dict[str, str]] = []
    seen = set()
    for line in str(raw_output or "").splitlines():
        parts = line.strip().split()
        if len(parts) < 4 or not parts[0].isdigit():
            continue
        uname = parts[1].strip().lower()
        if not uname or uname in ("nobody", "-", "root") or uname.startswith("("):
            continue
        machine = parts[3].strip()
        m_ip = _SMB_IP_RE.search(line)
        ip_addr = m_ip.group(1).strip() if m_ip else ""
        if ip_addr.startswith("::ffff:"):
            ip_addr = ip_addr[7:]
        if not ip_addr and re.match(r"^\d{1,3}(\.\d{1,3}){3}$", machine):
            ip_addr = machine
        key = (uname, ip_addr or machine)
        if key in seen:
            continue
        seen.add(key)
        clients.append({"username": uname, "machine": machine, "ip_address": ip_addr})
    return clients


def _sync_active_smb_clients(db_path: str) -> None:
    """Sinkronkan klien SMB aktif (`smbstatus -b`) ke tabel devices jika smbd berjalan."""
    if not shutil.which("smbstatus"):
        return
    try:
        proc = subprocess.run(
            ["smbstatus", "-b"],
            capture_output=True,
            text=True,
            timeout=2.0,
            check=False,
        )
        if proc.returncode != 0 or not proc.stdout:
            return
        parsed = _parse_smbstatus_clients(proc.stdout)
        if not parsed:
            return
        with get_db(db_path) as conn:
            for item in parsed:
                row = conn.execute(
                    "SELECT id FROM users WHERE LOWER(username) = LOWER(?)",
                    (item["username"],),
                ).fetchone()
                if not row:
                    continue
                uid = int(row["id"])
                ip_addr = item["ip_address"]
                mac_addr = _lookup_lan_mac_from_arp(ip_addr)
                dev_key = hashlib.sha256(f"smb|{uid}|{ip_addr or item['machine']}".encode("utf-8", "ignore")).hexdigest()[:10]
                upsert_device(
                    device_id=f"smb-{uid}-{dev_key}",
                    user_id=uid,
                    device_name=f"{item['machine']} (SMB)",
                    device_type="smb",
                    app_version="SMB",
                    db_path=db_path,
                    ip_address=ip_addr,
                    mac_address=mac_addr,
                )
    except Exception:
        pass


@router.get("", response_model=List[DeviceResponse])
def list_devices(
    username: Optional[str] = Query(None),
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mengambil daftar perangkat terhubung dengan isolasi multi-user & deduplikasi IP+owner."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    db_target = _current_db_path()
    _sync_active_smb_clients(db_target)
    try:
        deduplicate_devices_by_ip(db_target)
    except Exception:
        pass
    with get_db(db_target) as conn:
        if not is_admin:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE d.user_id = ?
                ORDER BY d.last_seen DESC
                """,
                (caller_uid,),
            ).fetchall()
        elif username and username.strip():
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE LOWER(u.username) = LOWER(?)
                ORDER BY d.last_seen DESC
                """,
                (username.strip(),),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                ORDER BY d.last_seen DESC
                """
            ).fetchall()

        deduped: List[DeviceResponse] = []
        seen_ip_keys = set()
        for r in rows:
            item = dict(r)
            ip_norm = str(item.get("ip_address") or "").strip().lower()
            if ip_norm.startswith("::ffff:"):
                ip_norm = ip_norm[7:]
            if ip_norm:
                is_loop = ip_norm in ("127.0.0.1", "::1", "localhost")
                key = (ip_norm, int(item.get("user_id") or 0)) if is_loop else (ip_norm, None)
                if key in seen_ip_keys:
                    continue
                seen_ip_keys.add(key)
            deduped.append(DeviceResponse(**item))
        return deduped


@router.delete("/{device_id}")
def delete_device(
    device_id: str,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Menghapus pendaftaran perangkat dan sesi terkait dari sistem (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(_current_db_path()) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (device_id,),
        ).fetchone()
        if not dev_row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perangkat tidak ditemukan")
        if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan menghapus perangkat milik pengguna lain.",
            )
        conn.execute("DELETE FROM devices WHERE device_id = ?", (device_id,))

    log_activity(
        device_id=device_id,
        task_id=None,
        action="DEVICE_DELETED",
        message=f"Perangkat '{device_id}' telah dihapus dari sistem.",
        db_path=_current_db_path(),
    )
    return {"status": "ok", "message": f"Perangkat {device_id} berhasil dihapus"}

