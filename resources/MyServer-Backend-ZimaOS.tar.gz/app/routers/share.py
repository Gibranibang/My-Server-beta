"""
Public Share Link Router & Standalone Dark Viewer for MyServer Native Backend (SHL-01, SHL-02).
Serves unauthenticated public share links (/s/{token} and /api/v1/share/{token}/{auth,meta,stream,download})
with PBKDF2 password verification, HMAC-SHA256 unlock cookies, strict os.path.commonpath subtree
confinement, HTTP 206 Partial Content Range streaming, and spooled streaming .zip folder downloads.
"""

import hashlib
import hmac
import html
import http.cookies
import json
import logging
import mimetypes
import os
import tempfile
import time
import urllib.parse
import zipfile
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("myserver.share")

try:
    from fastapi import APIRouter, HTTPException, Query, Request, Response
    from fastapi.responses import HTMLResponse, StreamingResponse
except ImportError:
    class APIRouter:
        def __init__(self, *a, **k):
            pass

        def __getattr__(self, name):
            return lambda *a, **k: (lambda f: f)

    from app.auth import HTTPException

    Query = lambda default=None, **kw: default
    Request = Response = object

    class _FallbackResponse:
        def __init__(self, content=None, status_code=200, headers=None, media_type=None, path=None):
            self.content = content
            self.body = content.encode("utf-8") if isinstance(content, str) else content
            self.status_code = status_code
            self.headers = headers or {}
            self.media_type = media_type
            self.path = path

    StreamingResponse = HTMLResponse = _FallbackResponse

import app.config as _app_config
from app.config import DB_PATH, STORAGE_DIR, is_admin_username
from app.database import (
    get_public_share,
    get_user_by_username,
    increment_share_download_count,
    log_activity,
    normalize_user_role,
    verify_password,
)
from app.models import PublicShareAuthRequest
from app.routers.storage import (
    _parse_allowed_disks_value,
    is_forbidden_for_user,
    stream_file_range,
)
from app.services.smb_manager import resolve_safe_storage_target

router = APIRouter(tags=["Public Share Links"])

SHARE_SESSION_TTL_SECONDS = 86400


def _storage_dir() -> str:
    return str(getattr(_app_config, "STORAGE_DIR", STORAGE_DIR))


def _db_path() -> str:
    return str(getattr(_app_config, "DB_PATH", DB_PATH))


def share_cookie_name(token: str) -> str:
    """Return canonical cookie name for a share link unlock session."""
    clean_tok = "".join(ch for ch in str(token or "").strip() if ch.isalnum() or ch in ("_", "-"))
    return f"myserver_share_{clean_tok}"


def _share_hmac_digest(token: str, exp_ts: int, password_hash: str) -> str:
    secret = str(getattr(_app_config, "JWT_SECRET", "") or "").encode("utf-8")
    pwd_digest = hashlib.sha256((password_hash or "").encode("utf-8")).hexdigest()[:16]
    msg = f"share-auth-v1:{token}:{exp_ts}:{pwd_digest}".encode("utf-8")
    return hmac.new(secret, msg, hashlib.sha256).hexdigest()


def create_share_access_token(
    token: str,
    password_hash: str,
    ttl_seconds: int = SHARE_SESSION_TTL_SECONDS,
) -> str:
    """Create an HMAC-SHA256 signed share access token bound to share token, expiry, and password hash."""
    exp_ts = int(time.time()) + max(60, int(ttl_seconds))
    sig = _share_hmac_digest(token, exp_ts, password_hash or "")
    return f"{exp_ts}.{sig}"


def verify_share_access_token(
    token: str,
    password_hash: Optional[str],
    candidate_token: Optional[str],
) -> bool:
    """Verify HMAC-SHA256 share access token in constant time."""
    clean_hash = str(password_hash or "").strip()
    if not clean_hash:
        return True
    raw_cand = str(candidate_token or "").strip()
    if not raw_cand or "." not in raw_cand:
        return False
    try:
        exp_str, sig_hex = raw_cand.split(".", 1)
        exp_ts = int(exp_str)
        if exp_ts < int(time.time()):
            return False
        expected_sig = _share_hmac_digest(token, exp_ts, clean_hash)
        return hmac.compare_digest(sig_hex.lower(), expected_sig.lower())
    except Exception:
        return False


def extract_share_access_token(
    token: str,
    request: Any = None,
    query_token: Optional[str] = None,
    header_token: Optional[str] = None,
    cookie_header: Optional[str] = None,
) -> str:
    """Extract share unlock token from query params, X-Share-Auth header, or myserver_share_{token} cookie."""
    if query_token and str(query_token).strip():
        return str(query_token).strip()
    if header_token and str(header_token).strip():
        return str(header_token).strip()

    cookie_key = share_cookie_name(token)

    if request is not None:
        qp = getattr(request, "query_params", None)
        if qp and hasattr(qp, "get"):
            q_val = qp.get("access_token") or qp.get("share_token")
            if q_val and str(q_val).strip():
                return str(q_val).strip()

        hdrs = getattr(request, "headers", None)
        if hdrs and hasattr(hdrs, "get"):
            h_val = hdrs.get("x-share-auth") or hdrs.get("X-Share-Auth")
            if h_val and str(h_val).strip():
                return str(h_val).strip()
            if not cookie_header:
                cookie_header = hdrs.get("cookie") or hdrs.get("Cookie")

        cookies_dict = getattr(request, "cookies", None)
        if cookies_dict and hasattr(cookies_dict, "get"):
            c_val = cookies_dict.get(cookie_key)
            if c_val and str(c_val).strip():
                return str(c_val).strip()

    if cookie_header:
        try:
            sc = http.cookies.SimpleCookie()
            sc.load(str(cookie_header))
            if cookie_key in sc and sc[cookie_key].value:
                return str(sc[cookie_key].value).strip()
        except Exception:
            for part in str(cookie_header).split(";"):
                k, _, v = part.strip().partition("=")
                if k.strip() == cookie_key and v.strip():
                    return v.strip()

    return ""


def is_share_request_unlocked(
    share: Dict[str, Any],
    request: Any = None,
    query_token: Optional[str] = None,
    header_token: Optional[str] = None,
    cookie_header: Optional[str] = None,
) -> bool:
    """Return True if share has no password or request carries a valid HMAC unlock cookie/token."""
    if not share.get("password_protected"):
        return True
    candidate = extract_share_access_token(
        share["token"],
        request=request,
        query_token=query_token,
        header_token=header_token,
        cookie_header=cookie_header,
    )
    return verify_share_access_token(share["token"], share.get("password_hash"), candidate)


def classify_preview_kind(filename: str, is_dir: bool = False) -> str:
    """Classify a file or folder into viewer preview kind."""
    if is_dir:
        return "folder"
    ext = os.path.splitext(str(filename or ""))[1].lower()
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg", ".ico", ".avif"):
        return "image"
    if ext in (".mp4", ".webm", ".mkv", ".mov", ".avi", ".m4v"):
        return "video"
    if ext in (".mp3", ".wav", ".ogg", ".flac", ".m4a", ".aac", ".opus"):
        return "audio"
    if ext == ".pdf":
        return "pdf"
    if ext in (
        ".txt", ".md", ".json", ".log", ".py", ".js", ".ts", ".tsx", ".jsx",
        ".html", ".css", ".yml", ".yaml", ".xml", ".csv", ".ini", ".conf",
        ".sh", ".toml", ".sql",
    ):
        return "text"
    return "file"


def load_active_share_or_raise(
    token: str,
    db_path: Optional[str] = None,
    include_secret: bool = True,
) -> Dict[str, Any]:
    """Load share record and raise 404 if unknown or 410 if expired/revoked."""
    target_db = db_path or _db_path()
    share = get_public_share(token, db_path=target_db, include_secret=include_secret)
    if not share:
        raise HTTPException(status_code=404, detail="Tautan berbagi tidak ditemukan.")
    if share.get("revoked") or share.get("is_expired") or share.get("status") != "active":
        raise HTTPException(status_code=410, detail="Tautan berbagi sudah kedaluwarsa atau telah dicabut.")
    return share


def resolve_share_subpath_target(
    storage_root: str,
    share: Dict[str, Any],
    subpath: Optional[str] = "",
    db_path: Optional[str] = None,
) -> Tuple[str, str, str]:
    """
    Resolve and confine a public share request strictly inside the shared file or directory root.
    Blocks relative path traversal ('..') and symlink escapes outside share_root_abs.
    """
    try:
        share_rel, share_root_abs = resolve_safe_storage_target(storage_root, share.get("target_path"))
    except ValueError:
        raise HTTPException(status_code=400, detail="Jalur target tautan berbagi tidak valid.")

    if not share_rel:
        raise HTTPException(status_code=403, detail="Pembagian root penyimpanan secara langsung tidak diizinkan.")

    # Verify owner still has permission on share_rel if owner exists in SQLite
    owner_username = str(share.get("owner_username") or "").strip()
    if owner_username:
        owner_rec = get_user_by_username(owner_username, db_path=db_path or _db_path())
        if owner_rec:
            owner_role = normalize_user_role(owner_rec.get("role"))
            owner_is_admin = bool(owner_role in ("admin", "root") or is_admin_username(owner_username))
            owner_disks = _parse_allowed_disks_value(owner_rec.get("allowed_disks", "[]"))
            if is_forbidden_for_user(share_rel, owner_username, owner_disks, is_admin=owner_is_admin):
                raise HTTPException(
                    status_code=403,
                    detail="Izin akses penyimpanan pemilik tautan telah dicabut.",
                )

    if not os.path.exists(share_root_abs):
        raise HTTPException(status_code=404, detail="Berkas atau direktori yang dibagikan tidak ditemukan di server.")

    raw_sub = str(subpath or "").strip().replace("\\", "/").strip("/")
    if not share.get("is_dir"):
        if raw_sub:
            raise HTTPException(status_code=400, detail="Subpath tidak berlaku untuk tautan berkas tunggal.")
        return share_rel, share_root_abs, ""

    if "\x00" in raw_sub:
        raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")
    if raw_sub:
        segments = [seg for seg in raw_sub.split("/") if seg]
        if any(seg in (".", "..") for seg in segments):
            raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")
        combined_rel = f"{share_rel}/{'/'.join(segments)}"
    else:
        combined_rel = share_rel

    try:
        target_rel, target_abs = resolve_safe_storage_target(storage_root, combined_rel)
    except ValueError:
        raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")

    # Strict subtree confinement inside share_root_abs (blocks symlink escape to sibling folders)
    try:
        if os.path.commonpath([share_root_abs, target_abs]) != share_root_abs:
            raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")
    except ValueError:
        raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau sub-folder tidak ditemukan.")

    clean_sub = "" if target_abs == share_root_abs else os.path.relpath(target_abs, share_root_abs).replace("\\", "/")
    return target_rel, target_abs, clean_sub


def build_share_meta_payload(
    storage_root: str,
    share: Dict[str, Any],
    subpath: Optional[str] = "",
    unlocked: bool = True,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Build metadata or directory listing payload for GET /api/v1/share/{token}/meta."""
    token = share["token"]
    raw_sub = str(subpath or "").strip().replace("\\", "/").strip("/")

    if share.get("password_protected") and not unlocked:
        if raw_sub:
            raise HTTPException(
                status_code=401,
                detail="Tautan ini dilindungi kata sandi. Silakan buka kunci tautan terlebih dahulu.",
            )
        return {
            "token": token,
            "label": share["label"],
            "is_dir": bool(share["is_dir"]),
            "target_is_dir": bool(share["is_dir"]),
            "password_required": True,
            "unlocked": False,
            "expires_at": share.get("expires_at"),
            "status": share.get("status", "active"),
            "download_count": int(share.get("download_count") or 0),
            "subpath": "",
            "parent_subpath": "",
            "items": [],
        }

    _, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    _, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root, share, subpath=raw_sub, db_path=db_path
    )

    is_target_dir = os.path.isdir(target_abs)
    parent_sub = os.path.dirname(clean_sub).replace("\\", "/") if clean_sub else ""
    q_clean_sub = f"?subpath={urllib.parse.quote(clean_sub)}" if clean_sub else ""

    if is_target_dir:
        items: List[Dict[str, Any]] = []
        try:
            for entry in os.scandir(target_abs):
                if entry.name.startswith(".") or entry.name.endswith(".part"):
                    continue
                entry_real = os.path.realpath(entry.path)
                try:
                    if os.path.commonpath([share_root_abs, entry_real]) != share_root_abs:
                        continue
                except ValueError:
                    continue
                try:
                    st = entry.stat()
                    entry_is_dir = entry.is_dir()
                    size = 0 if entry_is_dir else int(st.st_size)
                    mtime = int(st.st_mtime)
                except Exception:
                    continue

                item_sub = f"{clean_sub}/{entry.name}" if clean_sub else entry.name
                q_item_sub = urllib.parse.quote(item_sub)
                ext = "" if entry_is_dir else os.path.splitext(entry.name)[1].lower()
                mime_type = (
                    "inode/directory"
                    if entry_is_dir
                    else (mimetypes.guess_type(entry.name)[0] or "application/octet-stream")
                )
                p_kind = classify_preview_kind(entry.name, is_dir=entry_is_dir)
                items.append(
                    {
                        "name": entry.name,
                        "subpath": item_sub,
                        "is_dir": entry_is_dir,
                        "size": size,
                        "mtime": mtime,
                        "extension": ext,
                        "mime_type": mime_type,
                        "preview_kind": p_kind,
                        "stream_url": f"/api/v1/share/{token}/stream?subpath={q_item_sub}",
                        "download_url": f"/api/v1/share/{token}/download?subpath={q_item_sub}",
                    }
                )
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Gagal membaca isi folder: {exc}")

        items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
        return {
            "token": token,
            "label": share["label"],
            "name": os.path.basename(target_abs) if clean_sub else share["label"],
            "is_dir": bool(share["is_dir"]),
            "target_is_dir": True,
            "password_required": bool(share.get("password_protected")),
            "unlocked": True,
            "expires_at": share.get("expires_at"),
            "status": share.get("status", "active"),
            "download_count": int(share.get("download_count") or 0),
            "subpath": clean_sub,
            "parent_subpath": parent_sub,
            "preview_kind": "folder",
            "download_url": f"/api/v1/share/{token}/download{q_clean_sub}",
            "items": items,
        }

    # Single file target (either root file share or file inside shared directory)
    st = os.stat(target_abs)
    fname = os.path.basename(target_abs)
    ext = os.path.splitext(fname)[1].lower()
    mime_type = mimetypes.guess_type(fname)[0] or "application/octet-stream"
    p_kind = classify_preview_kind(fname, is_dir=False)
    text_preview: Optional[str] = None
    if p_kind == "text" and st.st_size <= 256 * 1024:
        try:
            with open(target_abs, "rb") as f:
                raw_bytes = f.read(65536)
            text_preview = raw_bytes.decode("utf-8", errors="replace")
        except Exception:
            text_preview = None

    return {
        "token": token,
        "label": share["label"],
        "name": fname,
        "is_dir": bool(share["is_dir"]),
        "target_is_dir": False,
        "password_required": bool(share.get("password_protected")),
        "unlocked": True,
        "expires_at": share.get("expires_at"),
        "status": share.get("status", "active"),
        "download_count": int(share.get("download_count") or 0),
        "subpath": clean_sub,
        "parent_subpath": parent_sub,
        "size": int(st.st_size),
        "mtime": int(st.st_mtime),
        "extension": ext,
        "mime_type": mime_type,
        "preview_kind": p_kind,
        "text_preview": text_preview,
        "stream_url": f"/api/v1/share/{token}/stream{q_clean_sub}",
        "download_url": f"/api/v1/share/{token}/download{q_clean_sub}",
        "items": [],
    }


def stream_directory_as_zip_file(
    share_root_abs: str,
    target_dir_abs: str,
    archive_root_name: str,
):
    """
    Create a spooled temporary .zip archive (in-memory up to 16 MB, spilling to disk above 16 MB)
    containing only files strictly confined inside share_root_abs.
    Returns (spooled_file, total_zip_bytes).
    """
    safe_root = (
        os.path.basename(str(archive_root_name or "shared_folder").strip().rstrip("/\\"))
        or "shared_folder"
    )
    spooled = tempfile.SpooledTemporaryFile(max_size=16 * 1024 * 1024, mode="w+b")
    written_entries = 0

    with zipfile.ZipFile(spooled, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(target_dir_abs, followlinks=False):
            valid_dirs = []
            for d in sorted(dirs):
                if d.startswith("."):
                    continue
                d_full = os.path.join(root, d)
                if os.path.islink(d_full):
                    continue
                d_real = os.path.realpath(d_full)
                try:
                    if os.path.commonpath([share_root_abs, d_real]) == share_root_abs:
                        valid_dirs.append(d)
                except ValueError:
                    continue
            dirs[:] = valid_dirs

            for f in sorted(files):
                if f.startswith(".") or f.endswith(".part"):
                    continue
                full_entry = os.path.join(root, f)
                if os.path.islink(full_entry):
                    continue
                entry_real = os.path.realpath(full_entry)
                try:
                    if os.path.commonpath([share_root_abs, entry_real]) != share_root_abs:
                        continue
                except ValueError:
                    continue
                if not os.path.isfile(entry_real):
                    continue
                rel_in_target = os.path.relpath(entry_real, target_dir_abs).replace("\\", "/")
                arcname = f"{safe_root}/{rel_in_target}"
                zf.write(entry_real, arcname=arcname)
                written_entries += 1

        if written_entries == 0:
            zf.writestr(f"{safe_root}/", b"")

    spooled.seek(0, os.SEEK_END)
    total_zip_bytes = int(spooled.tell())
    spooled.seek(0)
    return spooled, total_zip_bytes


def render_public_share_viewer_html(
    share: Optional[Dict[str, Any]],
    status_code: int = 200,
    error_title: str = "",
    error_message: str = "",
) -> str:
    """Render standalone dark Public Share Viewer HTML page matching 06-UI-SPEC Surface 3."""
    if status_code != 200 or not share:
        safe_err_title = html.escape(
            error_title
            or ("Tautan Tidak Ditemukan" if status_code == 404 else "Tautan Kedaluwarsa atau Dicabut"),
            quote=True,
        )
        safe_err_msg = html.escape(
            error_message
            or (
                "Tautan berbagi publik yang Anda akses tidak terdaftar atau salah ketik."
                if status_code == 404
                else "Tautan berbagi publik ini sudah melewati batas waktu aktif atau telah dicabut oleh pemiliknya."
            ),
            quote=True,
        )
        return f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{safe_err_title} - MyServer Share</title>
    <style>
        :root {{
            --bg-base: #090d16;
            --bg-surface: #111827;
            --bg-card: #1e293b;
            --accent: #84cc16;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border: rgba(148, 163, 184, 0.18);
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background: var(--bg-base);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }}
        .error-card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            max-width: 460px;
            width: 100%;
            padding: 36px 28px;
            text-align: center;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.55);
        }}
        .status-badge {{
            display: inline-block;
            background: rgba(239, 68, 68, 0.15);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.35);
            font-size: 12px;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 16px;
        }}
        h1 {{ font-size: 20px; font-weight: 700; margin-bottom: 10px; }}
        p {{ font-size: 14px; color: var(--text-muted); line-height: 1.6; }}
    </style>
</head>
<body>
    <div class="error-card">
        <span class="status-badge">HTTP {int(status_code)}</span>
        <h1>{safe_err_title}</h1>
        <p>{safe_err_msg}</p>
    </div>
</body>
</html>"""

    safe_token = html.escape(str(share["token"]), quote=True)
    safe_label = html.escape(str(share.get("label") or "Berkas Bersama"), quote=True)
    is_dir = bool(share.get("is_dir"))
    type_badge = "Folder Bersama" if is_dir else "Berkas Bersama"
    dl_btn_label = "Unduh ZIP" if is_dir else "Unduh"
    safe_expires = html.escape(str(share.get("expires_at") or "Tanpa Batas Waktu"), quote=True)
    dl_count = int(share.get("download_count") or 0)
    token_js_json = json.dumps(str(share["token"]))

    return f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{safe_label} - MyServer Public Share</title>
    <style>
        :root {{
            --bg-base: #090d16;
            --bg-surface: #111827;
            --bg-card: #1e293b;
            --accent: #84cc16;
            --accent-hover: #65a30d;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border: rgba(148, 163, 184, 0.18);
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background: var(--bg-base);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }}
        .topbar {{
            background: var(--bg-surface);
            border-bottom: 1px solid var(--border);
            padding: 14px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
        }}
        .brand-wrap {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .brand-icon {{
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: rgba(132, 204, 22, 0.15);
            border: 1px solid rgba(132, 204, 22, 0.4);
            color: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
        }}
        .share-title {{
            font-size: 16px;
            font-weight: 700;
            color: var(--text-main);
        }}
        .share-badges {{
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 3px;
        }}
        .badge {{
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--bg-card);
            color: var(--text-muted);
            border: 1px solid var(--border);
        }}
        .btn-primary {{
            background: var(--accent);
            color: #090d16;
            font-weight: 700;
            font-size: 13px;
            padding: 9px 16px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }}
        .btn-primary:hover {{ background: var(--accent-hover); color: #ffffff; }}
        .btn-secondary {{
            background: var(--bg-card);
            color: var(--text-main);
            border: 1px solid var(--border);
            font-size: 12px;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
        }}
        .container {{
            max-width: 1040px;
            width: 100%;
            margin: 24px auto;
            padding: 0 20px 40px;
            flex: 1;
        }}
        .card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 24px;
            margin-bottom: 20px;
        }}
        .unlock-card {{
            max-width: 420px;
            margin: 48px auto;
            text-align: center;
        }}
        .form-input {{
            width: 100%;
            background: var(--bg-card);
            border: 1px solid var(--border);
            color: var(--text-main);
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 14px;
            margin: 14px 0;
        }}
        .error-text {{
            color: #f87171;
            font-size: 13px;
            margin-bottom: 10px;
            display: none;
        }}
        .preview-stage {{
            min-height: 260px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #050811;
            border-radius: 10px;
            overflow: hidden;
            padding: 16px;
        }}
        .preview-stage img, .preview-stage video {{
            max-width: 100%;
            max-height: 70vh;
            border-radius: 8px;
        }}
        .preview-stage pre {{
            width: 100%;
            max-height: 65vh;
            overflow: auto;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-size: 13px;
            color: #e2e8f0;
            text-align: left;
            white-space: pre-wrap;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
            margin-bottom: 14px;
            font-size: 13px;
        }}
        .crumb-btn {{
            background: transparent;
            border: none;
            color: var(--accent);
            cursor: pointer;
            font-weight: 600;
        }}
        .items-table {{
            width: 100%;
            border-collapse: collapse;
        }}
        .items-table th, .items-table td {{
            padding: 11px 12px;
            border-bottom: 1px solid var(--border);
            text-align: left;
            font-size: 13px;
        }}
        .items-table tr:hover {{
            background: rgba(30, 41, 59, 0.55);
        }}
    </style>
</head>
<body>
    <header class="topbar">
        <div class="brand-wrap">
            <div class="brand-icon">MS</div>
            <div>
                <div class="share-title" id="shareHeaderTitle">{safe_label}</div>
                <div class="share-badges">
                    <span class="badge" id="shareTypeBadge">{type_badge}</span>
                    <span class="badge" id="shareExpiryBadge">Berlaku: {safe_expires}</span>
                    <span class="badge" id="shareDownloadCountBadge">Unduhan: {dl_count}</span>
                </div>
            </div>
        </div>
        <div>
            <a class="btn-primary" id="btnSharePrimaryDownload" href="/api/v1/share/{safe_token}/download">{dl_btn_label}</a>
        </div>
    </header>

    <main class="container">
        <section class="card unlock-card" id="shareUnlockCard" style="display: none;">
            <h2>Tautan Dilindungi Kata Sandi</h2>
            <p style="font-size: 13px; color: var(--text-muted); margin-top: 6px;">Masukkan kata sandi untuk melihat atau mengunduh berkas ini.</p>
            <input type="password" class="form-input" id="sharePasswordInput" placeholder="Kata sandi tautan">
            <div class="error-text" id="shareUnlockError"></div>
            <button type="button" class="btn-primary" id="btnUnlockShare" onclick="unlockProtectedShare()">Buka Tautan</button>
        </section>

        <section class="card" id="shareViewerSection" style="display: none;">
            <div class="preview-stage" id="sharePreviewStage"></div>
        </section>

        <section class="card" id="shareFolderSection" style="display: none;">
            <div class="breadcrumbs" id="shareBreadcrumbs"></div>
            <table class="items-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Ukuran</th>
                        <th style="text-align: right;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="shareItemsList"></tbody>
            </table>
        </section>
    </main>

    <script>
        const SHARE_TOKEN = {token_js_json};
        let currentSubpath = "";

        function escapeHtml(str) {{
            return String(str == null ? "" : str)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#39;");
        }}

        function formatBytes(bytes) {{
            const n = Number(bytes || 0);
            if (n <= 0) return "0 B";
            const units = ["B", "KB", "MB", "GB", "TB"];
            const i = Math.min(units.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
            return (n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + " " + units[i];
        }}

        async function loadShareMeta(subpath = "") {{
            currentSubpath = subpath || "";
            const q = currentSubpath ? ("?subpath=" + encodeURIComponent(currentSubpath)) : "";
            const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/meta" + q, {{
                credentials: "same-origin"
            }});
            if (!resp.ok) {{
                return;
            }}
            const data = await resp.json();
            const unlockCard = document.getElementById("shareUnlockCard");
            const viewerSec = document.getElementById("shareViewerSection");
            const folderSec = document.getElementById("shareFolderSection");
            const dlBtn = document.getElementById("btnSharePrimaryDownload");

            if (data.password_required && !data.unlocked) {{
                unlockCard.style.display = "block";
                viewerSec.style.display = "none";
                folderSec.style.display = "none";
                return;
            }}

            unlockCard.style.display = "none";
            if (dlBtn && data.download_url) {{
                dlBtn.href = data.download_url;
                dlBtn.textContent = data.target_is_dir ? "Unduh ZIP" : "Unduh";
            }}

            if (data.target_is_dir) {{
                folderSec.style.display = "block";
                viewerSec.style.display = "none";
                renderFolderNavigator(data);
            }} else {{
                folderSec.style.display = data.is_dir ? "block" : "none";
                viewerSec.style.display = "block";
                renderFilePreview(data);
            }}
        }}

        function renderFilePreview(meta) {{
            const stage = document.getElementById("sharePreviewStage");
            stage.innerHTML = "";
            const kind = meta.preview_kind || "file";
            if (kind === "image") {{
                const img = document.createElement("img");
                img.src = meta.stream_url;
                img.alt = meta.name || meta.label || "";
                stage.appendChild(img);
            }} else if (kind === "video") {{
                const vid = document.createElement("video");
                vid.controls = true;
                vid.preload = "metadata";
                vid.src = meta.stream_url;
                stage.appendChild(vid);
            }} else if (kind === "audio") {{
                const aud = document.createElement("audio");
                aud.controls = true;
                aud.preload = "metadata";
                aud.src = meta.stream_url;
                stage.appendChild(aud);
            }} else if (kind === "pdf") {{
                const frame = document.createElement("iframe");
                frame.setAttribute("sandbox", "");
                frame.style.width = "100%";
                frame.style.height = "65vh";
                frame.style.border = "none";
                frame.src = meta.stream_url;
                stage.appendChild(frame);
            }} else if (kind === "text" && meta.text_preview != null) {{
                const pre = document.createElement("pre");
                pre.textContent = meta.text_preview;
                stage.appendChild(pre);
            }} else {{
                const box = document.createElement("div");
                box.style.textAlign = "center";
                const p = document.createElement("p");
                p.textContent = (meta.name || meta.label || "Berkas") + " (" + formatBytes(meta.size) + ")";
                box.appendChild(p);
                stage.appendChild(box);
            }}
        }}

        function renderFolderNavigator(meta) {{
            const crumbsEl = document.getElementById("shareBreadcrumbs");
            crumbsEl.innerHTML = "";
            const rootBtn = document.createElement("button");
            rootBtn.className = "crumb-btn";
            rootBtn.textContent = meta.label || "Root";
            rootBtn.onclick = () => loadShareMeta("");
            crumbsEl.appendChild(rootBtn);

            if (meta.subpath) {{
                const parts = meta.subpath.split("/").filter(Boolean);
                let acc = "";
                parts.forEach((part) => {{
                    acc = acc ? (acc + "/" + part) : part;
                    const targetSub = acc;
                    const sep = document.createElement("span");
                    sep.textContent = "/";
                    crumbsEl.appendChild(sep);
                    const btn = document.createElement("button");
                    btn.className = "crumb-btn";
                    btn.textContent = part;
                    btn.onclick = () => loadShareMeta(targetSub);
                    crumbsEl.appendChild(btn);
                }});
            }}

            const tbody = document.getElementById("shareItemsList");
            tbody.innerHTML = "";
            (meta.items || []).forEach((item) => {{
                const tr = document.createElement("tr");
                const tdName = document.createElement("td");
                tdName.textContent = (item.is_dir ? "📁 " : "📄 ") + item.name;
                if (item.is_dir) {{
                    tdName.style.cursor = "pointer";
                    tdName.onclick = () => loadShareMeta(item.subpath);
                }}
                const tdSize = document.createElement("td");
                tdSize.textContent = item.is_dir ? "Folder" : formatBytes(item.size);
                const tdAct = document.createElement("td");
                tdAct.style.textAlign = "right";

                const openBtn = document.createElement("button");
                openBtn.className = "btn-secondary";
                openBtn.style.marginRight = "6px";
                openBtn.textContent = item.is_dir ? "Buka" : "Preview";
                openBtn.onclick = () => loadShareMeta(item.subpath);
                tdAct.appendChild(openBtn);

                const dlLink = document.createElement("a");
                dlLink.className = "btn-secondary";
                dlLink.href = item.download_url;
                dlLink.textContent = item.is_dir ? "ZIP" : "Unduh";
                tdAct.appendChild(dlLink);

                tr.appendChild(tdName);
                tr.appendChild(tdSize);
                tr.appendChild(tdAct);
                tbody.appendChild(tr);
            }});
        }}

        async function unlockProtectedShare() {{
            const pwdInput = document.getElementById("sharePasswordInput");
            const errEl = document.getElementById("shareUnlockError");
            errEl.style.display = "none";
            const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/auth", {{
                method: "POST",
                headers: {{ "Content-Type": "application/json" }},
                credentials: "same-origin",
                body: JSON.stringify({{ password: pwdInput.value || "" }})
            }});
            if (!resp.ok) {{
                errEl.textContent = "Kata sandi salah atau tautan sudah tidak berlaku.";
                errEl.style.display = "block";
                return;
            }}
            await loadShareMeta(currentSubpath);
        }}

        window.addEventListener("DOMContentLoaded", () => {{
            loadShareMeta("");
        }});
    </script>
</body>
</html>"""


@router.get("/s/{token}", response_class=HTMLResponse, include_in_schema=False)
def get_public_share_viewer_page(token: str):
    """Menyajikan halaman HTML Public Share Viewer mandiri (200 aktif, 404 tidak ditemukan, 410 kedaluwarsa/dicabut)."""
    db_path = _db_path()
    share = get_public_share(token, db_path=db_path, include_secret=False)
    if not share:
        html_404 = render_public_share_viewer_html(
            None,
            status_code=404,
            error_title="Tautan Tidak Ditemukan",
            error_message="Tautan berbagi publik yang Anda akses tidak ditemukan atau tidak valid.",
        )
        return HTMLResponse(content=html_404, status_code=404)

    if share.get("revoked") or share.get("is_expired") or share.get("status") != "active":
        html_410 = render_public_share_viewer_html(
            share,
            status_code=410,
            error_title="Tautan Kedaluwarsa atau Dicabut",
            error_message="Tautan berbagi publik ini telah melewati masa berlaku atau dicabut oleh pemiliknya.",
        )
        return HTMLResponse(content=html_410, status_code=410)

    html_200 = render_public_share_viewer_html(share, status_code=200)
    return HTMLResponse(content=html_200, status_code=200)


@router.post("/api/v1/share/{token}/auth")
def authenticate_public_share(
    token: str,
    req: PublicShareAuthRequest,
    response: Response = None,
):
    """Memverifikasi kata sandi tautan berbagi publik dan menerbitkan cookie sesi HMAC."""
    db_path = _db_path()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    pwd_hash = str(share.get("password_hash") or "").strip()
    if pwd_hash:
        if not req or not req.password or not verify_password(str(req.password), pwd_hash):
            raise HTTPException(status_code=401, detail="Kata sandi tautan tidak valid.")

    access_token = create_share_access_token(
        share["token"],
        pwd_hash,
        ttl_seconds=SHARE_SESSION_TTL_SECONDS,
    )
    cookie_key = share_cookie_name(share["token"])
    if response is not None and hasattr(response, "set_cookie"):
        response.set_cookie(
            key=cookie_key,
            value=access_token,
            max_age=SHARE_SESSION_TTL_SECONDS,
            path="/",
            httponly=True,
            samesite="lax",
        )
    return {
        "success": True,
        "token": share["token"],
        "access_token": access_token,
        "cookie_name": cookie_key,
        "expires_in": SHARE_SESSION_TTL_SECONDS,
    }


@router.get("/api/v1/share/{token}/meta")
def get_public_share_metadata(
    token: str,
    subpath: Optional[str] = Query(default=""),
    request: Request = None,
):
    """Mengembalikan metadata berkas atau daftar isi sub-folder di dalam direktori yang dibagikan."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    unlocked = is_share_request_unlocked(share, request=request)
    return build_share_meta_payload(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        unlocked=unlocked,
        db_path=db_path,
    )


@router.get("/api/v1/share/{token}/stream")
def stream_public_share_content(
    token: str,
    subpath: Optional[str] = Query(default=""),
    request: Request = None,
):
    """Menyajikan konten berkas inline dengan dukungan HTTP Range (206 Partial Content) dan header keamanan CSP."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    _, target_abs, _ = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        db_path=db_path,
    )
    if os.path.isdir(target_abs):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    range_header = None
    if request is not None:
        hdrs = getattr(request, "headers", None)
        if hdrs and hasattr(hdrs, "get"):
            range_header = hdrs.get("range") or hdrs.get("Range")

    return stream_file_range(target_abs, range_header=range_header)


@router.get("/api/v1/share/{token}/download")
def download_public_share_content(
    token: str,
    subpath: Optional[str] = Query(default=""),
    request: Request = None,
):
    """Mengunduh berkas tunggal atau melakukan streaming arsip .zip untuk folder, sembari menambah download_count."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    _, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    target_rel, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        db_path=db_path,
    )

    increment_share_download_count(share["token"], db_path=db_path)
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_DOWNLOAD",
            f"Unduhan publik pada tautan '{share['token']}' ({target_rel})",
            {"token": share["token"], "path": target_rel, "subpath": clean_sub},
            db_path=db_path,
        )
    except Exception:
        pass

    if os.path.isdir(target_abs):
        archive_base = os.path.basename(target_abs) if clean_sub else (share.get("label") or os.path.basename(target_abs))
        safe_zip_name = (
            os.path.basename(str(archive_base or "shared_folder").strip())
            .replace('"', "_")
            .replace("\r", "")
            .replace("\n", "")
        )
        if not safe_zip_name.lower().endswith(".zip"):
            safe_zip_name = f"{safe_zip_name}.zip"

        spooled, total_zip_bytes = stream_directory_as_zip_file(
            share_root_abs=share_root_abs,
            target_dir_abs=target_abs,
            archive_root_name=os.path.splitext(safe_zip_name)[0],
        )

        def zip_streamer():
            try:
                while chunk := spooled.read(256 * 1024):
                    yield chunk
            finally:
                try:
                    spooled.close()
                except Exception:
                    pass

        headers = {
            "Content-Disposition": f'attachment; filename="{safe_zip_name}"',
            "Content-Length": str(total_zip_bytes),
            "Content-Type": "application/zip",
            "X-Content-Type-Options": "nosniff",
        }
        return StreamingResponse(zip_streamer(), status_code=200, headers=headers)

    filename = os.path.basename(target_abs)
    safe_disp = filename.replace('"', "_").replace("\r", "").replace("\n", "")
    file_size = os.path.getsize(target_abs)
    mime_type = mimetypes.guess_type(target_abs)[0] or "application/octet-stream"

    def file_streamer():
        with open(target_abs, "rb") as f:
            while chunk := f.read(256 * 1024):
                yield chunk

    headers = {
        "Content-Disposition": f'attachment; filename="{safe_disp}"',
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        "Accept-Ranges": "bytes",
        "X-Content-Type-Options": "nosniff",
    }
    return StreamingResponse(file_streamer(), status_code=200, headers=headers)
