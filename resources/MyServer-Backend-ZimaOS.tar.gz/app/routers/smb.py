"""
SMB Management Router for MyServer Native Backend
Provides /api/v1/smb/status, /mode, /sync, and /shares with JWT enforcement.
"""

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from app.auth import HTTPException, get_current_user, status
from app.config import is_admin_username
from app.database import (
    create_or_update_user,
    get_user_by_username,
    log_activity,
    verify_password,
)
from app.models import SmbModeRequest, SmbShareItem, SmbSharesResponse, SmbStatusResponse
from app.services.smb_manager import (
    get_smb_shares_for_user,
    get_smb_status,
    set_smb_mode,
    sync_samba_configuration,
    sync_unix_and_samba_user,
)

try:
    from fastapi import APIRouter, Depends
except ImportError:
    Depends = lambda fn=None: fn

    class APIRouter:
        def __init__(self, **kw):
            pass

        def get(self, *a, **kw):
            return lambda f: f

        def post(self, *a, **kw):
            return lambda f: f

        def put(self, *a, **kw):
            return lambda f: f

        def delete(self, *a, **kw):
            return lambda f: f


logger = logging.getLogger("myserver.smb")
router = APIRouter(prefix="/api/v1/smb", tags=["SMB Management"])


def _resolve_caller_identity(
    current_user: Any,
) -> Tuple[str, str, bool, List[str], Optional[Dict[str, Any]]]:
    if not isinstance(current_user, dict):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Autentikasi JWT wajib disertakan.",
        )
    jwt_user = str(current_user.get("sub") or "").strip().lower()
    if not jwt_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Identitas token JWT tidak valid.",
        )
    user_rec = get_user_by_username(jwt_user)
    role = str(
        (user_rec.get("role") if user_rec else None)
        or current_user.get("role")
        or "staff"
    ).strip().lower()
    is_admin = bool(role in ("admin", "root") or is_admin_username(jwt_user))
    allowed_disks: List[str] = []
    if user_rec and user_rec.get("allowed_disks"):
        raw = user_rec.get("allowed_disks")
        if isinstance(raw, list):
            allowed_disks = [str(d).strip() for d in raw if str(d).strip()]
        else:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, list):
                    allowed_disks = [str(d).strip() for d in parsed if str(d).strip()]
            except Exception:
                allowed_disks = []
    return jwt_user, role, is_admin, allowed_disks, user_rec


@router.get("/status", response_model=SmbStatusResponse)
def get_smb_service_status(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil status terkini layanan SMB (ZimaOS vs Backend) dan daftar share."""
    _resolve_caller_identity(current_user)
    st = get_smb_status()
    return SmbStatusResponse(**st)


@router.get("/shares", response_model=SmbSharesResponse)
def get_smb_user_shares(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil daftar share SMB yang diizinkan untuk akun JWT yang sedang login."""
    jwt_user, role, is_admin, allowed_disks, _ = _resolve_caller_identity(current_user)
    shares_raw = get_smb_shares_for_user(
        jwt_user, role=role, allowed_disks=allowed_disks
    )
    st = get_smb_status()
    return SmbSharesResponse(
        mode=st["mode"],
        shares=[SmbShareItem(**s) for s in shares_raw],
        username=jwt_user,
        is_admin=is_admin,
    )


@router.post("/mode", response_model=SmbStatusResponse)
def switch_smb_mode(
    req: SmbModeRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Mengubah pemilik port 445 secara mutual-exclusive antara 'zimaos' dan 'backend'.
    - Mode 'backend': diizinkan untuk admin/root, atau user terautentikasi JWT dengan
      verifikasi kecocokan req.username == current_user['sub'] dan kata sandi SQLite.
    - Mode 'zimaos': diizinkan untuk admin/root maupun pemanggil JWT valid untuk melepas
      port 445 kembali ke host ZimaOS (ditolak 403 jika menyertakan username berbeda
      atau kata sandi salah).
    """
    jwt_user, role, is_admin, allowed_disks, user_rec = _resolve_caller_identity(current_user)
    mode = str(getattr(req, "mode", "") or "").strip().lower()
    if mode not in ("zimaos", "backend"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Mode SMB harus 'zimaos' atau 'backend'.",
        )

    req_user = str(getattr(req, "username", None) or "").strip().lower()
    req_pass = getattr(req, "password", None)

    if mode == "backend":
        if not is_admin:
            if not req_user or req_user != jwt_user or not req_pass:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Aktivasi mode SMB Backend oleh pengguna non-admin wajib menyertakan kredensial akun sendiri yang valid.",
                )
            if not user_rec or not user_rec.get("password_hash") or not verify_password(
                req_pass, user_rec["password_hash"]
            ):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Kata sandi akun tidak valid untuk mengaktifkan mode SMB Backend.",
                )
            create_or_update_user(
                username=jwt_user,
                password=req_pass,
                role=role,
                allowed_disks=allowed_disks,
            )
            sync_unix_and_samba_user(
                jwt_user, password=req_pass, uid_hint=user_rec["id"]
            )
        elif req_user or req_pass:
            if req_user and req_user != jwt_user:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Username permintaan tidak sesuai dengan akun yang sedang login.",
                )
            if req_pass:
                if user_rec and user_rec.get("password_hash") and not verify_password(
                    req_pass, user_rec["password_hash"]
                ):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Kata sandi akun tidak valid.",
                    )
                if user_rec:
                    create_or_update_user(
                        username=jwt_user,
                        password=req_pass,
                        role=role,
                        allowed_disks=allowed_disks,
                    )
                    sync_unix_and_samba_user(
                        jwt_user, password=req_pass, uid_hint=user_rec["id"]
                    )
    else:
        # Mode 'zimaos': melepas port 445 kembali ke host ZimaOS
        if not is_admin:
            if req_user and req_user != jwt_user:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Username permintaan tidak sesuai dengan akun yang sedang login.",
                )
            if req_pass:
                if not user_rec or not user_rec.get("password_hash") or not verify_password(
                    req_pass, user_rec["password_hash"]
                ):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Kata sandi akun tidak valid.",
                    )

    res = set_smb_mode(mode)
    log_activity(
        device_id=None,
        task_id=None,
        action="SMB_MODE_CHANGED",
        message=f"Pengguna '{jwt_user}' mengubah mode SMB ke '{mode}'.",
        details={"mode": mode, "username": jwt_user},
    )
    return SmbStatusResponse(**res)


@router.post("/sync")
def trigger_smb_sync(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Menyinkronkan ulang seluruh akun Samba dan smb.conf (Hanya Administrator)."""
    jwt_user, _, is_admin, _, _ = _resolve_caller_identity(current_user)
    if not is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan menyinkronkan konfigurasi SMB.",
        )
    res = sync_samba_configuration()
    log_activity(
        device_id=None,
        task_id=None,
        action="SMB_SYNCED",
        message=f"Administrator '{jwt_user}' menyinkronkan konfigurasi Samba ({res.get('users_count', 0)} user, {res.get('shares_count', 0)} share).",
        details={"users_count": res.get("users_count", 0), "shares_count": res.get("shares_count", 0)},
    )
    return res
