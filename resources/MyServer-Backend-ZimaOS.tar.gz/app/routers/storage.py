"""
Storage & Directory Browsing Router for MyServer Native Backend
Provides remote folder exploration and directory creation for Remote Folder Picker UI.
"""

import asyncio
import concurrent.futures
import email.utils
import gc
import os
import json
import queue
import re
import shutil
import struct
import sys
import tempfile
import threading
import time
import mimetypes
import hashlib
import html
import subprocess
import urllib.parse
import uuid
try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except Exception:  # pragma: no cover
    pillow_heif = None

_HEIF_EXTS = {".heic", ".heif", ".hif"}
_HEIF_INSTALL_LOCK = threading.Lock()
_HEIF_INSTALL_ATTEMPTED = False


def _ensure_heif_support() -> bool:
    """Pastikan pillow-heif terdaftar; jika belum ada di container OTA lama, pasang sekali secara otomatis."""
    global pillow_heif, _HEIF_INSTALL_ATTEMPTED
    if pillow_heif is not None:
        return True
    try:
        import pillow_heif as _ph  # type: ignore
        _ph.register_heif_opener()
        pillow_heif = _ph
        return True
    except Exception:
        pass
    with _HEIF_INSTALL_LOCK:
        if pillow_heif is not None:
            return True
        if _HEIF_INSTALL_ATTEMPTED:
            return False
        _HEIF_INSTALL_ATTEMPTED = True
        if (
            os.environ.get("MYSERVER_DISABLE_AUTO_PIP", "").strip() == "1"
            or "unittest" in sys.modules
            or "pytest" in sys.modules
        ):
            return False
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--no-cache-dir", "--quiet", "pillow-heif>=0.16.0"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=45.0,
                check=False,
            )
            import pillow_heif as _ph2  # type: ignore
            _ph2.register_heif_opener()
            pillow_heif = _ph2
            return True
        except Exception as exc:
            logger.warning(f"Auto-install pillow-heif gagal: {exc}")
            return False
try:
    import aiofiles
except ImportError:  # pragma: no cover
    aiofiles = None
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any, Union, Tuple, Set
import logging
logger = logging.getLogger(__name__)
try:
    from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, File, UploadFile, Form
    from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
except ImportError:
    Depends = lambda fn=None: fn

    class APIRouter:
        def __init__(self, *a, **k): pass
        def __getattr__(self, name): return lambda *a, **k: (lambda f: f)

    from app.auth import HTTPException
    Query = lambda default=None, **kw: default
    File = Form = lambda default=None, **kw: default
    Request = UploadFile = object

    class _FallbackResponse:
        def __init__(self, content=None, status_code=200, headers=None, media_type=None, path=None):
            self.content = content
            self.body = content.encode("utf-8") if isinstance(content, str) else content
            self.status_code = status_code
            self.headers = headers or {}
            self.media_type = media_type
            self.path = path

    Response = StreamingResponse = FileResponse = HTMLResponse = _FallbackResponse

import app.config
from app.config import STORAGE_DIR, TEMP_DIR, DATA_DIR, DB_PATH, is_admin_username
from app.auth import create_stream_token, get_current_user, publish_realtime_event, verify_active_jwt_user
from app.models import BaseModel
from app.models import (
    StorageBrowseFilesResponse, StorageDiskItem, StorageDisksResponse, DiskEntry,
    CloudAccountItemResponse, CloudAccountListResponse, CloudAccountConnectRequest,
    PublicShareCreateRequest, PublicShareSettingsRequest,
    InternalShareCreateRequest, InternalShareUpdateRequest, RenameRequest,
    GalleryConfigRequest,
)
from app.database import (
    log_activity, track_session, get_active_sessions, get_activity_logs, get_db,
    create_or_update_cloud_account, get_cloud_accounts_by_user, get_cloud_account_by_id,
    delete_cloud_account, get_or_create_user, get_user_by_id, get_user_by_username, normalize_user_role,
    get_user_preference, set_user_preference,
    get_media_metadata_batch, upsert_media_metadata_batch,
    create_public_share, get_public_share, list_public_shares, revoke_public_share,
    get_public_base_url, set_public_base_url,
    upsert_internal_share, update_internal_share_role, get_internal_share_by_id,
    list_internal_shares_for_path, list_internal_shares_for_grantee, delete_internal_share,
    delete_internal_shares_under_path, list_share_account_candidates,
    record_internal_share_upload, get_internal_upload_owner, list_internal_owned_paths_in_dir,
    is_internal_dir_fully_owned_by_user, remove_internal_upload_records, move_internal_upload_records,
)
from app.services.smb_manager import (
    _UPLOAD_RENAME_LOCK,
    build_content_disposition,
    build_stream_security_headers,
    is_fuse_or_remote_mount,
    is_storage_path_forbidden,
    render_media_player_html,
    resolve_non_colliding_target,
    resolve_safe_storage_target,
)

router = APIRouter(prefix="/api/v1/storage", tags=["Storage & Folder Picker"])

DISK_USAGE_CACHE_TTL_SEC = 12.0
DISK_USAGE_FUSE_CACHE_TTL_SEC = 60.0
DISK_USAGE_PROBE_TIMEOUT_SEC = 2.5
SCANDIR_FUSE_TIMEOUT_SEC = 15.0
SCANDIR_FUSE_CACHE_TTL_SEC = 30.0
_DISK_USAGE_CACHE_LOCK = threading.Lock()
_DISK_USAGE_CACHE: Dict[str, Tuple[int, int, int, float]] = {}
_DISK_USAGE_INFLIGHT: Dict[str, threading.Thread] = {}
_FUSE_SCANDIR_CACHE_LOCK = threading.Lock()
_FUSE_SCANDIR_CACHE: Dict[Tuple[str, bool], Tuple[List[Dict[str, Any]], float]] = {}
_FUSE_SCANDIR_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="fuse-scandir")
THUMB_CACHE_MAX_BYTES = max(
    1024 * 1024,
    int(os.getenv("MYSERVER_THUMB_CACHE_MAX_BYTES", str(2 * 1024 * 1024 * 1024))),
)
THUMB_CACHE_TARGET_RATIO = 0.85
THUMB_PREWARM_QUEUE_MAX = 5000
_THUMB_SEMAPHORE = threading.BoundedSemaphore(2)
_THUMB_PRUNE_LOCK = threading.Lock()
_THUMB_LAST_PRUNE_TS = 0.0
_THUMB_PREWARM_LOCK = threading.Lock()
_THUMB_PREWARM_QUEUE: "queue.Queue[Tuple[str, str, int]]" = queue.Queue(maxsize=THUMB_PREWARM_QUEUE_MAX)
_THUMB_PREWARM_PENDING: Set[Tuple[str, int]] = set()
_THUMB_PREWARM_THREAD: Optional[threading.Thread] = None
_THUMB_PREWARM_RUNNING = False
_VALID_THUMB_IMG_EXTS = {
    ".jpg", ".jpeg", ".jpe", ".jfif", ".png", ".webp", ".bmp", ".gif", ".ico",
    ".tiff", ".tif", ".avif", ".heic", ".heif", ".hif", ".jxl", ".jp2", ".j2k",
    ".psd", ".tga", ".dds", ".dng", ".raw", ".cr2", ".cr3", ".nef", ".arw",
    ".orf", ".rw2", ".raf", ".pef", ".srw",
}
_VALID_THUMB_VIDEO_EXTS = {
    ".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ts", ".m2ts", ".mts",
    ".3gp", ".3g2", ".flv", ".f4v", ".wmv", ".asf", ".mpg", ".mpeg", ".mpe",
    ".mpv", ".ogv", ".vob", ".rm", ".rmvb", ".divx", ".xvid", ".mxf",
}
_STORAGE_JOBS_LOCK = threading.Lock()
_STORAGE_JOBS: Dict[str, Dict[str, Any]] = {}
_STORAGE_CHUNK_UPLOAD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
STREAM_CHUNK_SIZE = 128 * 1024
FADVISE_WINDOW_BYTES = 2 * 1024 * 1024
OPEN_ENDED_RANGE_MAX_BYTES = max(1, int(os.getenv("MYSERVER_STREAM_RANGE_MAX_MB", "4"))) * 1024 * 1024


def _fadvise_dontneed(fd: int, offset: int, length: int) -> None:
    """Lepaskan Linux kernel page cache setelah chunk selesai dikirim agar RAM tidak menumpuk."""
    fn = getattr(os, "posix_fadvise", None)
    flag = getattr(os, "POSIX_FADV_DONTNEED", None)
    if fn is None or flag is None or length <= 0:
        return
    try:
        fn(fd, max(0, int(offset)), int(length), flag)
    except OSError:
        pass


def invalidate_scandir_cache(path: Optional[str] = None) -> None:
    """Invalidate cached FUSE directory listings (all or by canonical path)."""
    with _FUSE_SCANDIR_CACHE_LOCK:
        if path is None:
            _FUSE_SCANDIR_CACHE.clear()
        else:
            real_p = os.path.realpath(path)
            for key in [k for k in _FUSE_SCANDIR_CACHE if k[0] == real_p]:
                _FUSE_SCANDIR_CACHE.pop(key, None)


def _scandir_bounded(target_dir: str, include_stat: bool = False, timeout_sec: float = SCANDIR_FUSE_TIMEOUT_SEC) -> List[Dict[str, Any]]:
    """Membaca direktori secara aman dengan batas waktu & cache saat target berada di mount FUSE/remote."""
    def _collect() -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        with os.scandir(target_dir) as it:
            for entry in it:
                try:
                    is_dir = entry.is_dir(follow_symlinks=False)
                    size = 0
                    mtime = 0
                    if include_stat:
                        try:
                            st = entry.stat(follow_symlinks=False)
                            size = 0 if is_dir else int(st.st_size)
                            mtime = int(st.st_mtime)
                        except Exception:
                            pass
                    rows.append({
                        "name": entry.name,
                        "is_dir": is_dir,
                        "size": size,
                        "mtime": mtime,
                    })
                except Exception:
                    continue
        return rows

    if not is_fuse_or_remote_mount(target_dir):
        return _collect()

    real_dir = os.path.realpath(target_dir)
    cache_key = (real_dir, bool(include_stat))
    now_ts = time.monotonic()
    with _FUSE_SCANDIR_CACHE_LOCK:
        cached = _FUSE_SCANDIR_CACHE.get(cache_key)
        if cached and (now_ts - cached[1]) < SCANDIR_FUSE_CACHE_TTL_SEC:
            return [dict(r) for r in cached[0]]

    fut = _FUSE_SCANDIR_EXECUTOR.submit(_collect)

    def _cache_when_done(done_fut: concurrent.futures.Future) -> None:
        try:
            res_rows = done_fut.result()
            with _FUSE_SCANDIR_CACHE_LOCK:
                _FUSE_SCANDIR_CACHE[cache_key] = ([dict(r) for r in res_rows], time.monotonic())
        except Exception:
            pass

    fut.add_done_callback(_cache_when_done)
    try:
        rows = fut.result(timeout=max(0.5, float(timeout_sec)))
        with _FUSE_SCANDIR_CACHE_LOCK:
            _FUSE_SCANDIR_CACHE[cache_key] = ([dict(r) for r in rows], time.monotonic())
        return rows
    except concurrent.futures.TimeoutError as exc:
        raise TimeoutError(f"Pembacaan direktori '{target_dir}' timeout (>{timeout_sec}s).") from exc


def invalidate_disk_usage_cache(path: Optional[str] = None) -> None:
    """Invalidate cached shutil.disk_usage() and FUSE scandir entries (all or by canonical path)."""
    with _DISK_USAGE_CACHE_LOCK:
        if path is None:
            _DISK_USAGE_CACHE.clear()
        else:
            _DISK_USAGE_CACHE.pop(os.path.realpath(path), None)
    invalidate_scandir_cache(path)


def _get_cached_disk_usage(path: str, ttl_sec: float = DISK_USAGE_CACHE_TTL_SEC) -> Tuple[int, int, int]:
    """Return cached (total, used, free) byte tuple keyed strictly by os.path.realpath(path) with timeout guard."""
    canon = os.path.realpath(path)
    effective_ttl = (
        DISK_USAGE_FUSE_CACHE_TTL_SEC
        if ttl_sec == DISK_USAGE_CACHE_TTL_SEC and is_fuse_or_remote_mount(canon)
        else ttl_sec
    )
    now_mono = time.monotonic()
    stale_entry: Optional[Tuple[int, int, int]] = None
    existing_thread: Optional[threading.Thread] = None
    with _DISK_USAGE_CACHE_LOCK:
        entry = _DISK_USAGE_CACHE.get(canon)
        if entry is not None:
            stale_entry = (entry[0], entry[1], entry[2])
            if (now_mono - entry[3]) < effective_ttl:
                return stale_entry
        cand_thread = _DISK_USAGE_INFLIGHT.get(canon)
        if cand_thread is not None and cand_thread.is_alive():
            existing_thread = cand_thread

    if existing_thread is not None:
        existing_thread.join(timeout=DISK_USAGE_PROBE_TIMEOUT_SEC)
        with _DISK_USAGE_CACHE_LOCK:
            refreshed = _DISK_USAGE_CACHE.get(canon)
            if refreshed is not None:
                return (refreshed[0], refreshed[1], refreshed[2])
        return stale_entry if stale_entry is not None else (0, 0, 0)

    result_box: Dict[str, Any] = {}

    def _probe() -> None:
        try:
            usage = shutil.disk_usage(path)
            vals = (int(usage.total), int(usage.used), int(usage.free))
            result_box["vals"] = vals
            # Warm cache even if caller already returned on timeout so next poll succeeds immediately.
            with _DISK_USAGE_CACHE_LOCK:
                _DISK_USAGE_CACHE[canon] = (vals[0], vals[1], vals[2], time.monotonic())
        except Exception as exc:
            result_box["err"] = exc
        finally:
            with _DISK_USAGE_CACHE_LOCK:
                if _DISK_USAGE_INFLIGHT.get(canon) is threading.current_thread():
                    _DISK_USAGE_INFLIGHT.pop(canon, None)

    t = threading.Thread(target=_probe, daemon=True)
    with _DISK_USAGE_CACHE_LOCK:
        _DISK_USAGE_INFLIGHT[canon] = t
    t.start()
    t.join(timeout=DISK_USAGE_PROBE_TIMEOUT_SEC)
    if t.is_alive() or "err" in result_box or "vals" not in result_box:
        return stale_entry if stale_entry is not None else (0, 0, 0)

    return result_box["vals"]


def _storage_dir() -> str:
    return str(getattr(app.config, "STORAGE_DIR", STORAGE_DIR))


def _data_dir() -> str:
    return str(getattr(app.config, "DATA_DIR", DATA_DIR))


def _temp_dir() -> str:
    cfg_temp = getattr(app.config, "TEMP_DIR", None)
    if cfg_temp and cfg_temp != TEMP_DIR:
        return str(cfg_temp)
    data_d = _data_dir()
    if data_d != DATA_DIR:
        return os.path.join(data_d, "temp_chunks")
    return str(TEMP_DIR)


def _db_path() -> str:
    return str(getattr(app.config, "DB_PATH", DB_PATH))


def _resolve_storage_or_400(storage_root: str, raw_rel: Optional[str]) -> Tuple[str, str]:
    try:
        return resolve_safe_storage_target(storage_root, raw_rel)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


class MkdirRequest(BaseModel):
    path: str
    username: Optional[str] = None


def is_forbidden_for_user(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """Memeriksa apakah jalur mencoba mengakses namespace user lain yang privat atau disk yang tidak diizinkan di ZimaOS."""
    return is_storage_path_forbidden(rel_path, username, allowed_disks, is_admin=is_admin)


def _parse_allowed_disks_value(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(x).strip() for x in parsed if str(x).strip()]
        except Exception:
            return [x.strip() for x in raw.split(",") if x.strip()]
    return []


def _resolve_authenticated_acl(
    current_user: Any,
    username: Optional[str],
    allowed_disks: Optional[str],
    allow_stream_scope: bool = False,
    target_path: Optional[str] = None,
) -> Tuple[str, Optional[List[str]], bool]:
    """
    Menentukan identitas efektif, allowed_disks, dan status admin secara fail-closed & anti-spoofing:
    - Bila current_user berupa payload dict JWT (FastAPI DI): akun aktif, role & allowed_disks wajib ada di SQLite.
    - Bila current_user bukan dict (pemanggilan langsung dari unit test Python): fallback kompatibel ke argumen.
    """
    if isinstance(current_user, dict):
        user_rec = verify_active_jwt_user(
            current_user,
            allow_stream_scope=allow_stream_scope,
            target_path=target_path,
        )
        jwt_user = str(user_rec.get("username") or "").strip().lower()
        caller_role = normalize_user_role(user_rec.get("role"))
        caller_is_admin = bool(caller_role in ("admin", "root") or is_admin_username(jwt_user))

        if caller_is_admin and username and username.strip():
            eff_user = username.strip()
            if eff_user.lower() == jwt_user:
                eff_is_admin = True
                target_rec = user_rec
            else:
                target_rec = get_user_by_username(eff_user)
                target_role = normalize_user_role(target_rec.get("role") if target_rec else None)
                eff_is_admin = bool(target_role in ("admin", "root") or is_admin_username(eff_user))
        else:
            eff_user = jwt_user
            eff_is_admin = caller_is_admin
            target_rec = user_rec

        if not eff_is_admin:
            if caller_is_admin and allowed_disks:
                allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()]
            else:
                raw = target_rec.get("allowed_disks", "[]") if target_rec else "[]"
                allowed_list = _parse_allowed_disks_value(raw)
        else:
            raw_admin_disks = target_rec.get("allowed_disks", "[]") if target_rec else "[]"
            parsed_admin_disks = _parse_allowed_disks_value(raw_admin_disks)
            allowed_list = parsed_admin_disks if parsed_admin_disks else None
        return eff_user, allowed_list, eff_is_admin

    # Fallback kompatibilitas pemanggilan langsung dari Python unit test (tanpa DI FastAPI)
    safe_user = username.strip() if username else "admin"
    user_rec_direct = None
    try:
        user_rec_direct = get_user_by_username(safe_user) if safe_user else None
    except Exception:
        user_rec_direct = None
    direct_role = str((user_rec_direct.get("role") if user_rec_direct else None) or "").strip().lower()
    is_admin = bool(
        not safe_user
        or is_admin_username(safe_user)
        or direct_role in ("admin", "root")
    )
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if allowed_list is None and not is_admin and user_rec_direct and user_rec_direct.get("allowed_disks"):
        parsed = _parse_allowed_disks_value(user_rec_direct.get("allowed_disks"))
        if parsed:
            allowed_list = parsed
    return safe_user, allowed_list, is_admin


def _resolve_caller_user_record(
    current_user: Any,
    eff_user: str,
    db_path: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Resolve active SQLite user record for eff_user (works for both FastAPI JWT dicts and unit test direct calls)."""
    resolved_db = db_path or _db_path()
    if eff_user:
        try:
            rec = get_user_by_username(eff_user, db_path=resolved_db)
            if rec is not None:
                return rec
        except Exception:
            pass
    if isinstance(current_user, dict):
        uid = current_user.get("uid") or current_user.get("user_id")
        if uid is not None:
            try:
                rec = get_user_by_id(int(uid), db_path=resolved_db)
                if rec is not None:
                    return rec
            except Exception:
                pass
    return None


_INTERNAL_ROLE_RANKS: Dict[str, int] = {
    "viewer": 1,
    "editor": 2,
    "administrator": 3,
}


def resolve_effective_path_permission(
    rel_path: str,
    user_rec: Optional[Dict[str, Any]],
    allowed_list: Optional[List[str]],
    is_admin: bool,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Resolve effective permission for rel_path in strict precedence order:
    1. system_admin (is_admin=True)
    2. owner (not is_forbidden_for_user on allowed_list)
    3. highest active internal_shares grant (viewer < editor < administrator) where grantor still retains authority.
    """
    clean_rel = str(rel_path or "").strip().replace("\\", "/").strip("/")
    if "\x00" in clean_rel:
        return {"level": "none", "via": "none", "grant": None, "is_share_root": False}
    parts = [p for p in clean_rel.split("/") if p and p != "."]
    if any(p == ".." for p in parts):
        return {"level": "none", "via": "none", "grant": None, "is_share_root": False}
    norm_rel = "/".join(parts)

    if is_admin:
        return {"level": "system_admin", "via": "admin", "grant": None, "is_share_root": False}

    eff_user = str((user_rec or {}).get("username") or "").strip().lower()
    if norm_rel and eff_user and not is_forbidden_for_user(norm_rel, eff_user, allowed_list, is_admin=False):
        return {"level": "owner", "via": "disk", "grant": None, "is_share_root": False}

    uid = (user_rec or {}).get("id")
    if norm_rel and uid is not None:
        resolved_db = db_path or _db_path()
        try:
            grants = list_internal_shares_for_grantee(int(uid), db_path=resolved_db)
        except Exception:
            grants = []
        best_grant: Optional[Dict[str, Any]] = None
        best_rank = 0
        best_tp_len = -1
        for g in grants:
            tp = str(g.get("target_path") or "").strip().replace("\\", "/").strip("/")
            if not tp:
                continue
            is_dir_grant = bool(g.get("is_dir"))
            if not (norm_rel == tp or (is_dir_grant and norm_rel.startswith(tp + "/"))):
                continue
            role = str(g.get("role") or "viewer").strip().lower()
            rank = _INTERNAL_ROLE_RANKS.get(role, 0)
            if rank <= 0:
                continue

            # Verify grantor still exists and retains authority on target_path
            owner_rec = None
            owner_uname = str(g.get("owner_username") or "").strip()
            if owner_uname:
                owner_rec = get_user_by_username(owner_uname, db_path=resolved_db)
            if owner_rec is None and g.get("owner_user_id") is not None:
                owner_rec = get_user_by_id(int(g["owner_user_id"]), db_path=resolved_db)
            if owner_rec is None:
                continue
            owner_uname_eff = str(owner_rec.get("username") or "").strip()
            owner_role = normalize_user_role(owner_rec.get("role"))
            owner_is_admin = bool(owner_role in ("admin", "root") or is_admin_username(owner_uname_eff))
            owner_disks = _parse_allowed_disks_value(owner_rec.get("allowed_disks", "[]"))
            if is_forbidden_for_user(tp, owner_uname_eff, owner_disks, is_admin=owner_is_admin):
                continue

            if rank > best_rank or (rank == best_rank and len(tp) > best_tp_len):
                best_grant = g
                best_rank = rank
                best_tp_len = len(tp)

        if best_grant is not None:
            best_tp = str(best_grant.get("target_path") or "").strip().replace("\\", "/").strip("/")
            return {
                "level": str(best_grant.get("role") or "viewer").strip().lower(),
                "via": "internal_share",
                "grant": best_grant,
                "is_share_root": (norm_rel == best_tp),
            }

    return {"level": "none", "via": "none", "grant": None, "is_share_root": False}


def _resolve_simple_user(
    current_user: Any,
    username: Optional[str],
    default_user: str = "admin",
) -> Tuple[str, bool]:
    if isinstance(current_user, dict):
        u_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
        jwt_user = str(u_rec.get("username") or "").strip().lower()
        role = normalize_user_role(u_rec.get("role"))
        caller_is_admin = bool(role in ("admin", "root") or is_admin_username(jwt_user))
        if caller_is_admin and username and username.strip():
            return username.strip(), caller_is_admin
        return jwt_user, caller_is_admin
    safe_u = username.strip() if username else default_user
    return safe_u, bool(not safe_u or is_admin_username(safe_u))


@router.get("/disks", response_model=StorageDisksResponse)
def get_storage_disks(
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Mengembalikan daftar mount storage/partisi fisik & virtual dan status izin akses akun (Role-Based ACL).
    """
    safe_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)

    disks: List[StorageDiskItem] = []
    seen_names = set()

    target_storage = _storage_dir()
    os.makedirs(target_storage, exist_ok=True)

    # 1. Pindai subdirektori langsung di dalam target_storage (partisi / storage pool lokal)
    try:
        for entry in os.scandir(target_storage):
            if entry.is_dir():
                if entry.name == ".trash":
                    continue
                sub_rel = entry.name
                is_accessible = not is_forbidden_for_user(sub_rel, safe_user, allowed_list, is_admin=is_admin)

                if not is_accessible:
                    continue

                total_b, used_b, free_b = _get_cached_disk_usage(entry.path)
                is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(entry.path)))

                disks.append(StorageDiskItem(
                    name=entry.name,
                    relative_path=sub_rel,
                    label=entry.name,
                    mount_point=entry.path,
                    total_bytes=total_b,
                    used_bytes=used_b,
                    free_bytes=free_b,
                    is_accessible=is_accessible,
                    is_remote=is_remote,
                ))
                seen_names.add(entry.name.lower())
    except Exception as e:
        logger.warning(f"Gagal memindai subdirektori storage: {e}")

    # 2. Jika tidak ada subdirektori atau disk sama sekali di target_storage, daftarkan sebagai root disk default (hanya untuk admin tanpa filter disk)
    if not disks and is_admin and not allowed_list:
        total_b, used_b, free_b = _get_cached_disk_usage(target_storage)
        is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(target_storage)))

        disks.append(StorageDiskItem(
            name="Storage",
            relative_path="",
            label="Storage Utama",
            mount_point=os.path.abspath(target_storage),
            total_bytes=total_b,
            used_bytes=used_b,
            free_bytes=free_b,
            is_accessible=True,
            is_remote=is_remote,
        ))

    disks.sort(key=lambda d: d.name.lower())

    return StorageDisksResponse(
        disks=disks,
        total_disks=len(disks),
        username=safe_user,
        is_admin=is_admin
    )


# ==============================================================================
# CLOUD / GOOGLE DRIVE MULTI-ACCOUNT ENDPOINTS
# ==============================================================================

@router.get("/cloud-accounts", response_model=CloudAccountListResponse)
def get_cloud_accounts(
    username: Optional[str] = Query(default="admin"),
    provider: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil daftar akun cloud (Google Drive, OneDrive) yang tersimpan untuk user yang bersangkutan."""
    eff_user, _ = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else get_or_create_user(eff_user)
    accounts = get_cloud_accounts_by_user(user_id, provider=provider)
    
    items = [
        CloudAccountItemResponse(
            id=a["id"],
            user_id=a["user_id"],
            provider=a["provider"],
            email=a["email"],
            display_name=a.get("display_name"),
            quota_total=a.get("quota_total", 0),
            quota_used=a.get("quota_used", 0),
            status=a.get("status", "connected"),
            created_at=str(a.get("created_at") or ""),
            updated_at=str(a.get("updated_at") or "")
        )
        for a in accounts
    ]
    return CloudAccountListResponse(
        accounts=items,
        total_count=len(items),
        username=eff_user
    )


@router.post("/cloud-accounts", response_model=CloudAccountItemResponse)
def connect_cloud_account(
    req: CloudAccountConnectRequest,
    username: Optional[str] = Query(default="admin"),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyambungkan atau memperbarui akun Google Drive / Cloud storage untuk akun pengguna."""
    eff_user, _ = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else get_or_create_user(eff_user)
    
    account = create_or_update_cloud_account(
        user_id=user_id,
        email=req.email,
        provider=req.provider,
        display_name=req.display_name,
        access_token=req.access_token,
        refresh_token=req.refresh_token,
        token_expiry=req.token_expiry,
        quota_total=req.quota_total or 16106127360,
        quota_used=req.quota_used or 0,
        status="connected"
    )
    return CloudAccountItemResponse(
        id=account["id"],
        user_id=account["user_id"],
        provider=account["provider"],
        email=account["email"],
        display_name=account.get("display_name"),
        quota_total=account.get("quota_total", 0),
        quota_used=account.get("quota_used", 0),
        status=account.get("status", "connected"),
        created_at=str(account.get("created_at") or ""),
        updated_at=str(account.get("updated_at") or "")
    )


@router.delete("/cloud-accounts/{account_id}")
def remove_cloud_account(
    account_id: int,
    username: Optional[str] = Query(default="admin"),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memutus koneksi akun cloud storage."""
    eff_user, caller_is_admin = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else None
    
    is_admin = bool(caller_is_admin or not eff_user or is_admin_username(eff_user) or (u and u.get("role") in ("admin", "root")))
    del_user_id = None if is_admin else user_id
    
    ok = delete_cloud_account(account_id, user_id=del_user_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Akun cloud tidak ditemukan atau tidak memiliki akses")
    return {"status": "success", "message": "Akun cloud berhasil diputus", "account_id": account_id}




@router.get("/browse")
def browse_storage(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menjelajahi direktori folder & disk yang ada di server storage.
    Mendukung penjelajahan multi-disk dan proteksi isolasi multi-user berbasis API ZimaOS.
    """
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)

    if canonical_rel:
        perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin)
        if perm["level"] == "none":
            raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")
        if perm["via"] == "internal_share":
            if not os.path.exists(target_dir):
                raise HTTPException(status_code=404, detail="Direktori tidak ditemukan.")
            if not os.path.isdir(target_dir):
                raise HTTPException(status_code=400, detail="Target adalah berkas, bukan direktori.")
        else:
            os.makedirs(target_dir, exist_ok=True)
    else:
        if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")
        perm = {"level": "system_admin" if is_admin else "owner", "via": "admin" if is_admin else "disk", "grant": None, "is_share_root": False}
        os.makedirs(target_dir, exist_ok=True)

    dirs = []
    try:
        for entry in _scandir_bounded(target_dir, include_stat=False):
            if entry["is_dir"]:
                raw_sub = f"{canonical_rel}/{entry['name']}" if canonical_rel else entry["name"]
                try:
                    sub_rel, _ = resolve_safe_storage_target(storage_root, raw_sub)
                except ValueError:
                    continue
                if perm["via"] != "internal_share" and is_forbidden_for_user(sub_rel, eff_user, allowed_list, is_admin=is_admin):
                    continue
                dirs.append({
                    "name": entry["name"],
                    "relative_path": sub_rel
                })
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori: {e}")

    dirs.sort(key=lambda x: x["name"].lower())
    parent = os.path.dirname(canonical_rel).replace("\\", "/") if canonical_rel else ""

    return {
        "current_path": canonical_rel,
        "parent_path": parent,
        "directories": dirs
    }


@router.post("/mkdir")
def make_directory(
    req: MkdirRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat direktori baru di dalam storage server dengan proteksi hak akses multi-user."""
    storage_root = _storage_dir()
    dir_name, target_dir = _resolve_storage_or_400(storage_root, req.path)
    if not dir_name:
        raise HTTPException(status_code=400, detail="Path direktori tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()
    perm = resolve_effective_path_permission(dir_name, user_rec, allowed_list, is_admin, db_path=db_path)
    if perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat direktori di dalam ruang akun pengguna lain atau disk yang tidak diotorisasi.")

    if perm["level"] == "editor":
        parent_rel = os.path.dirname(dir_name).replace("\\", "/").strip("/")
        base_name = os.path.basename(dir_name)
        parent_abs = os.path.dirname(target_dir)
        os.makedirs(parent_abs, exist_ok=True)
        with _UPLOAD_RENAME_LOCK:
            saved_name, final_abs, renamed = resolve_non_colliding_target(parent_abs, base_name, is_dir=True)
            actual_rel = f"{parent_rel}/{saved_name}" if parent_rel else saved_name
            os.makedirs(final_abs, exist_ok=True)
        caller_uid = user_rec.get("id") if user_rec else None
        if caller_uid is not None:
            record_internal_share_upload(actual_rel, int(caller_uid), eff_user, is_dir=True, db_path=db_path)
        invalidate_disk_usage_cache()
        try:
            log_activity(None, None, "STORAGE_MKDIR", f"User '{eff_user or 'anonymous'}' membuat direktori '{actual_rel}'", {"path": actual_rel, "renamed": renamed})
        except Exception:
            pass
        return {"success": True, "created_path": actual_rel, "saved_name": saved_name, "renamed": renamed}

    os.makedirs(target_dir, exist_ok=True)
    invalidate_disk_usage_cache()
    try:
        log_activity(None, None, "STORAGE_MKDIR", f"User '{eff_user or 'anonymous'}' membuat direktori '{dir_name}'", {"path": dir_name})
    except Exception:
        pass
    return {"success": True, "created_path": dir_name}


@router.get("/browse-files", response_model=StorageBrowseFilesResponse)
def browse_files_and_folders(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menjelajahi berkas dan folder (metadata lengkap: ukuran, ekstensi, mime_type, mtime) di server storage.
    Mendukung isolasi hak akses multi-user dan integrasi ZimaOS multi-disk.
    """
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    if canonical_rel:
        perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] == "none":
            raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")
        if perm["via"] == "internal_share":
            if not os.path.exists(target_dir):
                raise HTTPException(status_code=404, detail="Direktori tidak ditemukan.")
            if not os.path.isdir(target_dir):
                raise HTTPException(status_code=400, detail="Target adalah berkas, bukan direktori.")
        else:
            os.makedirs(target_dir, exist_ok=True)
    else:
        if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")
        perm = {"level": "system_admin" if is_admin else "owner", "via": "admin" if is_admin else "disk", "grant": None, "is_share_root": False}
        os.makedirs(target_dir, exist_ok=True)

    caller_uid = user_rec.get("id") if user_rec else None
    owned_children = set()
    if perm["level"] == "editor" and caller_uid is not None:
        owned_children = list_internal_owned_paths_in_dir(canonical_rel, int(caller_uid), db_path=db_path)

    items = []
    try:
        for entry in _scandir_bounded(target_dir, include_stat=True):
            raw_sub = f"{canonical_rel}/{entry['name']}" if canonical_rel else entry["name"]
            try:
                sub_rel, _ = resolve_safe_storage_target(storage_root, raw_sub)
            except ValueError:
                continue
            if perm["via"] != "internal_share" and is_forbidden_for_user(sub_rel, eff_user, allowed_list, is_admin=is_admin):
                continue

            is_dir = entry["is_dir"]
            size = entry["size"]
            mtime = entry["mtime"]

            ext = "" if is_dir else os.path.splitext(entry["name"])[1].lower()
            mime_type = "inode/directory" if is_dir else (mimetypes.guess_type(entry["name"])[0] or "application/octet-stream")
            if perm["level"] in ("system_admin", "owner", "administrator"):
                can_delete = True
            elif perm["level"] == "editor":
                can_delete = sub_rel in owned_children
            else:
                can_delete = False

            items.append({
                "name": entry["name"],
                "relative_path": sub_rel,
                "is_dir": is_dir,
                "size": size,
                "mtime": mtime,
                "extension": ext,
                "mime_type": mime_type,
                "can_delete": can_delete,
            })
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori berkas: {e}")

    items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    parent = os.path.dirname(canonical_rel).replace("\\", "/") if canonical_rel else ""
    folders_count = sum(1 for x in items if x["is_dir"])
    files_count = len(items) - folders_count

    return {
        "current_path": canonical_rel,
        "parent_path": parent,
        "items": items,
        "total_count": len(items),
        "folders_count": folders_count,
        "files_count": files_count,
        "effective_role": perm["level"],
        "is_share_root": bool(perm.get("is_share_root")),
    }


def _parse_single_byte_range(
    range_header: str,
    file_size: int,
    max_open_ended_bytes: Optional[int] = None,
) -> Tuple[str, Optional[Tuple[int, int]]]:
    """
    Parser HTTP Range RFC 9110:
    Mengembalikan ('ok', (start, end)) | ('unsatisfiable', None) | ('ignore', None).
    Mendukung bytes=start-end (termasuk clamping end >= file_size), bytes=start- (dengan batas window opsional), dan suffix bytes=-N.
    """
    h_val = str(range_header or "").strip()
    if not h_val:
        return "ignore", None
    if not h_val.lower().startswith("bytes="):
        return "ignore", None
    range_spec = h_val[6:].strip()
    if not range_spec or "," in range_spec:
        return "ignore", None
    parts = range_spec.split("-")
    if len(parts) != 2:
        return "unsatisfiable", None
    start_str, end_str = parts[0].strip(), parts[1].strip()
    if file_size <= 0:
        return "unsatisfiable", None
    try:
        if not start_str and not end_str:
            return "unsatisfiable", None
        if not start_str:
            # Suffix range bytes=-N
            suffix_len = int(end_str)
            if suffix_len <= 0:
                return "unsatisfiable", None
            start = max(0, file_size - suffix_len)
            end = file_size - 1
            return "ok", (start, end)
        start = int(start_str)
        if end_str:
            end = int(end_str)
        elif max_open_ended_bytes and max_open_ended_bytes > 0:
            end = min(file_size - 1, start + int(max_open_ended_bytes) - 1)
        else:
            end = file_size - 1
        if start < 0 or start >= file_size:
            return "unsatisfiable", None
        if end < start:
            return "unsatisfiable", None
        end = min(end, file_size - 1)
        return "ok", (start, end)
    except ValueError:
        return "unsatisfiable", None


def _guess_media_mime(full_path: str) -> str:
    mime_type, _ = mimetypes.guess_type(full_path)
    if mime_type:
        return mime_type
    ext = os.path.splitext(full_path)[1].lower()
    ext_map = {
        ".mkv": "video/x-matroska",
        ".webm": "video/webm",
        ".mov": "video/quicktime",
        ".m4v": "video/x-m4v",
        ".3gp": "video/3gpp",
        ".3g2": "video/3gpp2",
        ".ts": "video/mp2t",
        ".m2ts": "video/mp2t",
        ".mts": "video/mp2t",
        ".flv": "video/x-flv",
        ".f4v": "video/x-f4v",
        ".wmv": "video/x-ms-wmv",
        ".asf": "video/x-ms-asf",
        ".ogv": "video/ogg",
        ".vob": "video/dvd",
        ".mpg": "video/mpeg",
        ".mpeg": "video/mpeg",
        ".mpe": "video/mpeg",
        ".mpv": "video/mpv",
        ".rm": "application/vnd.rn-realmedia",
        ".rmvb": "application/vnd.rn-realmedia-vbr",
        ".divx": "video/divx",
        ".xvid": "video/x-xvid",
        ".mxf": "application/mxf",
        ".flac": "audio/flac",
        ".m4a": "audio/mp4",
        ".m4b": "audio/mp4",
        ".m4p": "audio/mp4",
        ".aac": "audio/aac",
        ".opus": "audio/opus",
        ".oga": "audio/ogg",
        ".ogg": "audio/ogg",
        ".wav": "audio/wav",
        ".wma": "audio/x-ms-wma",
        ".alac": "audio/alac",
        ".aif": "audio/aiff",
        ".aiff": "audio/aiff",
        ".ape": "audio/x-ape",
        ".amr": "audio/amr",
        ".ac3": "audio/ac3",
        ".dts": "audio/vnd.dts",
        ".wv": "audio/x-wavpack",
        ".mka": "audio/x-matroska",
        ".mid": "audio/midi",
        ".midi": "audio/midi",
        ".caf": "audio/x-caf",
        ".dsf": "audio/x-dsf",
        ".heic": "image/heic",
        ".heif": "image/heif",
        ".hif": "image/heif",
        ".avif": "image/avif",
        ".webp": "image/webp",
        ".jxl": "image/jxl",
        ".jp2": "image/jp2",
        ".j2k": "image/jp2",
        ".jpe": "image/jpeg",
        ".jfif": "image/jpeg",
        ".tif": "image/tiff",
        ".tiff": "image/tiff",
        ".psd": "image/vnd.adobe.photoshop",
        ".tga": "image/x-tga",
        ".dds": "image/vnd.ms-dds",
        ".dng": "image/x-adobe-dng",
        ".raw": "image/x-raw",
        ".cr2": "image/x-canon-cr2",
        ".cr3": "image/x-canon-cr3",
        ".nef": "image/x-nikon-nef",
        ".arw": "image/x-sony-arw",
        ".orf": "image/x-olympus-orf",
        ".rw2": "image/x-panasonic-rw2",
        ".raf": "image/x-fuji-raf",
        ".pef": "image/x-pentax-pef",
        ".srw": "image/x-samsung-srw",
    }
    return ext_map.get(ext, "application/octet-stream")


def stream_file_range(
    full_path: str,
    range_header: Optional[str] = None,
    request_headers: Optional[Any] = None,
    method: str = "GET",
    inline: bool = False,
    request: Optional[Any] = None,
    cap_open_ended: bool = True,
):
    """Membangun StreamingResponse dengan HTTP Range 206, 416, ETag, Last-Modified, If-Range, HEAD, async streaming, dan pelepasan page cache."""
    st = os.stat(full_path)
    file_size = int(st.st_size)
    mtime_epoch = int(st.st_mtime)
    etag = f'"{file_size:x}-{mtime_epoch:x}"'
    last_modified = email.utils.formatdate(mtime_epoch, usegmt=True)
    mime_type = _guess_media_mime(full_path)

    sec_headers = build_stream_security_headers(full_path, inline=inline)
    base_cache_headers = {
        "Accept-Ranges": "bytes",
        "ETag": etag,
        "Last-Modified": last_modified,
        **sec_headers,
    }
    head_only = str(method or "GET").strip().upper() == "HEAD"

    def _hdr_get(name: str) -> Optional[str]:
        if request_headers is None:
            return None
        getter = getattr(request_headers, "get", None)
        if callable(getter):
            return getter(name) or getter(name.lower())
        return None

    if_none_match = str(_hdr_get("if-none-match") or "").strip()
    if if_none_match and (if_none_match == "*" or etag in if_none_match):
        return StreamingResponse(iter(()), status_code=304, headers=base_cache_headers)

    if_range = str(_hdr_get("if-range") or "").strip()
    effective_range = range_header
    if if_range and effective_range:
        if if_range != etag and if_range != last_modified:
            effective_range = None

    use_async = StreamingResponse.__name__ != "_FallbackResponse"

    async def _is_client_gone() -> bool:
        if request is None:
            return False
        checker = getattr(request, "is_disconnected", None)
        if callable(checker):
            try:
                return bool(await checker())
            except Exception:
                return False
        return False

    def _sync_range_generator(start_pos: int, length: int):
        fadv_offset = start_pos
        fadv_bytes = 0
        with open(full_path, "rb") as f:
            fd = f.fileno()
            f.seek(start_pos)
            remaining = length
            try:
                while remaining > 0:
                    data = f.read(min(STREAM_CHUNK_SIZE, remaining))
                    if not data:
                        break
                    remaining -= len(data)
                    fadv_bytes += len(data)
                    if fadv_bytes >= FADVISE_WINDOW_BYTES:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                        fadv_offset += fadv_bytes
                        fadv_bytes = 0
                    yield data
            finally:
                if fadv_bytes > 0:
                    _fadvise_dontneed(fd, fadv_offset, fadv_bytes)

    async def _async_range_generator(start_pos: int, length: int):
        fadv_offset = start_pos
        fadv_bytes = 0
        remaining = length
        if aiofiles is not None:
            async with aiofiles.open(full_path, "rb") as f:
                fd = f.fileno()
                await f.seek(start_pos)
                try:
                    while remaining > 0:
                        if await _is_client_gone():
                            break
                        data = await f.read(min(STREAM_CHUNK_SIZE, remaining))
                        if not data:
                            break
                        remaining -= len(data)
                        fadv_bytes += len(data)
                        if fadv_bytes >= FADVISE_WINDOW_BYTES:
                            _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                            fadv_offset += fadv_bytes
                            fadv_bytes = 0
                        yield data
                finally:
                    if fadv_bytes > 0:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
        else:
            f = await asyncio.to_thread(open, full_path, "rb")
            fd = f.fileno()
            try:
                await asyncio.to_thread(f.seek, start_pos)
                while remaining > 0:
                    if await _is_client_gone():
                        break
                    data = await asyncio.to_thread(f.read, min(STREAM_CHUNK_SIZE, remaining))
                    if not data:
                        break
                    remaining -= len(data)
                    fadv_bytes += len(data)
                    if fadv_bytes >= FADVISE_WINDOW_BYTES:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                        fadv_offset += fadv_bytes
                        fadv_bytes = 0
                    yield data
            finally:
                if fadv_bytes > 0:
                    _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                await asyncio.to_thread(f.close)

    if effective_range:
        range_cap = OPEN_ENDED_RANGE_MAX_BYTES if cap_open_ended else None
        kind, bounds = _parse_single_byte_range(effective_range, file_size, max_open_ended_bytes=range_cap)
        if kind == "unsatisfiable":
            return StreamingResponse(
                iter(()),
                status_code=416,
                headers={
                    "Content-Range": f"bytes */{file_size}",
                    "Accept-Ranges": "bytes",
                    "Content-Type": mime_type,
                    **sec_headers,
                },
            )
        if kind == "ok" and bounds is not None:
            start, end = bounds
            content_length = end - start + 1
            headers = {
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Content-Length": str(content_length),
                "Content-Type": mime_type,
                **base_cache_headers,
            }
            if head_only:
                body_gen = iter(())
            elif use_async:
                body_gen = _async_range_generator(start, content_length)
            else:
                body_gen = _sync_range_generator(start, content_length)
            return StreamingResponse(body_gen, status_code=206, headers=headers)

    headers = {
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        **base_cache_headers,
    }
    if head_only:
        body_gen = iter(())
    elif use_async:
        body_gen = _async_range_generator(0, file_size)
    else:
        body_gen = _sync_range_generator(0, file_size)
    return StreamingResponse(body_gen, status_code=200, headers=headers)


@router.get("/stream")
@router.head("/stream")
def stream_media(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    inline: bool = Query(default=False),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Streaming HTTP Range 206 Partial Content untuk pemutaran video, audio, dan dokumen langsung dari server.
    Mendukung SEEK, ETag/If-Range, 416, serta metode HEAD.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user,
        username,
        allowed_disks,
        allow_stream_scope=True,
        target_path=canonical_rel,
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin)
    if perm["level"] == "none":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas dari direktori terlarang.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    req_headers = getattr(request, "headers", None) if request is not None else None
    req_method = getattr(request, "method", "GET") if request is not None else "GET"
    range_header = req_headers.get("range") if req_headers is not None else None
    session_id = (req_headers.get("x-session-id") if req_headers is not None else None) or f"sess_{abs(hash(target_file))}_{int(time.time() // 60)}"
    client_ip = request.client.host if (request is not None and request.client and request.client.host) else "unknown"
    try:
        if str(req_method).upper() != "HEAD":
            track_session(session_id, eff_user or "anonymous", canonical_rel, client_ip, session_type="stream")
            if not range_header or range_header.startswith("bytes=0-"):
                log_activity(None, None, "STORAGE_STREAM", f"User '{eff_user or 'anonymous'}' memutar stream '{os.path.basename(target_file)}'", {"path": canonical_rel, "ip": client_ip})
    except Exception:
        pass
    return stream_file_range(target_file, range_header, request_headers=req_headers, method=req_method, inline=inline, request=request, cap_open_ended=True)


@router.get("/player", response_class=HTMLResponse)
def get_media_player(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menyediakan UI Web Player modern (HTML5) yang seragam antara Browser dan Native Desktop App (Edge App Mode).
    Mendukung video, audio, gambar dengan keyboard shortcuts, range seeking, dan responsif.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin)
    if perm["level"] == "none":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    scoped_token = ""
    if isinstance(current_user, dict):
        uid_val = current_user.get("uid")
        if uid_val is None and eff_user:
            u_rec = get_user_by_username(eff_user)
            if u_rec:
                uid_val = u_rec.get("id")
        if eff_user and uid_val is not None:
            try:
                scoped_token = create_stream_token(eff_user, int(uid_val), canonical_rel, ttl_seconds=300)
            except Exception:
                scoped_token = ""

    raw_token = scoped_token
    if not raw_token and isinstance(current_user, dict) and request is not None:
        qp = getattr(request, "query_params", None)
        if qp and hasattr(qp, "get"):
            raw_token = str(qp.get("token") or "").strip()
        if not raw_token:
            hdrs = getattr(request, "headers", None)
            if hdrs and hasattr(hdrs, "get"):
                auth_hdr = str(hdrs.get("authorization") or hdrs.get("Authorization") or "").strip()
                if auth_hdr.lower().startswith("bearer "):
                    raw_token = auth_hdr[7:].strip()

    filename = os.path.basename(target_file)
    stream_url = f"/api/v1/storage/stream?path={urllib.parse.quote(canonical_rel)}"
    download_url = f"/api/v1/storage/download?path={urllib.parse.quote(canonical_rel)}"
    if raw_token:
        tok_q = f"&token={urllib.parse.quote(raw_token)}"
        stream_url += tok_q
        download_url += tok_q

    html_content = render_media_player_html(filename, canonical_rel, stream_url, download_url)
    return HTMLResponse(content=html_content)


@router.get("/download")
@router.head("/download")
def download_file(
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
    request: Request = None,
):
    """Mengunduh berkas langsung dari server storage tanpa kompresi ZIP."""
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user,
        username,
        allowed_disks,
        allow_stream_scope=True,
        target_path=canonical_rel,
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin)
    if perm["level"] == "none":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunduh berkas dari direktori terlarang.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    filename = os.path.basename(target_file)
    file_size = os.path.getsize(target_file)
    mime_type, _ = mimetypes.guess_type(target_file)
    mime_type = mime_type or "application/octet-stream"

    try:
        log_activity(None, None, "STORAGE_DOWNLOAD", f"User '{eff_user or 'anonymous'}' mengunduh '{filename}'", {"path": canonical_rel, "size": file_size})
    except Exception:
        pass

    async def file_streamer():
        fadv_offset = 0
        fadv_bytes = 0
        if aiofiles is not None:
            async with aiofiles.open(target_file, "rb") as f:
                fd = f.fileno()
                try:
                    while True:
                        if request is not None and callable(getattr(request, "is_disconnected", None)):
                            try:
                                if await request.is_disconnected():
                                    break
                            except Exception:
                                pass
                        chunk = await f.read(STREAM_CHUNK_SIZE)
                        if not chunk:
                            break
                        fadv_bytes += len(chunk)
                        if fadv_bytes >= FADVISE_WINDOW_BYTES:
                            _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                            fadv_offset += fadv_bytes
                            fadv_bytes = 0
                        yield chunk
                finally:
                    if fadv_bytes > 0:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
        else:
            f = await asyncio.to_thread(open, target_file, "rb")
            fd = f.fileno()
            try:
                while True:
                    chunk = await asyncio.to_thread(f.read, STREAM_CHUNK_SIZE)
                    if not chunk:
                        break
                    fadv_bytes += len(chunk)
                    if fadv_bytes >= FADVISE_WINDOW_BYTES:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                        fadv_offset += fadv_bytes
                        fadv_bytes = 0
                    yield chunk
            finally:
                if fadv_bytes > 0:
                    _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                await asyncio.to_thread(f.close)

    def sync_file_streamer():
        fadv_offset = 0
        fadv_bytes = 0
        with open(target_file, "rb") as f:
            fd = f.fileno()
            try:
                while chunk := f.read(STREAM_CHUNK_SIZE):
                    fadv_bytes += len(chunk)
                    if fadv_bytes >= FADVISE_WINDOW_BYTES:
                        _fadvise_dontneed(fd, fadv_offset, fadv_bytes)
                        fadv_offset += fadv_bytes
                        fadv_bytes = 0
                    yield chunk
            finally:
                if fadv_bytes > 0:
                    _fadvise_dontneed(fd, fadv_offset, fadv_bytes)

    headers = {
        "Content-Disposition": build_content_disposition("attachment", filename),
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        "Accept-Ranges": "bytes",
        "X-Content-Type-Options": "nosniff",
    }
    head_only = request is not None and str(getattr(request, "method", "GET")).upper() == "HEAD"
    if head_only:
        body_stream = iter(())
    elif StreamingResponse.__name__ != "_FallbackResponse":
        body_stream = file_streamer()
    else:
        body_stream = sync_file_streamer()
    return StreamingResponse(body_stream, headers=headers)


@router.post("/upload")
async def upload_direct_file(
    file: UploadFile = File(...),
    path: Optional[str] = Form(default=None),
    path_param: Optional[str] = Query(default=None, alias="path"),
    filename: Optional[str] = Query(default=None),
    filename_form: Optional[str] = Form(default=None, alias="filename"),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengunggah berkas langsung ke direktori storage secara non-blocking & atomik."""
    resolved_path = (path if path is not None else path_param) or ""
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, resolved_path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()
    dir_perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not canonical_rel) or dir_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah berkas ke direktori terlarang.")

    chosen_name = filename or filename_form or getattr(file, "filename", "") or ""
    clean_filename = os.path.basename(chosen_name.strip().replace("\\", "/"))
    if not clean_filename or clean_filename in (".", ".."):
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid")

    file_candidate_rel = f"{canonical_rel}/{clean_filename}" if canonical_rel else clean_filename
    actual_rel, target_file = _resolve_storage_or_400(storage_root, file_candidate_rel)
    file_perm = resolve_effective_path_permission(actual_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not actual_rel) or file_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah berkas ke direktori terlarang.")

    max_upload = int(getattr(app.config, "MAX_UPLOAD_SIZE_BYTES", 4096 * 1024 * 1024))
    tmp_file = f"{target_file}.tmp.{uuid.uuid4().hex[:8]}"
    await asyncio.to_thread(os.makedirs, target_dir, exist_ok=True)

    is_internal_editor = (dir_perm["level"] == "editor")
    saved_name = clean_filename
    renamed = False
    bytes_written = 0
    f_out = await asyncio.to_thread(open, tmp_file, "wb")
    try:
        while True:
            chunk = await file.read(256 * 1024)
            if not chunk:
                break
            bytes_written += len(chunk)
            if bytes_written > max_upload:
                raise HTTPException(
                    status_code=413,
                    detail=f"Ukuran unggahan melebihi batas maksimal ({max_upload // (1024 * 1024)} MB).",
                )
            await asyncio.to_thread(f_out.write, chunk)

        def _finalize_atomic():
            nonlocal saved_name, renamed, actual_rel, target_file
            f_out.flush()
            os.fsync(f_out.fileno())
            f_out.close()
            if is_internal_editor:
                with _UPLOAD_RENAME_LOCK:
                    saved_name, final_abs, renamed = resolve_non_colliding_target(
                        target_dir, clean_filename, is_dir=False
                    )
                    actual_rel = f"{canonical_rel}/{saved_name}" if canonical_rel else saved_name
                    target_file = final_abs
                    os.replace(tmp_file, final_abs)
            else:
                os.replace(tmp_file, target_file)

        await asyncio.to_thread(_finalize_atomic)
    except Exception:
        try:
            f_out.close()
        except Exception:
            pass
        if os.path.exists(tmp_file):
            try:
                await asyncio.to_thread(os.remove, tmp_file)
            except Exception:
                pass
        raise

    if is_internal_editor:
        caller_uid = user_rec.get("id") if user_rec else None
        if caller_uid is not None:
            await asyncio.to_thread(
                record_internal_share_upload,
                actual_rel,
                int(caller_uid),
                eff_user,
                False,
                db_path,
            )

    try:
        await asyncio.to_thread(
            log_activity,
            None,
            None,
            "STORAGE_UPLOAD",
            f"User '{eff_user or 'anonymous'}' mengunggah '{saved_name}'",
            {"path": actual_rel, "bytes": bytes_written, "renamed": renamed},
        )
    except Exception:
        pass

    invalidate_disk_usage_cache()
    _enqueue_file_prewarm_if_media(actual_rel, target_file)
    return {
        "success": True,
        "filename": saved_name,
        "saved_name": saved_name,
        "renamed": renamed,
        "bytes_written": bytes_written,
        "relative_path": actual_rel,
    }


@router.post("/upload-chunk")
async def upload_explorer_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Endpoint upload chunked untuk Web Explorer agar file besar tahan timeout Cloudflare/WAN."""
    verify_active_jwt_user(current_user, allow_stream_scope=False)
    clean_uid = str(upload_id or "").strip()
    if not _STORAGE_CHUNK_UPLOAD_ID_RE.match(clean_uid):
        raise HTTPException(status_code=400, detail="Format upload_id tidak valid.")
    if total_chunks <= 0 or chunk_index < 0 or chunk_index >= total_chunks or total_chunks > 10000:
        raise HTTPException(status_code=400, detail="Indeks chunk tidak valid.")

    chunk_dir = os.path.join(_temp_dir(), f"web_{clean_uid}")
    chunk_path = os.path.join(chunk_dir, f"part_{chunk_index:06d}.tmp")
    stage_path = f"{chunk_path}.{uuid.uuid4().hex[:6]}"
    await asyncio.to_thread(os.makedirs, chunk_dir, exist_ok=True)
    bytes_written = 0
    fh = await asyncio.to_thread(open, stage_path, "wb")
    try:
        while True:
            part = await file.read(256 * 1024)
            if not part:
                break
            bytes_written += len(part)
            await asyncio.to_thread(fh.write, part)

        def _commit_chunk():
            fh.flush()
            os.fsync(fh.fileno())
            fh.close()
            os.replace(stage_path, chunk_path)

        await asyncio.to_thread(_commit_chunk)
    except Exception:
        try:
            fh.close()
        except Exception:
            pass
        if os.path.exists(stage_path):
            try:
                await asyncio.to_thread(os.remove, stage_path)
            except Exception:
                pass
        raise
    return {"success": True, "upload_id": clean_uid, "chunk_index": chunk_index, "bytes_written": bytes_written}


@router.post("/upload-commit")
def commit_explorer_chunked_upload(
    upload_id: str = Query(...),
    path: str = Query(default=""),
    filename: str = Query(...),
    total_chunks: int = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menggabungkan seluruh chunk upload Web Explorer menjadi berkas atomik di storage."""
    clean_uid = str(upload_id or "").strip()
    if not _STORAGE_CHUNK_UPLOAD_ID_RE.match(clean_uid):
        raise HTTPException(status_code=400, detail="Format upload_id tidak valid.")
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()
    clean_filename = os.path.basename(filename.strip().replace("\\", "/"))
    if not clean_filename or clean_filename in (".", ".."):
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid.")
    actual_rel, target_file = _resolve_storage_or_400(
        storage_root, f"{canonical_rel}/{clean_filename}" if canonical_rel else clean_filename
    )
    perm = resolve_effective_path_permission(actual_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not actual_rel) or perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah ke direktori terlarang.")

    chunk_dir = os.path.join(_temp_dir(), f"web_{clean_uid}")
    for idx in range(total_chunks):
        if not os.path.isfile(os.path.join(chunk_dir, f"part_{idx:06d}.tmp")):
            raise HTTPException(status_code=400, detail=f"Potongan chunk ke-{idx} belum tersedia.")

    os.makedirs(target_dir, exist_ok=True)
    tmp_target = f"{target_file}.tmp.{uuid.uuid4().hex[:8]}"
    bytes_written = 0
    is_internal_editor = (perm["level"] == "editor")
    saved_name = clean_filename
    renamed = False
    try:
        with open(tmp_target, "wb") as f_out:
            for idx in range(total_chunks):
                with open(os.path.join(chunk_dir, f"part_{idx:06d}.tmp"), "rb") as f_in:
                    while buf := f_in.read(256 * 1024):
                        f_out.write(buf)
                        bytes_written += len(buf)
            f_out.flush()
            os.fsync(f_out.fileno())
        if is_internal_editor:
            with _UPLOAD_RENAME_LOCK:
                saved_name, final_abs, renamed = resolve_non_colliding_target(
                    target_dir, clean_filename, is_dir=False
                )
                actual_rel = f"{canonical_rel}/{saved_name}" if canonical_rel else saved_name
                os.replace(tmp_target, final_abs)
        else:
            os.replace(tmp_target, target_file)
    except Exception:
        if os.path.exists(tmp_target):
            try:
                os.remove(tmp_target)
            except Exception:
                pass
        raise
    shutil.rmtree(chunk_dir, ignore_errors=True)
    if is_internal_editor:
        caller_uid = user_rec.get("id") if user_rec else None
        if caller_uid is not None:
            record_internal_share_upload(actual_rel, int(caller_uid), eff_user, is_dir=False, db_path=db_path)
    try:
        log_activity(None, None, "STORAGE_UPLOAD", f"User '{eff_user or 'anonymous'}' mengunggah (chunked) '{saved_name}'", {"path": actual_rel, "bytes": bytes_written, "renamed": renamed})
    except Exception:
        pass
    invalidate_disk_usage_cache()
    final_uploaded_abs = final_abs if is_internal_editor else target_file
    _enqueue_file_prewarm_if_media(actual_rel, final_uploaded_abs)
    return {"success": True, "filename": saved_name, "saved_name": saved_name, "renamed": renamed, "bytes_written": bytes_written, "relative_path": actual_rel}


@router.get("/activity-logs")
def get_storage_activity_logs(
    limit: int = Query(default=50, ge=1, le=500),
    username: Optional[str] = Query(default=None),
    action: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil riwayat log aktivitas dan operasi storage (upload, download, stream, dll)."""
    if isinstance(current_user, dict):
        eff_user, caller_is_admin = _resolve_simple_user(current_user, username, default_user="")
        query_user = username if (caller_is_admin and username is not None) else (None if caller_is_admin else eff_user)
    else:
        query_user = username
    logs = get_activity_logs(limit=limit, username=query_user, action=action)
    return {"logs": logs, "total": len(logs)}


@router.get("/sessions")
def get_storage_sessions(
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil daftar sesi aktif streaming dan akses berkas."""
    sessions = get_active_sessions()
    if isinstance(current_user, dict):
        eff_user, caller_is_admin = _resolve_simple_user(current_user, None, default_user="")
        if not caller_is_admin:
            sessions = [s for s in sessions if str(s.get("username") or "").strip().lower() == eff_user]
    return {"sessions": sessions, "active_count": len(sessions)}


@router.api_route("/cleanup-temp", methods=["GET", "POST"])
def cleanup_temp_storage(
    max_age_hours: float = Query(default=1.0, ge=0.01),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Membersihkan berkas sementara, potongan chunk kadaluarsa (.part),
    dan sesi unggah terputus yang lebih tua dari batas jam yang ditentukan (default 1 jam).
    """
    if isinstance(current_user, dict):
        _, caller_is_admin = _resolve_simple_user(current_user, None, default_user="")
        if not caller_is_admin:
            raise HTTPException(status_code=403, detail="Hanya administrator yang diizinkan membersihkan cache sementara.")

    cutoff_time = time.time() - (max_age_hours * 3600)
    deleted_files = []
    freed_bytes = 0

    temp_root = _temp_dir()

    if os.path.exists(temp_root):
        for root, dirs, files in os.walk(temp_root, topdown=False):
            for f in files:
                fpath = os.path.join(root, f)
                try:
                    st = os.stat(fpath)
                    if st.st_mtime < cutoff_time:
                        fsize = st.st_size
                        os.remove(fpath)
                        deleted_files.append(f)
                        freed_bytes += fsize
                except Exception:
                    pass
            if root != temp_root:
                try:
                    if not os.listdir(root):
                        os.rmdir(root)
                except Exception:
                    pass

    # Potongan unggahan (.part) hanya dibuat di temp_root; jangan pernah melakukan os.walk()
    # terhadap storage_root karena share FUSE/cloud (mis. Google Drive ZimaOS) akan ter-crawl penuh
    # setiap 30 menit dan memicu rate-limit/freeze File Explorer.

    try:
        with get_db(_db_path()) as conn:
            conn.execute("""
                UPDATE upload_sessions 
                SET status = 'failed' 
                WHERE status IN ('pending', 'uploading') 
                AND strftime('%s', 'now') - strftime('%s', created_at) > ?
            """, (int(max_age_hours * 3600),))
    except Exception:
        pass

    try:
        log_activity(
            device_id=None,
            task_id=None,
            action="TEMP_CLEANUP",
            message=f"Pembersihan temp chunk: {len(deleted_files)} berkas dihapus ({freed_bytes} bytes dibebaskan).",
            details={"deleted_count": len(deleted_files), "freed_bytes": freed_bytes}
        )
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {
        "success": True,
        "total_deleted": len(deleted_files),
        "freed_bytes": freed_bytes,
        "deleted_files": deleted_files[:100]
    }


def _thumb_cache_dir() -> str:
    thumb_dir = os.path.join(_data_dir(), ".thumbnails")
    os.makedirs(thumb_dir, exist_ok=True)
    return thumb_dir


def _thumb_cache_key(canonical_rel: str, file_mtime: int, size: int) -> str:
    return hashlib.md5(f"v4_{canonical_rel}_{file_mtime}_{size}".encode("utf-8")).hexdigest()


def _find_cached_thumb(thumb_dir: str, cache_key: str) -> Optional[Tuple[str, str]]:
    for ext, mime in ((".webp", "image/webp"), (".jpg", "image/jpeg")):
        cand = os.path.join(thumb_dir, f"{cache_key}{ext}")
        try:
            if os.path.isfile(cand) and os.path.getsize(cand) > 0:
                return cand, mime
        except OSError:
            pass
    return None


def _prune_thumb_cache(
    thumb_dir: str,
    max_bytes: Optional[int] = None,
    force: bool = False,
) -> Tuple[int, int]:
    """Pangkas cache thumbnail LRU di disk bila total ukuran melewati batas (default 2 GB)."""
    global _THUMB_LAST_PRUNE_TS
    if not os.path.isdir(thumb_dir):
        return 0, 0
    limit = int(max_bytes) if max_bytes is not None else THUMB_CACHE_MAX_BYTES
    limit = max(1, limit)
    target = int(limit * THUMB_CACHE_TARGET_RATIO)

    with _THUMB_PRUNE_LOCK:
        now_mono = time.monotonic()
        if not force and (now_mono - _THUMB_LAST_PRUNE_TS) < 120.0:
            return 0, 0
        _THUMB_LAST_PRUNE_TS = now_mono
        entries: List[Tuple[str, int, float]] = []
        total_bytes = 0
        try:
            with os.scandir(thumb_dir) as it:
                for entry in it:
                    name_low = entry.name.lower()
                    if not (name_low.endswith(".webp") or name_low.endswith(".jpg")):
                        continue
                    try:
                        if not entry.is_file(follow_symlinks=False):
                            continue
                        st = entry.stat(follow_symlinks=False)
                        fsize = int(st.st_size)
                        atime = float(max(st.st_atime, st.st_mtime))
                        entries.append((entry.path, fsize, atime))
                        total_bytes += fsize
                    except OSError:
                        pass
        except OSError:
            return 0, 0

        if total_bytes <= limit:
            return 0, 0

        entries.sort(key=lambda item: item[2])
        deleted_count = 0
        freed_bytes = 0
        for fpath, fsize, _ in entries:
            if total_bytes <= target:
                break
            try:
                os.remove(fpath)
                total_bytes -= fsize
                freed_bytes += fsize
                deleted_count += 1
            except OSError:
                pass
        return deleted_count, freed_bytes


def _ffmpeg_generate_jpeg(src_path: str, dst_tmp: str, size: int, is_video: bool) -> bool:
    ffmpeg_bin = shutil.which("ffmpeg")
    if not ffmpeg_bin:
        return False
    scale_filter = f"scale='min({int(size)},iw)':-2"
    seek_candidates = ("00:00:01", "00:00:00") if is_video else (None,)
    for seek_ts in seek_candidates:
        cmd = [ffmpeg_bin, "-hide_banner", "-loglevel", "error", "-y"]
        if seek_ts is not None:
            cmd.extend(["-ss", seek_ts])
        cmd.extend([
            "-i", src_path,
            "-frames:v", "1",
            "-vf", scale_filter,
            "-q:v", "7",
            "-f", "image2",
            "-vcodec", "mjpeg",
            dst_tmp,
        ])
        try:
            proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10.0)
            if proc.returncode == 0 and os.path.isfile(dst_tmp) and os.path.getsize(dst_tmp) > 0:
                return True
        except Exception:
            pass
        if os.path.exists(dst_tmp):
            try:
                os.remove(dst_tmp)
            except OSError:
                pass
    return False


def _heif_convert_generate_jpeg(src_path: str, dst_tmp: str, size: int) -> bool:
    """Fallback native libheif (`heif-convert`) untuk merakit grid HEIC penuh warna (bukan ffmpeg tile)."""
    heif_bin = shutil.which("heif-convert")
    if not heif_bin:
        return False
    try:
        with tempfile.TemporaryDirectory() as tmp_d:
            out_jpg = os.path.join(tmp_d, "primary.jpg")
            proc = subprocess.run(
                [heif_bin, "-q", "88", src_path, out_jpg],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=15.0,
                check=False,
            )
            cand_path = out_jpg
            if not (os.path.isfile(cand_path) and os.path.getsize(cand_path) > 0):
                alt_jpg = os.path.join(tmp_d, "primary-1.jpg")
                if os.path.isfile(alt_jpg) and os.path.getsize(alt_jpg) > 0:
                    cand_path = alt_jpg
            if proc.returncode == 0 and os.path.isfile(cand_path) and os.path.getsize(cand_path) > 0:
                try:
                    from PIL import Image, ImageOps
                    with Image.open(cand_path) as im:
                        im = ImageOps.exif_transpose(im)
                        resample_filter = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                        im.thumbnail((size, size), resample=resample_filter)
                        if im.mode != "RGB":
                            im = im.convert("RGB")
                        im.save(dst_tmp, format="JPEG", quality=85, optimize=True)
                except Exception:
                    shutil.copyfile(cand_path, dst_tmp)
                return os.path.isfile(dst_tmp) and os.path.getsize(dst_tmp) > 0
    except Exception:
        pass
    return False


def _generate_thumbnail_to_disk(
    canonical_rel: str,
    target_file: str,
    size: int,
    thumb_dir: str,
    sem_timeout: float = 10.0,
) -> Tuple[str, str, str]:
    """Generate thumbnail WebP/JPEG ke disk dengan batas semaphore & tanpa menahan RAM."""
    ext = os.path.splitext(target_file)[1].lower()
    if ext not in _VALID_THUMB_IMG_EXTS and ext not in _VALID_THUMB_VIDEO_EXTS:
        raise HTTPException(status_code=415, detail=f"Pembuatan thumbnail tidak didukung untuk tipe berkas {ext}")

    file_mtime = int(os.path.getmtime(target_file))
    cache_key = _thumb_cache_key(canonical_rel, file_mtime, size)
    hit = _find_cached_thumb(thumb_dir, cache_key)
    if hit is not None:
        return hit[0], hit[1], cache_key

    is_heif = ext in _HEIF_EXTS
    if is_heif:
        _ensure_heif_support()

    acquired = _THUMB_SEMAPHORE.acquire(timeout=sem_timeout)
    if not acquired:
        raise HTTPException(status_code=503, detail="Generator thumbnail sedang sibuk, coba sebentar lagi.")

    tmp_paths: List[str] = []
    try:
        hit = _find_cached_thumb(thumb_dir, cache_key)
        if hit is not None:
            return hit[0], hit[1], cache_key

        jpg_cache = os.path.join(thumb_dir, f"{cache_key}.jpg")
        webp_cache = os.path.join(thumb_dir, f"{cache_key}.webp")
        rand_tag = uuid.uuid4().hex[:6]

        if ext in _VALID_THUMB_VIDEO_EXTS:
            tmp_jpg = f"{jpg_cache}.tmp.{rand_tag}"
            tmp_paths.append(tmp_jpg)
            if not _ffmpeg_generate_jpeg(target_file, tmp_jpg, size, is_video=True):
                raise HTTPException(status_code=415, detail=f"Thumbnail video tidak tersedia untuk {ext}")
            os.replace(tmp_jpg, jpg_cache)
            _prune_thumb_cache(thumb_dir)
            return jpg_cache, "image/jpeg", cache_key

        out_path = webp_cache
        out_mime = "image/webp"
        tmp_webp = f"{webp_cache}.tmp.{rand_tag}"
        tmp_jpg = f"{jpg_cache}.tmp.{rand_tag}"
        tmp_paths.extend([tmp_webp, tmp_jpg])

        try:
            from PIL import Image, ImageOps
            # Batas aman anti-decompression-bomb (~40 megapiksel) agar kontainer NAS hemat RAM
            Image.MAX_IMAGE_PIXELS = 40_000_000
            with Image.open(target_file) as im:
                if not is_heif:
                    try:
                        im.draft("RGB", (size * 2, size * 2))
                    except Exception:
                        pass
                im = ImageOps.exif_transpose(im)
                resample_filter = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                im.thumbnail((size, size), resample=resample_filter)
                if im.mode in ("RGBA", "LA", "P"):
                    background = Image.new("RGB", im.size, (255, 255, 255))
                    if im.mode == "P":
                        im = im.convert("RGBA")
                    if im.mode in ("RGBA", "LA"):
                        background.paste(im, mask=im.split()[-1])
                    else:
                        background.paste(im)
                    im = background
                elif im.mode != "RGB":
                    im = im.convert("RGB")
                try:
                    im.save(tmp_webp, format="WEBP", quality=80, method=4)
                    os.replace(tmp_webp, webp_cache)
                    out_path, out_mime = webp_cache, "image/webp"
                except Exception:
                    im.save(tmp_jpg, format="JPEG", quality=82, optimize=True)
                    os.replace(tmp_jpg, jpg_cache)
                    out_path, out_mime = jpg_cache, "image/jpeg"
        except Exception as pil_exc:
            # Untuk HEIC/HEIF jangan pernah fallback ke ffmpeg karena menghasilkan HDR gain-map B&W atau potongan tile 512x512 ter-zoom.
            if is_heif:
                if _heif_convert_generate_jpeg(target_file, tmp_jpg, size):
                    os.replace(tmp_jpg, jpg_cache)
                    out_path, out_mime = jpg_cache, "image/jpeg"
                else:
                    raise HTTPException(
                        status_code=415,
                        detail="Dekoder HEIC (pillow-heif/libheif) belum aktif; silakan rebuild/tarik image container terbaru.",
                    )
            elif _ffmpeg_generate_jpeg(target_file, tmp_jpg, size, is_video=False):
                os.replace(tmp_jpg, jpg_cache)
                out_path, out_mime = jpg_cache, "image/jpeg"
            else:
                raise pil_exc

        _prune_thumb_cache(thumb_dir)
        return out_path, out_mime, cache_key
    finally:
        for tp in tmp_paths:
            if os.path.exists(tp):
                try:
                    os.remove(tp)
                except OSError:
                    pass
        _THUMB_SEMAPHORE.release()


def _thumb_prewarm_worker() -> None:
    """Worker latar prioritas rendah yang mengisi cache thumbnail ke disk tanpa menahan RAM."""
    global _THUMB_PREWARM_RUNNING
    processed_since_gc = 0
    try:
        thumb_dir = _thumb_cache_dir()
        while True:
            try:
                canonical_rel, target_file, size = _THUMB_PREWARM_QUEUE.get(timeout=2.0)
            except queue.Empty:
                break
            try:
                with _THUMB_PREWARM_LOCK:
                    _THUMB_PREWARM_PENDING.discard((canonical_rel, size))
                if os.path.isfile(target_file):
                    try:
                        file_mtime = int(os.path.getmtime(target_file))
                        cache_key = _thumb_cache_key(canonical_rel, file_mtime, size)
                        if _find_cached_thumb(thumb_dir, cache_key) is None:
                            _generate_thumbnail_to_disk(canonical_rel, target_file, size, thumb_dir, sem_timeout=0.5)
                            processed_since_gc += 1
                            if processed_since_gc >= 50:
                                processed_since_gc = 0
                                gc.collect()
                            time.sleep(0.05)
                    except Exception:
                        pass
            finally:
                _THUMB_PREWARM_QUEUE.task_done()
    finally:
        with _THUMB_PREWARM_LOCK:
            _THUMB_PREWARM_RUNNING = False


def _enqueue_thumbnail_prewarm(items: List[Tuple[str, str]], size: int = 256, force_start: bool = False) -> int:
    """Masukkan berkas media ke antrean pre-warm berbatas (maks 5000 item) secara aman RAM."""
    global _THUMB_PREWARM_THREAD, _THUMB_PREWARM_RUNNING
    if not items:
        return 0
    queued = 0
    is_test_env = "unittest" in sys.modules or "pytest" in sys.modules
    with _THUMB_PREWARM_LOCK:
        for canonical_rel, target_file in items:
            ext = os.path.splitext(target_file)[1].lower()
            if ext not in _VALID_THUMB_IMG_EXTS and ext not in _VALID_THUMB_VIDEO_EXTS:
                continue
            key = (canonical_rel, int(size))
            if key in _THUMB_PREWARM_PENDING:
                continue
            try:
                _THUMB_PREWARM_QUEUE.put_nowait((canonical_rel, target_file, int(size)))
                _THUMB_PREWARM_PENDING.add(key)
                queued += 1
            except queue.Full:
                break
        if queued > 0 and not _THUMB_PREWARM_RUNNING and (force_start or not is_test_env):
            _THUMB_PREWARM_RUNNING = True
            _THUMB_PREWARM_THREAD = threading.Thread(
                target=_thumb_prewarm_worker,
                name="thumb-prewarm-worker",
                daemon=True,
            )
            _THUMB_PREWARM_THREAD.start()
    return queued


def _enqueue_file_prewarm_if_media(canonical_rel: str, target_file: str, size: int = 256) -> int:
    ext = os.path.splitext(target_file)[1].lower()
    if ext not in _VALID_THUMB_IMG_EXTS and ext not in _VALID_THUMB_VIDEO_EXTS:
        return 0
    if "unittest" in sys.modules or "pytest" in sys.modules:
        return 0
    return _enqueue_thumbnail_prewarm([(canonical_rel, target_file)], size=size)


def _queue_folders_prewarm(
    storage_root: str,
    rel_folders: List[str],
    max_files: int = 2000,
    size: int = 256,
    force_start: bool = False,
) -> int:
    """Kumpulkan berkas media dari folder Gallery terpilih dan antrekan untuk pre-warm thumbnail."""
    collected: List[Tuple[str, str]] = []
    seen: Set[str] = set()
    for raw_rel in rel_folders:
        if len(collected) >= max_files:
            break
        try:
            canon_rel, base_abs = resolve_safe_storage_target(storage_root, str(raw_rel))
        except ValueError:
            continue
        if not canon_rel or not os.path.isdir(base_abs):
            continue
        for root_dir, dirnames, filenames in os.walk(base_abs):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            for fn in filenames:
                if fn.startswith("."):
                    continue
                ext = os.path.splitext(fn)[1].lower()
                if ext not in _VALID_THUMB_IMG_EXTS and ext not in _VALID_THUMB_VIDEO_EXTS:
                    continue
                full_p = os.path.join(root_dir, fn)
                rel_from_root = os.path.relpath(full_p, storage_root).replace("\\", "/")
                if rel_from_root in seen:
                    continue
                seen.add(rel_from_root)
                collected.append((rel_from_root, full_p))
                if len(collected) >= max_files:
                    break
            if len(collected) >= max_files:
                break
    return _enqueue_thumbnail_prewarm(collected, size=size, force_start=force_start)


def _thumb_cache_stats_snapshot(thumb_dir: str) -> Dict[str, Any]:
    file_count = 0
    total_bytes = 0
    if os.path.isdir(thumb_dir):
        try:
            with os.scandir(thumb_dir) as it:
                for entry in it:
                    name_low = entry.name.lower()
                    if not (name_low.endswith(".webp") or name_low.endswith(".jpg")):
                        continue
                    try:
                        if entry.is_file(follow_symlinks=False):
                            file_count += 1
                            total_bytes += int(entry.stat(follow_symlinks=False).st_size)
                    except OSError:
                        pass
        except OSError:
            pass
    with _THUMB_PREWARM_LOCK:
        prewarm_queued = _THUMB_PREWARM_QUEUE.qsize()
        prewarm_running = _THUMB_PREWARM_RUNNING
    usage_pct = round((total_bytes / float(THUMB_CACHE_MAX_BYTES)) * 100.0, 2) if THUMB_CACHE_MAX_BYTES > 0 else 0.0
    return {
        "file_count": file_count,
        "total_bytes": total_bytes,
        "max_bytes": THUMB_CACHE_MAX_BYTES,
        "usage_percent": usage_pct,
        "prewarm_queued": prewarm_queued,
        "prewarm_running": prewarm_running,
    }


@router.get("/thumbnails/stats")
def get_thumbnail_cache_stats(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Statistik pemakaian disk cache thumbnail & status antrean pre-warm (khusus admin)."""
    _eff_user, _allowed, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if not is_admin:
        raise HTTPException(status_code=403, detail="Hanya admin yang dapat mengelola cache thumbnail.")
    return _thumb_cache_stats_snapshot(_thumb_cache_dir())


@router.post("/thumbnails/clear")
def clear_thumbnail_cache(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Menghapus seluruh berkas cache thumbnail di disk (khusus admin)."""
    _eff_user, _allowed, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if not is_admin:
        raise HTTPException(status_code=403, detail="Hanya admin yang dapat membersihkan cache thumbnail.")
    thumb_dir = _thumb_cache_dir()
    deleted_count = 0
    freed_bytes = 0
    if os.path.isdir(thumb_dir):
        with _THUMB_PRUNE_LOCK:
            try:
                with os.scandir(thumb_dir) as it:
                    for entry in it:
                        name_low = entry.name.lower()
                        if not (name_low.endswith(".webp") or name_low.endswith(".jpg") or ".tmp." in name_low):
                            continue
                        try:
                            if entry.is_file(follow_symlinks=False):
                                sz = int(entry.stat(follow_symlinks=False).st_size)
                                os.remove(entry.path)
                                deleted_count += 1
                                freed_bytes += sz
                        except OSError:
                            pass
            except OSError:
                pass
    return {
        "deleted_count": deleted_count,
        "freed_bytes": freed_bytes,
        **_thumb_cache_stats_snapshot(thumb_dir),
    }


@router.post("/thumbnails/prewarm")
def prewarm_thumbnail_cache(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memicu pre-warm cache thumbnail Gallery di latar belakang tanpa menahan RAM (khusus admin)."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if not is_admin:
        raise HTTPException(status_code=403, detail="Hanya admin yang dapat menjalankan pre-warm thumbnail.")
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    uid = user_rec.get("id") if user_rec else None
    storage_root = _storage_dir()

    folders = _load_gallery_folders_pref(uid, db_path)
    if not folders and os.path.isdir(storage_root):
        try:
            with os.scandir(storage_root) as it:
                for entry in it:
                    if entry.name.startswith(".") or not entry.is_dir(follow_symlinks=False):
                        continue
                    perm = resolve_effective_path_permission(entry.name, user_rec, allowed_list, is_admin, db_path=db_path)
                    if perm["level"] != "none":
                        folders.append(entry.name)
        except OSError:
            pass

    queued = _queue_folders_prewarm(storage_root, folders, max_files=2000, size=256)
    snap = _thumb_cache_stats_snapshot(_thumb_cache_dir())
    return {
        "queued": queued,
        "folders": folders,
        **snap,
    }


@router.get("/thumbnail")
def get_file_thumbnail(
    path: str = Query(...),
    size: int = Query(default=256, ge=32, le=2048),
    v: Optional[str] = Query(default=None),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
    request: Request = None,
):
    """
    Menghasilkan dan mengembalikan thumbnail gambar atau berkas dengan disk cache LRU 2 GB & ETag 304.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin)
    if perm["level"] == "none":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    ext = os.path.splitext(target_file)[1].lower()
    if ext not in _VALID_THUMB_IMG_EXTS and ext not in _VALID_THUMB_VIDEO_EXTS:
        raise HTTPException(status_code=415, detail=f"Pembuatan thumbnail tidak didukung untuk tipe berkas {ext}")

    thumb_dir = _thumb_cache_dir()
    file_mtime = int(os.path.getmtime(target_file))
    cache_key = _thumb_cache_key(canonical_rel, file_mtime, size)
    etag = f'"{cache_key}"'
    resp_headers = {
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, max-age=604800, immutable",
        "ETag": etag,
    }

    hit = _find_cached_thumb(thumb_dir, cache_key)
    if hit is not None:
        hit_path, hit_mime = hit
        try:
            os.utime(hit_path, None)
        except OSError:
            pass
        if_none_match = request.headers.get("if-none-match") if hasattr(request, "headers") else None
        if if_none_match and etag in if_none_match:
            return Response(status_code=304, headers=resp_headers)
        return FileResponse(hit_path, media_type=hit_mime, headers=resp_headers)

    try:
        out_path, out_mime, _ = _generate_thumbnail_to_disk(canonical_rel, target_file, size, thumb_dir, sem_timeout=10.0)
        return FileResponse(out_path, media_type=out_mime, headers=resp_headers)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Gagal generate thumbnail untuk {target_file}: {e}")
        raise HTTPException(status_code=500, detail=f"Gagal membuat thumbnail: {str(e)}")


class DeleteRequest(BaseModel):
    path: Optional[str] = None
    paths: Optional[List[str]] = None
    username: Optional[str] = None


class CopyMoveRequest(BaseModel):
    src_paths: List[str]
    dest_dir: str
    username: Optional[str] = None
    conflict_mode: Optional[str] = "rename"


class DesktopClipboardCopyRequest(BaseModel):
    paths: List[str]
    username: Optional[str] = None


class TouchRequest(BaseModel):
    path: str
    username: Optional[str] = None


@router.post("/touch")
def create_empty_file(
    req: TouchRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat berkas baru kosong di dalam direktori target storage."""
    storage_root = _storage_dir()
    canonical_rel, target_path = _resolve_storage_or_400(storage_root, req.path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path berkas tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not canonical_rel) or perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")

    parent_dir = os.path.dirname(target_path)
    os.makedirs(parent_dir, exist_ok=True)

    base_dir = os.path.dirname(canonical_rel)
    orig_name = os.path.basename(canonical_rel)
    name_no_ext, ext = os.path.splitext(orig_name)
    counter = 1
    actual_rel = canonical_rel
    actual_path = target_path
    while os.path.exists(actual_path):
        new_name = f"{name_no_ext} ({counter}){ext}"
        cand_rel = f"{base_dir}/{new_name}" if base_dir else new_name
        actual_rel, actual_path = _resolve_storage_or_400(storage_root, cand_rel)
        cand_perm = resolve_effective_path_permission(actual_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if (not is_admin and not actual_rel) or cand_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")
        counter += 1

    actual_rel, actual_path = _resolve_storage_or_400(storage_root, actual_rel)
    final_perm = resolve_effective_path_permission(actual_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not actual_rel) or final_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")

    with open(actual_path, "w", encoding="utf-8") as f:
        pass
    if final_perm["level"] == "editor":
        caller_uid = user_rec.get("id") if user_rec else None
        if caller_uid is not None:
            record_internal_share_upload(actual_rel, int(caller_uid), eff_user, is_dir=False, db_path=db_path)
    invalidate_disk_usage_cache()

    try:
        log_activity(None, None, "STORAGE_TOUCH", f"User '{eff_user or 'anonymous'}' membuat berkas baru '{actual_rel}'", {"path": actual_rel})
    except Exception:
        pass

    return {"success": True, "created_path": actual_rel, "filename": os.path.basename(actual_rel)}


@router.post("/copy")
def copy_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyalin berkas atau direktori (Ctrl+C & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    raw_mode = str(req.conflict_mode or "rename").strip().lower()
    if raw_mode not in ("rename", "overwrite", "skip"):
        raise HTTPException(status_code=400, detail="conflict_mode tidak valid (gunakan rename, overwrite, atau skip).")

    storage_root = _storage_dir()
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    dest_rel, dest_full = _resolve_storage_or_400(storage_root, req.dest_dir)
    dest_perm = resolve_effective_path_permission(dest_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not dest_rel) or dest_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin ke direktori tujuan.")

    eff_mode = "rename" if dest_perm["level"] == "editor" else raw_mode

    validated_srcs = []
    for s in req.src_paths:
        src_rel, src_full = _resolve_storage_or_400(storage_root, s)
        src_perm = resolve_effective_path_permission(src_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if (not is_admin and not src_rel) or src_perm["level"] == "none":
            raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin berkas dari direktori sumber terlarang.")
        if src_rel:
            validated_srcs.append((src_rel, src_full))

    os.makedirs(dest_full, exist_ok=True)

    caller_uid = user_rec.get("id") if user_rec else None
    copied_items = []
    skipped_items = []
    for src_rel, src_full in validated_srcs:
        if not os.path.exists(src_full):
            continue

        base_name = os.path.basename(src_full)
        target_rel = f"{dest_rel}/{base_name}" if dest_rel else base_name
        target_rel_checked, target_item = _resolve_storage_or_400(storage_root, target_rel)
        target_perm = resolve_effective_path_permission(target_rel_checked, user_rec, allowed_list, is_admin, db_path=db_path)
        if target_perm["level"] not in ("system_admin", "owner", "administrator", "editor"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin ke target terlarang.")

        if os.path.exists(target_item):
            if eff_mode == "skip":
                skipped_items.append(base_name)
                continue
            elif eff_mode == "overwrite":
                src_abs = os.path.abspath(src_full)
                tgt_abs = os.path.abspath(target_item)
                if src_abs == tgt_abs:
                    skipped_items.append(base_name)
                    continue
                if os.path.isdir(src_abs) and os.path.commonpath([src_abs, tgt_abs]) == src_abs:
                    skipped_items.append(base_name)
                    continue
                if os.path.isdir(tgt_abs) and not os.path.isdir(src_abs):
                    skipped_items.append(base_name)
                    continue
                if os.path.isdir(tgt_abs):
                    shutil.rmtree(tgt_abs)
                else:
                    os.remove(tgt_abs)
            else:
                name_no_ext, ext = os.path.splitext(base_name)
                counter = 1
                if os.path.dirname(src_full) == dest_full:
                    cand = f"{name_no_ext} - Copy{ext}"
                    target_rel_checked, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
                while os.path.exists(target_item):
                    cand = f"{name_no_ext} - Copy ({counter}){ext}"
                    target_rel_checked, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
                    counter += 1

        try:
            is_dir_src = os.path.isdir(src_full)
            if is_dir_src:
                shutil.copytree(src_full, target_item)
            else:
                shutil.copy2(src_full, target_item)
            copied_items.append(os.path.basename(target_item))
            if dest_perm["level"] == "editor" and caller_uid is not None:
                record_internal_share_upload(target_rel_checked, int(caller_uid), eff_user, is_dir=is_dir_src, db_path=db_path)
        except Exception as e:
            logger.error(f"Gagal menyalin {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_COPY", f"User '{eff_user or 'anonymous'}' menyalin {len(copied_items)} item ke '{dest_rel}'", {"count": len(copied_items), "dest": dest_rel, "conflict_mode": eff_mode})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {
        "success": True,
        "copied_count": len(copied_items),
        "items": copied_items,
        "skipped_items": skipped_items,
        "conflict_mode": eff_mode,
    }


@router.post("/desktop-clipboard")
def copy_to_desktop_clipboard(
    req: DesktopClipboardCopyRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyiarkan item pilihan Web Explorer ke clipboard Desktop melalui SSE terautentikasi JWT."""
    raw_paths = [str(p or "").strip() for p in (req.paths or []) if str(p or "").strip()]
    if not raw_paths:
        raise HTTPException(status_code=400, detail="Daftar paths tidak boleh kosong.")

    storage_root = _storage_dir()
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    validated_items: List[Dict[str, Any]] = []
    for raw_p in raw_paths:
        rel_p, abs_p = _resolve_storage_or_400(storage_root, raw_p)
        if not rel_p:
            raise HTTPException(status_code=400, detail="Path tidak boleh kosong.")
        perm = resolve_effective_path_permission(rel_p, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] == "none":
            raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin item dari direktori terlarang.")
        if not os.path.exists(abs_p):
            raise HTTPException(status_code=404, detail="Berkas atau direktori tidak ditemukan.")
        is_dir = os.path.isdir(abs_p)
        validated_items.append({
            "relative_path": rel_p,
            "name": os.path.basename(abs_p),
            "is_dir": is_dir,
            "size": 0 if is_dir else os.path.getsize(abs_p),
        })

    delivered = publish_realtime_event(
        "desktop_clipboard_copy",
        {"username": eff_user, "items": validated_items},
    )
    return {
        "success": True,
        "count": len(validated_items),
        "items": validated_items,
        "delivered": delivered,
    }


@router.post("/move")
def move_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memindahkan berkas atau direktori (Ctrl+X & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    storage_root = _storage_dir()
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    dest_rel, dest_full = _resolve_storage_or_400(storage_root, req.dest_dir)
    dest_perm = resolve_effective_path_permission(dest_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if (not is_admin and not dest_rel) or dest_perm["level"] not in ("system_admin", "owner", "administrator"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan ke direktori tujuan.")

    validated_srcs = []
    for s in req.src_paths:
        src_rel, src_full = _resolve_storage_or_400(storage_root, s)
        src_perm = resolve_effective_path_permission(src_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if (not is_admin and not src_rel) or src_perm["level"] not in ("system_admin", "owner", "administrator"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan berkas dari direktori sumber terlarang.")
        if src_perm["level"] == "administrator" and src_perm["is_share_root"]:
            raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan folder akar yang dibagikan.")
        if src_rel:
            validated_srcs.append((src_rel, src_full))

    os.makedirs(dest_full, exist_ok=True)

    moved_items = []
    for src_rel, src_full in validated_srcs:
        if not os.path.exists(src_full):
            continue

        if os.path.isdir(src_full):
            if dest_full == src_full or dest_full.startswith(src_full + os.sep):
                continue

        base_name = os.path.basename(src_full)
        if os.path.dirname(src_full) == dest_full:
            continue

        target_rel = f"{dest_rel}/{base_name}" if dest_rel else base_name
        target_rel_checked, target_item = _resolve_storage_or_400(storage_root, target_rel)
        target_perm = resolve_effective_path_permission(target_rel_checked, user_rec, allowed_list, is_admin, db_path=db_path)
        if target_perm["level"] not in ("system_admin", "owner", "administrator"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan ke target terlarang.")

        if os.path.exists(target_item):
            name_no_ext, ext = os.path.splitext(base_name)
            counter = 1
            while os.path.exists(target_item):
                cand = f"{name_no_ext} ({counter}){ext}"
                target_rel_checked, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
                counter += 1

        try:
            was_dir = os.path.isdir(src_full)
            shutil.move(src_full, target_item)
            moved_items.append(os.path.basename(target_item))
            move_internal_upload_records(src_rel, target_rel_checked, is_dir=was_dir, db_path=db_path)
        except Exception as e:
            logger.error(f"Gagal memindahkan {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_MOVE", f"User '{eff_user or 'anonymous'}' memindahkan {len(moved_items)} item ke '{dest_rel}'", {"count": len(moved_items), "dest": dest_rel})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {"success": True, "moved_count": len(moved_items), "items": moved_items}


@router.post("/rename")
def rename_file_or_folder(
    req: RenameRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengganti nama berkas atau folder (dilarang untuk viewer/editor atau administrator pada share root)."""
    storage_root = _storage_dir()
    canonical_rel, target_abs = _resolve_storage_or_400(storage_root, req.path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path target tidak boleh kosong.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if perm["level"] not in ("system_admin", "owner", "administrator"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengganti nama berkas atau folder ini.")
    if perm["level"] == "administrator" and perm["is_share_root"]:
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengganti nama folder akar yang dibagikan.")

    raw_new_name = str(req.new_name or "").strip()
    if (
        not raw_new_name
        or raw_new_name in (".", "..")
        or "/" in raw_new_name
        or "\\" in raw_new_name
        or "\x00" in raw_new_name
    ):
        raise HTTPException(status_code=400, detail="Nama baru tidak valid.")

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau folder tidak ditemukan.")

    parent_rel = os.path.dirname(canonical_rel).replace("\\", "/").strip("/")
    new_rel_raw = f"{parent_rel}/{raw_new_name}" if parent_rel else raw_new_name
    new_rel, new_abs = _resolve_storage_or_400(storage_root, new_rel_raw)
    new_perm = resolve_effective_path_permission(new_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if new_perm["level"] not in ("system_admin", "owner", "administrator"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengganti nama ke lokasi terlarang.")

    if new_abs == target_abs:
        return {"success": True, "old_path": canonical_rel, "new_path": new_rel, "new_name": raw_new_name}

    if os.path.exists(new_abs):
        raise HTTPException(status_code=409, detail="Berkas atau folder dengan nama tersebut sudah ada.")

    was_dir = os.path.isdir(target_abs)
    os.replace(target_abs, new_abs)
    move_internal_upload_records(canonical_rel, new_rel, is_dir=was_dir, db_path=db_path)
    invalidate_disk_usage_cache()
    try:
        log_activity(
            None,
            None,
            "STORAGE_RENAME",
            f"User '{eff_user or 'anonymous'}' mengganti nama '{canonical_rel}' menjadi '{new_rel}'",
            {"old_path": canonical_rel, "new_path": new_rel},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "old_path": canonical_rel, "new_path": new_rel, "new_name": raw_new_name}


@router.post("/delete")
def delete_file_or_folder(
    req: DeleteRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menghapus berkas atau direktori (single maupun batch) secara aman dari server storage."""
    raw_paths = []
    if req.paths:
        raw_paths = [p for p in req.paths if p and str(p).strip()]
    elif req.path and str(req.path).strip():
        raw_paths = [req.path]

    if not raw_paths:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    caller_uid = user_rec.get("id") if user_rec else None
    db_path = _db_path()

    storage_root = _storage_dir()
    root_real = os.path.realpath(storage_root)
    resolved_targets = []
    for raw_p in raw_paths:
        canonical_rel, target_path = _resolve_storage_or_400(storage_root, raw_p)
        perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if (not is_admin and not canonical_rel) or perm["level"] in ("none", "viewer"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan menghapus berkas atau direktori terlarang.")
        if perm["level"] == "administrator" and perm["is_share_root"]:
            raise HTTPException(status_code=403, detail="Tidak diizinkan menghapus folder akar yang dibagikan.")
        if perm["level"] == "editor":
            if perm["is_share_root"] or caller_uid is None:
                raise HTTPException(status_code=403, detail="Editor hanya diizinkan menghapus item yang diunggah sendiri.")
            if os.path.exists(target_path):
                if os.path.isdir(target_path):
                    if not is_internal_dir_fully_owned_by_user(storage_root, canonical_rel, target_path, int(caller_uid), db_path=db_path):
                        raise HTTPException(status_code=403, detail="Folder berisi item milik pengguna lain dan tidak dapat dihapus oleh Editor.")
                else:
                    up_owner = get_internal_upload_owner(canonical_rel, db_path=db_path)
                    if not up_owner or int(up_owner["uploaded_by_user_id"]) != int(caller_uid):
                        raise HTTPException(status_code=403, detail="Editor hanya diizinkan menghapus berkas yang diunggah sendiri.")
        resolved_targets.append((canonical_rel, target_path))

    deleted_paths = []
    for canonical_rel, target_path in resolved_targets:
        if not canonical_rel or not os.path.exists(target_path) or target_path == root_real:
            continue

        is_dir = os.path.isdir(target_path)
        try:
            if is_dir:
                shutil.rmtree(target_path)
            else:
                os.remove(target_path)
            deleted_paths.append(canonical_rel)
            remove_internal_upload_records(canonical_rel, is_dir=is_dir, db_path=db_path)
            delete_internal_shares_under_path(canonical_rel, is_dir=is_dir, db_path=db_path)
        except Exception as e:
            logger.error(f"Gagal menghapus target: {str(e)}")

    try:
        log_activity(None, None, "STORAGE_DELETE", f"User '{eff_user or 'anonymous'}' menghapus {len(deleted_paths)} target", {"deleted_paths": deleted_paths})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {"success": True, "deleted_count": len(deleted_paths), "deleted_paths": deleted_paths}


def _launch_storage_job(op_name: str, worker_fn) -> Dict[str, Any]:
    """Menjalankan operasi storage besar (copy/move/delete) sebagai background job terpantau."""
    job_id = uuid.uuid4().hex[:16]
    rec = {
        "job_id": job_id,
        "operation": op_name,
        "status": "running",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "result": None,
        "error": None,
    }
    with _STORAGE_JOBS_LOCK:
        if len(_STORAGE_JOBS) > 200:
            done_keys = [k for k, v in _STORAGE_JOBS.items() if v.get("status") != "running"]
            for k in done_keys[: max(0, len(done_keys) - 50)]:
                _STORAGE_JOBS.pop(k, None)
        _STORAGE_JOBS[job_id] = rec

    def _runner():
        try:
            res = worker_fn()
            with _STORAGE_JOBS_LOCK:
                rec["status"] = "completed"
                rec["result"] = res
        except Exception as exc:
            with _STORAGE_JOBS_LOCK:
                rec["status"] = "failed"
                rec["error"] = str(exc)

    threading.Thread(target=_runner, daemon=True, name=f"storage-job-{job_id}").start()
    return dict(rec)


@router.get("/jobs/{job_id}")
def get_storage_job_status(job_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memeriksa status dan progres background job copy/move/delete."""
    verify_active_jwt_user(current_user, allow_stream_scope=False)
    with _STORAGE_JOBS_LOCK:
        job = _STORAGE_JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job storage tidak ditemukan.")
        return dict(job)


@router.post("/jobs/copy")
def enqueue_copy_job(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "copy",
        lambda: copy_files_or_folders(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.post("/jobs/move")
def enqueue_move_job(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "move",
        lambda: move_files_or_folders(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.post("/jobs/delete")
def enqueue_delete_job(
    req: DeleteRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "delete",
        lambda: delete_file_or_folder(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.get("/explorer", response_class=HTMLResponse)
def get_storage_explorer_page(
    path: Optional[str] = Query(default=""),
):
    """
    Menyajikan Modern Storage Explorer Web Single-Page Application.
    Mendukung tampilan Kartu Grid & List, dynamic thumbnails, video streaming player,
    drag-and-drop upload, dan aksi cepat 'Salin untuk WhatsApp'.
    """
    template_paths = [
        os.path.join(os.path.dirname(__file__), "..", "templates", "explorer.html"),
        os.path.join(os.path.dirname(__file__), "templates", "explorer.html"),
        os.path.join(_data_dir(), "templates", "explorer.html"),
    ]
    html_content = None
    for p in template_paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    html_content = f.read()
                break
            except Exception:
                pass

    if not html_content:
        html_content = "<html><body><h3>MyServer Explorer: template not found</h3></body></html>"

    return HTMLResponse(content=html_content, status_code=200)


# ==============================================================================
# PUBLIC SHARE LINK MANAGEMENT ENDPOINTS (JWT-AUTHENTICATED - SHL-01)
# ==============================================================================

MAX_PUBLIC_SHARE_UPLOAD_MB = 102400


def validate_public_share_role_and_limit(
    raw_role: Optional[str],
    raw_max_upload_mb: Any,
    is_dir: bool,
) -> Tuple[str, Optional[int]]:
    """Validasi role ('viewer'|'editor') dan max_upload_mb (None atau int 1..102400) untuk tautan publik."""
    if raw_role is None or not str(raw_role).strip():
        norm_role = "viewer"
    else:
        norm_role = str(raw_role).strip().lower()
    if norm_role not in ("viewer", "editor"):
        raise HTTPException(
            status_code=400,
            detail="Peran tautan publik tidak valid. Hanya 'viewer' atau 'editor' yang diizinkan.",
        )
    eff_role = "editor" if (norm_role == "editor" and bool(is_dir)) else "viewer"

    if raw_max_upload_mb is None:
        return eff_role, None
    if isinstance(raw_max_upload_mb, bool) or not isinstance(raw_max_upload_mb, int):
        raise HTTPException(
            status_code=400,
            detail=f"Nilai max_upload_mb harus berupa bilangan bulat antara 1 hingga {MAX_PUBLIC_SHARE_UPLOAD_MB} MB.",
        )
    if raw_max_upload_mb < 1 or raw_max_upload_mb > MAX_PUBLIC_SHARE_UPLOAD_MB:
        raise HTTPException(
            status_code=400,
            detail=f"Nilai max_upload_mb harus antara 1 hingga {MAX_PUBLIC_SHARE_UPLOAD_MB} MB.",
        )
    return eff_role, int(raw_max_upload_mb) * 1024 * 1024


@router.post("/shares")
def create_storage_public_share(
    req: PublicShareCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat tautan berbagi publik baru untuk berkas atau folder di dalam allowed_disks pengguna."""
    storage_root = _storage_dir()
    canonical_rel, target_abs = _resolve_storage_or_400(storage_root, req.path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path berkas atau folder tidak boleh kosong.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if perm["level"] not in ("system_admin", "owner", "administrator"):
        raise HTTPException(
            status_code=403,
            detail="Tidak diizinkan membagikan berkas atau direktori di luar otorisasi akun.",
        )

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau direktori tidak ditemukan.")

    target_is_dir = os.path.isdir(target_abs)
    eff_role, max_upload_bytes = validate_public_share_role_and_limit(
        getattr(req, "role", "viewer"),
        getattr(req, "max_upload_mb", None),
        target_is_dir,
    )

    db_path = _db_path()
    if req.public_base_url is not None:
        raw_base = str(req.public_base_url or "").strip().rstrip("/")
        if not is_admin:
            current_base = get_public_base_url(db_path=db_path).strip().rstrip("/")
            if raw_base and raw_base != current_base:
                raise HTTPException(
                    status_code=403,
                    detail="Hanya administrator yang diizinkan mengubah Public Base URL.",
                )
        else:
            try:
                set_public_base_url(req.public_base_url, db_path=db_path)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    expires_at = None
    if req.expires_in_hours is not None:
        try:
            hrs = float(req.expires_in_hours)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Nilai expires_in_hours tidak valid.")
        if hrs > 0:
            now_utc = datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)
            expires_at = (now_utc + timedelta(hours=hrs)).isoformat() + "Z"
    elif req.expires_at and str(req.expires_at).strip():
        expires_at = str(req.expires_at).strip()

    owner_uid = None
    if isinstance(current_user, dict):
        owner_uid = current_user.get("user_id") or current_user.get("uid")
    if owner_uid is None:
        u_rec = get_user_by_username(eff_user, db_path=db_path)
        owner_uid = u_rec["id"] if u_rec else None

    clean_pwd = str(req.password).strip() if (req.password and str(req.password).strip()) else None
    share_rec = create_public_share(
        owner_username=eff_user,
        owner_user_id=owner_uid,
        target_path=canonical_rel,
        is_dir=target_is_dir,
        label=(req.label or os.path.basename(canonical_rel)),
        expires_at=expires_at,
        password=clean_pwd,
        role=eff_role,
        max_upload_bytes=max_upload_bytes,
        db_path=db_path,
    )
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_CREATED",
            f"User '{eff_user}' membuat tautan berbagi publik '{canonical_rel}'",
            {
                "token": share_rec["token"],
                "path": canonical_rel,
                "is_dir": share_rec["is_dir"],
                "role": share_rec["role"],
                "max_upload_bytes": share_rec["max_upload_bytes"],
            },
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "share": share_rec}


@router.get("/shares")
def list_storage_public_shares(
    include_revoked: bool = Query(default=False),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menampilkan daftar tautan berbagi publik milik pengguna atau yang dikelola Scoped Folder Admin."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    if is_admin:
        shares = list_public_shares(
            owner_username=eff_user,
            is_admin=True,
            include_revoked=bool(include_revoked),
            db_path=db_path,
        )
    else:
        user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
        all_shares = list_public_shares(
            owner_username=None,
            is_admin=True,
            include_revoked=bool(include_revoked),
            db_path=db_path,
        )
        shares = []
        for s in all_shares:
            if str(s.get("owner_username") or "").strip().lower() == eff_user.lower():
                shares.append(s)
                continue
            s_perm = resolve_effective_path_permission(
                str(s.get("target_path") or ""),
                user_rec,
                allowed_list,
                is_admin=False,
                db_path=db_path,
            )
            if s_perm["level"] == "administrator":
                shares.append(s)
    return {
        "shares": shares,
        "total": len(shares),
        "public_base_url": get_public_base_url(db_path=db_path),
        "username": eff_user,
        "is_admin": is_admin,
    }


@router.put("/shares/settings")
def update_storage_public_share_settings(
    req: PublicShareSettingsRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyimpan pengaturan Public Base URL untuk tautan berbagi publik (Hanya Administrator)."""
    _, _, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if not is_admin:
        raise HTTPException(
            status_code=403,
            detail="Hanya administrator yang diizinkan mengubah Public Base URL.",
        )
    db_path = _db_path()
    try:
        clean_url = set_public_base_url(req.public_base_url or "", db_path=db_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"success": True, "public_base_url": clean_url}


@router.delete("/shares/{share_token}")
def delete_storage_public_share(
    share_token: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mencabut (revoke) tautan berbagi publik berdasarkan token (pemilik, system admin, atau Scoped Folder Admin)."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    can_revoke_as_admin = bool(is_admin)
    if not can_revoke_as_admin:
        existing_share = get_public_share(share_token, db_path=db_path, include_secret=False)
        if not existing_share:
            raise HTTPException(status_code=404, detail="Tautan berbagi tidak ditemukan.")
        if str(existing_share.get("owner_username") or "").strip().lower() != eff_user.lower():
            user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
            s_perm = resolve_effective_path_permission(
                str(existing_share.get("target_path") or ""),
                user_rec,
                allowed_list,
                is_admin=False,
                db_path=db_path,
            )
            if s_perm["level"] == "administrator":
                can_revoke_as_admin = True
    ok, reason = revoke_public_share(
        token=share_token,
        requester_username=eff_user,
        is_admin=can_revoke_as_admin,
        db_path=db_path,
    )
    if not ok and reason == "not_found":
        raise HTTPException(status_code=404, detail="Tautan berbagi tidak ditemukan.")
    if not ok and reason == "forbidden":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mencabut tautan milik pengguna lain.")
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_REVOKED",
            f"User '{eff_user}' mencabut tautan berbagi publik '{share_token}'",
            {"token": share_token},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "token": share_token, "status": "revoked"}


# ==============================================================================
# INTERNAL ACCOUNT SHARING ENDPOINTS (SHRL-02)
# ==============================================================================

_INTERNAL_GRANT_ALLOWED_ROLES = ("viewer", "editor", "administrator")


def _caller_grant_ceiling_rank(perm_level: str) -> int:
    if perm_level in ("system_admin", "owner", "administrator"):
        return 3
    return 0


@router.get("/share-accounts")
def get_share_account_candidates(
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengembalikan daftar akun non-sensitif [{id, username}] selain pemanggil untuk picker berbagi internal."""
    eff_user, _, _ = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    caller_uid = user_rec.get("id") if user_rec else None
    accounts = list_share_account_candidates(exclude_user_id=caller_uid, db_path=db_path)
    return {"accounts": accounts}


@router.get("/shared-with-me")
def get_shared_with_me(
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menampilkan daftar berkas/folder yang dibagikan ke akun pemanggil via internal_shares."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    storage_root = _storage_dir()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    caller_uid = user_rec.get("id") if user_rec else None
    if caller_uid is None:
        return {"items": [], "total": 0}

    grants = list_internal_shares_for_grantee(int(caller_uid), db_path=db_path)
    items: List[Dict[str, Any]] = []
    for g in grants:
        if int(g.get("owner_user_id") or -1) == int(caller_uid):
            continue
        tp = str(g.get("target_path") or "").strip().replace("\\", "/").strip("/")
        if not tp:
            continue
        try:
            canonical_rel, target_abs = resolve_safe_storage_target(storage_root, tp)
        except ValueError:
            continue
        if not os.path.exists(target_abs):
            continue
        perm = resolve_effective_path_permission(
            canonical_rel,
            user_rec,
            allowed_list,
            is_admin=False,
            db_path=db_path,
        )
        if perm["level"] == "none":
            continue
        items.append({
            "id": int(g["id"]),
            "target_path": canonical_rel,
            "name": os.path.basename(canonical_rel) or canonical_rel,
            "is_dir": bool(os.path.isdir(target_abs)),
            "role": str(perm["level"] if perm["via"] == "internal_share" else g["role"]),
            "owner_username": str(g.get("owner_username") or ""),
            "exists": True,
            "created_at": str(g.get("created_at") or ""),
            "updated_at": str(g.get("updated_at") or ""),
        })
    return {"items": items, "total": len(items)}


@router.get("/account-shares")
def list_account_shares(
    target_path: str = Query(...),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menampilkan daftar izin berbagi internal pada target_path tertentu."""
    storage_root = _storage_dir()
    canonical_rel, _ = _resolve_storage_or_400(storage_root, target_path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="target_path tidak boleh kosong.")
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    if perm["level"] not in ("system_admin", "owner", "administrator"):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengelola berbagi internal untuk jalur ini.")
    shares = list_internal_shares_for_path(canonical_rel, db_path=db_path)
    return {"shares": shares, "total": len(shares), "caller_role": perm["level"]}


@router.post("/account-shares")
def create_or_update_account_share(
    req: InternalShareCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memberikan atau memperbarui izin berbagi internal ke akun Backend lain."""
    storage_root = _storage_dir()
    canonical_rel, target_abs = _resolve_storage_or_400(storage_root, req.target_path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="target_path tidak boleh kosong.")

    req_role = str(req.role or "viewer").strip().lower()
    if req_role not in _INTERNAL_GRANT_ALLOWED_ROLES:
        raise HTTPException(status_code=400, detail="Peran berbagi internal harus viewer, editor, atau administrator.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    perm = resolve_effective_path_permission(canonical_rel, user_rec, allowed_list, is_admin, db_path=db_path)
    ceiling = _caller_grant_ceiling_rank(perm["level"])
    if ceiling <= 0:
        raise HTTPException(status_code=403, detail="Tidak diizinkan membagikan jalur ini secara internal.")
    if _INTERNAL_ROLE_RANKS.get(req_role, 99) > ceiling:
        raise HTTPException(status_code=403, detail="Tidak dapat memberikan peran lebih tinggi dari otoritas Anda.")

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau folder target tidak ditemukan.")

    grantee_uname = str(req.grantee_username or "").strip().lower()
    if not grantee_uname:
        raise HTTPException(status_code=400, detail="grantee_username wajib diisi.")
    if grantee_uname == eff_user.lower():
        raise HTTPException(status_code=400, detail="Tidak dapat membagikan ke akun sendiri.")

    grantee_rec = get_user_by_username(grantee_uname, db_path=db_path)
    if not grantee_rec:
        raise HTTPException(status_code=404, detail="Akun penerima tidak ditemukan.")

    target_is_dir = os.path.isdir(target_abs)
    eff_role = req_role if target_is_dir else "viewer"
    owner_uid = user_rec.get("id") if user_rec else None

    share_rec = upsert_internal_share(
        owner_user_id=owner_uid,
        owner_username=eff_user,
        target_path=canonical_rel,
        is_dir=target_is_dir,
        grantee_user_id=int(grantee_rec["id"]),
        grantee_username=str(grantee_rec["username"]),
        role=eff_role,
        db_path=db_path,
    )
    try:
        log_activity(
            None,
            None,
            "INTERNAL_SHARE_GRANTED",
            f"User '{eff_user}' membagikan '{canonical_rel}' ke '{grantee_rec['username']}' ({eff_role})",
            {"path": canonical_rel, "grantee": grantee_rec["username"], "role": eff_role, "grant_id": share_rec["id"]},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "share": share_rec}


def _handle_update_account_share_role(
    grant_id: int,
    req: InternalShareUpdateRequest,
    current_user: Dict[str, Any],
) -> Dict[str, Any]:
    req_role = str(req.role or "").strip().lower()
    if req_role not in _INTERNAL_GRANT_ALLOWED_ROLES:
        raise HTTPException(status_code=400, detail="Peran berbagi internal harus viewer, editor, atau administrator.")
    db_path = _db_path()
    grant = get_internal_share_by_id(grant_id, db_path=db_path)
    if not grant:
        raise HTTPException(status_code=404, detail="Izin berbagi internal tidak ditemukan.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    perm = resolve_effective_path_permission(grant["target_path"], user_rec, allowed_list, is_admin, db_path=db_path)
    ceiling = _caller_grant_ceiling_rank(perm["level"])
    if ceiling <= 0:
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengubah izin berbagi internal untuk jalur ini.")
    if _INTERNAL_ROLE_RANKS.get(req_role, 99) > ceiling:
        raise HTTPException(status_code=403, detail="Tidak dapat memberikan peran lebih tinggi dari otoritas Anda.")

    eff_role = req_role if bool(grant["is_dir"]) else "viewer"
    updated = update_internal_share_role(grant_id, eff_role, db_path=db_path)
    if not updated:
        raise HTTPException(status_code=404, detail="Izin berbagi internal tidak ditemukan.")
    try:
        log_activity(
            None,
            None,
            "INTERNAL_SHARE_UPDATED",
            f"User '{eff_user}' memperbarui izin '{grant['target_path']}' untuk '{grant['grantee_username']}' menjadi '{eff_role}'",
            {"grant_id": grant_id, "path": grant["target_path"], "role": eff_role},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "share": updated}


@router.patch("/account-shares/{grant_id}")
def patch_account_share_role(
    grant_id: int,
    req: InternalShareUpdateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memperbarui peran izin berbagi internal (PATCH)."""
    return _handle_update_account_share_role(grant_id, req, current_user)


@router.put("/account-shares/{grant_id}")
def put_account_share_role(
    grant_id: int,
    req: InternalShareUpdateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memperbarui peran izin berbagi internal (PUT)."""
    return _handle_update_account_share_role(grant_id, req, current_user)


@router.delete("/account-shares/{grant_id}")
def revoke_account_share(
    grant_id: int,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mencabut izin berbagi internal (oleh admin/owner/scoped-admin atau penerima untuk keluar)."""
    db_path = _db_path()
    grant = get_internal_share_by_id(grant_id, db_path=db_path)
    if not grant:
        raise HTTPException(status_code=404, detail="Izin berbagi internal tidak ditemukan.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    caller_uid = user_rec.get("id") if user_rec else None
    is_grantee = bool(
        (caller_uid is not None and int(caller_uid) == int(grant["grantee_user_id"]))
        or str(grant.get("grantee_username") or "").strip().lower() == eff_user.lower()
    )
    if not is_grantee:
        perm = resolve_effective_path_permission(grant["target_path"], user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] not in ("system_admin", "owner", "administrator"):
            raise HTTPException(status_code=403, detail="Tidak diizinkan mencabut izin berbagi internal ini.")

    delete_internal_share(grant_id, db_path=db_path)
    try:
        log_activity(
            None,
            None,
            "INTERNAL_SHARE_REVOKED",
            f"User '{eff_user}' mencabut izin berbagi '{grant['target_path']}' dari '{grant['grantee_username']}'",
            {"grant_id": grant_id, "path": grant["target_path"], "grantee": grant["grantee_username"]},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "id": grant_id, "status": "revoked"}


# ==============================================================================
# STORAGE SEARCH & GALLERY ENDPOINTS (v2.1.0)
# ==============================================================================

_GALLERY_IMAGE_EXTS = {
    ".jpg", ".jpeg", ".jpe", ".jfif", ".png", ".webp", ".bmp", ".gif", ".svg", ".ico",
    ".tiff", ".tif", ".avif", ".heic", ".heif", ".hif", ".jxl", ".jp2", ".j2k",
    ".psd", ".tga", ".dds", ".dng", ".raw", ".cr2", ".cr3", ".nef", ".arw",
    ".orf", ".rw2", ".raf", ".pef", ".srw",
}
_GALLERY_VIDEO_EXTS = {
    ".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ts", ".m2ts", ".mts",
    ".3gp", ".3g2", ".flv", ".f4v", ".wmv", ".asf", ".mpg", ".mpeg", ".mpe",
    ".mpv", ".ogv", ".vob", ".rm", ".rmvb", ".divx", ".xvid", ".mxf",
}


def _parse_exif_datetime_str(raw: Any) -> Optional[int]:
    """Parse EXIF 'YYYY:MM:DD HH:MM:SS' or ISO datetime string into epoch seconds."""
    if raw is None:
        return None
    text = str(raw).strip().strip("\x00")
    if not text or text.startswith("0000:00:00"):
        return None
    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            dt = datetime.strptime(text[:19], fmt)
            ts = int(dt.timestamp())
            if 631152000 <= ts <= int(time.time()) + 86400:
                return ts
        except Exception:
            continue
    return None


def _extract_jpeg_exif_raw(abs_path: str) -> Optional[int]:
    """Pure-Python lightweight JPEG APP1 EXIF DateTimeOriginal parser."""
    try:
        with open(abs_path, "rb") as fp:
            head = fp.read(65536)
        if not head.startswith(b"\xff\xd8"):
            return None
        pos = 2
        n = len(head)
        while pos + 4 <= n:
            if head[pos] != 0xFF:
                break
            marker = head[pos + 1]
            if marker in (0xD8, 0xD9, 0xDA):
                break
            seg_len = struct.unpack(">H", head[pos + 2: pos + 4])[0]
            seg_start = pos + 4
            seg_end = seg_start + max(0, seg_len - 2)
            if marker == 0xE1 and head[seg_start: seg_start + 6] == b"Exif\x00\x00":
                tiff = head[seg_start + 6: seg_end]
                if len(tiff) < 8:
                    return None
                endian = "<" if tiff[:2] == b"II" else (">" if tiff[:2] == b"MM" else "")
                if not endian:
                    return None
                ifd0_off = struct.unpack(endian + "I", tiff[4:8])[0]

                def _read_ifd(off: int) -> Dict[int, Any]:
                    tags: Dict[int, Any] = {}
                    if off + 2 > len(tiff):
                        return tags
                    cnt = struct.unpack(endian + "H", tiff[off: off + 2])[0]
                    for i in range(cnt):
                        ent_off = off + 2 + i * 12
                        if ent_off + 12 > len(tiff):
                            break
                        tag_id, typ, count = struct.unpack(endian + "HHI", tiff[ent_off: ent_off + 8])
                        val_bytes = tiff[ent_off + 8: ent_off + 12]
                        if typ == 2 and count >= 19:  # ASCII datetime string
                            str_off = struct.unpack(endian + "I", val_bytes)[0]
                            if str_off + count <= len(tiff):
                                tags[tag_id] = tiff[str_off: str_off + count].decode("ascii", errors="ignore")
                        elif typ == 4 and count == 1:
                            tags[tag_id] = struct.unpack(endian + "I", val_bytes)[0]
                    return tags

                ifd0 = _read_ifd(ifd0_off)
                if 0x8769 in ifd0:
                    exif_ifd = _read_ifd(int(ifd0[0x8769]))
                    for tag in (0x9003, 0x9004):
                        ts = _parse_exif_datetime_str(exif_ifd.get(tag))
                        if ts:
                            return ts
                ts = _parse_exif_datetime_str(ifd0.get(0x0132))
                if ts:
                    return ts
                return None
            pos = seg_start + max(0, seg_len - 2)
    except Exception:
        return None
    return None


def _extract_image_taken_at(abs_path: str) -> Optional[int]:
    """Extract original capture timestamp from image EXIF metadata (with PIL + pure-Python fallback)."""
    try:
        from PIL import Image
        try:
            import pillow_heif  # type: ignore
            pillow_heif.register_heif_opener()
        except Exception:
            pass
        with Image.open(abs_path) as im:
            exif = im.getexif()
            if exif:
                try:
                    exif_ifd = exif.get_ifd(0x8769)
                    if exif_ifd:
                        for tag_id in (36867, 36868):  # DateTimeOriginal, DateTimeDigitized
                            ts = _parse_exif_datetime_str(exif_ifd.get(tag_id))
                            if ts:
                                return ts
                except Exception:
                    pass
                for tag_id in (36867, 36868, 306):  # DateTimeOriginal, DateTimeDigitized, DateTime
                    ts = _parse_exif_datetime_str(exif.get(tag_id))
                    if ts:
                        return ts
    except Exception:
        pass
    return _extract_jpeg_exif_raw(abs_path)


def _extract_mp4_mvhd_creation_time(abs_path: str) -> Optional[int]:
    """Fast pure-Python parser for MP4/MOV moov->mvhd creation_time atom."""
    try:
        file_size = os.path.getsize(abs_path)
        if file_size < 16:
            return None
        with open(abs_path, "rb") as fp:
            def _scan_boxes(start: int, end: int, target: bytes) -> Optional[Tuple[int, int]]:
                pos = start
                while pos + 8 <= end:
                    fp.seek(pos)
                    hdr = fp.read(8)
                    if len(hdr) < 8:
                        break
                    box_size, box_type = struct.unpack(">I4s", hdr)
                    hdr_len = 8
                    if box_size == 1:
                        ext_hdr = fp.read(8)
                        if len(ext_hdr) < 8:
                            break
                        box_size = struct.unpack(">Q", ext_hdr)[0]
                        hdr_len = 16
                    elif box_size == 0:
                        box_size = end - pos
                    if box_size < hdr_len:
                        break
                    if box_type == target:
                        return (pos + hdr_len, min(end, pos + box_size))
                    pos += box_size
                return None

            moov_span = _scan_boxes(0, file_size, b"moov")
            if not moov_span:
                return None
            mvhd_span = _scan_boxes(moov_span[0], moov_span[1], b"mvhd")
            if not mvhd_span:
                return None
            fp.seek(mvhd_span[0])
            ver_flags = fp.read(4)
            if len(ver_flags) < 4:
                return None
            version = ver_flags[0]
            if version == 0:
                raw_ts = struct.unpack(">I", fp.read(4))[0]
            elif version == 1:
                raw_ts = struct.unpack(">Q", fp.read(8))[0]
            else:
                return None
            # QuickTime epoch offset between 1904-01-01 and 1970-01-01 = 2082844800 seconds
            unix_ts = int(raw_ts) - 2082844800
            if 631152000 <= unix_ts <= int(time.time()) + 86400:
                return unix_ts
    except Exception:
        pass
    return None


def _extract_video_taken_at(abs_path: str) -> Optional[int]:
    """Extract original video creation timestamp from MP4 atom or ffprobe fallback."""
    ext = os.path.splitext(abs_path)[1].lower()
    if ext in (".mp4", ".m4v", ".mov", ".3gp", ".3g2"):
        ts = _extract_mp4_mvhd_creation_time(abs_path)
        if ts:
            return ts

    ffprobe_bin = shutil.which("ffprobe")
    if not ffprobe_bin:
        return None
    try:
        proc = subprocess.run(
            [
                ffprobe_bin,
                "-v", "quiet",
                "-print_format", "json",
                "-show_entries", "format_tags=creation_time:stream_tags=creation_time",
                abs_path,
            ],
            capture_output=True,
            text=True,
            timeout=2.0,
        )
        if proc.returncode == 0 and proc.stdout:
            meta = json.loads(proc.stdout)
            candidates: List[str] = []
            fmt_tags = (meta.get("format") or {}).get("tags") or {}
            if fmt_tags.get("creation_time"):
                candidates.append(str(fmt_tags["creation_time"]))
            for st in (meta.get("streams") or []):
                st_tags = (st or {}).get("tags") or {}
                if st_tags.get("creation_time"):
                    candidates.append(str(st_tags["creation_time"]))
            for raw_ct in candidates:
                clean_ct = raw_ct.strip().replace("Z", "+00:00")
                try:
                    dt = datetime.fromisoformat(clean_ct)
                    ts = int(dt.timestamp())
                    if 631152000 <= ts <= int(time.time()) + 86400:
                        return ts
                except Exception:
                    ts = _parse_exif_datetime_str(raw_ct)
                    if ts:
                        return ts
    except Exception:
        pass
    return None


def _resolve_media_taken_at(abs_path: str, is_video: bool) -> Optional[int]:
    """Resolve original capture timestamp for photo/video files."""
    if is_video:
        return _extract_video_taken_at(abs_path)
    return _extract_image_taken_at(abs_path)


def _authorized_search_roots(
    storage_root: str,
    eff_user: str,
    allowed_list: Optional[List[str]],
    is_admin: bool,
    user_rec: Optional[Dict[str, Any]],
    db_path: str,
    scope_path: Optional[str] = None,
) -> List[Tuple[str, str]]:
    """Return authorized (canonical_rel, abs_path) roots for search/gallery traversal."""
    clean_scope = str(scope_path or "").strip().replace("\\", "/").strip("/")
    if clean_scope:
        canon, abs_p = _resolve_storage_or_400(storage_root, clean_scope)
        perm = resolve_effective_path_permission(canon, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] == "none":
            raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses jalur tersebut.")
        if not os.path.isdir(abs_p):
            return []
        return [(canon, abs_p)]

    roots: List[Tuple[str, str]] = []
    if os.path.isdir(storage_root):
        try:
            for entry in os.scandir(storage_root):
                if not entry.is_dir() or entry.name.startswith("."):
                    continue
                sub_rel = entry.name
                if is_admin or not is_forbidden_for_user(sub_rel, eff_user, allowed_list, is_admin=False):
                    roots.append((sub_rel, os.path.realpath(entry.path)))
        except OSError:
            pass
    return roots


@router.get("/search")
def search_storage_items(
    q: str = Query(default=""),
    path: Optional[str] = Query(default=""),
    limit: int = Query(default=60, ge=1, le=200),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mencari berkas dan folder secara rekursif di ruang penyimpanan yang diotorisasi."""
    needle = str(q or "").strip().lower()
    if not needle:
        return {"query": "", "items": [], "total": 0, "truncated": False}

    storage_root = _storage_dir()
    storage_real = os.path.realpath(storage_root)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    user_rec = _resolve_caller_user_record(current_user, eff_user)
    db_path = _db_path()

    roots = _authorized_search_roots(
        storage_root, eff_user, allowed_list, is_admin, user_rec, db_path, scope_path=path
    )

    matches: List[Dict[str, Any]] = []
    seen_rels = set()
    deadline = time.monotonic() + 3.0
    truncated = False
    scanned = 0
    max_scanned = 6000

    for root_rel, root_abs in roots:
        if time.monotonic() > deadline or len(matches) >= limit or scanned >= max_scanned:
            truncated = True
            break
        queue_dirs: List[Tuple[str, str, int]] = [(root_rel, root_abs, 0)]
        while queue_dirs:
            if time.monotonic() > deadline or len(matches) >= limit or scanned >= max_scanned:
                truncated = True
                break
            cur_rel, cur_abs, depth = queue_dirs.pop(0)
            if depth > 6:
                continue
            try:
                entries = _scandir_bounded(cur_abs, include_stat=True, timeout_sec=2.0)
            except Exception:
                continue
            for entry in entries:
                scanned += 1
                name = entry["name"]
                if name.startswith(".") or name.endswith(".part"):
                    continue
                sub_rel = f"{cur_rel}/{name}" if cur_rel else name
                if sub_rel in seen_rels:
                    continue
                try:
                    safe_rel, safe_abs = resolve_safe_storage_target(storage_real, sub_rel)
                except ValueError:
                    continue
                if not is_admin and is_forbidden_for_user(safe_rel, eff_user, allowed_list, is_admin=False):
                    # Tetap izinkan jika ada shared access pada root scope
                    if not path:
                        continue
                is_dir = bool(entry["is_dir"])
                if is_dir and depth < 6:
                    queue_dirs.append((safe_rel, safe_abs, depth + 1))
                if needle in name.lower():
                    seen_rels.add(safe_rel)
                    ext = "" if is_dir else os.path.splitext(name)[1].lower()
                    mime_type = "inode/directory" if is_dir else _guess_media_mime(name)
                    parent_rel = os.path.dirname(safe_rel).replace("\\", "/")
                    matches.append({
                        "name": name,
                        "relative_path": safe_rel,
                        "parent_path": parent_rel,
                        "is_dir": is_dir,
                        "size": 0 if is_dir else int(entry["size"]),
                        "mtime": int(entry["mtime"]),
                        "extension": ext,
                        "mime_type": mime_type,
                    })
                    if len(matches) >= limit:
                        truncated = True
                        break

    matches.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    return {
        "query": q,
        "items": matches,
        "total": len(matches),
        "truncated": truncated,
    }


def _load_gallery_folders_pref(user_id: Optional[int], db_path: str) -> List[str]:
    if user_id is None:
        return []
    raw = get_user_preference(int(user_id), "gallery_folders", default="[]", db_path=db_path)
    try:
        parsed = json.loads(raw) if raw else []
        if isinstance(parsed, list):
            return [str(p).strip().replace("\\", "/").strip("/") for p in parsed if str(p).strip()]
    except Exception:
        pass
    return []


@router.get("/gallery/config")
def get_gallery_config(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil daftar folder sumber Gallery yang dipilih oleh akun pengguna."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    uid = user_rec.get("id") if user_rec else None
    storage_root = _storage_dir()

    raw_folders = _load_gallery_folders_pref(uid, db_path)
    valid_folders: List[str] = []
    for f in raw_folders:
        try:
            canon_rel, target_abs = resolve_safe_storage_target(storage_root, f)
        except ValueError:
            continue
        if not canon_rel or not os.path.isdir(target_abs):
            continue
        perm = resolve_effective_path_permission(canon_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] != "none" and canon_rel not in valid_folders:
            valid_folders.append(canon_rel)

    return {
        "configured": len(valid_folders) > 0,
        "folders": valid_folders,
    }


@router.put("/gallery/config")
def save_gallery_config(
    req: GalleryConfigRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyimpan daftar folder sumber Gallery milik pengguna setelah validasi ACL."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    uid = user_rec.get("id") if user_rec else None
    if uid is None:
        raise HTTPException(status_code=401, detail="Akun pengguna tidak ditemukan.")

    storage_root = _storage_dir()
    cleaned: List[str] = []
    for raw_p in (getattr(req, "folders", None) or []):
        try:
            canon_rel, target_abs = resolve_safe_storage_target(storage_root, str(raw_p))
        except ValueError:
            continue
        if not canon_rel or not os.path.isdir(target_abs):
            continue
        perm = resolve_effective_path_permission(canon_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] == "none":
            raise HTTPException(status_code=403, detail=f"Tidak memiliki izin akses ke folder '{canon_rel}'.")
        if canon_rel not in cleaned:
            cleaned.append(canon_rel)

    set_user_preference(int(uid), "gallery_folders", json.dumps(cleaned), db_path=db_path)
    if cleaned and not ("unittest" in sys.modules or "pytest" in sys.modules):
        threading.Thread(
            target=_queue_folders_prewarm,
            args=(storage_root, list(cleaned)),
            kwargs={"max_files": 2000, "size": 256},
            name="gallery-prewarm-scan",
            daemon=True,
        ).start()
    return {
        "configured": len(cleaned) > 0,
        "folders": cleaned,
    }


@router.get("/gallery/media")
def list_gallery_media(
    folder: Optional[str] = Query(default=""),
    media_type: str = Query(default="all"),
    date_from: Optional[str] = Query(default=""),
    date_to: Optional[str] = Query(default=""),
    q: Optional[str] = Query(default=""),
    sort: str = Query(default="newest"),
    limit: int = Query(default=120, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil media foto & video dari folder Gallery terpilih dengan filter folder, tanggal, tipe, dan pengurutan."""
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    user_rec = _resolve_caller_user_record(current_user, eff_user, db_path=db_path)
    uid = user_rec.get("id") if user_rec else None
    storage_root = _storage_dir()

    configured_folders = _load_gallery_folders_pref(uid, db_path)
    valid_folders: List[str] = []
    for f in configured_folders:
        try:
            canon_rel, target_abs = resolve_safe_storage_target(storage_root, f)
        except ValueError:
            continue
        if not canon_rel or not os.path.isdir(target_abs):
            continue
        perm = resolve_effective_path_permission(canon_rel, user_rec, allowed_list, is_admin, db_path=db_path)
        if perm["level"] != "none" and canon_rel not in valid_folders:
            valid_folders.append(canon_rel)

    if not valid_folders:
        return {
            "configured": False,
            "folders": [],
            "items": [],
            "total": 0,
            "has_more": False,
        }

    filter_folder = str(folder or "").strip().replace("\\", "/").strip("/")
    scan_folders = [f for f in valid_folders if f == filter_folder] if filter_folder else list(valid_folders)
    norm_type = str(media_type or "all").strip().lower()
    needle = str(q or "").strip().lower()

    ts_from: Optional[int] = None
    ts_to: Optional[int] = None
    if date_from and str(date_from).strip():
        try:
            dt_from = datetime.strptime(str(date_from).strip()[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            ts_from = int(dt_from.timestamp())
        except ValueError:
            pass
    if date_to and str(date_to).strip():
        try:
            dt_to = datetime.strptime(str(date_to).strip()[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            ts_to = int(dt_to.timestamp()) + 86399
        except ValueError:
            pass

    candidates: List[Dict[str, Any]] = []
    seen_paths = set()
    deadline = time.monotonic() + 4.0
    max_scan = 8000
    scanned = 0

    for root_folder in scan_folders:
        try:
            root_rel, root_abs = resolve_safe_storage_target(storage_root, root_folder)
        except ValueError:
            continue
        if not os.path.isdir(root_abs):
            continue
        queue_dirs: List[Tuple[str, str, int]] = [(root_rel, root_abs, 0)]
        while queue_dirs and time.monotonic() < deadline and scanned < max_scan:
            cur_rel, cur_abs, depth = queue_dirs.pop(0)
            if depth > 5:
                continue
            try:
                entries = _scandir_bounded(cur_abs, include_stat=True, timeout_sec=2.0)
            except Exception:
                continue
            for entry in entries:
                scanned += 1
                name = entry["name"]
                if name.startswith(".") or name.endswith(".part"):
                    continue
                sub_rel = f"{cur_rel}/{name}" if cur_rel else name
                try:
                    safe_rel, safe_abs = resolve_safe_storage_target(storage_root, sub_rel)
                except ValueError:
                    continue
                if entry["is_dir"]:
                    if depth < 5:
                        queue_dirs.append((safe_rel, safe_abs, depth + 1))
                    continue
                ext = os.path.splitext(name)[1].lower()
                is_img = ext in _GALLERY_IMAGE_EXTS
                is_vid = ext in _GALLERY_VIDEO_EXTS
                if not is_img and not is_vid:
                    continue
                if norm_type == "image" and not is_img:
                    continue
                if norm_type == "video" and not is_vid:
                    continue
                if needle and needle not in name.lower():
                    continue
                if safe_rel in seen_paths:
                    continue
                seen_paths.add(safe_rel)
                candidates.append({
                    "name": name,
                    "relative_path": safe_rel,
                    "abs_path": safe_abs,
                    "source_folder": root_rel,
                    "size": int(entry["size"]),
                    "fs_mtime": int(entry["mtime"]),
                    "extension": ext,
                    "is_vid": is_vid,
                })

    cached_meta = get_media_metadata_batch([c["relative_path"] for c in candidates], db_path=db_path)
    meta_updates: List[Tuple[str, int, int, Optional[int]]] = []
    extract_deadline = time.monotonic() + 2.5

    all_items: List[Dict[str, Any]] = []
    for c in candidates:
        safe_rel = c["relative_path"]
        fs_mtime = c["fs_mtime"]
        file_size = c["size"]
        hit = cached_meta.get(safe_rel)
        if hit and hit[0] == fs_mtime and hit[1] == file_size:
            taken_at = hit[2]
        elif time.monotonic() < extract_deadline:
            taken_at = _resolve_media_taken_at(c["abs_path"], c["is_vid"])
            meta_updates.append((safe_rel, fs_mtime, file_size, taken_at))
        else:
            taken_at = None

        eff_mtime = int(taken_at) if (taken_at is not None and int(taken_at) > 0) else fs_mtime
        if ts_from is not None and eff_mtime < ts_from:
            continue
        if ts_to is not None and eff_mtime > ts_to:
            continue
        all_items.append({
            "name": c["name"],
            "relative_path": safe_rel,
            "source_folder": c["source_folder"],
            "is_dir": False,
            "size": file_size,
            "mtime": eff_mtime,
            "taken_at": taken_at,
            "fs_mtime": fs_mtime,
            "extension": c["extension"],
            "mime_type": _guess_media_mime(c["name"]),
            "media_kind": "video" if c["is_vid"] else "image",
        })

    if meta_updates:
        upsert_media_metadata_batch(meta_updates, db_path=db_path)

    sort_key = str(sort or "newest").strip().lower()
    if sort_key == "oldest":
        all_items.sort(key=lambda x: (x["mtime"], x["name"].lower()))
    elif sort_key == "name":
        all_items.sort(key=lambda x: x["name"].lower())
    elif sort_key == "size":
        all_items.sort(key=lambda x: (-x["size"], -x["mtime"]))
    else:
        all_items.sort(key=lambda x: (-x["mtime"], x["name"].lower()))

    total = len(all_items)
    sliced = all_items[offset: offset + limit]
    return {
        "configured": True,
        "folders": valid_folders,
        "items": sliced,
        "total": total,
        "has_more": (offset + len(sliced)) < total,
    }








