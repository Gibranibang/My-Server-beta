import asyncio
import inspect
import json
import os
import re
import shutil
import socket
import zipfile
import threading
import time
import glob
import logging
import urllib.request
import urllib.error
from datetime import datetime
from typing import Optional, Dict, Any, Tuple
try:
    from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status, Depends
except ImportError:
    Depends = lambda fn=None: fn
    File = Form = lambda default=..., **kw: default
    UploadFile = object

    class APIRouter:
        def __init__(self, **kw):
            pass

        def get(self, *a, **kw):
            return lambda f: f

        def post(self, *a, **kw):
            return lambda f: f

        def put(self, *a, **kw):
            return lambda f: f

        def delete(self, *a, **kw):
            return lambda f: f

    from app.auth import HTTPException, status
from app.config import (
    SERVER_VERSION,
    STORAGE_DIR,
    DATA_DIR,
    DB_PATH,
    is_admin_username,
)
import app.config as _app_config
from app.models import (
    HealthResponse, SystemInfoResponse, StorageStats, SystemUpdateResponse,
    PowerControlRequest, PowerControlResponse
)
from app.auth import get_current_user, get_optional_current_user, verify_active_jwt_user
from app.database import get_db, log_activity, normalize_user_role
from app.routers.auth import authorize_system_update_request
from app.routers.storage import _get_cached_disk_usage
from app.services.dashboard_service import build_dashboard_summary
from app.services.smb_manager import is_fuse_or_remote_mount
from app.services.ota_utils import apply_ota_zip, get_process_boot_id

logger = logging.getLogger("myserver.system")

router = APIRouter(tags=["System"])
_SYSTEM_STARTED_AT = time.time()


@router.get("/health", response_model=HealthResponse)
@router.get("/api/v1/health", response_model=HealthResponse)
def get_health():
    """Uji status operasional server backup."""
    return HealthResponse(
        status="ok",
        app="MyServer Native Backend",
        version=SERVER_VERSION,
        timestamp=datetime.utcnow().isoformat() + "Z",
        boot_id=get_process_boot_id()
    )


@router.get("/health/live")
@router.get("/api/v1/health/live")
def get_liveness():
    """Liveness probe ringan tanpa dependensi I/O."""
    return {
        "status": "alive",
        "version": SERVER_VERSION,
        "boot_id": get_process_boot_id(),
    }


@router.get("/health/ready")
@router.get("/api/v1/health/ready")
def get_readiness():
    """Readiness probe: memeriksa konektivitas SQLite, thread scheduler VM, dan status daemon SMB."""
    checks: Dict[str, Any] = {}
    ready = True
    try:
        with get_db(DB_PATH) as conn:
            conn.execute("SELECT 1").fetchone()
        checks["sqlite"] = "ok"
    except Exception as exc:
        checks["sqlite"] = f"error: {exc}"
        ready = False

    try:
        from app.services.smb_manager import get_smb_status
        smb_st = get_smb_status(db_path=DB_PATH, live=False)
        checks["smb_mode"] = smb_st.get("mode", "zimaos")
        checks["smb_running"] = bool(smb_st.get("running", False))
        if smb_st.get("mode") == "backend" and not smb_st.get("simulation_mode") and not smb_st.get("running"):
            ready = False
    except Exception as exc:
        checks["smb"] = f"unknown: {exc}"

    if not ready:
        raise HTTPException(
            status_code=getattr(status, "HTTP_503_SERVICE_UNAVAILABLE", 503),
            detail={"status": "not_ready", "checks": checks},
        )
    return {
        "status": "ready",
        "version": SERVER_VERSION,
        "boot_id": get_process_boot_id(),
        "checks": checks,
    }


def _aggregate_storage_usage() -> Tuple[int, int, int]:
    """Aggregate bounded cached disk usage across local non-remote partitions under STORAGE_DIR."""
    seen_devs = set()
    total = 0
    used = 0
    free = 0

    try:
        if not is_fuse_or_remote_mount(os.path.realpath(STORAGE_DIR)):
            st = os.stat(STORAGE_DIR)
            seen_devs.add(st.st_dev)
            r_tot, r_usd, r_fre = _get_cached_disk_usage(STORAGE_DIR)
            total += r_tot
            used += r_usd
            free += r_fre
    except Exception:
        pass

    if os.path.exists(STORAGE_DIR):
        try:
            for entry in os.scandir(STORAGE_DIR):
                if entry.is_dir():
                    try:
                        real_entry = os.path.realpath(entry.path)
                        if is_fuse_or_remote_mount(real_entry):
                            continue
                        st = os.stat(entry.path)
                        if st.st_dev not in seen_devs:
                            seen_devs.add(st.st_dev)
                            d_tot, d_usd, d_fre = _get_cached_disk_usage(entry.path)
                            total += d_tot
                            used += d_usd
                            free += d_fre
                    except Exception:
                        pass
        except Exception:
            pass

    if total == 0:
        try:
            if not is_fuse_or_remote_mount(os.path.realpath(STORAGE_DIR)):
                total, used, free = _get_cached_disk_usage(STORAGE_DIR)
        except Exception:
            total, used, free = _get_cached_disk_usage(STORAGE_DIR)

    return total, used, free


@router.get("/api/v1/system/info", response_model=SystemInfoResponse)
def get_system_info():
    # Menghitung agregasi kapasitas dari seluruh disk yang terpasang di STORAGE_DIR
    total, used, free = _aggregate_storage_usage()

    percent = (used / total * 100.0) if total > 0 else 0.0
    
    with get_db(DB_PATH) as conn:
        devices_count = conn.execute("SELECT COUNT(*) AS c FROM devices").fetchone()["c"]
        tasks_count = conn.execute("SELECT COUNT(*) AS c FROM backup_tasks").fetchone()["c"]
        files_count = conn.execute("SELECT COUNT(*) AS c FROM files WHERE status = 'active'").fetchone()["c"]
        bytes_count = conn.execute("SELECT COALESCE(SUM(file_size), 0) AS s FROM files WHERE status = 'active'").fetchone()["s"]

    return SystemInfoResponse(
        version=SERVER_VERSION,
        hostname=socket.gethostname(),
        storage=StorageStats(
            total_bytes=total,
            used_bytes=used,
            free_bytes=free,
            percent_used=round(percent, 2)
        ),
        total_devices=devices_count,
        total_tasks=tasks_count,
        total_backed_up_files=files_count,
        total_backed_up_bytes=bytes_count
    )


@router.post("/api/v1/system/update", response_model=SystemUpdateResponse)
async def update_system_backend(
    file: UploadFile = File(..., description="Berkas arsip .zip pembaruan modul backend (berisi folder app/)"),
    username: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    zimaos_token: Optional[str] = Form(None),
    current_user: Optional[Dict[str, Any]] = Depends(get_optional_current_user),
):
    """
    Endpoint One-Click OTA (Over-The-Air) Pembaruan Backend:
    Menerima file ZIP kode backend setelah autentikasi administrator terverifikasi,
    membuat backup timestamped kode lama, mengekstrak pembaruan ke direktori aplikasi,
    dan memicu restart aman kontainer Docker.
    """
    authorize_system_update_request(
        current_user=current_user,
        username=username,
        password=password,
        zimaos_token=zimaos_token,
    )

    # 1. Validasi ekstensi berkas
    fname = file.filename or "update.zip"
    if not fname.lower().endswith(".zip"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Paket pembaruan harus berformat berkas .zip."
        )

    # 2. Baca isi ke penyimpanan sementara dengan batas ukuran OTA (anti-DoS RAM)
    max_ota_bytes = int(getattr(_app_config, "MAX_OTA_SIZE_BYTES", 256 * 1024 * 1024))
    temp_zip = os.path.join(DATA_DIR, f"update_{int(time.time())}_{os.getpid()}.zip")
    os.makedirs(DATA_DIR, exist_ok=True)
    bytes_written = 0

    async def _read_upload_into_file() -> int:
        total = 0
        accepts_size = False
        try:
            sig = inspect.signature(file.read)
            accepts_size = len(sig.parameters) >= 1
        except (TypeError, ValueError):
            accepts_size = False

        if accepts_size:
            f_out = await asyncio.to_thread(open, temp_zip, "wb")
            try:
                while True:
                    part = await file.read(256 * 1024)
                    if not part:
                        break
                    total += len(part)
                    if total > max_ota_bytes:
                        raise HTTPException(
                            status_code=getattr(status, "HTTP_413_REQUEST_ENTITY_TOO_LARGE", 413),
                            detail=f"Paket pembaruan melebihi batas maksimal ({max_ota_bytes // (1024 * 1024)} MB).",
                        )
                    await asyncio.to_thread(f_out.write, part)
                await asyncio.to_thread(f_out.flush)
            finally:
                try:
                    await asyncio.to_thread(f_out.close)
                except Exception:
                    pass
            if total < 50:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Berkas pembaruan kosong atau tidak lengkap."
                )
            return total
        else:
            data_blob = await file.read()
            total = len(data_blob or b"")
            if total > max_ota_bytes:
                raise HTTPException(
                    status_code=getattr(status, "HTTP_413_REQUEST_ENTITY_TOO_LARGE", 413),
                    detail=f"Paket pembaruan melebihi batas maksimal ({max_ota_bytes // (1024 * 1024)} MB).",
                )
            if total < 50:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Berkas pembaruan kosong atau tidak lengkap."
                )

            def _write_sync():
                with open(temp_zip, "wb") as f:
                    f.write(data_blob)

            await asyncio.to_thread(_write_sync)
            return total

    try:
        bytes_written = await _read_upload_into_file()
        return await _apply_ota_and_schedule_restart(temp_zip, bytes_written)
    finally:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass


async def _apply_ota_and_schedule_restart(temp_zip: str, bytes_written: int) -> SystemUpdateResponse:
    """Memvalidasi ZIP OTA, menerapkan perubahan berkas, lalu memicu restart proses."""
    if not await asyncio.to_thread(zipfile.is_zipfile, temp_zip):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Berkas bukan arsip ZIP yang valid."
        )

    current_routers_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_routers_dir)
    base_dir = os.path.dirname(app_dir)
    cur_ver = str(getattr(_app_config, "SERVER_VERSION", SERVER_VERSION) or SERVER_VERSION)

    try:
        ota_res = await asyncio.to_thread(
            apply_ota_zip,
            temp_zip=temp_zip,
            app_dir=app_dir,
            base_dir=base_dir,
            data_dir=DATA_DIR,
            current_version=cur_ver,
            keep_backups=3,
        )
    except ValueError as ve:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(ve)
        )

    extracted_files = ota_res["extracted_files"]
    new_version = ota_res["new_version"]
    backup_target_dir = ota_res["backup_dir"]

    await asyncio.to_thread(
        log_activity,
        device_id=None,
        task_id=None,
        action="SYSTEM_OTA_UPDATE",
        message=(
            f"Pembaruan OTA berhasil diterapkan ({ota_res['files_extracted']} berkas disalin, "
            f"{ota_res['files_removed']} berkas usang dihapus). Versi: {cur_ver} -> {new_version}."
        ),
        details={
            "old_version": cur_ver,
            "new_version": new_version,
            "files_count": ota_res["files_extracted"],
            "files_removed": ota_res["files_removed"],
            "rebuild_required": ota_res["rebuild_required"],
            "backups_pruned": ota_res["backups_pruned"],
            "zip_bytes": bytes_written,
        }
    )

    def _delayed_restart():
        time.sleep(1.25)
        logger.info("Memicu restart proses untuk pembaruan OTA (stopping scheduler & smbd, exit code 1)...")
        try:
            from app.services.vm_scheduler import stop_vm_scheduler
            stop_vm_scheduler()
        except Exception as sched_err:
            logger.warning(f"Peringatan saat menghentikan vm_scheduler sebelum restart: {sched_err}")
        try:
            from app.services.smb_manager import stop_backend_smbd
            stop_backend_smbd()
        except Exception as smb_err:
            logger.warning(f"Peringatan saat menghentikan supervised smbd sebelum restart: {smb_err}")
        time.sleep(0.25)
        os._exit(1)

    threading.Thread(target=_delayed_restart, daemon=True).start()

    restart_msg = (
        f"Pembaruan berhasil disinkronkan ({len(extracted_files)} berkas). "
        "Server akan merestart otomatis dalam 2 detik."
    )
    if ota_res["rebuild_required"]:
        restart_msg += " Perubahan Dockerfile/requirements.txt terdeteksi; disarankan rebuild image container."

    return SystemUpdateResponse(
        status="success",
        message=restart_msg,
        old_version=cur_ver,
        new_version=new_version,
        backup_dir=backup_target_dir,
        files_extracted=ota_res["files_extracted"],
        files_removed=ota_res["files_removed"],
        rebuild_required=ota_res["rebuild_required"],
        backups_pruned=ota_res["backups_pruned"],
        boot_id=ota_res["boot_id"]
    )


def _parse_semver_tuple(ver: str) -> Tuple[int, ...]:
    nums = [int(x) for x in re.findall(r"\d+", str(ver or "0"))]
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums[:4])


def _get_update_repo_slug() -> str:
    return str(getattr(_app_config, "UPDATE_REPO_SLUG", "Gibranibang/My-Server-beta") or "Gibranibang/My-Server-beta").strip()


def _fetch_remote_backend_manifest() -> Dict[str, Any]:
    repo = _get_update_repo_slug()
    manifest_url = f"https://github.com/{repo}/releases/latest/download/backend_manifest.json"
    req = urllib.request.Request(
        manifest_url,
        headers={
            "User-Agent": f"MyServer-Backend/{getattr(_app_config, 'SERVER_VERSION', SERVER_VERSION)}",
            "Accept": "application/json",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=8.0) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if not isinstance(data, dict) or not data.get("version"):
        raise ValueError("Manifest rilis Backend tidak valid.")
    pkg_zip = str(data.get("package_zip") or "MyServer-Backend-ZimaOS.zip").strip()
    if "/" in pkg_zip or "\\" in pkg_zip or not pkg_zip.endswith(".zip"):
        pkg_zip = "MyServer-Backend-ZimaOS.zip"
    return {
        "repo": repo,
        "version": str(data.get("version")).strip(),
        "package_zip": pkg_zip,
        "download_url": f"https://github.com/{repo}/releases/latest/download/{pkg_zip}",
    }


def _download_remote_ota_zip(download_url: str, dest_path: str, max_bytes: int) -> int:
    req = urllib.request.Request(
        download_url,
        headers={
            "User-Agent": f"MyServer-Backend/{getattr(_app_config, 'SERVER_VERSION', SERVER_VERSION)}",
        },
        method="GET",
    )
    total = 0
    with urllib.request.urlopen(req, timeout=60.0) as resp, open(dest_path, "wb") as f_out:
        while True:
            chunk = resp.read(256 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise HTTPException(
                    status_code=getattr(status, "HTTP_413_REQUEST_ENTITY_TOO_LARGE", 413),
                    detail=f"Paket pembaruan melebihi batas maksimal ({max_bytes // (1024 * 1024)} MB).",
                )
            f_out.write(chunk)
        f_out.flush()
    if total < 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Berkas pembaruan dari GitHub kosong atau tidak lengkap.",
        )
    return total


@router.get("/api/v1/system/update/check")
async def check_system_update(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memeriksa versi Backend terbaru di GitHub Releases untuk Admin UI."""
    authorize_system_update_request(current_user=current_user)
    cur_ver = str(getattr(_app_config, "SERVER_VERSION", SERVER_VERSION) or SERVER_VERSION)
    repo = _get_update_repo_slug()
    try:
        manifest = await asyncio.to_thread(_fetch_remote_backend_manifest)
        latest_ver = manifest["version"]
        update_available = _parse_semver_tuple(latest_ver) > _parse_semver_tuple(cur_ver)
        return {
            "status": "ok",
            "current_version": cur_ver,
            "latest_version": latest_ver,
            "update_available": update_available,
            "package_zip": manifest["package_zip"],
            "download_url": manifest["download_url"],
            "repo": manifest["repo"],
            "boot_id": get_process_boot_id(),
        }
    except Exception as exc:
        return {
            "status": "offline",
            "current_version": cur_ver,
            "latest_version": None,
            "update_available": False,
            "repo": repo,
            "boot_id": get_process_boot_id(),
            "error": str(exc),
        }


@router.post("/api/v1/system/update/remote", response_model=SystemUpdateResponse)
async def update_system_backend_remote(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengunduh paket Backend terbaru dari GitHub Releases dan langsung menjalankan OTA update."""
    authorize_system_update_request(current_user=current_user)
    try:
        manifest = await asyncio.to_thread(_fetch_remote_backend_manifest)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Gagal memeriksa rilis terbaru di GitHub: {exc}",
        )

    max_ota_bytes = int(getattr(_app_config, "MAX_OTA_SIZE_BYTES", 256 * 1024 * 1024))
    temp_zip = os.path.join(DATA_DIR, f"remote_update_{int(time.time())}_{os.getpid()}.zip")
    os.makedirs(DATA_DIR, exist_ok=True)
    try:
        try:
            bytes_written = await asyncio.to_thread(
                _download_remote_ota_zip, manifest["download_url"], temp_zip, max_ota_bytes
            )
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Gagal mengunduh paket pembaruan: {exc}",
            )
        return await _apply_ota_and_schedule_restart(temp_zip, bytes_written)
    finally:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass


_CPU_SAMPLE_LOCK = threading.Lock()
_CPU_LAST_SNAPSHOT: Dict[str, Any] = {"total": 0.0, "idle": 0.0, "pct": 0.0}


def _read_cpu_percent() -> float:
    """Membaca persentase CPU secara non-blocking berbasis delta /proc/stat antar panggilan."""
    try:
        import psutil
        return round(float(psutil.cpu_percent(interval=None)), 1)
    except Exception:
        pass

    try:
        with open("/proc/stat", "r") as f:
            line = f.readline()
        vals = [float(x) for x in line.strip().split()[1:]]
        idle = vals[3] + (vals[4] if len(vals) > 4 else 0.0)
        total = sum(vals)
        with _CPU_SAMPLE_LOCK:
            prev_tot = float(_CPU_LAST_SNAPSHOT["total"])
            prev_idle = float(_CPU_LAST_SNAPSHOT["idle"])
            _CPU_LAST_SNAPSHOT["total"] = total
            _CPU_LAST_SNAPSHOT["idle"] = idle
            if prev_tot > 0.0 and total > prev_tot:
                diff_tot = total - prev_tot
                diff_idle = idle - prev_idle
                pct = (1.0 - (diff_idle / diff_tot)) * 100.0
                _CPU_LAST_SNAPSHOT["pct"] = round(max(0.0, min(100.0, pct)), 1)
            return float(_CPU_LAST_SNAPSHOT["pct"])
    except Exception:
        pass
    return 0.0


def _read_cpu_temperature() -> Optional[float]:
    """Membaca suhu CPU dari sensor thermal Linux / sysfs."""
    for p in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            with open(p, "r") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue

    for p in glob.glob("/sys/class/hwmon/hwmon*/temp*_input"):
        try:
            with open(p, "r") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue
    return None


def _read_memory_info() -> Dict[str, Any]:
    """Membaca status RAM dari /proc/meminfo."""
    try:
        import psutil
        v = psutil.virtual_memory()
        return {
            "total": int(v.total),
            "used": int(v.used),
            "free": int(v.available),
            "usedPercent": round(float(v.percent), 1)
        }
    except Exception:
        pass

    total = 0
    available = 0
    free = 0
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    if key == "MemTotal":
                        total = int(val) * 1024
                    elif key == "MemAvailable":
                        available = int(val) * 1024
                    elif key == "MemFree":
                        free = int(val) * 1024
    except Exception:
        pass

    if total > 0:
        used = total - (available if available > 0 else free)
        pct = round((used / total) * 100.0, 1)
    else:
        used = 0
        pct = 0.0

    return {
        "total": total,
        "used": used,
        "free": available if available > 0 else free,
        "usedPercent": pct
    }


def _read_network_io() -> Dict[str, Any]:
    """Membaca metrik traffic jaringan dari /proc/net/dev."""
    bytes_recv = 0
    bytes_sent = 0
    try:
        with open("/proc/net/dev", "r") as f:
            lines = f.readlines()[2:]
            for line in lines:
                parts = line.strip().split(":")
                if len(parts) == 2:
                    iface = parts[0].strip()
                    if iface == "lo":
                        continue
                    stats = parts[1].split()
                    bytes_recv += int(stats[0])
                    bytes_sent += int(stats[8])
    except Exception:
        pass
    return {"bytes_sent": bytes_sent, "bytes_recv": bytes_recv}


@router.get("/api/v1/system/vitals")
def get_system_vitals():
    """
    Mengambil telemetri vitalitas sistem host secara real-time (CPU, RAM, HDD, Jaringan, Suhu).
    Klien desktop dan mobile membaca endpoint ini melalui port 8080 (misal http://zimaos.local:8080).
    """
    cpu_pct = _read_cpu_percent()
    cpu_temp = _read_cpu_temperature()
    mem_info = _read_memory_info()
    net_info = _read_network_io()

    total, used, free = _aggregate_storage_usage()

    disk_pct = round((used / total * 100.0) if total > 0 else 0.0, 1)

    uptime_sec = 0.0
    try:
        with open("/proc/uptime", "r") as f:
            uptime_sec = float(f.readline().split()[0])
    except Exception:
        pass

    return {
        "status": "ok",
        "data": {
            "cpu": {
                "percent": cpu_pct,
                "usage": cpu_pct,
                "temperature": cpu_temp,
                "temp": cpu_temp
            },
            "mem": mem_info,
            "sys_disk": {
                "total": total,
                "size": total,
                "used": used,
                "free": free,
                "percent": disk_pct
            },
            "network": net_info,
            "uptime_seconds": uptime_sec,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
    }


@router.get("/api/v1/dashboard/summary")
def get_dashboard_summary(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengembalikan ringkasan telemetri host, disk, dan layanan terisolasi RBAC (SECH-03)."""
    db_path = str(getattr(_app_config, "DB_PATH", DB_PATH))
    storage_dir = str(getattr(_app_config, "STORAGE_DIR", STORAGE_DIR))
    user_rec = verify_active_jwt_user(
        current_user,
        allow_stream_scope=False,
        db_path=db_path,
    )
    return build_dashboard_summary(
        current_user=user_rec,
        storage_dir=storage_dir,
        db_path=db_path,
        started_at=_SYSTEM_STARTED_AT,
    )


@router.post("/api/v1/system/power", response_model=PowerControlResponse)
def control_system_power(
    req: PowerControlRequest,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Kontrol Daya Server (Reboot / Shutdown) dengan otorisasi Bearer token Admin.
    Meneruskan perintah ke D-Bus host / systemd atau ZimaOS internal endpoint.
    """
    user_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
    role = normalize_user_role(user_rec.get("role"))
    if role not in ("admin", "root") and not is_admin_username(user_rec.get("username")):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang memiliki izin mematikan atau merestart server."
        )

    act = req.action.lower().strip()
    if act in ("restart", "reboot"):
        target_action = "restart"
    elif act in ("shutdown", "poweroff", "off"):
        target_action = "off"
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Aksi daya '{req.action}' tidak valid. Pilihan yang didukung: restart, shutdown."
        )

    log_activity(
        device_id=None,
        task_id=None,
        action="SYSTEM_POWER_CONTROL",
        message=f"Perintah daya '{target_action}' dipicu oleh pengguna '{user_rec.get('username')}'.",
        details={"action": target_action, "user": {"sub": user_rec.get("username"), "uid": user_rec.get("id"), "role": role}}
    )

    success = False
    # 1. Coba forward ke ZimaOS internal endpoint (Port 80)
    for host in ["http://172.17.0.1:80", "http://127.0.0.1:80", "http://localhost:80"]:
        url = f"{host}/v1/sys/state/{target_action}"
        try:
            req_z = urllib.request.Request(url, method="PUT")
            with urllib.request.urlopen(req_z, timeout=3.0) as resp:
                if resp.status in (200, 201, 204):
                    success = True
                    break
        except Exception:
            continue

    # 2. Coba via systemctl jika di host Linux
    if not success:
        try:
            import subprocess
            if target_action == "restart":
                subprocess.Popen(["reboot"])
            else:
                subprocess.Popen(["poweroff"])
            success = True
        except Exception:
            pass

    return PowerControlResponse(
        status="success" if success else "pending",
        action=target_action,
        message=f"Perintah daya '{target_action}' berhasil diteruskan ke sistem host."
    )


