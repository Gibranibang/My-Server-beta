"""
Standalone SMB Engine Service (smbd) & Port 445 Mutual Exclusion Manager.
Synchronizes SQLite users, encrypted SMB passwords, and allowed_disks ACLs
to /app/data/samba/smb.conf and passdb.tdb deterministically.
"""

import hashlib
import html
import logging
import os
import re
import shutil
import signal
import socket
import subprocess
import tempfile
import threading
import time
import urllib.parse
from typing import Any, Dict, List, Optional, Tuple

import app.config
from app.config import is_admin_username
from app.database import (
    decrypt_smb_password,
    get_system_setting,
    list_all_users,
    list_users_with_smb_secrets,
    normalize_user_role,
    set_system_setting,
)

logger = logging.getLogger("myserver.smb")

_SMB_SYNC_LOCK = threading.RLock()
_SMB_STATUS_LOCK = _SMB_SYNC_LOCK
_UPLOAD_RENAME_LOCK = threading.RLock()
_SMBD_CHILD_PROC: Optional[subprocess.Popen] = None
_SMBD_STDERR_LOG_MAX_BYTES = 512 * 1024
_LAST_STORAGE_DIR_SNAPSHOT: Optional[Tuple[str, ...]] = None
ZIMAOS_SMBD_STATUS_CACHE_TTL_SEC = 12.0
_ZIMAOS_SMBD_STATUS_CACHE: Dict[Tuple[str, str], Tuple[bool, float]] = {}
_USERNAME_RE = re.compile(r"^[a-z0-9_.-]+$")
_EXCLUDED_SMB_SHARE_NAMES = {"global", "homes", "printers", "ipc$", "pc_backups"}
DANGEROUS_INLINE_STREAM_EXTENSIONS = {".svg", ".svgz", ".html", ".htm", ".xhtml", ".xml", ".js", ".mjs"}
_REMOTE_FSTYPES = {
    "fuse",
    "fuse3",
    "rclone",
    "cifs",
    "smb3",
    "nfs",
    "nfs4",
    "davfs",
    "davfs2",
    "sshfs",
    "mergerfs",
    "overlay",
    "gvfsd-fuse",
}


def is_fuse_or_remote_mount(path: str, proc_mounts_path: str = "/proc/mounts") -> bool:
    """Return True if canonical path resides on a userspace FUSE/cloud or network mount."""
    if not path or not os.path.isfile(proc_mounts_path):
        return False
    try:
        canon = os.path.realpath(path).rstrip("/") or "/"
        best_mount = ""
        best_fstype = ""
        best_src = ""
        with open(proc_mounts_path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) < 3:
                    continue
                src_dev = parts[0].strip().lower()
                mp = parts[1].replace("\\040", " ").rstrip("/") or "/"
                fstype = parts[2].strip().lower()
                if canon == mp or (mp == "/") or canon.startswith(mp + "/"):
                    if len(mp) >= len(best_mount):
                        best_mount = mp
                        best_fstype = fstype
                        best_src = src_dev
        if not best_fstype or best_fstype in ("fuseblk", "fusectl"):
            return False
        if best_fstype in _REMOTE_FSTYPES or best_fstype.startswith(("fuse.", "fuse3.")):
            return True
        return "rclone" in best_src
    except Exception:
        return False


def invalidate_smb_status_cache() -> None:
    """Clear cached ZimaOS host smbd status under _SMB_SYNC_LOCK."""
    with _SMB_SYNC_LOCK:
        _ZIMAOS_SMBD_STATUS_CACHE.clear()


def _file_sha256(path: str) -> str:
    """Return SHA-256 hex digest of file bytes, or empty string if missing or unreadable."""
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return ""


def _get_data_dir() -> str:
    return str(getattr(app.config, "DATA_DIR", app.config.DATA_DIR))


def _get_storage_dir() -> str:
    return str(getattr(app.config, "STORAGE_DIR", app.config.STORAGE_DIR))


def _get_db_path(db_path: Optional[str] = None) -> str:
    return db_path or str(getattr(app.config, "DB_PATH", app.config.DB_PATH))


def get_samba_paths() -> Dict[str, str]:
    """Resolve persistent and runtime Samba directories dynamically.

    In production containers (DATA_DIR == '/app/data') with writable /dev/shm tmpfs,
    place volatile TDB lock & cache directories on tmpfs so Explorer directory queries
    and locking never stall on HDD/bind-mount fsyncs, while keeping passdb.tdb,
    smb.conf, and ncalrpc persistent/isolated under DATA_DIR/samba.
    """
    data_dir = _get_data_dir()
    base = os.path.join(data_dir, "samba")
    runtime_base = base
    if data_dir == "/app/data" and os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK | os.X_OK):
        runtime_base = "/dev/shm/myserver-samba"
    return {
        "base": base,
        "private": os.path.join(base, "private"),
        "run": os.path.join(base, "run"),
        "lock": os.path.join(runtime_base, "lock"),
        "state": os.path.join(base, "state"),
        "cache": os.path.join(runtime_base, "cache"),
        "ncalrpc": os.path.join(base, "ncalrpc"),
        "conf": os.path.join(base, "smb.conf"),
        "dfree": os.path.join(base, "dfree_safe.py"),
        "pid": os.path.join(base, "run", "smbd.pid"),
        "passdb": os.path.join(base, "private", "passdb.tdb"),
        "stderr_log": os.path.join(base, "smbd_stderr.log"),
    }


def _get_smbd_stderr_log_path() -> str:
    """Resolve bounded stderr log path for supervised smbd."""
    paths = get_samba_paths()
    base_dir = paths.get("base") or os.path.dirname(paths.get("conf") or "") or _get_data_dir()
    return paths.get("stderr_log") or os.path.join(base_dir, "smbd_stderr.log")


_DFREE_HELPER_CODE = '''#!/usr/bin/env python3
"""Bounded non-blocking dfree helper for Samba so stalled FUSE/HDD statvfs never freezes Explorer."""
import hashlib
import json
import os
import sys
import threading
import time

CACHE_FILE = (
    "/dev/shm/myserver-samba/dfree_cache.json"
    if os.path.isdir("/dev/shm")
    else "/tmp/myserver_dfree_cache.json"
)
FALLBACK_BLOCKS = "104857600 52428800"
target = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else "."
key = hashlib.sha1(os.path.abspath(target).encode("utf-8", "replace")).hexdigest()[:16]
now = time.time()

cache = {}
try:
    if os.path.isfile(CACHE_FILE):
        with open(CACHE_FILE, "r", encoding="utf-8") as fh:
            loaded = json.load(fh)
            if isinstance(loaded, dict):
                cache = loaded
except Exception:
    cache = {}

cached_ent = cache.get(key)
if isinstance(cached_ent, dict) and (now - float(cached_ent.get("ts") or 0)) < 45.0:
    tot = int(cached_ent.get("tot") or 0)
    avail = int(cached_ent.get("avail") or 0)
    if tot > 0:
        sys.stdout.write(f"{tot} {avail}\\n")
        sys.stdout.flush()
        os._exit(0)

res = {}


def _probe():
    try:
        st = os.statvfs(target)
        bsize = int(st.f_frsize or st.f_bsize or 1024)
        tot_kb = max(1, (int(st.f_blocks) * bsize) // 1024)
        avail_kb = max(0, (int(st.f_bavail) * bsize) // 1024)
        res["val"] = (tot_kb, min(avail_kb, tot_kb))
    except Exception:
        pass


t = threading.Thread(target=_probe, daemon=True)
t.start()
t.join(timeout=1.2)

if "val" in res:
    tot_kb, avail_kb = res["val"]
    try:
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        cache[key] = {"tot": tot_kb, "avail": avail_kb, "ts": now}
        tmp = f"{CACHE_FILE}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cache, fh)
        os.replace(tmp, CACHE_FILE)
    except Exception:
        pass
    sys.stdout.write(f"{tot_kb} {avail_kb}\\n")
    sys.stdout.flush()
    os._exit(0)

if isinstance(cached_ent, dict) and int(cached_ent.get("tot") or 0) > 0:
    sys.stdout.write(f"{int(cached_ent['tot'])} {int(cached_ent.get('avail') or 0)}\\n")
else:
    sys.stdout.write(FALLBACK_BLOCKS + "\\n")
sys.stdout.flush()
os._exit(0)
'''


def _ensure_dfree_script(dfree_path: str) -> str:
    """Write and chmod +x bounded dfree helper script atomically."""
    _atomic_write_text(dfree_path, _DFREE_HELPER_CODE)
    try:
        os.chmod(dfree_path, 0o755)
    except OSError:
        pass
    return dfree_path


def ensure_samba_dirs() -> Dict[str, str]:
    """Ensure all Samba persistence/runtime subdirectories exist."""
    paths = get_samba_paths()
    for key in ("base", "private", "run", "lock", "state", "cache", "ncalrpc"):
        os.makedirs(paths[key], exist_ok=True)
    # Minimal containers without systemd lack /run/samba; Samba tools still probe it.
    try:
        os.makedirs("/run/samba", exist_ok=True)
    except OSError:
        pass
    try:
        os.chmod(paths["private"], 0o700)
    except OSError:
        pass
    return paths


def validate_smb_username(username: str) -> str:
    """Validate and normalize SMB/UNIX username against strict allowlist regex."""
    if not isinstance(username, str):
        raise ValueError("Username harus berupa string.")
    clean_u = username.strip().lower()
    if (
        not clean_u
        or len(clean_u) > 64
        or clean_u in (".", "..")
        or not _USERNAME_RE.match(clean_u)
    ):
        raise ValueError(f"Username '{username}' mengandung karakter tidak diizinkan.")
    return clean_u


def resolve_safe_storage_target(storage_root: str, raw_rel: Optional[str]) -> Tuple[str, str]:
    """
    Kanonalisasi jalur relatif terhadap os.path.realpath(storage_root) sebelum cek ACL.
    Menolak path traversal ('..') atau symlink escape keluar storage_root dengan ValueError.
    """
    if not storage_root:
        raise ValueError("Akses path tidak diizinkan")
    root_real = os.path.realpath(storage_root)
    raw_str = "" if raw_rel is None else str(raw_rel)
    if "\x00" in raw_str:
        raise ValueError("Akses path tidak diizinkan")
    cleaned = raw_str.strip().replace("\\", "/").lstrip("/")
    if cleaned and any(seg == ".." for seg in cleaned.split("/")):
        raise ValueError("Akses path tidak diizinkan")
    if cleaned and ":" in cleaned.split("/")[0]:
        raise ValueError("Akses path tidak diizinkan")
    candidate_real = os.path.realpath(os.path.join(root_real, cleaned)) if cleaned else root_real
    if os.path.commonpath([root_real, candidate_real]) != root_real:
        raise ValueError("Akses path tidak diizinkan")
    canonical_rel = "" if candidate_real == root_real else os.path.relpath(candidate_real, root_real).replace("\\", "/")
    return canonical_rel, candidate_real


def resolve_non_colliding_target(
    dir_abs: str,
    raw_filename: str,
    is_dir: bool = False,
) -> Tuple[str, str, bool]:
    """
    Menghasilkan (saved_name, final_abs, renamed) di bawah _UPLOAD_RENAME_LOCK tanpa menimpa
    berkas/folder yang sudah ada (file: 'stem (1).ext', folder: 'name (1)').
    """
    if not dir_abs:
        raise ValueError("Direktori tujuan tidak valid.")
    raw_str = "" if raw_filename is None else str(raw_filename)
    if "\x00" in raw_str or "/" in raw_str or "\\" in raw_str:
        raise ValueError("Nama berkas atau folder tidak valid.")
    clean_name = raw_str.strip()
    if not clean_name or clean_name in (".", ".."):
        raise ValueError("Nama berkas atau folder tidak valid.")

    dir_real = os.path.realpath(dir_abs)
    if is_dir:
        base_stem, ext = clean_name, ""
    else:
        base_stem, ext = os.path.splitext(clean_name)

    with _UPLOAD_RENAME_LOCK:
        cand_name = clean_name
        cand_abs = os.path.join(dir_real, cand_name)
        counter = 1
        while os.path.lexists(cand_abs):
            cand_name = f"{base_stem} ({counter})" if is_dir else f"{base_stem} ({counter}){ext}"
            cand_abs = os.path.join(dir_real, cand_name)
            counter += 1

        cand_real = os.path.realpath(cand_abs)
        if os.path.commonpath([dir_real, cand_real]) != dir_real or cand_real == dir_real:
            raise ValueError("Nama berkas atau folder keluar dari direktori tujuan.")
        return cand_name, cand_abs, (cand_name != clean_name)


def _normalize_allowed_disk_norms(allowed_disks: Optional[list]) -> set:
    allowed_norms = set()
    if allowed_disks is None:
        return allowed_norms
    for a in allowed_disks:
        clean_a = str(a).lower().replace("/media/", "").replace("/data/", "").strip("/").replace(" ", "_")
        root_a = clean_a.split("/")[0] if clean_a else ""
        if root_a:
            allowed_norms.add(root_a)
        if clean_a:
            allowed_norms.add(clean_a)
    return allowed_norms


def is_storage_path_forbidden(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """
    Pemeriksaan ACL multi-user & multi-disk (fail-closed):
    - Menolak segmen '..' pada semua peran sebagai pertahanan berlapis.
    - Menolak jika username kosong/None dan is_admin=False.
    - Memeriksa parts[0] terhadap allowed_disks SEBELUM aturan pc_backups bila parts[0] != 'pc_backups'.
    """
    raw_parts = [p for p in (rel_path or "").replace("\\", "/").strip("/").split("/") if p and p != "."]
    if any(p == ".." for p in raw_parts):
        return True
    if is_admin:
        return False
    clean_u = (username or "").strip()
    if not clean_u:
        return True
    if is_admin_username(clean_u):
        return False

    parts = [p.lower() for p in raw_parts]
    if not parts:
        return False

    allowed_norms = _normalize_allowed_disk_norms(allowed_disks)
    root_part = parts[0].replace(" ", "_")

    if root_part != "pc_backups":
        if allowed_disks is None or root_part not in allowed_norms:
            return True
        if "pc_backups" in parts:
            idx = parts.index("pc_backups")
            if len(parts) > idx + 1:
                return parts[idx + 1] != clean_u.lower()
            return "pc_backups" not in allowed_norms
        return False

    if len(parts) > 1:
        owner = parts[1]
        return owner != clean_u.lower()
    return "pc_backups" not in allowed_norms


_STATIC_ROOT = os.path.realpath(
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")
)
_STATIC_MIME_TYPES = {
    ".mjs": "application/javascript; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml; charset=utf-8",
}


def resolve_static_bundle_asset(subdir: str, asset_path: str) -> Tuple[str, str]:
    """Resolusi aman aset statis vendored di bawah app/static/<subdir> dengan proteksi path traversal."""
    if subdir not in ("pdfjs", "vendor", "icons"):
        raise FileNotFoundError("Aset statis tidak ditemukan")
    raw = str(asset_path or "")
    if not raw or "\x00" in raw:
        raise FileNotFoundError("Aset statis tidak ditemukan")
    parts = [p for p in raw.replace("\\", "/").split("/") if p and p != "."]
    if not parts or any(p == ".." for p in parts):
        raise PermissionError("Akses path statis ditolak")
    bundle_dir = os.path.realpath(os.path.join(_STATIC_ROOT, subdir))
    candidate = os.path.realpath(os.path.join(bundle_dir, *parts))
    if os.path.commonpath([bundle_dir, candidate]) != bundle_dir or candidate == bundle_dir:
        raise PermissionError("Akses path statis ditolak")
    if not os.path.isfile(candidate):
        raise FileNotFoundError("Aset statis tidak ditemukan")
    ext = os.path.splitext(candidate)[1].lower()
    media_type = _STATIC_MIME_TYPES.get(ext, "text/plain; charset=utf-8")
    return candidate, media_type


def build_content_disposition(disposition: str, filename: str) -> str:
    """Bangun header Content-Disposition RFC 5987 UTF-8 yang aman dari CRLF dan UnicodeEncodeError."""
    clean_disp = "inline" if str(disposition or "").strip().lower() == "inline" else "attachment"
    raw_base = os.path.basename(str(filename or "file").strip()) or "file"
    clean_name = (
        raw_base.replace('"', "")
        .replace("\r", "")
        .replace("\n", "")
        .replace("\\", "")
        .replace(";", "")
    )
    is_unmodified = (clean_name == raw_base)
    clean_name = clean_name or "file"
    if is_unmodified and all(0x20 <= ord(c) < 0x7F and c not in ('"', "\\", ";") for c in clean_name):
        return f'{clean_disp}; filename="{clean_name}"'
    clean_name = clean_name or "file"
    ascii_fallback = (
        clean_name.encode("ascii", "replace")
        .decode("ascii")
        .replace('"', "_")
        .replace(";", "_")
        .replace("\\", "_")
        or "file"
    )
    utf8_quoted = urllib.parse.quote(clean_name, safe="")
    return f'{clean_disp}; filename="{ascii_fallback}"; filename*=UTF-8\'\'{utf8_quoted}'


def build_stream_security_headers(full_path: str, inline: bool = False) -> Dict[str, str]:
    """Bangun header keamanan respons streaming (anti-XSS SVG/HTML, ?inline=1 PDF, & nosniff)."""
    ext = os.path.splitext(full_path)[1].lower()
    base_name = os.path.basename(full_path)
    if ext in DANGEROUS_INLINE_STREAM_EXTENSIONS:
        return {
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'none'; sandbox",
            "Content-Disposition": build_content_disposition("attachment", base_name),
        }
    if inline and ext == ".pdf":
        return {
            "X-Content-Type-Options": "nosniff",
            "Content-Disposition": build_content_disposition("inline", base_name),
        }
    return {
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
    }


def _safe_url_attr(url: str) -> str:
    return (
        str(url)
        .replace('"', "%22")
        .replace("'", "%27")
        .replace("<", "%3C")
        .replace(">", "%3E")
        .replace("\r", "")
        .replace("\n", "")
    )


def render_media_player_html(filename: str, rel_req: str, stream_url: str, download_url: str) -> str:
    """Render HTML5 Media Player bersama dengan escaping HTML penuh untuk mencegah XSS."""
    ext = os.path.splitext(filename)[1].lower()
    safe_filename = html.escape(filename)
    safe_rel = html.escape(rel_req)
    safe_ext = html.escape(ext)
    safe_stream_url = _safe_url_attr(stream_url)
    safe_download_url = _safe_url_attr(download_url)

    is_video = ext in (".mp4", ".mkv", ".webm", ".mov", ".avi", ".ts")
    is_audio = ext in (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".wma")
    is_image = ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg")

    if is_video:
        media_tag = f"""<video id="player" controls autoplay playsinline preload="metadata">
            <source src="{safe_stream_url}">
            Peramban Anda tidak mendukung pemutaran video HTML5.
        </video>"""
    elif is_audio:
        media_tag = f"""<div class="audio-card">
            <div class="audio-icon">🎵</div>
            <div class="audio-title">{safe_filename}</div>
            <div class="audio-path">{safe_rel}</div>
            <audio id="player" controls autoplay preload="metadata" src="{safe_stream_url}"></audio>
        </div>"""
    elif is_image:
        media_tag = f"""<div class="img-container">
            <img id="imgViewer" src="{safe_stream_url}" alt="{safe_filename}" />
        </div>"""
    else:
        media_tag = f"""<div class="fallback-card">
            <div class="icon">📄</div>
            <h2>{safe_filename}</h2>
            <p>Format berkas ini ({safe_ext}) tidak dapat diputar langsung di pemutar web.</p>
            <a href="{safe_download_url}" class="btn-download" download>Unduh Berkas</a>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyServer Media Player - {safe_filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background-color: #0b0f19;
            color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
            user-select: none;
        }}
        .header {{
            background-color: #111827;
            border-bottom: 1px solid #1f2937;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 52px;
            z-index: 10;
        }}
        .brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 600;
            color: #38bdf8;
        }}
        .file-info {{
            display: flex;
            flex-direction: column;
            max-width: 60%;
            overflow: hidden;
        }}
        .file-title {{
            font-size: 14px;
            font-weight: 600;
            color: #f1f5f9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .file-sub {{
            font-size: 11px;
            color: #94a3b8;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .actions {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .btn {{
            background-color: #1f2937;
            border: 1px solid #374151;
            color: #e2e8f0;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            text-decoration: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }}
        .btn:hover {{
            background-color: #374151;
            color: #ffffff;
        }}
        .player-viewport {{
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #030712;
            position: relative;
            overflow: hidden;
        }}
        video {{
            width: 100%;
            height: 100%;
            max-width: 100vw;
            max-height: calc(100vh - 52px);
            outline: none;
            background: #000;
        }}
        .audio-card {{
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 16px;
            padding: 36px 44px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
            max-width: 480px;
            width: 90%;
        }}
        .audio-icon {{
            font-size: 48px;
            background: #1e293b;
            width: 90px;
            height: 90px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(56, 189, 248, 0.2);
        }}
        .audio-title {{
            font-size: 17px;
            font-weight: 600;
            color: #f8fafc;
            text-align: center;
            word-break: break-all;
        }}
        .audio-path {{
            font-size: 12px;
            color: #64748b;
            text-align: center;
        }}
        audio {{
            width: 320px;
            outline: none;
            margin-top: 10px;
        }}
        .img-container {{
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        .img-container img {{
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 4px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.7);
        }}
        .fallback-card {{
            background: #111827;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            max-width: 420px;
        }}
        .fallback-card .icon {{ font-size: 48px; margin-bottom: 12px; }}
        .fallback-card h2 {{ font-size: 16px; margin-bottom: 8px; }}
        .fallback-card p {{ font-size: 13px; color: #94a3b8; margin-bottom: 20px; }}
        .btn-download {{
            background: #0284c7;
            color: white;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">
            <span>⚡ MyServer Player</span>
        </div>
        <div class="file-info">
            <span class="file-title">{safe_filename}</span>
            <span class="file-sub">{safe_rel}</span>
        </div>
        <div class="actions">
            <a href="{safe_download_url}" class="btn" title="Unduh berkas">⬇️ Unduh</a>
            <button class="btn" onclick="toggleFullscreen()" title="Layar Penuh (F)">⛶ Layar Penuh</button>
        </div>
    </div>
    <div class="player-viewport">
        {media_tag}
    </div>
    <script>
        const p = document.getElementById('player');
        function toggleFullscreen() {{
            if (!document.fullscreenElement) {{
                document.documentElement.requestFullscreen().catch(() => {{}});
            }} else {{
                document.exitFullscreen().catch(() => {{}});
            }}
        }}
        window.addEventListener('keydown', (e) => {{
            if (!p) return;
            if (e.key === ' ' || e.code === 'Space') {{
                e.preventDefault();
                p.paused ? p.play() : p.pause();
            }} else if (e.key === 'ArrowRight') {{
                p.currentTime = Math.min(p.duration || 0, p.currentTime + 5);
            }} else if (e.key === 'ArrowLeft') {{
                p.currentTime = Math.max(0, p.currentTime - 5);
            }} else if (e.key === 'ArrowUp') {{
                e.preventDefault();
                p.volume = Math.min(1, p.volume + 0.1);
            }} else if (e.key === 'ArrowDown') {{
                e.preventDefault();
                p.volume = Math.max(0, p.volume - 0.1);
            }} else if (e.key.toLowerCase() === 'f') {{
                toggleFullscreen();
            }} else if (e.key.toLowerCase() === 'm') {{
                p.muted = !p.muted;
            }}
        }});
    </script>
</body>
</html>"""


def _is_forbidden_for_user_fallback(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """Stdlib mirror of app.routers.storage.is_forbidden_for_user when pydantic/fastapi is unavailable."""
    return is_storage_path_forbidden(rel_path, username, allowed_disks, is_admin=is_admin)


def _is_disk_forbidden_for_user(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """
    Lazy-delegate disk ACL check to app.routers.storage.is_forbidden_for_user without
    requiring top-level pydantic/fastapi import on host Python environments.
    """
    if is_admin:
        return False
    try:
        from app.routers.storage import is_forbidden_for_user as storage_is_forbidden

        return bool(storage_is_forbidden(rel_path, username, allowed_disks, is_admin=is_admin))
    except ImportError:
        return _is_forbidden_for_user_fallback(
            rel_path, username, allowed_disks, is_admin=is_admin
        )


def _atomic_write_text(target_path: str, content: str) -> None:
    """Write file atomically using temp file in the same directory + os.replace."""
    parent_dir = os.path.dirname(os.path.abspath(target_path))
    os.makedirs(parent_dir, exist_ok=True)
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=parent_dir,
            prefix=".tmp_smb_",
            delete=False,
        ) as tf:
            tmp_path = tf.name
            tf.write(content)
            tf.flush()
            try:
                os.fsync(tf.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target_path)
    except Exception:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise


def _mirror_system_smb_conf(content: str) -> None:
    """Mirror generated smb.conf to /etc/samba/smb.conf when running inside root container."""
    try:
        is_root = hasattr(os, "geteuid") and os.geteuid() == 0
    except Exception:
        is_root = False
    if is_root and os.path.isdir("/etc/samba") and os.access("/etc/samba", os.W_OK):
        try:
            _atomic_write_text("/etc/samba/smb.conf", content)
        except OSError as exc:
            logger.warning(f"Gagal menyalin smb.conf ke /etc/samba/smb.conf: {exc}")


def _is_valid_smb_share_name(disk_name: str) -> bool:
    if not disk_name or disk_name.startswith("."):
        return False
    if disk_name.lower() in _EXCLUDED_SMB_SHARE_NAMES:
        return False
    if any(c in disk_name for c in ("[", "]", "\n", "\r")):
        return False
    return True


def _compute_shares_inventory(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Compute share list and authorized SQLite valid_users per immediate directory under STORAGE_DIR."""
    target_storage = storage_dir or _get_storage_dir()
    target_db = _get_db_path(db_path)
    os.makedirs(target_storage, exist_ok=True)
    storage_real = os.path.realpath(target_storage)

    users = list_all_users(target_db)
    shares: List[Dict[str, Any]] = []

    try:
        entries = [e for e in os.scandir(target_storage) if e.is_dir()]
    except OSError as exc:
        logger.warning(f"Gagal memindai STORAGE_DIR '{target_storage}': {exc}")
        entries = []

    entries.sort(key=lambda e: e.name.lower())

    for entry in entries:
        disk_name = entry.name
        if not _is_valid_smb_share_name(disk_name):
            continue
        try:
            if os.path.commonpath([storage_real, os.path.realpath(entry.path)]) != storage_real:
                continue
        except OSError:
            continue
        valid_users: List[str] = []
        seen_users = set()
        for user in users:
            raw_uname = str(user.get("username") or "")
            try:
                clean_u = validate_smb_username(raw_uname)
            except ValueError:
                continue
            if clean_u in seen_users:
                continue
            role_str = normalize_user_role(user.get("role"))
            user_is_admin = bool(role_str in ("admin", "root") or is_admin_username(clean_u))
            allowed_disks = user.get("allowed_disks")
            if not isinstance(allowed_disks, list):
                allowed_disks = []
            if user_is_admin or not _is_disk_forbidden_for_user(
                disk_name, clean_u, allowed_disks, is_admin=user_is_admin
            ):
                seen_users.add(clean_u)
                valid_users.append(clean_u)

        shares.append(
            {
                "name": disk_name,
                "path": os.path.abspath(entry.path),
                "valid_users": valid_users,
                "writable": True,
            }
        )

    return shares


def generate_smb_conf(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    """
    Generate /app/data/samba/smb.conf atomically from STORAGE_DIR subdirectories
    and SQLite users/role/allowed_disks ACLs. Returns path to generated smb.conf.
    """
    with _SMB_SYNC_LOCK:
        paths = ensure_samba_dirs()
        base_dir = paths.get("base") or os.path.dirname(paths["conf"])
        dfree_path = _ensure_dfree_script(paths.get("dfree") or os.path.join(base_dir, "dfree_safe.py"))
        shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=db_path)

        lines = [
            "[global]",
            "   workgroup = WORKGROUP",
            "   netbios name = MYSERVER",
            "   server string = MyServer Backend SMB Engine",
            "   security = user",
            "   map to guest = Never",
            f"   passdb backend = tdbsam:{paths['passdb']}",
            f"   private dir = {paths['private']}",
            f"   lock directory = {paths['lock']}",
            f"   state directory = {paths['state']}",
            f"   cache directory = {paths['cache']}",
            f"   pid directory = {paths['run']}",
            f"   ncalrpc dir = {paths['ncalrpc']}",
            "   smb ports = 445",
            "   disable netbios = yes",
            "   server min protocol = SMB2",
            "   server max protocol = SMB3",
            "   wide links = no",
            "   unix extensions = no",
            "   load printers = no",
            "   printing = bsd",
            "   printcap name = /dev/null",
            "   disable spoolss = yes",
            "   socket options = TCP_NODELAY IPTOS_LOWDELAY",
            "   keepalive = 30",
            "   deadtime = 0",
            "   dns proxy = no",
            "   hostname lookups = no",
            "   kernel oplocks = no",
            "   kernel change notify = no",
            "   stat cache = yes",
            "   max stat cache size = 1024",
            "   directory name cache size = 100",
            "   getwd cache = yes",
            "   dfree cache time = 60",
            f"   dfree command = {dfree_path}",
            "   ea support = no",
            "   store dos attributes = no",
            "   map archive = no",
            "   map hidden = no",
            "   map system = no",
            "   map readonly = no",
            "   use sendfile = yes",
            "   min receivefile size = 16384",
            "   smb2 leases = no",
            "   aio read size = 1",
            "   aio write size = 1",
            "",
        ]

        for share in shares:
            valid_list = share["valid_users"]
            lines.append(f"[{share['name']}]")
            lines.append(f"   path = {share['path']}")
            if valid_list:
                lines.append("   browseable = yes")
                lines.append("   read only = no")
                lines.append("   writable = yes")
                lines.append("   guest ok = no")
                lines.append(f"   valid users = {', '.join(valid_list)}")
            else:
                lines.append("   browseable = no")
                lines.append("   read only = yes")
                lines.append("   writable = no")
                lines.append("   guest ok = no")
                lines.append("   valid users = __myserver_nobody__")
                lines.append("   invalid users = *")
            lines.append("   force user = root")
            lines.append("   force group = root")
            lines.append("   create mask = 0664")
            lines.append("   directory mask = 0775")
            if is_fuse_or_remote_mount(share["path"]):
                # Hindari oplock break / POSIX lock / sendfile / aio / notify deadlock pada partisi FUSE (mis. Google Drive ZimaOS)
                lines.append("   oplocks = no")
                lines.append("   level2 oplocks = no")
                lines.append("   posix locking = no")
                lines.append("   strict locking = no")
                lines.append("   use sendfile = no")
                lines.append("   aio read size = 0")
                lines.append("   aio write size = 0")
                lines.append("   strict sync = no")
                lines.append("   change notify = no")
                lines.append("   fake directory create times = yes")
                lines.append("   delete readonly = yes")
            lines.append("")

        conf_text = "\n".join(lines)
        _atomic_write_text(paths["conf"], conf_text)
        _mirror_system_smb_conf(conf_text)
        return paths["conf"]


def sync_unix_and_samba_user(
    username: str,
    password: Optional[str] = None,
    uid_hint: Optional[int] = None,
    db_path: Optional[str] = None,
) -> bool:
    """
    Ensure UNIX account exists with deterministic UID (10000 + user_id) and sync
    Samba passdb credentials via safe list-based subprocess without shell=True.
    """
    clean_u = validate_smb_username(username)
    smbpasswd_bin = shutil.which("smbpasswd")
    if not smbpasswd_bin:
        return False

    with _SMB_SYNC_LOCK:
        paths = ensure_samba_dirs()
        if not os.path.isfile(paths["conf"]):
            generate_smb_conf(db_path=db_path)

        try:
            res_id = subprocess.run(
                ["id", "-u", clean_u],
                shell=False,
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            if res_id.returncode != 0:
                cmd = ["useradd", "-M", "-s", "/usr/sbin/nologin"]
                if uid_hint is not None:
                    try:
                        uid_val = 10000 + int(uid_hint)
                        if uid_val >= 10000:
                            cmd.extend(["-u", str(uid_val), "-o"])
                    except (TypeError, ValueError):
                        pass
                cmd.append(clean_u)
                res_add = subprocess.run(
                    cmd,
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=5.0,
                )
                if res_add.returncode != 0:
                    res_recheck = subprocess.run(
                        ["id", "-u", clean_u],
                        shell=False,
                        capture_output=True,
                        text=True,
                        timeout=3.0,
                    )
                    if res_recheck.returncode != 0:
                        logger.warning(f"Gagal membuat akun UNIX '{clean_u}': {res_add.stderr}")
                        return False

            if password:
                proc = subprocess.run(
                    ["smbpasswd", "-c", paths["conf"], "-a", "-s", clean_u],
                    input=f"{password}\n{password}\n",
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=5.0,
                )
                if proc.returncode != 0:
                    logger.warning(f"smbpasswd gagal untuk '{clean_u}': {proc.stderr}")
                    return False
                proc_en = subprocess.run(
                    ["smbpasswd", "-c", paths["conf"], "-e", clean_u],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=3.0,
                )
                if proc_en.returncode != 0:
                    logger.warning(f"smbpasswd -e gagal untuk '{clean_u}': {proc_en.stderr}")
                    return False
                return True
            return True
        except Exception as exc:
            logger.warning(f"Gagal sinkronisasi akun Samba '{clean_u}': {exc}")
            return False


def remove_unix_and_samba_user(username: str) -> bool:
    """Remove a user from Samba passdb safely without shell=True."""
    clean_u = validate_smb_username(username)
    if not shutil.which("smbpasswd"):
        return False

    with _SMB_SYNC_LOCK:
        paths = get_samba_paths()
        if not os.path.isfile(paths["conf"]):
            return True
        try:
            proc = subprocess.run(
                ["smbpasswd", "-c", paths["conf"], "-x", clean_u],
                shell=False,
                capture_output=True,
                text=True,
                timeout=5.0,
            )
            return proc.returncode == 0
        except Exception as exc:
            logger.warning(f"Gagal menghapus akun Samba '{clean_u}': {exc}")
            return False


def _read_pid_file(pid_path: str) -> Optional[int]:
    if not os.path.isfile(pid_path):
        return None
    try:
        with open(pid_path, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        return int(raw) if raw else None
    except Exception:
        return None


def _is_pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


_HOST_ENV_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


def _iter_backend_pid_files() -> List[str]:
    """Collect smbd PID file candidates under Samba run_dir (handles smbd.pid and smbd-*.pid)."""
    paths = get_samba_paths()
    candidates = [paths["pid"]]
    run_dir = os.path.dirname(paths["pid"])
    if os.path.isdir(run_dir):
        try:
            for fn in sorted(os.listdir(run_dir)):
                if fn.startswith("smbd") and fn.endswith(".pid"):
                    full_p = os.path.join(run_dir, fn)
                    if full_p not in candidates:
                        candidates.append(full_p)
        except OSError:
            pass
    return candidates


def _read_backend_smbd_pids() -> List[int]:
    pids: List[int] = []
    for pid_path in _iter_backend_pid_files():
        pid = _read_pid_file(pid_path)
        if pid and pid not in pids:
            pids.append(pid)
    return pids


def _run_host_nsenter(shell_cmd: str, timeout: float = 8.0) -> subprocess.CompletedProcess:
    return subprocess.run(
        [
            "nsenter",
            "-t",
            "1",
            "-m",
            "-u",
            "-n",
            "-i",
            "env",
            f"PATH={_HOST_ENV_PATH}",
            "sh",
            "-c",
            shell_cmd,
        ],
        shell=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _is_backend_smbd_running() -> bool:
    global _SMBD_CHILD_PROC
    if _SMBD_CHILD_PROC is not None:
        try:
            if _SMBD_CHILD_PROC.poll() is None:
                return True
        except Exception:
            pass
    for pid in _read_backend_smbd_pids():
        if _is_pid_alive(pid):
            return True
    if shutil.which("pgrep"):
        paths = get_samba_paths()
        try:
            pattern = f"^([^ ]*/)?smbd( .*)? -s {re.escape(paths['conf'])}( |$)"
            res = subprocess.run(
                ["pgrep", "-f", pattern],
                shell=False,
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            return res.returncode == 0 and bool((res.stdout or "").strip())
        except Exception:
            pass
    return False


def _is_zimaos_smbd_running(current_mode: str, force_refresh: bool = False) -> bool:
    with _SMB_SYNC_LOCK:
        cache_key = (str(current_mode or "").strip().lower(), get_samba_paths()["conf"])
        if not force_refresh and cache_key in _ZIMAOS_SMBD_STATUS_CACHE:
            cached_running, cached_ts = _ZIMAOS_SMBD_STATUS_CACHE[cache_key]
            if (time.monotonic() - cached_ts) < ZIMAOS_SMBD_STATUS_CACHE_TTL_SEC:
                return cached_running

    if not shutil.which("nsenter"):
        running = current_mode == "zimaos"
    else:
        try:
            res = _run_host_nsenter(
                "for u in smb.service smbd.service smb smbd samba; do "
                "systemctl is-active --quiet \"$u\" 2>/dev/null && exit 0; "
                "done; "
                "for u in smb smbd samba; do "
                "service \"$u\" status >/dev/null 2>&1 && exit 0; "
                "done; "
                "exit 1",
                timeout=3.0,
            )
            running = res.returncode == 0
        except Exception:
            running = current_mode == "zimaos"

    with _SMB_SYNC_LOCK:
        _ZIMAOS_SMBD_STATUS_CACHE[cache_key] = (bool(running), time.monotonic())
    return bool(running)


def _wait_port_445_free(timeout_sec: float = 2.0) -> bool:
    """Poll TCP 127.0.0.1:445 until released or timeout expires."""
    deadline = time.monotonic() + timeout_sec
    while True:
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.15)
            err = sock.connect_ex(("127.0.0.1", 445))
            if err != 0:
                return True
        except OSError:
            return True
        finally:
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.1)


def _wait_backend_smbd_ready(timeout_sec: float = 2.0) -> bool:
    """Confirm daemonized smbd stayed alive and began listening on port 445."""
    deadline = time.monotonic() + timeout_sec
    while True:
        if _is_backend_smbd_running():
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.15)
                if sock.connect_ex(("127.0.0.1", 445)) == 0:
                    return True
            except OSError:
                pass
            finally:
                if sock is not None:
                    try:
                        sock.close()
                    except OSError:
                        pass
        if time.monotonic() >= deadline:
            return _is_backend_smbd_running()
        time.sleep(0.1)


def _read_smbd_error_tail(max_lines: int = 6) -> str:
    """Read tail lines of Samba daemon log when startup fails post-fork."""
    candidates = [
        _get_smbd_stderr_log_path(),
        os.path.join(get_samba_paths()["base"], "log.smbd"),
        "/var/log/samba/log.smbd",
    ]
    for log_path in candidates:
        if log_path and os.path.isfile(log_path):
            try:
                with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                    lines = [ln.strip() for ln in f.readlines() if ln.strip()]
                if lines:
                    return " | ".join(lines[-max_lines:])
            except OSError:
                pass
    return ""


def _reload_running_smbd(conf_path: str) -> None:
    """Reload smbd configuration via smbcontrol or SIGHUP if active."""
    live_pids: List[int] = []
    proc = _SMBD_CHILD_PROC
    if proc is not None:
        try:
            if proc.poll() is None:
                proc_pid = getattr(proc, "pid", None)
                if not isinstance(proc_pid, bool) and isinstance(proc_pid, int) and proc_pid > 0:
                    live_pids.append(proc_pid)
        except Exception:
            pass

    for pid in _read_backend_smbd_pids():
        if _is_pid_alive(pid) and pid not in live_pids:
            live_pids.append(pid)

    if not live_pids:
        return

    if shutil.which("smbcontrol"):
        try:
            res = subprocess.run(
                ["smbcontrol", "-s", conf_path, "smbd", "reload-config"],
                shell=False,
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            if res.returncode == 0:
                return
        except Exception:
            pass

    for pid in live_pids:
        try:
            os.kill(pid, signal.SIGHUP)
        except OSError:
            pass


def sync_samba_configuration(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
    force_reload: bool = False,
) -> Dict[str, Any]:
    """
    Atomically regenerate smb.conf, synchronize all SQLite users (UNIX UID 10000+id
    + smbpasswd from encrypted smb_password_enc), and reload smbd if running and
    smb.conf content changed (or force_reload=True).
    """
    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        ensure_samba_dirs()
        old_hash = _file_sha256(get_samba_paths()["conf"])
        conf_path = generate_smb_conf(storage_dir=storage_dir, db_path=target_db)
        new_hash = _file_sha256(conf_path)
        conf_changed = (old_hash != new_hash)
        users = list_users_with_smb_secrets(target_db)

        has_smbpasswd = bool(shutil.which("smbpasswd"))
        has_smbd = bool(shutil.which("smbd"))
        simulation_mode = not bool(has_smbd and has_smbpasswd)

        synced_users: List[str] = []
        skipped_users: List[str] = []
        failed_users: List[str] = []
        for u in users:
            raw_name = str(u.get("username") or "")
            try:
                clean_u = validate_smb_username(raw_name)
            except ValueError:
                logger.warning(f"Melewati sinkronisasi user SMB dengan username tidak valid: {raw_name!r}")
                skipped_users.append(raw_name)
                continue
            plain_pw = decrypt_smb_password(u.get("smb_password_enc") or "")
            ok = sync_unix_and_samba_user(
                clean_u,
                password=plain_pw or None,
                uid_hint=u.get("id"),
                db_path=target_db,
            )
            if has_smbpasswd and not ok:
                failed_users.append(clean_u)
            else:
                synced_users.append(clean_u)

        reloaded = bool(force_reload or conf_changed)
        if reloaded:
            _reload_running_smbd(conf_path)
        invalidate_smb_status_cache()
        shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=target_db)
        return {
            "success": len(failed_users) == 0,
            "conf_path": conf_path,
            "synced_users": synced_users,
            "users_count": len(synced_users),
            "skipped_users": skipped_users,
            "failed_users": failed_users,
            "shares_count": len(shares),
            "simulation_mode": simulation_mode,
            "conf_changed": conf_changed,
            "reloaded": reloaded,
        }


def _launch_supervised_smbd(conf_path: str) -> subprocess.Popen:
    """Meluncurkan smbd secara supervised foreground (--no-process-group) dengan stderr log file agar pipe tidak pernah deadlock."""
    global _SMBD_CHILD_PROC
    stderr_log_path = _get_smbd_stderr_log_path()
    try:
        log_parent = os.path.dirname(stderr_log_path)
        if log_parent:
            os.makedirs(log_parent, exist_ok=True)
        if os.path.isfile(stderr_log_path) and os.path.getsize(stderr_log_path) > _SMBD_STDERR_LOG_MAX_BYTES:
            with open(stderr_log_path, "wb"):
                pass
    except OSError:
        pass

    stderr_fh = None
    try:
        stderr_fh = open(stderr_log_path, "ab")
    except OSError:
        stderr_fh = None

    try:
        proc = subprocess.Popen(
            ["smbd", "-F", "--no-process-group", "-s", conf_path],
            shell=False,
            stdout=subprocess.DEVNULL,
            stderr=stderr_fh if stderr_fh is not None else subprocess.DEVNULL,
        )
    finally:
        if stderr_fh is not None:
            try:
                stderr_fh.close()
            except OSError:
                pass

    _SMBD_CHILD_PROC = proc
    return proc


def stop_backend_smbd() -> bool:
    """Stop standalone Backend smbd gracefully via supervised Popen, PID file(s), and targeted pkill fallback."""
    global _SMBD_CHILD_PROC
    with _SMB_SYNC_LOCK:
        paths = get_samba_paths()
        proc = _SMBD_CHILD_PROC
        _SMBD_CHILD_PROC = None
        if proc is not None:
            try:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=2.0)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=1.0)
            except Exception:
                pass
        for pid in _read_backend_smbd_pids():
            if _is_pid_alive(pid):
                try:
                    os.kill(pid, signal.SIGTERM)
                    deadline = time.monotonic() + 1.0
                    while time.monotonic() < deadline and _is_pid_alive(pid):
                        time.sleep(0.05)
                except OSError:
                    pass
        for pid_path in _iter_backend_pid_files():
            if os.path.isfile(pid_path):
                try:
                    os.remove(pid_path)
                except OSError:
                    pass
        if shutil.which("pkill"):
            try:
                pattern = f"^([^ ]*/)?smbd( .*)? -s {re.escape(paths['conf'])}( |$)"
                subprocess.run(
                    ["pkill", "-f", pattern],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=3.0,
                )
            except Exception:
                pass
        invalidate_smb_status_cache()
        return True


def get_smb_status(
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
    force_refresh: bool = False,
    live: bool = True,
) -> Dict[str, Any]:
    """Return current SMB engine status, mode, port 445 owner, and share inventory (lock-free read path)."""
    target_db = _get_db_path(db_path)
    paths = get_samba_paths()
    mode = get_system_setting("smb_mode", default="zimaos", db_path=target_db).strip().lower()
    if mode not in ("zimaos", "backend"):
        mode = "zimaos"

    has_smbd = bool(shutil.which("smbd"))
    simulation_mode = not has_smbd
    if simulation_mode:
        backend_running = mode == "backend"
        zimaos_running = mode == "zimaos"
    else:
        backend_running = _is_backend_smbd_running()
        zimaos_running = _is_zimaos_smbd_running(mode, force_refresh=force_refresh) if live else (mode == "zimaos")

    shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=target_db)
    users = list_all_users(target_db)
    running_active = backend_running if mode == "backend" else zimaos_running

    return {
        "mode": mode,
        "running": running_active,
        "backend_smbd_running": backend_running,
        "zimaos_smbd_running": zimaos_running,
        "port_445_owner": mode,
        "simulation_mode": simulation_mode,
        "conf_path": paths["conf"],
        "shares_count": len(shares),
        "shares": shares,
        "users_count": len(users),
        "message": (
            "Mode simulasi dev aktif (binary smbd tidak terpasang di host)."
            if simulation_mode
            else f"Port 445 aktif pada mode '{mode}'."
        ),
    }


def _start_host_zimaos_smbd() -> None:
    """Start or restart host ZimaOS SMB services via nsenter."""
    try:
        _run_host_nsenter(
            "for u in smb.service smbd.service smb smbd samba; do "
            "if systemctl restart \"$u\" 2>/dev/null || systemctl start \"$u\" 2>/dev/null || "
            "service \"$u\" restart 2>/dev/null || service \"$u\" start 2>/dev/null; then break; fi; "
            "done; "
            "for u in nmb.service nmb nmbd; do "
            "systemctl start \"$u\" 2>/dev/null || service \"$u\" start 2>/dev/null || true; "
            "done",
            timeout=8.0,
        )
    except Exception as exc:
        logger.warning(f"Gagal menyalakan kembali smb host ZimaOS via nsenter: {exc}")


def set_smb_mode(
    mode: str,
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Switch Port 445 SMB owner deterministically between 'zimaos' and 'backend'.
    Persists mode in SQLite system_settings for container restart recovery.
    """
    mode_clean = str(mode or "").strip().lower()
    if mode_clean not in ("zimaos", "backend"):
        raise ValueError("Mode SMB harus 'zimaos' atau 'backend'.")

    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        paths = ensure_samba_dirs()
        has_smbd = bool(shutil.which("smbd"))
        has_nsenter = bool(shutil.which("nsenter"))

        if mode_clean == "backend":
            sync_samba_configuration(storage_dir=storage_dir, db_path=target_db)
            host_smbd_stopped = False
            if has_nsenter:
                try:
                    _run_host_nsenter(
                        "for u in smb.socket smbd.socket smb.service smb smbd.service smbd nmb.service nmb nmbd samba.service samba; do "
                        "systemctl stop \"$u\" 2>/dev/null || service \"$u\" stop 2>/dev/null || true; "
                        "done",
                        timeout=8.0,
                    )
                    host_smbd_stopped = True
                except Exception as exc:
                    logger.warning(f"Gagal menghentikan smb host ZimaOS via nsenter: {exc}")

            if has_smbd and not _is_backend_smbd_running():
                try:
                    if not _wait_port_445_free(timeout_sec=3.0):
                        raise RuntimeError(
                            "Port 445 masih digunakan oleh layanan SMB host ZimaOS; gagal mengaktifkan mode Backend."
                        )
                    proc = _launch_supervised_smbd(paths["conf"])
                    time.sleep(0.15)
                    exit_rc = proc.poll()
                    if exit_rc is not None and exit_rc != 0:
                        err_detail = ""
                        try:
                            if getattr(proc, "stderr", None) is not None:
                                err_detail = (proc.stderr.read() or "").strip()
                        except Exception:
                            pass
                        if not err_detail:
                            err_detail = _read_smbd_error_tail()
                        raise RuntimeError(
                            f"smbd Backend gagal dijalankan (kode {exit_rc}): {err_detail}"
                        )
                    if not _wait_backend_smbd_ready(timeout_sec=2.5):
                        log_tail = _read_smbd_error_tail() or "proses smbd berhenti sesaat setelah startup"
                        raise RuntimeError(
                            f"smbd Backend berhenti setelah startup: {log_tail}"
                        )
                except RuntimeError:
                    stop_backend_smbd()
                    if has_nsenter and host_smbd_stopped:
                        _start_host_zimaos_smbd()
                    invalidate_smb_status_cache()
                    raise

            set_system_setting("smb_mode", "backend", db_path=target_db)
        else:
            stop_backend_smbd()
            if has_smbd:
                _wait_port_445_free(timeout_sec=2.0)
            if has_nsenter:
                _start_host_zimaos_smbd()

            set_system_setting("smb_mode", "zimaos", db_path=target_db)

        invalidate_smb_status_cache()
        status_data = get_smb_status(db_path=target_db, storage_dir=storage_dir, force_refresh=True)
        status_data["success"] = True
        return status_data


def get_smb_shares_for_user(
    username: str,
    role: str = "user",
    allowed_disks: Optional[List[str]] = None,
    storage_dir: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Return authorized SMB shares for the given user using SQLite role & allowed_disks ACL."""
    clean_u = (username or "").strip().lower()
    role_clean = normalize_user_role(role)
    user_is_admin = bool(role_clean in ("admin", "root") or is_admin_username(clean_u))

    target_storage = storage_dir or _get_storage_dir()
    os.makedirs(target_storage, exist_ok=True)
    storage_real = os.path.realpath(target_storage)

    try:
        entries = [e for e in os.scandir(target_storage) if e.is_dir()]
    except OSError:
        entries = []
    entries.sort(key=lambda e: e.name.lower())

    result: List[Dict[str, Any]] = []
    for entry in entries:
        disk_name = entry.name
        if not _is_valid_smb_share_name(disk_name):
            continue
        try:
            if os.path.commonpath([storage_real, os.path.realpath(entry.path)]) != storage_real:
                continue
        except OSError:
            continue
        if user_is_admin or not _is_disk_forbidden_for_user(
            disk_name, clean_u, allowed_disks, is_admin=user_is_admin
        ):
            result.append(
                {
                    "name": disk_name,
                    "path": os.path.abspath(entry.path),
                    "valid_users": [clean_u] if clean_u else [],
                    "writable": True,
                }
            )
    return result


def initialize_smb_on_startup(
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Restore UNIX/Samba users and smb.conf from SQLite on container startup and apply
    the persisted smb_mode ('zimaos' default or 'backend').
    """
    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        invalidate_smb_status_cache()
        sync_samba_configuration(storage_dir=storage_dir, db_path=target_db)
        mode = get_system_setting("smb_mode", default="", db_path=target_db).strip().lower()
        if mode not in ("zimaos", "backend"):
            mode = "zimaos"
            set_system_setting("smb_mode", "zimaos", db_path=target_db)
        if mode == "backend":
            return set_smb_mode("backend", db_path=target_db, storage_dir=storage_dir)
        stop_backend_smbd()
        return get_smb_status(db_path=target_db, storage_dir=storage_dir)


def ensure_smb_watchdog_and_mount_sync(
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Watchdog & Dynamic Mount Sync:
    1. Mendeteksi penambahan/pengurangan direktori disk di /app/storage dan menjalankan smbcontrol reload-config.
    2. Jika smb_mode == 'backend' dan proses smbd berhenti tak terduga (crash), me-restart smbd secara otomatis.
    """
    global _LAST_STORAGE_DIR_SNAPSHOT
    target_db = _get_db_path(db_path)
    target_storage = storage_dir or _get_storage_dir()
    actions: Dict[str, Any] = {"mount_changed": False, "restarted_smbd": False}

    with _SMB_SYNC_LOCK:
        try:
            names = tuple(
                sorted(
                    e.name
                    for e in os.scandir(target_storage)
                    if e.is_dir() and _is_valid_smb_share_name(e.name)
                )
            )
        except OSError:
            names = ()

        if _LAST_STORAGE_DIR_SNAPSHOT is None:
            _LAST_STORAGE_DIR_SNAPSHOT = names
        elif names != _LAST_STORAGE_DIR_SNAPSHOT:
            _LAST_STORAGE_DIR_SNAPSHOT = names
            sync_samba_configuration(storage_dir=target_storage, db_path=target_db, force_reload=True)
            actions["mount_changed"] = True

        mode = get_system_setting("smb_mode", default="zimaos", db_path=target_db).strip().lower()
        if mode == "backend" and shutil.which("smbd") and not _is_backend_smbd_running():
            logger.warning("[smb_watchdog] smbd mode 'backend' terdeteksi mati tak terduga; memulai ulang...")
            set_smb_mode("backend", db_path=target_db, storage_dir=target_storage)
            actions["restarted_smbd"] = True

    return actions


def shutdown_smb_on_exit(db_path: Optional[str] = None) -> None:
    """Menghentikan supervised smbd agar tidak meninggalkan orphan dan memulihkan SMB host bila mode backend aktif."""
    target_db = _get_db_path(db_path)
    mode = get_system_setting("smb_mode", default="zimaos", db_path=target_db).strip().lower()
    stop_backend_smbd()
    if mode == "backend" and os.getenv("MYSERVER_RESTORE_HOST_SMB_ON_SHUTDOWN", "0") == "1" and shutil.which("nsenter"):
        try:
            _run_host_nsenter(
                "for u in smb.service smbd.service smb smbd samba; do "
                "systemctl start \"$u\" 2>/dev/null || service \"$u\" start 2>/dev/null && break; "
                "done",
                timeout=6.0,
            )
        except Exception:
            pass
