#!/usr/bin/env bash
# ==============================================================================
# MyServer Native Backend - Smart Dual-Mode Installer (v1.4.6)
# Mendukung Fresh Install (Instalasi Baru) & Update OTA (Pembaruan)
# Dilengkapi Proteksi Rollback Otomatis, Preservasi Mount Disk & Registrasi ZimaOS
# ==============================================================================

set -eE

# ANSI Color Codes
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}======================================================${NC}"
echo -e "${CYAN}     MyServer Native Backend - ZimaOS Deployment      ${NC}"
echo -e "${CYAN}            v1.4.6 (Smart Dual-Mode & Rollback)       ${NC}"
echo -e "${CYAN}======================================================${NC}"

# ZimaOS Immutable Rootfs Compatibility: redirect docker config to writable /tmp
export DOCKER_CONFIG="/tmp/.docker"
export TMPDIR="/tmp"
mkdir -p "$DOCKER_CONFIG"

# Direktori sumber & target instalasi (dapat di-override untuk pengujian terisolasi)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${TARGET_DIR:-/DATA/AppData/myserver-backend}"
DATA_DIR="${DATA_DIR:-$TARGET_DIR/data}"
STORAGE_DIR="${STORAGE_DIR:-/DATA/Backups}"
CASAOS_APP_DIR="${CASAOS_APP_DIR:-/var/lib/casaos/apps/myserver-backend}"
CASAOS_COMPOSE="${CASAOS_COMPOSE:-$CASAOS_APP_DIR/docker-compose.yml}"
CASAOS_APP_DIR="$(dirname "$CASAOS_COMPOSE")"
PRESERVED_MOUNTS_FILE="$(mktemp "${TMPDIR:-/tmp}/myserver_preserved_mounts.XXXXXX.json")"

cleanup_preserved_mounts() {
    rm -f "$PRESERVED_MOUNTS_FILE" 2>/dev/null || ${SUDO:-} rm -f "$PRESERVED_MOUNTS_FILE" 2>/dev/null || true
}
trap cleanup_preserved_mounts EXIT

echo -e "\n${YELLOW}[1/5] Memeriksa Lingkungan Docker & Hak Akses...${NC}"

if ! command -v docker &> /dev/null; then
    echo -e "${RED}[ERROR] Docker tidak terdeteksi! Pastikan ZimaOS terpasang dengan benar.${NC}"
    exit 1
fi

DOCKER_COMPOSE_CMD=""
if docker compose version &> /dev/null; then
    DOCKER_COMPOSE_CMD="docker compose"
elif command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE_CMD="docker-compose"
else
    echo -e "${RED}[ERROR] docker compose tidak ditemukan!${NC}"
    exit 1
fi

SUDO=""
if [ "$EUID" -ne 0 ]; then
    if command -v sudo &> /dev/null; then
        SUDO="sudo"
    fi
fi

echo -e "${GREEN}✓ Docker & Compose terdeteksi ($DOCKER_COMPOSE_CMD).${NC}"

# 2. Deteksi Mode: Fresh Install vs Update OTA
echo -e "\n${YELLOW}[2/5] Mendeteksi Mode Instalasi...${NC}"

MODE="fresh"
if [ -d "$DATA_DIR" ] && [ -f "$DATA_DIR/backup_meta.db" ]; then
    MODE="update"
    echo -e "${CYAN}✓ Mode Terdeteksi: UPDATE OTA (Database & data persistensi ditemukan).${NC}"
else
    echo -e "${CYAN}✓ Mode Terdeteksi: FRESH INSTALL (Instalasi awal backend baru).${NC}"
fi

$SUDO mkdir -p "$DATA_DIR" "$STORAGE_DIR"

# PENTING: Ekstrak mount volume /app/storage/* kustom pengguna dari $CASAOS_COMPOSE
# dan $TARGET_DIR/docker-compose.yml SEBELUM menyalin/menimpa $TARGET_DIR/docker-compose.yml.
# Menggunakan Python 3 stdlib murni (tanpa dependensi pihak ketiga).
if command -v python3 &> /dev/null; then
    echo -e "${YELLOW}[Volume] Memindai mount volume kustom sebelum sinkronisasi compose...${NC}"
    $SUDO python3 - "$PRESERVED_MOUNTS_FILE" "$CASAOS_COMPOSE" "$TARGET_DIR/docker-compose.yml" << 'PY_EXTRACT'
import json
import os
import re
import sys

def strip_inline_comment(s):
    in_sq = False
    in_dq = False
    for idx, ch in enumerate(s):
        if ch == "'" and not in_dq:
            in_sq = not in_sq
        elif ch == '"' and not in_sq:
            in_dq = not in_dq
        elif ch == "#" and not in_sq and not in_dq:
            if idx == 0 or s[idx - 1].isspace():
                return s[:idx].rstrip()
    return s.rstrip()

def unquote(s):
    s = s.strip()
    if len(s) >= 2 and ((s[0] == '"' and s[-1] == '"') or (s[0] == "'" and s[-1] == "'")):
        return s[1:-1]
    return s

def find_service_volumes_blocks(lines):
    n = len(lines)
    i = 0
    while i < n:
        raw = lines[i]
        stripped = strip_inline_comment(raw).strip()
        indent = len(raw) - len(raw.lstrip(" "))
        if stripped == "services:":
            services_indent = indent
            i += 1
            svc_indent = None
            prop_indent = None
            while i < n:
                r2 = lines[i]
                s2 = strip_inline_comment(r2).strip()
                if not s2:
                    i += 1
                    continue
                ind2 = len(r2) - len(r2.lstrip(" "))
                if ind2 <= services_indent:
                    break
                if svc_indent is None or ind2 <= svc_indent:
                    svc_indent = ind2
                    prop_indent = None
                    i += 1
                    continue
                if prop_indent is None or ind2 < prop_indent:
                    prop_indent = ind2
                if ind2 == prop_indent and (s2 == "volumes:" or s2.startswith("volumes:")):
                    vol_key_idx = i
                    vol_indent = ind2
                    rest = s2[len("volumes:"):].strip()
                    i += 1
                    if rest == "[]":
                        yield (vol_key_idx, vol_indent, vol_key_idx + 1, vol_key_idx + 1)
                        continue
                    block_start = i
                    last_idx = i
                    while i < n:
                        r3 = lines[i]
                        s3 = strip_inline_comment(r3).strip()
                        if not s3:
                            i += 1
                            continue
                        ind3 = len(r3) - len(r3.lstrip(" "))
                        is_seq = s3 == "-" or s3.startswith("- ")
                        if ind3 > vol_indent or (ind3 == vol_indent and is_seq):
                            last_idx = i + 1
                            i += 1
                            continue
                        break
                    yield (vol_key_idx, vol_indent, block_start, last_idx)
                    continue
                i += 1
            continue
        i += 1

def parse_short_mount(val):
    val = unquote(val)
    parts = val.split(":")
    if len(parts) == 2:
        return {"type": "bind", "source": parts[0].strip(), "target": parts[1].strip(), "read_only": False}
    if len(parts) >= 3 and not parts[-1].strip().startswith("/"):
        mode = parts[-1].strip()
        tgt = parts[-2].strip()
        src = ":".join(parts[:-2]).strip()
        ro = "ro" in [m.strip().lower() for m in mode.split(",")]
        return {"type": "bind", "source": src, "target": tgt, "read_only": ro}
    return None

def parse_flow_dict(val):
    inner = val.strip()[1:-1]
    kv = {}
    for part in inner.split(","):
        if ":" in part:
            k, v = part.split(":", 1)
            kv[k.strip()] = unquote(v)
    return {
        "type": kv.get("type", "bind") or "bind",
        "source": kv.get("source", ""),
        "target": kv.get("target", ""),
        "read_only": kv.get("read_only", "").lower() in ("true", "1", "yes"),
    }

def parse_volume_items(lines, block_start, block_end):
    items = []
    item_indent = None
    cur_first = None
    cur_sub = []
    for idx in range(block_start, block_end):
        raw = lines[idx]
        s = strip_inline_comment(raw).strip()
        if not s:
            continue
        ind = len(raw) - len(raw.lstrip(" "))
        is_seq = s == "-" or s.startswith("- ")
        if item_indent is None:
            if not is_seq:
                continue
            item_indent = ind
        if ind == item_indent and is_seq:
            if cur_first is not None:
                items.append((cur_first, cur_sub))
            cur_first = s[1:].strip() if len(s) > 1 else ""
            cur_sub = []
        elif cur_first is not None and ind > item_indent:
            cur_sub.append((ind, s))
    if cur_first is not None:
        items.append((cur_first, cur_sub))

    parsed = []
    for first_part, sublines in items:
        if not sublines and first_part:
            if first_part.startswith("{") and first_part.endswith("}"):
                parsed.append(parse_flow_dict(first_part))
                continue
            is_mapping = (
                not first_part.startswith(('"', "'", "/"))
                and re.match(r"^[A-Za-z_][A-Za-z0-9_-]*\s*:", first_part) is not None
            )
            if not is_mapping:
                sm = parse_short_mount(first_part)
                if sm:
                    parsed.append(sm)
                continue
        kv = {}
        dict_indent = None
        entries = []
        if first_part:
            entries.append((None, first_part))
        for sub_ind, sub_s in sublines:
            if dict_indent is None or sub_ind < dict_indent:
                dict_indent = sub_ind
            entries.append((sub_ind, sub_s))
        for ent_ind, ent_s in entries:
            if ent_ind is not None and dict_indent is not None and ent_ind > dict_indent:
                continue
            if ":" in ent_s:
                k, v = ent_s.split(":", 1)
                kv[k.strip()] = unquote(v)
        parsed.append({
            "type": kv.get("type", "bind") or "bind",
            "source": kv.get("source", ""),
            "target": kv.get("target", ""),
            "read_only": kv.get("read_only", "").lower() in ("true", "1", "yes"),
        })
    return parsed

out_file = sys.argv[1]
preserved = []
seen_targets = set()
for compose_path in sys.argv[2:]:
    if not compose_path or not os.path.isfile(compose_path):
        continue
    try:
        with open(compose_path, "r", encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except OSError:
        continue
    for _, _, b_start, b_end in find_service_volumes_blocks(lines):
        for item in parse_volume_items(lines, b_start, b_end):
            src = (item.get("source") or "").strip()
            tgt = (item.get("target") or "").strip().rstrip("/")
            item_type = (item.get("type") or "bind").strip()
            if not src or not tgt:
                continue
            if item_type not in ("", "bind"):
                continue
            if not tgt.startswith("/app/storage/"):
                continue
            if tgt == "/app/storage/Disk_Sistem" and src == "/DATA/Backups":
                continue
            if tgt in seen_targets:
                continue
            seen_targets.add(tgt)
            preserved.append({
                "source": src,
                "target": tgt,
                "read_only": bool(item.get("read_only", False)),
            })

with open(out_file, "w", encoding="utf-8") as out_fh:
    json.dump(preserved, out_fh, indent=2)
PY_EXTRACT
fi

UPDATE_COMPOSE_DOWN_DONE=0
rollback_update_artifacts() {
    local restart_flag="${1:-0}"
    if [ "$MODE" != "update" ]; then
        return 0
    fi
    echo -e "${YELLOW}[ROLLBACK] Mengaktifkan pemulihan otomatis ke versi sebelumnya...${NC}"
    if [ -d "$TARGET_DIR/app.bak" ]; then
        $SUDO rm -rf "$TARGET_DIR/app"
        $SUDO mv "$TARGET_DIR/app.bak" "$TARGET_DIR/app"
    fi
    for f_bak in Dockerfile docker-compose.yml requirements.txt; do
        if [ -f "$TARGET_DIR/${f_bak}.bak" ]; then
            $SUDO mv -f "$TARGET_DIR/${f_bak}.bak" "$TARGET_DIR/${f_bak}"
        fi
    done
    if [ -n "${CASAOS_COMPOSE:-}" ] && [ -f "${CASAOS_COMPOSE}.bak" ]; then
        $SUDO mv -f "${CASAOS_COMPOSE}.bak" "$CASAOS_COMPOSE"
    fi
    if [ "$restart_flag" -eq 1 ] && [ -f "$TARGET_DIR/docker-compose.yml" ]; then
        local rb_compose="$TARGET_DIR/docker-compose.yml"
        if [ -n "${ACTIVE_COMPOSE_FILE:-}" ] && [ -f "${ACTIVE_COMPOSE_FILE:-}" ]; then
            rb_compose="$ACTIVE_COMPOSE_FILE"
        fi
        $SUDO docker rm -f myserver-backend myserver-native-backend 2>/dev/null || true
        $SUDO $DOCKER_COMPOSE_CMD -p myserver-backend -f "$rb_compose" up -d 2>/dev/null || true
    fi
}

rollback_on_update_err() {
    local exit_code=$?
    trap - ERR
    rollback_update_artifacts "$UPDATE_COMPOSE_DOWN_DONE"
    exit "$exit_code"
}

# Jika dijalankan dari luar TARGET_DIR (misal dari /tmp/staging):
if [ "$SCRIPT_DIR" != "$TARGET_DIR" ]; then
    if [ "$MODE" = "update" ]; then
        echo -e "${YELLOW}[Backup] Membuat cadangan app & konfigurasi lama (*.bak)...${NC}"
        $SUDO rm -rf "$TARGET_DIR/app.bak"
        if [ -d "$TARGET_DIR/app" ]; then
            $SUDO cp -r "$TARGET_DIR/app" "$TARGET_DIR/app.bak"
        fi
        for f_bak in Dockerfile docker-compose.yml requirements.txt; do
            $SUDO rm -f "$TARGET_DIR/${f_bak}.bak"
            if [ -f "$TARGET_DIR/${f_bak}" ]; then
                $SUDO cp "$TARGET_DIR/${f_bak}" "$TARGET_DIR/${f_bak}.bak"
            fi
        done
        if [ -n "${CASAOS_COMPOSE:-}" ] && [ -f "$CASAOS_COMPOSE" ]; then
            $SUDO cp "$CASAOS_COMPOSE" "${CASAOS_COMPOSE}.bak"
        fi
        trap rollback_on_update_err ERR
        echo -e "${YELLOW}[Sync] Menyinkronkan modul app/ baru secara bersih ke direktori produksi...${NC}"
        $SUDO rm -rf "$TARGET_DIR/app"
        $SUDO cp -r "$SCRIPT_DIR/app" "$TARGET_DIR/app"
        $SUDO cp "$SCRIPT_DIR/Dockerfile" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/docker-compose.yml" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/requirements.txt" "$TARGET_DIR/" 2>/dev/null || true
    else
        echo -e "${YELLOW}[Setup] Menyalin seluruh paket instalasi ke $TARGET_DIR...${NC}"
        $SUDO mkdir -p "$TARGET_DIR"
        $SUDO cp -r "$SCRIPT_DIR"/* "$TARGET_DIR/" 2>/dev/null || true
        if [ -d "$SCRIPT_DIR/app" ]; then
            $SUDO rm -rf "$TARGET_DIR/app"
            $SUDO cp -r "$SCRIPT_DIR/app" "$TARGET_DIR/app"
        fi
        $SUDO cp "$SCRIPT_DIR/Dockerfile" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/docker-compose.yml" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/requirements.txt" "$TARGET_DIR/" 2>/dev/null || true
    fi
fi

# Pastikan direktori app/ terjamin ada sebelum bind mount /app/app dijalankan
$SUDO mkdir -p "$TARGET_DIR/app"

# Gabungkan kembali mount volume /app/storage/* kustom pengguna ke $TARGET_DIR/docker-compose.yml
if [ -f "$PRESERVED_MOUNTS_FILE" ] && [ -f "$TARGET_DIR/docker-compose.yml" ] && command -v python3 &> /dev/null; then
    $SUDO python3 - "$PRESERVED_MOUNTS_FILE" "$TARGET_DIR/docker-compose.yml" << 'PY_MERGE'
import json
import os
import re
import sys

def strip_inline_comment(s):
    in_sq = False
    in_dq = False
    for idx, ch in enumerate(s):
        if ch == "'" and not in_dq:
            in_sq = not in_sq
        elif ch == '"' and not in_sq:
            in_dq = not in_dq
        elif ch == "#" and not in_sq and not in_dq:
            if idx == 0 or s[idx - 1].isspace():
                return s[:idx].rstrip()
    return s.rstrip()

def unquote(s):
    s = s.strip()
    if len(s) >= 2 and ((s[0] == '"' and s[-1] == '"') or (s[0] == "'" and s[-1] == "'")):
        return s[1:-1]
    return s

def yaml_scalar(val):
    special = (' ', ':', '#', '"', "'", '{', '}', '[', ']', '&', '*', '!', '|', '>', '%', '@', '`')
    if not val or any(c in val for c in special):
        escaped = val.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return val

def find_first_service_volumes(lines):
    n = len(lines)
    i = 0
    while i < n:
        raw = lines[i]
        stripped = strip_inline_comment(raw).strip()
        indent = len(raw) - len(raw.lstrip(" "))
        if stripped == "services:":
            services_indent = indent
            i += 1
            svc_indent = None
            prop_indent = None
            while i < n:
                r2 = lines[i]
                s2 = strip_inline_comment(r2).strip()
                if not s2:
                    i += 1
                    continue
                ind2 = len(r2) - len(r2.lstrip(" "))
                if ind2 <= services_indent:
                    break
                if svc_indent is None or ind2 <= svc_indent:
                    svc_indent = ind2
                    prop_indent = None
                    i += 1
                    continue
                if prop_indent is None or ind2 < prop_indent:
                    prop_indent = ind2
                if ind2 == prop_indent and (s2 == "volumes:" or s2.startswith("volumes:")):
                    vol_key_idx = i
                    vol_indent = ind2
                    i += 1
                    block_start = i
                    last_idx = i
                    while i < n:
                        r3 = lines[i]
                        s3 = strip_inline_comment(r3).strip()
                        if not s3:
                            i += 1
                            continue
                        ind3 = len(r3) - len(r3.lstrip(" "))
                        is_seq = s3 == "-" or s3.startswith("- ")
                        if ind3 > vol_indent or (ind3 == vol_indent and is_seq):
                            last_idx = i + 1
                            i += 1
                            continue
                        break
                    return (vol_key_idx, vol_indent, block_start, last_idx)
                i += 1
            continue
        i += 1
    return None

preserved_path = sys.argv[1]
compose_path = sys.argv[2]

try:
    with open(preserved_path, "r", encoding="utf-8") as fh:
        preserved = json.load(fh)
except Exception:
    preserved = []

if not preserved:
    sys.exit(0)

with open(compose_path, "r", encoding="utf-8") as fh:
    lines = fh.read().splitlines()

found = find_first_service_volumes(lines)
if not found:
    sys.exit(0)

vol_key_idx, vol_indent, b_start, b_end = found
existing_targets = set()
seq_indent = None
for idx in range(b_start, b_end):
    raw = lines[idx]
    s = strip_inline_comment(raw).strip()
    if not s:
        continue
    ind = len(raw) - len(raw.lstrip(" "))
    if seq_indent is None and (s == "-" or s.startswith("- ")):
        seq_indent = ind
    if s.startswith("target:"):
        existing_targets.add(unquote(s.split(":", 1)[1]).strip().rstrip("/"))
    elif s.startswith("- target:"):
        existing_targets.add(unquote(s.split(":", 1)[1]).strip().rstrip("/"))
    elif s.startswith("- ") and ":" in s and not re.match(r"^-\s+[A-Za-z_][A-Za-z0-9_-]*\s*:", s):
        val = unquote(s[2:].strip())
        parts = val.split(":")
        if len(parts) == 2:
            existing_targets.add(parts[1].strip().rstrip("/"))
        elif len(parts) >= 3 and not parts[-1].strip().startswith("/"):
            existing_targets.add(parts[-2].strip().rstrip("/"))

if seq_indent is None:
    seq_indent = vol_indent + 2

custom_disk_sistem = None
to_add = []
for item in preserved:
    tgt = (item.get("target") or "").strip().rstrip("/")
    src = (item.get("source") or "").strip()
    if not src or not tgt:
        continue
    if tgt == "/app/storage/Disk_Sistem":
        if src != "/DATA/Backups" and custom_disk_sistem is None:
            custom_disk_sistem = {
                "source": src,
                "target": tgt,
                "read_only": bool(item.get("read_only", False)),
            }
        continue
    if tgt in existing_targets:
        continue
    existing_targets.add(tgt)
    to_add.append({
        "source": src,
        "target": tgt,
        "read_only": bool(item.get("read_only", False)),
    })

modified_disk_sistem = False
if custom_disk_sistem is not None:
    groups = []
    cur_start = None
    for idx in range(b_start, b_end):
        raw = lines[idx]
        s = strip_inline_comment(raw).strip()
        ind = len(raw) - len(raw.lstrip(" "))
        if s and (s == "-" or s.startswith("- ")) and (cur_start is None or ind <= seq_indent):
            if cur_start is not None:
                groups.append((cur_start, idx))
            cur_start = idx
    if cur_start is not None:
        groups.append((cur_start, b_end))

    for g_start, g_end in groups:
        is_target_ds = False
        src_line_idx = None
        short_line_idx = None
        for idx in range(g_start, g_end):
            s = strip_inline_comment(lines[idx]).strip()
            if s.startswith("target:") or s.startswith("- target:"):
                t_val = unquote(s.split(":", 1)[1]).strip().rstrip("/")
                if t_val == "/app/storage/Disk_Sistem":
                    is_target_ds = True
            elif s.startswith("source:") or s.startswith("- source:"):
                src_line_idx = idx
            elif s.startswith("- ") and ":" in s and not re.match(r"^-\s+[A-Za-z_][A-Za-z0-9_-]*\s*:", s):
                val = unquote(s[2:].strip())
                parts = val.split(":")
                if len(parts) == 2 and parts[1].strip().rstrip("/") == "/app/storage/Disk_Sistem":
                    is_target_ds = True
                    short_line_idx = idx
                elif len(parts) >= 3 and not parts[-1].strip().startswith("/") and parts[-2].strip().rstrip("/") == "/app/storage/Disk_Sistem":
                    is_target_ds = True
                    short_line_idx = idx
        if is_target_ds:
            if src_line_idx is not None:
                orig_line = lines[src_line_idx]
                lead_ws = orig_line[:len(orig_line) - len(orig_line.lstrip(" "))]
                key_prefix = "- source:" if orig_line.lstrip(" ").startswith("- source:") else "source:"
                lines[src_line_idx] = f"{lead_ws}{key_prefix} {yaml_scalar(custom_disk_sistem['source'])}"
                modified_disk_sistem = True
            elif short_line_idx is not None:
                orig_line = lines[short_line_idx]
                lead_ws = orig_line[:len(orig_line) - len(orig_line.lstrip(" "))]
                ro_suffix = ":ro" if custom_disk_sistem["read_only"] else ""
                lines[short_line_idx] = f"{lead_ws}- {yaml_scalar(custom_disk_sistem['source'])}:/app/storage/Disk_Sistem{ro_suffix}"
                modified_disk_sistem = True
            break

if not to_add and not modified_disk_sistem:
    sys.exit(0)

pad = " " * seq_indent
sub_pad = " " * (seq_indent + 2)
insert_lines = []
for item in to_add:
    insert_lines.append(f"{pad}- type: bind")
    insert_lines.append(f"{sub_pad}source: {yaml_scalar(item['source'])}")
    insert_lines.append(f"{sub_pad}target: {yaml_scalar(item['target'])}")
    if item["read_only"]:
        insert_lines.append(f"{sub_pad}read_only: true")

if insert_lines and lines[vol_key_idx].strip() == "volumes: []":
    lines[vol_key_idx] = (" " * vol_indent) + "volumes:"

new_lines = lines[:b_end] + insert_lines + lines[b_end:]
with open(compose_path, "w", encoding="utf-8", newline="\n") as fh:
    fh.write("\n".join(new_lines) + "\n")
print(f"Preserved {len(to_add) + (1 if modified_disk_sistem else 0)} custom storage mount(s) into {compose_path}")
PY_MERGE
    rm -f "$PRESERVED_MOUNTS_FILE" 2>/dev/null || $SUDO rm -f "$PRESERVED_MOUNTS_FILE" 2>/dev/null || true
fi

cd "$TARGET_DIR"

# 3. Membangun / Menarik Citra Docker Sebelum Menghentikan Layanan Aktif
echo -e "\n${YELLOW}[3/5] Menyiapkan Image Docker (ghcr.io/gibranibang/myserver-backend:latest)...${NC}"
DOCKER_BUILD_ARGS=""
if [ "$MODE" = "fresh" ] || [ "${MYSERVER_FORCE_NO_CACHE:-0}" = "1" ]; then
    DOCKER_BUILD_ARGS="--no-cache"
fi
IMAGE_READY=0
if [ "${MYSERVER_FORCE_LOCAL_BUILD:-0}" != "1" ]; then
    echo -e "${CYAN}[INFO] Menarik pre-built multi-arch image dari GHCR...${NC}"
    if $SUDO docker pull ghcr.io/gibranibang/myserver-backend:latest; then
        IMAGE_READY=1
    else
        echo -e "${YELLOW}[INFO] Pull GHCR gagal/offline, beralih ke build Docker lokal...${NC}"
    fi
fi
if [ "$IMAGE_READY" -eq 0 ]; then
    $SUDO docker build ${DOCKER_BUILD_ARGS:+$DOCKER_BUILD_ARGS }-t ghcr.io/gibranibang/myserver-backend:latest "$TARGET_DIR"
fi
$SUDO docker tag ghcr.io/gibranibang/myserver-backend:latest myserver-backend:latest 2>/dev/null || true

# 4. Menghentikan Project Lama & Membersihkan Kontainer Konflik Sebelum Start Ulang
echo -e "\n${YELLOW}[4/5] Membersihkan Project Lama & Menyiapkan Container Docker...${NC}"
$SUDO $DOCKER_COMPOSE_CMD -p myserver-native-backend down 2>/dev/null || true
$SUDO $DOCKER_COMPOSE_CMD -p myserver-backend down 2>/dev/null || true
if [ -f "$CASAOS_COMPOSE" ]; then
    $SUDO $DOCKER_COMPOSE_CMD -p myserver-backend -f "$CASAOS_COMPOSE" down 2>/dev/null || true
fi
$SUDO docker rm -f myserver-backend myserver-native-backend 2>/dev/null || true
UPDATE_COMPOSE_DOWN_DONE=1

# 5. Sinkronisasi Manifest ZimaOS & Jalankan Compose (tanpa POST /v2/app_management/compose paralel agar tidak race / pull GHCR tak berujung)
echo -e "\n${YELLOW}[5/5] Menyinkronkan Manifest ZimaOS & Menjalankan Container...${NC}"
ACTIVE_COMPOSE_FILE="$TARGET_DIR/docker-compose.yml"
if $SUDO mkdir -p "$CASAOS_APP_DIR" 2>/dev/null && $SUDO cp "$TARGET_DIR/docker-compose.yml" "$CASAOS_COMPOSE" 2>/dev/null; then
    ACTIVE_COMPOSE_FILE="$CASAOS_COMPOSE"
    echo -e "${GREEN}✓ Manifest compose disalin ke $CASAOS_COMPOSE.${NC}"
else
    echo -e "${YELLOW}[INFO] Direktori ZimaOS App Management ($CASAOS_APP_DIR) tidak tersedia, fallback ke $TARGET_DIR/docker-compose.yml.${NC}"
fi

$SUDO $DOCKER_COMPOSE_CMD -p myserver-backend -f "$ACTIVE_COMPOSE_FILE" up -d

# 6. Uji Kesehatan Layanan (Healthcheck Verification)
echo -e "\n${YELLOW}Memverifikasi respons server (Healthcheck)...${NC}"
SERVER_READY=0
for i in {1..20}; do
    if curl -s -f http://127.0.0.1:8080/health > /dev/null 2>&1; then
        SERVER_READY=1
        break
    fi
    echo -n "."
    sleep 2
done
echo ""

HOST_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
if [ -z "$HOST_IP" ]; then
    HOST_IP="127.0.0.1"
fi

if [ $SERVER_READY -eq 1 ]; then
    trap - ERR
    if [ "$MODE" = "update" ]; then
        $SUDO rm -rf "$TARGET_DIR/app.bak" "$TARGET_DIR/Dockerfile.bak" "$TARGET_DIR/docker-compose.yml.bak" "$TARGET_DIR/requirements.txt.bak"
        if [ -n "${CASAOS_COMPOSE:-}" ]; then
            $SUDO rm -f "${CASAOS_COMPOSE}.bak" 2>/dev/null || true
        fi
    fi
    HEALTH_RESP=$(curl -s http://127.0.0.1:8080/health 2>/dev/null || echo "{}")
    echo -e "\n${GREEN}======================================================${NC}"
    echo -e "${GREEN}   ✓ BERHASIL: MyServer Backend v1.4.6 Aktif!         ${NC}"
    echo -e "${GREEN}======================================================${NC}"
    echo -e "Status Layanan:"
    echo -e "  - Respons Health : ${CYAN}${HEALTH_RESP}${NC}"
    echo -e "  - Mode Selesai   : ${GREEN}${MODE^^}${NC}"
    echo -e "  - URL Akses      : ${CYAN}http://${HOST_IP}:8080${NC}"
    echo -e "  - API Docs       : ${CYAN}http://${HOST_IP}:8080/docs${NC}"
    echo -e "${GREEN}======================================================${NC}"
    exit 0
else
    trap - ERR
    echo -e "\n${RED}======================================================${NC}"
    echo -e "${RED}[GALAT] Layanan belum merespons dalam 40 detik!${NC}"
    rollback_update_artifacts 1
    echo -e "Periksa log container dengan perintah:"
    echo -e "  ${YELLOW}$DOCKER_COMPOSE_CMD -p myserver-backend -f \"$ACTIVE_COMPOSE_FILE\" logs --tail 50${NC}"
    echo -e "${RED}======================================================${NC}"
    exit 1
fi
