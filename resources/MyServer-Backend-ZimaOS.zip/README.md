# 🚀 MyServer Native Backend Engine (Project Algitha)
### *Layanan Server Backup Mandiri & 100% Bebas Pihak Ketiga untuk ZimaOS*

`MyServer Backend` adalah daemon service independen berkinerja tinggi yang dirancang khusus untuk menangani proses sinkronisasi, deduplikasi cerdas, dan pencadangan berkas langsung ke hard disk server ZimaOS dari aplikasi **MyServer Desktop (Windows)** dan **MyServer Mobile (Flutter)**.

---

## 🌟 Fitur Utama
1. **100% Bebas Pihak Ketiga (Zero Third-Party)**: Tidak membutuhkan Nextcloud, Syncthing, FileBrowser, atau Immich.
2. **Deduplikasi Cerdas Berbasis Hash SHA-256**: Berkas yang sudah ada di server secara otomatis dilewati (*skip*), menghemat kuota bandwidth dan mempercepat proses sinkronisasi hingga 90%.
3. **Chunked Streaming Upload (4MB / 8MB)**: Mendukung pengunggahan berkas besar (ratusan GB) dengan mekanisme *resume otomatis* jika koneksi Wi-Fi atau internet terputus di tengah jalan.
4. **Katalog Metadata SQLite Berkecepatan Tinggi**: Menggunakan SQLite dalam mode `WAL` (*Write-Ahead Logging*) untuk pencatatan riwayat berkas, versi, dan log aktivitas secara konkuren tanpa overhead database berat seperti PostgreSQL atau MySQL.
5. **Koneksi Multi-Perangkat**: Manajemen perangkat terintegrasi untuk mendeteksi laptop, desktop, dan ponsel cerdas yang terhubung.
6. **OpenAPI / Swagger Otomatis**: Antarmuka dokumentasi dan testing API interaktif di endpoint `/docs`.

---

## 📁 Struktur Direktori
```text
MyServer Backend by algitha/
├── app/
│   ├── config.py            # Konfigurasi path, port, batas chunk, & JWT secret
│   ├── database.py          # DDL Skema SQLite, WAL mode, & query data access
│   ├── models.py            # Model DTO & validasi skema request/response
│   ├── auth.py              # Generator & verifikator token HMAC-SHA256
│   ├── main.py              # Entrypoint FastAPI, CORS, & middleware
│   └── routers/
│       ├── system.py        # /health, /api/v1/system/info
│       ├── auth.py          # /api/v1/auth/verify
│       ├── devices.py       # /api/v1/devices (registrasi & heartbeat)
│       ├── tasks.py         # /api/v1/tasks (definisi folder backup)
│       └── backup.py        # /check-hashes, /upload-chunk, /commit-file, /files
├── data/                    # Mount folder untuk backup_meta.db
├── storage/                 # Mount folder untuk penyimpanan berkas fisik HDD
├── tests/                   # Pengujian unit database dan kontrak API
├── openapi_spec.json        # Kontrak standar OpenAPI 3.1.0
├── Dockerfile               # Container build untuk Linux/ZimaOS
├── docker-compose.yml       # Definisi instalasi 1-klik di CasaOS/ZimaOS
└── requirements.txt         # Pustaka Python minimum
```

---

## 🛠️ Panduan Instalasi di ZimaOS

### Cara 1: Menggunakan Skrip Otomatis (Sangat Direkomendasikan via SSH / Terminal ZimaOS)
Unggah folder atau ekstrak file `MyServer-Backend-ZimaOS.zip` ke ZimaOS, lalu jalankan:
```bash
cd /DATA/AppData/myserver-backend
chmod +x install_zimaos.sh
./install_zimaos.sh
```
Skrip ini akan secara otomatis:
- Menyiapkan folder persisten `/DATA/AppData/myserver-backend/data` & `/DATA/Backups`
- Membangun citra Docker `myserver-backend:latest`
- Menjalankan container dengan port `8080`
- Memverifikasi kesehatan server dengan healthcheck otomatis

### Cara 2: Menggunakan Custom Install (+) di Web UI ZimaOS
1. Buka Web UI ZimaOS (misal: `http://192.168.1.11`).
2. Masuk ke **App Store** -> Klik tanda **+ (Custom Install)** di pojok kanan atas.
3. Klik tombol **Import** di kiri atas dialog, lalu tempel isi berkas [`docker-compose.yml`](docker-compose.yml).
4. Pastikan path volume terarah ke:
   - `/DATA/AppData/myserver-backend/data` -> `/app/data`
   - `/DATA/Backups` -> `/app/storage`
5. Klik **Submit / Install**.
6. Server siap melayani di port `8080` (Dapat diakses di `http://[IP-ZimaOS]:8080/docs`).

---

## 🧪 Menjalankan Pengujian Lokal (Development)
Untuk menguji logika skema database dan fungsi deduplikasi pada mesin pengembang:
```bash
python -m unittest tests/test_database.py
```
