"""
MyServer Native Backend Package
Version: 1.0.3
"""

__version__ = "1.0.3"
