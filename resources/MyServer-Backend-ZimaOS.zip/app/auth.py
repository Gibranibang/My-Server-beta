"""
Authentication & Token Verification Module
Uses secure HMAC-SHA256 tokens with support for ZimaOS pass-through authentication.
"""

import hmac
import hashlib
import json
import base64
import os
import threading
import time
from collections import deque
from typing import Optional, Dict, Any, Tuple
from app.config import JWT_SECRET, JWT_EXPIRE_HOURS, is_admin_username

_RATE_LIMIT_LOCK = threading.Lock()
_RATE_LIMIT_BUCKETS: Dict[str, deque] = {}


def base64url_encode(data: bytes) -> str:
    """Encode bytes ke format Base64URL tanpa padding."""
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def base64url_decode(data: str) -> bytes:
    """Decode string Base64URL dengan penyesuaian padding otomatis."""
    rem = len(data) % 4
    if rem > 0:
        data += "=" * (4 - rem)
    return base64.urlsafe_b64decode(data.encode("utf-8"))


def create_access_token(
    username: str,
    user_id: int,
    role: str = "user",
    token_version: Optional[int] = None,
) -> str:
    """Membuat token akses sesi aman bertanda tangan HMAC-SHA256."""
    role_norm = str(role or "").strip().lower()
    if role_norm not in ("admin", "root"):
        role_norm = "user"
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    payload = {
        "sub": username,
        "uid": user_id,
        "role": role_norm,
        "iat": now,
        "exp": now + (JWT_EXPIRE_HOURS * 3600)
    }
    if token_version is not None:
        payload["tv"] = int(token_version)
    
    header_b64 = base64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = base64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    
    signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
    signature = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()
    sig_b64 = base64url_encode(signature)
    
    return f"{header_b64}.{payload_b64}.{sig_b64}"


def create_refresh_token(
    username: str,
    user_id: int,
    role: str = "user",
    token_version: int = 1,
    ttl_hours: Optional[int] = None,
) -> str:
    """Membuat refresh token berumur panjang untuk rotasi sesi tanpa login ulang."""
    role_norm = str(role or "").strip().lower()
    if role_norm not in ("admin", "root"):
        role_norm = "user"
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    exp_hours = int(ttl_hours) if ttl_hours is not None else max(JWT_EXPIRE_HOURS * 3, 24 * 90)
    payload = {
        "sub": username,
        "uid": user_id,
        "role": role_norm,
        "scope": "refresh",
        "tv": int(token_version or 1),
        "iat": now,
        "exp": now + (exp_hours * 3600),
    }
    header_b64 = base64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = base64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
    signature = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{base64url_encode(signature)}"


def verify_refresh_token(token: str) -> Optional[Dict[str, Any]]:
    """Memvalidasi refresh token dan memastikan scope == 'refresh'."""
    payload = verify_access_token(token)
    if not payload or str(payload.get("scope") or "").strip().lower() != "refresh":
        return None
    return payload


def create_stream_token(
    username: str,
    user_id: int,
    path: str,
    ttl_seconds: int = 300,
) -> str:
    """Membuat token streaming jangka pendek yang terikat ke satu berkas (scope='stream')."""
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    clean_path = (path or "").strip().replace("\\", "/").strip("/")
    payload = {
        "sub": username,
        "uid": user_id,
        "scope": "stream",
        "path": clean_path,
        "iat": now,
        "exp": now + max(1, int(ttl_seconds)),
    }

    header_b64 = base64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = base64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))

    signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
    signature = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()
    sig_b64 = base64url_encode(signature)

    return f"{header_b64}.{payload_b64}.{sig_b64}"


def verify_access_token(token: str) -> Optional[Dict[str, Any]]:
    """Memverifikasi keabsahan token dan masa berlakunya."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None

        header_b64, payload_b64, sig_b64 = parts
        signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
        expected_sig = hmac.new(JWT_SECRET.encode("utf-8"), signing_input, hashlib.sha256).digest()

        actual_sig = base64url_decode(sig_b64)
        if not hmac.compare_digest(expected_sig, actual_sig):
            return None

        payload = json.loads(base64url_decode(payload_b64).decode("utf-8"))
        exp_val = payload.get("exp")
        if not isinstance(exp_val, (int, float)) or int(exp_val) < int(time.time()):
            return None  # Token kadaluarsa

        return payload
    except Exception:
        return None


try:
    from fastapi import Depends, Header, Query, HTTPException, status
except ImportError:
    Depends = lambda fn=None: fn
    Header = lambda default=None, **kw: default
    Query = lambda default=None, **kw: default

    class HTTPException(Exception):
        def __init__(self, status_code: int = 400, detail: str = ""):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail

    class status:
        HTTP_400_BAD_REQUEST = 400
        HTTP_401_UNAUTHORIZED = 401
        HTTP_403_FORBIDDEN = 403


def _extract_raw_token(authorization: Optional[str], token: Optional[str]) -> Optional[str]:
    if authorization and authorization.lower().startswith("bearer "):
        raw = authorization[7:].strip()
        if raw:
            return raw
    if token:
        raw = token.strip()
        if raw:
            return raw
    return None


def get_optional_current_user(
    authorization: Optional[str] = Header(None),
    token: Optional[str] = Query(None),
) -> Optional[Dict[str, Any]]:
    """
    Memvalidasi JWT Bearer/query bila disertakan, atau mengembalikan None jika request tanpa token.
    Tetap menolak token tidak valid/kedaluwarsa dengan HTTP 401.
    """
    raw_token = _extract_raw_token(authorization, token)
    if not raw_token:
        return None

    payload = verify_access_token(raw_token)
    if not payload:
        if os.getenv("MYSERVER_ALLOW_DEV_TOKENS") == "1" and raw_token.startswith("auth_verified_"):
            uname = raw_token.replace("auth_verified_", "")
            return {"sub": uname, "uid": 1, "role": "admin"}
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token autentikasi tidak valid atau telah kedaluwarsa.",
        )
    return payload


def get_current_user(
    authorization: Optional[str] = Header(None),
    token: Optional[str] = Query(None)
) -> Dict[str, Any]:
    """
    FastAPI dependency untuk memvalidasi token akses Bearer atau token query parameter.
    Menolak request tanpa token valid dengan status HTTP 401 Unauthorized.
    """
    payload = get_optional_current_user(authorization=authorization, token=token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token autentikasi tidak ditemukan. Harap sertakan Authorization: Bearer <token>."
        )
    return payload


def verify_active_jwt_user(
    current_user: Any,
    allow_stream_scope: bool = False,
    target_path: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Validasi fail-closed atas payload JWT terhadap database SQLite aktif:
    - Menolak akun yang sudah dihapus atau memiliki uid tidak cocok (HTTP 401)
    - Menolak token scope='stream' di luar endpoint stream/download atau jalur berbeda (HTTP 403)
    """
    if not isinstance(current_user, dict):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Autentikasi JWT diperlukan.",
        )

    token_scope = str(current_user.get("scope") or "").strip().lower()
    if token_scope == "stream":
        if not allow_stream_scope:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Token streaming terbatas tidak diizinkan untuk operasi ini.",
            )
        token_path = str(current_user.get("path") or "").strip().replace("\\", "/").strip("/")
        req_norm = ("" if target_path is None else str(target_path)).strip().replace("\\", "/").strip("/")
        if not token_path or not req_norm or token_path != req_norm:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Token streaming tidak cocok dengan berkas yang diminta.",
            )
    elif token_scope:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cakupan token autentikasi tidak dikenali.",
        )

    jwt_user = str(current_user.get("sub") or "").strip().lower()
    if not jwt_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Identitas token JWT tidak valid.",
        )

    from app.database import get_user_by_username

    user_rec = get_user_by_username(jwt_user, db_path=db_path) if db_path else get_user_by_username(jwt_user)
    jwt_uid = current_user.get("uid")
    try:
        uid_matches = (jwt_uid is None) or (
            user_rec is not None and int(jwt_uid) == int(user_rec["id"])
        )
    except (TypeError, ValueError):
        uid_matches = False

    if not user_rec or not uid_matches:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Akun pengguna tidak lagi terdaftar atau telah dicabut.",
        )

    raw_tv = current_user.get("tv")
    try:
        token_tv = int(raw_tv) if raw_tv is not None else 1
        db_tv = int(user_rec.get("token_version") or 1)
    except (TypeError, ValueError):
        token_tv = -1
        db_tv = 0
    if token_tv != db_tv:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Sesi token telah dicabut (kata sandi diubah atau logout semua sesi).",
        )

    return user_rec


def get_control_plane_user(
    authorization: Optional[str] = Header(None),
    token: Optional[str] = Query(None),
) -> Dict[str, Any]:
    """
    Dependency autentikasi fail-closed untuk control-plane (/api/v1/vms, /devices, /tasks).
    Selalu menegakkan JWT valid + validasi DB aktif dan mengembalikan identitas DB otoritatif.
    """
    payload = get_current_user(authorization=authorization, token=token)
    user_rec = verify_active_jwt_user(payload, allow_stream_scope=False)

    from app.database import normalize_user_role

    username = str(user_rec.get("username") or "").strip().lower()
    db_role = normalize_user_role(user_rec.get("role"))
    is_admin = bool(db_role in ("admin", "root") or is_admin_username(username))
    eff_role = "admin" if is_admin else db_role

    raw_disks = user_rec.get("allowed_disks", "[]")
    if isinstance(raw_disks, list):
        allowed_disks = [str(d).strip() for d in raw_disks if str(d).strip()]
    elif isinstance(raw_disks, str):
        try:
            parsed_disks = json.loads(raw_disks)
            allowed_disks = [str(d).strip() for d in parsed_disks if str(d).strip()] if isinstance(parsed_disks, list) else []
        except Exception:
            allowed_disks = []
    else:
        allowed_disks = []

    uid = int(user_rec["id"])
    return {
        "sub": username,
        "username": username,
        "uid": uid,
        "user_id": uid,
        "role": eff_role,
        "is_admin": is_admin,
        "allowed_disks": allowed_disks,
        "tv": int(user_rec.get("token_version") or 1),
    }


def require_control_plane_admin(
    identity: Dict[str, Any] = Depends(get_control_plane_user),
) -> Dict[str, Any]:
    """Dependency otorisasi administrator untuk endpoint control-plane sensitif."""
    if not isinstance(identity, dict) or not identity.get("is_admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan mengakses endpoint ini.",
        )
    return identity


def record_rate_limit_attempt(key: str, max_attempts: int = 15, window_seconds: float = 60.0) -> Tuple[bool, int]:
    """Mencatat percobaan pada jendela waktu geser; mengembalikan (allowed, retry_after_sec)."""
    now = time.monotonic()
    cutoff = now - max(1.0, float(window_seconds))
    with _RATE_LIMIT_LOCK:
        bucket = _RATE_LIMIT_BUCKETS.get(key)
        if bucket is None:
            bucket = deque()
            _RATE_LIMIT_BUCKETS[key] = bucket
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= max_attempts:
            retry_after = max(1, int(bucket[0] + window_seconds - now) + 1)
            return False, retry_after
        bucket.append(now)
        if len(_RATE_LIMIT_BUCKETS) > 4096:
            stale = [k for k, dq in _RATE_LIMIT_BUCKETS.items() if not dq or dq[-1] < cutoff]
            for k in stale:
                _RATE_LIMIT_BUCKETS.pop(k, None)
    return True, 0


def reset_rate_limit_bucket(key: str) -> None:
    """Mengosongkan bucket rate limit setelah autentikasi berhasil."""
    with _RATE_LIMIT_LOCK:
        _RATE_LIMIT_BUCKETS.pop(key, None)


def enforce_rate_limit(key: str, max_attempts: int = 15, window_seconds: float = 60.0) -> None:
    """Memblokir dengan HTTP 429 Too Many Requests jika batas percobaan terlampaui."""
    allowed, retry_after = record_rate_limit_attempt(key, max_attempts=max_attempts, window_seconds=window_seconds)
    if not allowed:
        raise HTTPException(
            status_code=getattr(status, "HTTP_429_TOO_MANY_REQUESTS", 429),
            detail=f"Terlalu banyak percobaan gagal. Coba lagi dalam {retry_after} detik.",
        )


_SSE_LOCK = threading.Lock()
_SSE_SUBSCRIBERS: Dict[str, Any] = {}


def subscribe_realtime_events(sub_id: str, queue_obj: Any, loop: Any = None) -> None:
    with _SSE_LOCK:
        _SSE_SUBSCRIBERS[sub_id] = (queue_obj, loop)


def unsubscribe_realtime_events(sub_id: str) -> None:
    with _SSE_LOCK:
        _SSE_SUBSCRIBERS.pop(sub_id, None)


def publish_realtime_event(event_type: str, payload: Optional[Dict[str, Any]] = None) -> int:
    """Mengirim event real-time (SMB/VM/Storage) ke seluruh subscriber SSE aktif secara thread-safe."""
    evt = {
        "type": str(event_type or "update"),
        "ts": int(time.time()),
        "data": payload or {},
    }
    delivered = 0
    with _SSE_LOCK:
        items = list(_SSE_SUBSCRIBERS.items())
    for sub_id, (q_obj, loop) in items:
        try:
            if loop is not None and not loop.is_closed():
                def _put_safe(q=q_obj, item=evt):
                    try:
                        if q.full():
                            q.get_nowait()
                        q.put_nowait(item)
                    except Exception:
                        pass
                loop.call_soon_threadsafe(_put_safe)
            else:
                if hasattr(q_obj, "full") and q_obj.full():
                    q_obj.get_nowait()
                q_obj.put_nowait(evt)
            delivered += 1
        except Exception:
            unsubscribe_realtime_events(sub_id)
    return delivered
