"""
Configuration Module for MyServer Native Backend
"""

import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = os.getenv("MYSERVER_DATA_DIR", str(BASE_DIR / "data"))
STORAGE_DIR = os.getenv("MYSERVER_STORAGE_DIR", str(BASE_DIR / "storage"))
TEMP_DIR = os.path.join(DATA_DIR, "temp_chunks")

# Database Path
DB_PATH = os.getenv("MYSERVER_DB_PATH", os.path.join(DATA_DIR, "backup_meta.db"))

# Server Parameters
PORT = int(os.getenv("MYSERVER_PORT", "8080"))
HOST = os.getenv("MYSERVER_HOST", "0.0.0.0")
JWT_SECRET = os.getenv("MYSERVER_JWT_SECRET", "myserver_algitha_secret_jwt_key_2026")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = int(os.getenv("MYSERVER_JWT_EXPIRE_HOURS", "720"))  # 30 days

# Backup Engine Parameters
CHUNK_SIZE_BYTES = int(os.getenv("MYSERVER_CHUNK_SIZE_MB", "4")) * 1024 * 1024  # Default 4MB
MAX_PARALLEL_CHUNKS = int(os.getenv("MYSERVER_MAX_PARALLEL_CHUNKS", "4"))
SERVER_VERSION = "1.2.5"

# Ensure directories exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(STORAGE_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)
