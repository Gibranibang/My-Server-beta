"""
Database Manager for MyServer Native Backend
SQLite Schema & Data Access Layer (WAL mode enabled)
"""

import sqlite3
import os
import json
import logging
import threading
import hashlib
import hmac
import secrets
from contextlib import contextmanager
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.config import DB_PATH

logger = logging.getLogger("myserver.database")

SCHEMA_SQL = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- 1. Tabel Pengguna (Users)
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT DEFAULT '',
    role TEXT DEFAULT 'staff',
    allowed_disks TEXT DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabel Perangkat Klien (Devices: Desktop Windows, Mobile Android/iOS)
CREATE TABLE IF NOT EXISTS devices (
    device_id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    device_name TEXT NOT NULL,
    device_type TEXT NOT NULL, -- 'windows', 'android', 'ios', 'linux'
    app_version TEXT NOT NULL,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

-- 3. Tabel Tugas Cadangan (Backup Tasks)
CREATE TABLE IF NOT EXISTS backup_tasks (
    task_id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    task_name TEXT NOT NULL,
    target_folder TEXT NOT NULL,
    sync_mode TEXT DEFAULT 'one_way', -- 'one_way', 'mirror'
    username TEXT DEFAULT 'admin',
    status TEXT DEFAULT 'idle', -- 'idle', 'syncing', 'completed', 'error'
    total_files INTEGER DEFAULT 0,
    total_bytes INTEGER DEFAULT 0,
    last_run TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices (device_id) ON DELETE CASCADE
);

-- 4. Tabel Berkas Tercatat (Files Registry)
CREATE TABLE IF NOT EXISTS files (
    file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_hash TEXT NOT NULL, -- SHA-256 berkas utuh
    modified_time INTEGER NOT NULL, -- Client timestamp (epoch seconds)
    storage_path TEXT NOT NULL, -- Lokasi fisik relatif di HDD server
    status TEXT DEFAULT 'active', -- 'active', 'deleted', 'archived'
    version INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES backup_tasks (task_id) ON DELETE CASCADE,
    UNIQUE(task_id, relative_path)
);

-- 5. Tabel Sesi Unggah Potongan (Upload Sessions)
CREATE TABLE IF NOT EXISTS upload_sessions (
    upload_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_hash TEXT NOT NULL,
    total_chunks INTEGER NOT NULL,
    chunks_received INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending', -- 'pending', 'uploading', 'merging', 'completed', 'failed'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES backup_tasks (task_id) ON DELETE CASCADE
);

-- 6. Tabel Potongan Berkas (Chunks)
CREATE TABLE IF NOT EXISTS chunks (
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
    upload_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    chunk_hash TEXT NOT NULL,
    chunk_size INTEGER NOT NULL,
    is_uploaded BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (upload_id) REFERENCES upload_sessions (upload_id) ON DELETE CASCADE,
    UNIQUE(upload_id, chunk_index)
);

-- 7. Tabel Log Aktivitas (Activity Logs)
CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT,
    task_id TEXT,
    action TEXT NOT NULL, -- 'DEVICE_REGISTERED', 'BACKUP_STARTED', 'FILE_UPLOADED', 'ERROR'
    message TEXT NOT NULL,
    details TEXT, -- JSON string
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Tabel Multi-Akun Cloud Storage (Google Drive / OneDrive per Akun)
CREATE TABLE IF NOT EXISTS cloud_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    provider TEXT DEFAULT 'gdrive', -- 'gdrive', 'onedrive', 'dropbox'
    email TEXT NOT NULL,
    display_name TEXT,
    access_token TEXT,
    refresh_token TEXT,
    token_expiry TIMESTAMP,
    quota_total INTEGER DEFAULT 0,
    quota_used INTEGER DEFAULT 0,
    status TEXT DEFAULT 'connected', -- 'connected', 'expired', 'disconnected'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    UNIQUE(user_id, provider, email)
);

-- 9. Tabel Virtual Machine Terkelola (Managed VMs & 24/7 Server Automation - v1.2.0)
CREATE TABLE IF NOT EXISTS managed_vms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT 'instabox',
    status TEXT NOT NULL DEFAULT 'sleeping',
    ssh_host TEXT DEFAULT '',
    ssh_port INTEGER DEFAULT 22,
    ssh_user TEXT DEFAULT '',
    token_expiry TEXT DEFAULT '',
    web_port INTEGER,
    web_url TEXT,
    screen_url TEXT,
    screen_target TEXT DEFAULT 'ask',
    api_key TEXT,
    machine_id TEXT,
    keep_alive_enabled BOOLEAN DEFAULT 0,
    auto_on_enabled BOOLEAN DEFAULT 0,
    auto_on_mode TEXT DEFAULT 'clock',
    auto_on_time TEXT DEFAULT '07:00',
    auto_on_delay_min INTEGER DEFAULT 60,
    auto_on_delay_unit TEXT DEFAULT 'minutes',
    auto_on_days TEXT DEFAULT '["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]',
    auto_restart_enabled BOOLEAN DEFAULT 0,
    auto_restart_mode TEXT DEFAULT 'interval',
    auto_restart_val INTEGER DEFAULT 7,
    auto_restart_unit TEXT DEFAULT 'hours',
    auto_restart_time TEXT DEFAULT '03:00',
    smart_reset_cycle TEXT DEFAULT 'sleep_2s',
    runtime_limit_hours INTEGER DEFAULT 8,
    runtime_minutes INTEGER DEFAULT 0,
    schedule_timezone TEXT DEFAULT '',
    tz_offset_minutes INTEGER,
    last_runtime_check TIMESTAMP,
    last_wake_time TIMESTAMP,
    last_sleep_time TIMESTAMP,
    last_reset_time TIMESTAMP,
    telemetry TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indeks Performa Tinggi
CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_device ON backup_tasks(device_id);
CREATE INDEX IF NOT EXISTS idx_files_lookup ON files(task_id, relative_path);
CREATE INDEX IF NOT EXISTS idx_files_hash ON files(file_hash);
CREATE INDEX IF NOT EXISTS idx_upload_sessions_task ON upload_sessions(task_id);
CREATE INDEX IF NOT EXISTS idx_chunks_session ON chunks(upload_id, chunk_index);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON activity_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_cloud_accounts_user ON cloud_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_managed_vms_provider ON managed_vms(provider);
CREATE INDEX IF NOT EXISTS idx_managed_vms_status ON managed_vms(status);
"""


@contextmanager
def get_db(db_path: str = DB_PATH):
    """Context manager untuk koneksi SQLite yang thread-safe & auto-commit."""
    conn = sqlite3.connect(db_path, timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: str = DB_PATH):
    """Inisialisasi tabel dan indeks database jika belum ada."""
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    with get_db(db_path) as conn:
        conn.executescript(SCHEMA_SQL)
        # Migrasi otomatis multi-user isolation
        cols = [r["name"] for r in conn.execute("PRAGMA table_info(backup_tasks)").fetchall()]
        if "username" not in cols:
            conn.execute("ALTER TABLE backup_tasks ADD COLUMN username TEXT DEFAULT 'admin'")
        
        # Migrasi otomatis tabel users untuk custom account & RBAC
        user_cols = [r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
        if "password_hash" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN password_hash TEXT DEFAULT ''")
        if "role" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'staff'")
        if "allowed_disks" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN allowed_disks TEXT DEFAULT '[]'")

        # Migrasi otomatis tabel managed_vms untuk kolom jadwal & reset
        vm_cols = [r["name"] for r in conn.execute("PRAGMA table_info(managed_vms)").fetchall()]
        if "auto_on_delay_unit" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN auto_on_delay_unit TEXT DEFAULT 'minutes'")
        if "last_reset_time" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN last_reset_time TIMESTAMP")
        if "schedule_timezone" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN schedule_timezone TEXT DEFAULT ''")
        if "tz_offset_minutes" not in vm_cols:
            conn.execute("ALTER TABLE managed_vms ADD COLUMN tz_offset_minutes INTEGER")
    logger.info(f"Database initialized successfully at: {db_path}")


# ==============================================================================
# DATA ACCESS HELPERS: AUTH & USER MANAGEMENT
# ==============================================================================

def hash_password(password: str, salt: bytes = None) -> str:
    """Hash password menggunakan PBKDF2-HMAC-SHA256 (100.000 iterasi)."""
    if not salt:
        salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
    return f"{salt.hex()}:{key.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verifikasi kecocokan password dengan hash tersimpan (timing-attack resistant)."""
    if not stored_hash or ":" not in stored_hash:
        return False
    try:
        salt_hex, key_hex = stored_hash.split(":", 1)
        salt = bytes.fromhex(salt_hex)
        key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100000)
        return hmac.compare_digest(key.hex(), key_hex)
    except Exception:
        return False


def get_user_by_username(username: str, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data lengkap pengguna berdasarkan username."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", (username.strip(),)).fetchone()
        return dict(row) if row else None


def get_user_by_id(user_id: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data lengkap pengguna berdasarkan user_id."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return dict(row) if row else None


def list_all_users(db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Daftar seluruh pengguna terdaftar untuk manajemen akun administrator."""
    with get_db(db_path) as conn:
        rows = conn.execute("SELECT id, username, role, allowed_disks, created_at FROM users ORDER BY id ASC").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["allowed_disks"] = json.loads(d["allowed_disks"]) if d.get("allowed_disks") else []
            except Exception:
                d["allowed_disks"] = []
            result.append(d)
        return result


def create_or_update_user(
    username: str,
    password: Optional[str] = None,
    role: str = "staff",
    allowed_disks: Optional[List[str]] = None,
    db_path: str = DB_PATH
) -> Dict[str, Any]:
    """Membuat pengguna baru atau memperbarui role/allowed_disks/password pengguna eksisting."""
    u_clean = username.strip().lower()
    disks_json = json.dumps(allowed_disks if allowed_disks is not None else [])
    
    with get_db(db_path) as conn:
        existing = conn.execute("SELECT * FROM users WHERE LOWER(username) = ?", (u_clean,)).fetchone()
        if existing:
            updates = ["role = ?", "allowed_disks = ?"]
            params = [role, disks_json]
            if password:
                pwd_h = hash_password(password)
                updates.append("password_hash = ?")
                params.append(pwd_h)
            params.append(existing["id"])
            conn.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", params)
            user_id = existing["id"]
        else:
            pwd_h = hash_password(password) if password else ""
            cursor = conn.execute("""
                INSERT INTO users (username, password_hash, role, allowed_disks)
                VALUES (?, ?, ?, ?)
            """, (u_clean, pwd_h, role, disks_json))
            user_id = cursor.lastrowid

        row = conn.execute("SELECT id, username, role, allowed_disks, created_at FROM users WHERE id = ?", (user_id,)).fetchone()
        res = dict(row)
        try:
            res["allowed_disks"] = json.loads(res["allowed_disks"])
        except Exception:
            res["allowed_disks"] = []
        return res


def delete_user_by_id(user_id: int, db_path: str = DB_PATH) -> bool:
    """Menghapus akun pengguna dari database."""
    with get_db(db_path) as conn:
        cursor = conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        return cursor.rowcount > 0


# ==============================================================================
# DATA ACCESS HELPERS: CLOUD / GOOGLE DRIVE MULTI-ACCOUNT
# ==============================================================================

def create_or_update_cloud_account(
    user_id: int,
    email: str,
    provider: str = "gdrive",
    display_name: Optional[str] = None,
    access_token: Optional[str] = None,
    refresh_token: Optional[str] = None,
    token_expiry: Optional[str] = None,
    quota_total: int = 0,
    quota_used: int = 0,
    status: str = "connected",
    db_path: str = DB_PATH
) -> Dict[str, Any]:
    """Menyimpan atau memperbarui akun Google Drive / Cloud storage untuk user tertentu."""
    with get_db(db_path) as conn:
        existing = conn.execute(
            "SELECT id FROM cloud_accounts WHERE user_id = ? AND provider = ? AND LOWER(email) = ?",
            (user_id, provider, email.lower().strip())
        ).fetchone()

        if existing:
            account_id = existing["id"]
            conn.execute("""
                UPDATE cloud_accounts 
                SET display_name = COALESCE(?, display_name),
                    access_token = COALESCE(?, access_token),
                    refresh_token = COALESCE(?, refresh_token),
                    token_expiry = COALESCE(?, token_expiry),
                    quota_total = ?,
                    quota_used = ?,
                    status = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (display_name, access_token, refresh_token, token_expiry, quota_total, quota_used, status, account_id))
        else:
            cursor = conn.execute("""
                INSERT INTO cloud_accounts (
                    user_id, provider, email, display_name, access_token, refresh_token,
                    token_expiry, quota_total, quota_used, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, provider, email.lower().strip(), display_name or email, access_token, refresh_token,
                  token_expiry, quota_total, quota_used, status))
            account_id = cursor.lastrowid

        row = conn.execute("SELECT * FROM cloud_accounts WHERE id = ?", (account_id,)).fetchone()
        return dict(row)


def get_cloud_accounts_by_user(user_id: int, provider: Optional[str] = None, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil daftar akun cloud storage milik seorang user."""
    with get_db(db_path) as conn:
        if provider:
            rows = conn.execute(
                "SELECT id, user_id, provider, email, display_name, quota_total, quota_used, status, created_at, updated_at "
                "FROM cloud_accounts WHERE user_id = ? AND provider = ? ORDER BY created_at ASC",
                (user_id, provider)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, user_id, provider, email, display_name, quota_total, quota_used, status, created_at, updated_at "
                "FROM cloud_accounts WHERE user_id = ? ORDER BY created_at ASC",
                (user_id,)
            ).fetchall()
        return [dict(r) for r in rows]


def get_cloud_account_by_id(account_id: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil detail akun cloud berdasarkan ID."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT * FROM cloud_accounts WHERE id = ?", (account_id,)).fetchone()
        return dict(row) if row else None


def delete_cloud_account(account_id: int, user_id: Optional[int] = None, db_path: str = DB_PATH) -> bool:
    """Menghapus akun cloud storage."""
    with get_db(db_path) as conn:
        if user_id is not None:
            cursor = conn.execute("DELETE FROM cloud_accounts WHERE id = ? AND user_id = ?", (account_id, user_id))
        else:
            cursor = conn.execute("DELETE FROM cloud_accounts WHERE id = ?", (account_id,))
        return cursor.rowcount > 0


# ==============================================================================
# DATA ACCESS HELPERS
# ==============================================================================

def get_or_create_user(username: str, db_path: str = DB_PATH) -> int:
    """Mengambil atau membuat entri pengguna baru."""
    with get_db(db_path) as conn:
        row = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        if row:
            return row["id"]
        cursor = conn.execute("INSERT INTO users (username) VALUES (?)", (username,))
        return cursor.lastrowid


def upsert_device(device_id: str, user_id: int, device_name: str, device_type: str, app_version: str, db_path: str = DB_PATH) -> Dict[str, Any]:
    """Registrasi atau perbarui status perangkat klien."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO devices (device_id, user_id, device_name, device_type, app_version, last_seen)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(device_id) DO UPDATE SET
                user_id = excluded.user_id,
                device_name = excluded.device_name,
                device_type = excluded.device_type,
                app_version = excluded.app_version,
                last_seen = CURRENT_TIMESTAMP;
        """, (device_id, user_id, device_name, device_type, app_version))
        row = conn.execute("""
            SELECT d.*, u.username 
            FROM devices d 
            LEFT JOIN users u ON d.user_id = u.id 
            WHERE d.device_id = ?
        """, (device_id,)).fetchone()
        return dict(row) if row else {}


def update_device_heartbeat(device_id: str, db_path: str = DB_PATH) -> bool:
    """Perbarui waktu aktif perangkat terakhir."""
    with get_db(db_path) as conn:
        cursor = conn.execute("UPDATE devices SET last_seen = CURRENT_TIMESTAMP WHERE device_id = ?", (device_id,))
        return cursor.rowcount > 0


def upsert_task(task_id: str, device_id: str, task_name: str, target_folder: str, sync_mode: str = "one_way", username: str = "admin", db_path: str = DB_PATH) -> Dict[str, Any]:
    """Registrasi atau perbarui definisi tugas backup."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO backup_tasks (task_id, device_id, task_name, target_folder, sync_mode, username)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(task_id) DO UPDATE SET
                task_name = excluded.task_name,
                target_folder = excluded.target_folder,
                sync_mode = excluded.sync_mode,
                username = excluded.username;
        """, (task_id, device_id, task_name, target_folder, sync_mode, username))
        row = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
        return dict(row) if row else {}


def check_hashes_bulk(task_id: str, file_entries: List[Dict[str, Any]], db_path: str = DB_PATH) -> Dict[str, Any]:
    """
    Deduplikasi Cerdas: Membandingkan daftar hash berkas klien dengan yang ada di server.
    Mengembalikan daftar berkas yang sudah ada (skip) dan yang harus diunggah (needed).
    """
    with get_db(db_path) as conn:
        existing_rows = conn.execute(
            "SELECT relative_path, file_hash, file_size FROM files WHERE task_id = ? AND status = 'active'",
            (task_id,)
        ).fetchall()
        
        server_files = {row["relative_path"]: row["file_hash"] for row in existing_rows}
        
        needed = []
        up_to_date = []
        
        for entry in file_entries:
            rel_path = entry.get("relative_path")
            client_hash = entry.get("file_hash")
            
            if rel_path in server_files and server_files[rel_path] == client_hash:
                up_to_date.append(rel_path)
            else:
                needed.append(entry)
                
        return {
            "needed_files": needed,
            "existing_files": up_to_date,
            "total_checked": len(file_entries),
            "skipped_count": len(up_to_date)
        }


def create_upload_session(upload_id: str, task_id: str, relative_path: str, file_size: int, file_hash: str, total_chunks: int, db_path: str = DB_PATH) -> Dict[str, Any]:
    """Inisialisasi sesi unggah bertahap untuk berkas baru/berubah."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO upload_sessions (upload_id, task_id, relative_path, file_size, file_hash, total_chunks, status)
            VALUES (?, ?, ?, ?, ?, ?, 'uploading')
            ON CONFLICT(upload_id) DO UPDATE SET
                status = 'uploading',
                updated_at = CURRENT_TIMESTAMP;
        """, (upload_id, task_id, relative_path, file_size, file_hash, total_chunks))
        
        # Cari chunk yang sudah pernah terunggah jika sesi di-resume
        uploaded = conn.execute("SELECT chunk_index FROM chunks WHERE upload_id = ? AND is_uploaded = 1", (upload_id,)).fetchall()
        uploaded_indices = [r["chunk_index"] for r in uploaded]
        missing_indices = [i for i in range(total_chunks) if i not in uploaded_indices]
        
        return {
            "upload_id": upload_id,
            "total_chunks": total_chunks,
            "uploaded_chunks": uploaded_indices,
            "missing_chunks": missing_indices
        }


def save_chunk_record(upload_id: str, chunk_index: int, chunk_hash: str, chunk_size: int, db_path: str = DB_PATH) -> bool:
    """Mencatat potongan berkas yang berhasil diterima."""
    with get_db(db_path) as conn:
        conn.execute("""
            INSERT INTO chunks (upload_id, chunk_index, chunk_hash, chunk_size, is_uploaded)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(upload_id, chunk_index) DO UPDATE SET
                chunk_hash = excluded.chunk_hash,
                chunk_size = excluded.chunk_size,
                is_uploaded = 1;
        """, (upload_id, chunk_index, chunk_hash, chunk_size))
        
        conn.execute("""
            UPDATE upload_sessions
            SET chunks_received = (SELECT COUNT(*) FROM chunks WHERE upload_id = ? AND is_uploaded = 1),
                updated_at = CURRENT_TIMESTAMP
            WHERE upload_id = ?;
        """, (upload_id, upload_id))
        return True


def commit_file_record(upload_id: str, storage_path: str, modified_time: int, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Finalisasi berkas setelah seluruh chunk berhasil digabungkan."""
    with get_db(db_path) as conn:
        session = conn.execute("SELECT * FROM upload_sessions WHERE upload_id = ?", (upload_id,)).fetchone()
        if not session:
            return None
            
        task_id = session["task_id"]
        relative_path = session["relative_path"]
        file_size = session["file_size"]
        file_hash = session["file_hash"]
        
        # Simpan atau update berkas ke tabel files
        conn.execute("""
            INSERT INTO files (task_id, relative_path, file_size, file_hash, modified_time, storage_path, status, version, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'active', 1, CURRENT_TIMESTAMP)
            ON CONFLICT(task_id, relative_path) DO UPDATE SET
                file_size = excluded.file_size,
                file_hash = excluded.file_hash,
                modified_time = excluded.modified_time,
                storage_path = excluded.storage_path,
                status = 'active',
                version = files.version + 1,
                updated_at = CURRENT_TIMESTAMP;
        """, (task_id, relative_path, file_size, file_hash, modified_time, storage_path))
        
        # Tandai sesi selesai
        conn.execute("UPDATE upload_sessions SET status = 'completed', updated_at = CURRENT_TIMESTAMP WHERE upload_id = ?", (upload_id,))
        
        # Perbarui total file & byte pada task
        conn.execute("""
            UPDATE backup_tasks
            SET total_files = (SELECT COUNT(*) FROM files WHERE task_id = ? AND status = 'active'),
                total_bytes = (SELECT COALESCE(SUM(file_size), 0) FROM files WHERE task_id = ? AND status = 'active'),
                last_run = CURRENT_TIMESTAMP
            WHERE task_id = ?;
        """, (task_id, task_id, task_id))
        
        row = conn.execute("SELECT * FROM files WHERE task_id = ? AND relative_path = ?", (task_id, relative_path)).fetchone()
        return dict(row) if row else None


def log_activity(device_id: Optional[str], task_id: Optional[str], action: str, message: str, details: Optional[Dict[str, Any]] = None, db_path: str = DB_PATH):
    """Mencatat aktivitas dan riwayat transaksi ke database."""
    details_str = json.dumps(details or {})
    try:
        with get_db(db_path) as conn:
            conn.execute("""
                INSERT INTO activity_logs (device_id, task_id, action, message, details)
                VALUES (?, ?, ?, ?, ?)
            """, (device_id, task_id, action, message, details_str))
    except Exception as e:
        logger.error(f"Gagal mencatat log aktivitas: {e}")


_active_sessions: Dict[str, Dict[str, Any]] = {}
_sessions_lock = threading.Lock()


def track_session(session_id: str, username: str, path: str, client_ip: str, session_type: str = "stream") -> Dict[str, Any]:
    """Mencatat atau memperbarui sesi streaming/akses berkas aktif."""
    now_iso = datetime.utcnow().isoformat() + "Z"
    with _sessions_lock:
        if session_id in _active_sessions:
            _active_sessions[session_id]["last_active"] = now_iso
        else:
            _active_sessions[session_id] = {
                "session_id": session_id,
                "username": username or "anonymous",
                "path": path,
                "client_ip": client_ip or "unknown",
                "session_type": session_type,
                "started_at": now_iso,
                "last_active": now_iso
            }
        return dict(_active_sessions[session_id])


def get_active_sessions(timeout_seconds: int = 300) -> List[Dict[str, Any]]:
    """Mengambil daftar sesi aktif yang belum kedaluwarsa."""
    now = datetime.utcnow()
    with _sessions_lock:
        expired = []
        for sid, sess in _active_sessions.items():
            try:
                last_dt = datetime.fromisoformat(sess["last_active"].replace("Z", "+00:00")).replace(tzinfo=None)
                if (now - last_dt).total_seconds() > timeout_seconds:
                    expired.append(sid)
            except Exception:
                pass
        for sid in expired:
            _active_sessions.pop(sid, None)
        return list(_active_sessions.values())


def get_activity_logs(limit: int = 50, username: Optional[str] = None, action: Optional[str] = None, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil daftar riwayat log aktivitas dari database."""
    query = "SELECT * FROM activity_logs"
    params = []
    conditions = []
    if action:
        conditions.append("action LIKE ?")
        params.append(f"%{action}%")
    if username:
        conditions.append("(message LIKE ? OR details LIKE ?)")
        params.extend([f"%{username}%", f"%{username}%"])
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(max(1, min(limit, 500)))

    logs = []
    try:
        with get_db(db_path) as conn:
            rows = conn.execute(query, params).fetchall()
            for r in rows:
                item = dict(r)
                if item.get("details"):
                    try:
                        item["details"] = json.loads(item["details"])
                    except Exception:
                        pass
                logs.append(item)
    except Exception as e:
        logger.error(f"Gagal mengambil log aktivitas: {e}")
    return logs


# ==============================================================================
# 9. MANAGED VMS & 24/7 AUTOMATION DATA ACCESS METHODS (v1.2.7)
# ==============================================================================

import time as _time

_deleted_vms_tombstone: Dict[tuple, float] = {}
_deleted_vms_lock = threading.Lock()
_TOMBSTONE_TTL_SEC = 60.0


def is_vm_tombstoned(vm_id: str, db_path: str = DB_PATH) -> bool:
    """Mengecek apakah VM baru saja dihapus (mencegah zombie resurrection dari request paralel)."""
    key = (os.path.abspath(db_path), str(vm_id))
    now = _time.time()
    with _deleted_vms_lock:
        ts = _deleted_vms_tombstone.get(key)
        if ts is not None:
            if now - ts < _TOMBSTONE_TTL_SEC:
                return True
            _deleted_vms_tombstone.pop(key, None)
    return False


def clear_vm_tombstone(vm_id: str, db_path: str = DB_PATH) -> None:
    """Menghapus tombstone VM jika ingin dibuat ulang secara eksplisit."""
    key = (os.path.abspath(db_path), str(vm_id))
    with _deleted_vms_lock:
        _deleted_vms_tombstone.pop(key, None)


def _row_to_vm_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Helper untuk mengonversi row database managed_vms menjadi dict terstruktur."""
    item = dict(row)
    # Parse JSON fields
    if item.get("auto_on_days"):
        try:
            item["auto_on_days"] = json.loads(item["auto_on_days"])
        except Exception:
            item["auto_on_days"] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    else:
        item["auto_on_days"] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    if item.get("telemetry"):
        try:
            item["telemetry"] = json.loads(item["telemetry"])
        except Exception:
            item["telemetry"] = None

    # Cast boolean fields
    item["keep_alive_enabled"] = bool(item.get("keep_alive_enabled", 0))
    item["auto_on_enabled"] = bool(item.get("auto_on_enabled", 0))
    item["auto_restart_enabled"] = bool(item.get("auto_restart_enabled", 0))

    # v1.2.1+: Properti camelCase untuk kompatibilitas penuh MyServer Desktop Companion
    item["keepAliveEnabled"] = item["keep_alive_enabled"]
    item["autoOnEnabled"] = item["auto_on_enabled"]
    item["autoRestartEnabled"] = item["auto_restart_enabled"]
    item["apiKey"] = item.get("api_key")
    item["machineId"] = item.get("machine_id")
    item["sshHost"] = item.get("ssh_host")
    item["sshUser"] = item.get("ssh_user")
    item["sshPort"] = item.get("ssh_port")
    item["webPort"] = item.get("web_port")
    item["webUrl"] = item.get("web_url")
    item["screenUrl"] = item.get("screen_url")
    item["screenOpenTarget"] = item.get("screen_target")
    item["runtimeMinutes"] = int(item.get("runtime_minutes") or 0)
    item["maxRuntimeMinutes"] = int(item.get("runtime_limit_hours") or 8) * 60
    item["schedule_timezone"] = item.get("schedule_timezone") or ""
    item["scheduleTimezone"] = item["schedule_timezone"]
    item["tz_offset_minutes"] = item.get("tz_offset_minutes")
    item["tzOffsetMinutes"] = item["tz_offset_minutes"]

    delay_unit = item.get("auto_on_delay_unit") or "minutes"

    # Rekonstruksi struktur nested autoRestart & autoOn untuk sinkronisasi sempurna
    item["autoRestart"] = {
        "enabled": item["auto_restart_enabled"],
        "mode": item.get("auto_restart_mode", "interval"),
        "intervalValue": int(item.get("auto_restart_val") or 7),
        "intervalUnit": item.get("auto_restart_unit", "hours"),
        "clockTime": item.get("auto_restart_time", "03:00"),
        "resetCycleMode": item.get("smart_reset_cycle", "sleep_2s"),
    }
    item["autoOn"] = {
        "enabled": item["auto_on_enabled"],
        "mode": item.get("auto_on_mode", "clock"),
        "clockTime": item.get("auto_on_time", "07:00"),
        "delayValue": int(item.get("auto_on_delay_min") or 60),
        "delayUnit": delay_unit,
        "days": list(item.get("auto_on_days") or []),
    }

    # Snapshot nilai asli row agar shallow merge {**existing, **update_data}
    # dapat mendeteksi secara akurat field mana yang baru diubah (snake_case vs camelCase vs nested).
    item["_db_snapshot"] = {
        "keep_alive_enabled": item["keep_alive_enabled"],
        "keepAliveEnabled": item["keepAliveEnabled"],
        "auto_on_enabled": item["auto_on_enabled"],
        "autoOnEnabled": item["autoOnEnabled"],
        "auto_on_mode": item.get("auto_on_mode", "clock"),
        "auto_on_time": item.get("auto_on_time", "07:00"),
        "auto_on_delay_min": int(item.get("auto_on_delay_min") or 60),
        "auto_on_delay_unit": delay_unit,
        "auto_on_days": list(item.get("auto_on_days") or []),
        "auto_restart_enabled": item["auto_restart_enabled"],
        "autoRestartEnabled": item["autoRestartEnabled"],
        "auto_restart_mode": item.get("auto_restart_mode", "interval"),
        "auto_restart_val": int(item.get("auto_restart_val") or 7),
        "auto_restart_unit": item.get("auto_restart_unit", "hours"),
        "auto_restart_time": item.get("auto_restart_time", "03:00"),
        "smart_reset_cycle": item.get("smart_reset_cycle", "sleep_2s"),
        "autoRestart": dict(item["autoRestart"]),
        "autoOn": dict(item["autoOn"]),
        "runtime_minutes": item["runtimeMinutes"],
        "runtimeMinutes": item["runtimeMinutes"],
        "schedule_timezone": item["schedule_timezone"],
        "scheduleTimezone": item["scheduleTimezone"],
        "tz_offset_minutes": item["tz_offset_minutes"],
        "tzOffsetMinutes": item["tzOffsetMinutes"],
    }
    return item


def get_all_managed_vms(db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    """Mengambil seluruh daftar VM yang dikelola oleh server ZimaOS."""
    vms = []
    try:
        with get_db(db_path) as conn:
            rows = conn.execute("SELECT * FROM managed_vms ORDER BY created_at ASC").fetchall()
            for r in rows:
                vid = r["id"]
                if is_vm_tombstoned(vid, db_path=db_path):
                    continue
                vms.append(_row_to_vm_dict(r))
    except Exception as e:
        logger.error(f"Gagal mengambil daftar VM: {e}")
    return vms


def get_managed_vm(vm_id: str, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Mengambil data detail satu VM berdasarkan ID."""
    if is_vm_tombstoned(vm_id, db_path=db_path):
        return None
    try:
        with get_db(db_path) as conn:
            row = conn.execute("SELECT * FROM managed_vms WHERE id = ?", (vm_id,)).fetchone()
            if row:
                return _row_to_vm_dict(row)
    except Exception as e:
        logger.error(f"Gagal mengambil VM {vm_id}: {e}")
    return None


def _resolve_aliased_field(vm: Dict[str, Any], snap: Dict[str, Any], candidates: List[tuple], default: Any) -> Any:
    """
    Memilih nilai terbaru dari daftar kandidat (source_dict, key, snap_key).
    Jika vm memiliki _db_snapshot (hasil merge dengan existing), kandidat yang nilainya
    berubah dibanding snapshot diprioritaskan agar nilai lama di alias lain tidak menimpa update baru.
    """
    if snap:
        for src, key, snap_val in candidates:
            if isinstance(src, dict) and key in src and src[key] is not None:
                if src[key] != snap_val:
                    return src[key]
    for src, key, _ in candidates:
        if isinstance(src, dict) and key in src and src[key] is not None:
            return src[key]
    return default


def upsert_managed_vm(vm: Dict[str, Any], db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Menyimpan atau memperbarui data VM ke dalam database SQLite server."""
    vm_id = vm.get("id")
    if not vm_id:
        raise ValueError("VM ID wajib ada")

    # Cegah zombie resurrection jika ada request save in-flight untuk VM yang baru dihapus
    if not vm.get("_force_recreate") and is_vm_tombstoned(vm_id, db_path=db_path):
        logger.info(f"[database] Mengabaikan upsert untuk VM {vm_id} karena berstatus tombstoned (baru dihapus).")
        return None

    snap = vm.get("_db_snapshot") if isinstance(vm.get("_db_snapshot"), dict) else {}
    snap_ar = snap.get("autoRestart") if isinstance(snap.get("autoRestart"), dict) else {}
    snap_ao = snap.get("autoOn") if isinstance(snap.get("autoOn"), dict) else {}

    # Ekstrak autoRestart nested jika ada
    ar = vm.get("autoRestart") if isinstance(vm.get("autoRestart"), dict) else {}
    ar_enabled = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_enabled", snap.get("auto_restart_enabled")),
            (vm, "autoRestartEnabled", snap.get("autoRestartEnabled")),
            (ar, "enabled", snap_ar.get("enabled")),
        ],
        False,
    ))
    ar_mode = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_mode", snap.get("auto_restart_mode")),
            (ar, "mode", snap_ar.get("mode")),
        ],
        "interval",
    ) or "interval")
    ar_val = int(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_val", snap.get("auto_restart_val")),
            (ar, "intervalValue", snap_ar.get("intervalValue")),
        ],
        7,
    ) or 7)
    ar_unit = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_unit", snap.get("auto_restart_unit")),
            (ar, "intervalUnit", snap_ar.get("intervalUnit")),
        ],
        "hours",
    ) or "hours")
    ar_time = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_restart_time", snap.get("auto_restart_time")),
            (ar, "clockTime", snap_ar.get("clockTime")),
        ],
        "03:00",
    ) or "03:00")
    ar_cycle = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "smart_reset_cycle", snap.get("smart_reset_cycle")),
            (ar, "resetCycleMode", snap_ar.get("resetCycleMode")),
        ],
        "sleep_2s",
    ) or "sleep_2s")

    # Ekstrak autoOn nested jika ada
    ao = vm.get("autoOn") if isinstance(vm.get("autoOn"), dict) else {}
    ao_enabled = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_enabled", snap.get("auto_on_enabled")),
            (vm, "autoOnEnabled", snap.get("autoOnEnabled")),
            (ao, "enabled", snap_ao.get("enabled")),
        ],
        False,
    ))
    ao_mode = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_mode", snap.get("auto_on_mode")),
            (ao, "mode", snap_ao.get("mode")),
        ],
        "clock",
    ) or "clock")
    ao_time = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_time", snap.get("auto_on_time")),
            (ao, "clockTime", snap_ao.get("clockTime")),
        ],
        "07:00",
    ) or "07:00")
    ao_delay = int(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_delay_min", snap.get("auto_on_delay_min")),
            (ao, "delayValue", snap_ao.get("delayValue")),
        ],
        60,
    ) or 60)
    ao_delay_unit = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_delay_unit", snap.get("auto_on_delay_unit")),
            (ao, "delayUnit", snap_ao.get("delayUnit")),
        ],
        "minutes",
    ) or "minutes")

    # Konversi hari jika array integer [0, 1, 2, ...] atau string
    DAY_NUM_TO_STR = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}
    raw_days = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "auto_on_days", snap.get("auto_on_days")),
            (ao, "days", snap_ao.get("days")),
        ],
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    )
    converted_days = []
    if isinstance(raw_days, list):
        for d in raw_days:
            if isinstance(d, int) and d in DAY_NUM_TO_STR:
                converted_days.append(DAY_NUM_TO_STR[d])
            elif str(d).strip().isdigit() and int(str(d).strip()) in DAY_NUM_TO_STR:
                converted_days.append(DAY_NUM_TO_STR[int(str(d).strip())])
            elif str(d).strip():
                converted_days.append(str(d).strip())
    if not converted_days:
        converted_days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    auto_on_days = json.dumps(converted_days)

    keep_alive = bool(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "keep_alive_enabled", snap.get("keep_alive_enabled")),
            (vm, "keepAliveEnabled", snap.get("keepAliveEnabled")),
        ],
        False,
    ))
    api_key_val = vm.get("api_key") or vm.get("apiKey")
    machine_id_val = vm.get("machine_id") or vm.get("machineId")
    ssh_host_val = vm.get("ssh_host") or vm.get("sshHost") or ""
    ssh_port_val = int(vm.get("ssh_port") or vm.get("sshPort") or 22)
    ssh_user_val = vm.get("ssh_user") or vm.get("sshUser") or ""
    screen_url_val = vm.get("screen_url") or vm.get("screenUrl")
    screen_target_val = vm.get("screen_target") or vm.get("screenOpenTarget") or "ask"
    raw_runtime = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "runtime_minutes", snap.get("runtime_minutes")),
            (vm, "runtimeMinutes", snap.get("runtimeMinutes")),
        ],
        0,
    )
    runtime_mins_val = int(raw_runtime or 0)
    runtime_limit_val = int(vm.get("runtime_limit_hours") or (int(vm.get("maxRuntimeMinutes") or 480) // 60) or 8)
    tz_name_val = str(_resolve_aliased_field(
        vm, snap,
        [
            (vm, "schedule_timezone", snap.get("schedule_timezone")),
            (vm, "scheduleTimezone", snap.get("scheduleTimezone")),
            (vm, "timezone", snap.get("timezone")),
        ],
        "",
    ) or "").strip()
    raw_tz_offset = _resolve_aliased_field(
        vm, snap,
        [
            (vm, "tz_offset_minutes", snap.get("tz_offset_minutes")),
            (vm, "tzOffsetMinutes", snap.get("tzOffsetMinutes")),
        ],
        None,
    )
    tz_offset_val = int(raw_tz_offset) if raw_tz_offset is not None and str(raw_tz_offset).strip() != "" else None
    reset_sleep_timer = (
        ao_enabled
        and ao_mode == "after_off"
        and (
            not bool(snap.get("auto_on_enabled"))
            or snap.get("auto_on_mode") != "after_off"
            or int(snap.get("auto_on_delay_min") or 60) != ao_delay
            or str(snap.get("auto_on_delay_unit") or "minutes") != ao_delay_unit
        )
    )

    telemetry = json.dumps(vm.get("telemetry")) if vm.get("telemetry") else None

    query = """
    INSERT INTO managed_vms (
        id, name, provider, status, ssh_host, ssh_port, ssh_user, token_expiry,
        web_port, web_url, screen_url, screen_target, api_key, machine_id,
        keep_alive_enabled, auto_on_enabled, auto_on_mode, auto_on_time, auto_on_delay_min, auto_on_delay_unit, auto_on_days,
        auto_restart_enabled, auto_restart_mode, auto_restart_val, auto_restart_unit, auto_restart_time,
        smart_reset_cycle, runtime_limit_hours, runtime_minutes, schedule_timezone, tz_offset_minutes, telemetry,
        last_wake_time, last_sleep_time, updated_at
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        CASE WHEN ? = 'running' THEN CURRENT_TIMESTAMP ELSE NULL END,
        CASE WHEN ? != 'running' THEN CURRENT_TIMESTAMP ELSE NULL END,
        CURRENT_TIMESTAMP
    )
    ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        provider = excluded.provider,
        status = excluded.status,
        ssh_host = CASE WHEN excluded.ssh_host != '' THEN excluded.ssh_host ELSE managed_vms.ssh_host END,
        ssh_port = excluded.ssh_port,
        ssh_user = CASE WHEN excluded.ssh_user != '' THEN excluded.ssh_user ELSE managed_vms.ssh_user END,
        token_expiry = excluded.token_expiry,
        web_port = COALESCE(excluded.web_port, managed_vms.web_port),
        web_url = COALESCE(excluded.web_url, managed_vms.web_url),
        screen_url = COALESCE(excluded.screen_url, managed_vms.screen_url),
        screen_target = excluded.screen_target,
        api_key = COALESCE(excluded.api_key, managed_vms.api_key),
        machine_id = COALESCE(excluded.machine_id, managed_vms.machine_id),
        keep_alive_enabled = excluded.keep_alive_enabled,
        auto_on_enabled = excluded.auto_on_enabled,
        auto_on_mode = excluded.auto_on_mode,
        auto_on_time = excluded.auto_on_time,
        auto_on_delay_min = excluded.auto_on_delay_min,
        auto_on_delay_unit = excluded.auto_on_delay_unit,
        auto_on_days = excluded.auto_on_days,
        auto_restart_enabled = excluded.auto_restart_enabled,
        auto_restart_mode = excluded.auto_restart_mode,
        auto_restart_val = excluded.auto_restart_val,
        auto_restart_unit = excluded.auto_restart_unit,
        auto_restart_time = excluded.auto_restart_time,
        smart_reset_cycle = excluded.smart_reset_cycle,
        runtime_limit_hours = excluded.runtime_limit_hours,
        runtime_minutes = CASE
            WHEN excluded.status != 'running' THEN 0
            WHEN excluded.runtime_minutes > 0 THEN excluded.runtime_minutes
            ELSE managed_vms.runtime_minutes
        END,
        schedule_timezone = CASE WHEN excluded.schedule_timezone != '' THEN excluded.schedule_timezone ELSE managed_vms.schedule_timezone END,
        tz_offset_minutes = COALESCE(excluded.tz_offset_minutes, managed_vms.tz_offset_minutes),
        last_wake_time = CASE
            WHEN excluded.status = 'running' AND (managed_vms.status != 'running' OR managed_vms.last_wake_time IS NULL) THEN CURRENT_TIMESTAMP
            ELSE managed_vms.last_wake_time
        END,
        last_sleep_time = CASE
            WHEN excluded.status != 'running' AND (managed_vms.status = 'running' OR managed_vms.last_sleep_time IS NULL OR ?) THEN CURRENT_TIMESTAMP
            ELSE managed_vms.last_sleep_time
        END,
        telemetry = COALESCE(excluded.telemetry, managed_vms.telemetry),
        updated_at = CURRENT_TIMESTAMP
    """

    status_val = str(vm.get("status", "sleeping") or "sleeping").lower()
    if status_val not in ("running", "sleeping", "stopped"):
        status_val = "sleeping"

    params = (
        vm_id,
        vm.get("name", "Unnamed VM"),
        vm.get("provider", "instabox"),
        status_val,
        ssh_host_val,
        ssh_port_val,
        ssh_user_val,
        vm.get("token_expiry", ""),
        vm.get("web_port") if vm.get("web_port") is not None else vm.get("webPort"),
        vm.get("web_url") if vm.get("web_url") is not None else vm.get("webUrl"),
        screen_url_val,
        screen_target_val,
        api_key_val,
        machine_id_val,
        1 if keep_alive else 0,
        1 if ao_enabled else 0,
        ao_mode,
        ao_time,
        ao_delay,
        ao_delay_unit,
        auto_on_days,
        1 if ar_enabled else 0,
        ar_mode,
        ar_val,
        ar_unit,
        ar_time,
        ar_cycle,
        runtime_limit_val,
        runtime_mins_val,
        tz_name_val,
        tz_offset_val,
        telemetry,
        status_val,
        status_val,
        1 if reset_sleep_timer else 0,
    )

    with get_db(db_path) as conn:
        conn.execute(query, params)

    return get_managed_vm(vm_id, db_path=db_path) or vm


def delete_managed_vm(vm_id: str, db_path: str = DB_PATH) -> bool:
    """Menghapus data VM dari database server dan mencatat tombstone anti-zombie."""
    key = (os.path.abspath(db_path), str(vm_id))
    with _deleted_vms_lock:
        _deleted_vms_tombstone[key] = _time.time()
    try:
        with get_db(db_path) as conn:
            cur = conn.execute("DELETE FROM managed_vms WHERE id = ?", (vm_id,))
            return cur.rowcount > 0
    except Exception as e:
        logger.error(f"Gagal menghapus VM {vm_id}: {e}")
        return False


def update_vm_runtime_and_status(
    vm_id: str,
    status: Optional[str] = None,
    runtime_minutes: Optional[int] = None,
    telemetry: Optional[dict] = None,
    machine_id: Optional[str] = None,
    ssh_host: Optional[str] = None,
    ssh_port: Optional[int] = None,
    ssh_user: Optional[str] = None,
    runtime_limit_hours: Optional[int] = None,
    mark_reset: bool = False,
    db_path: str = DB_PATH
) -> bool:
    """Memperbarui status runtime, waktu aktif, metrik telemetri, dan koneksi VM."""
    if is_vm_tombstoned(vm_id, db_path=db_path):
        return False

    sets = ["updated_at = CURRENT_TIMESTAMP"]
    params = []

    if status is not None:
        if status == "running":
            sets.append("last_wake_time = CASE WHEN status != 'running' OR last_wake_time IS NULL THEN CURRENT_TIMESTAMP ELSE last_wake_time END")
        elif status in ("sleeping", "stopped"):
            sets.append("last_sleep_time = CASE WHEN status NOT IN ('sleeping', 'stopped') OR last_sleep_time IS NULL THEN CURRENT_TIMESTAMP ELSE last_sleep_time END")
        sets.append("status = ?")
        params.append(status)

    if mark_reset:
        sets.append("last_reset_time = CURRENT_TIMESTAMP")

    if runtime_minutes is not None:
        sets.append("runtime_minutes = ?")
        params.append(runtime_minutes)
        sets.append("last_runtime_check = CURRENT_TIMESTAMP")

    if telemetry is not None:
        sets.append("telemetry = ?")
        params.append(json.dumps(telemetry))

    if machine_id:
        sets.append("machine_id = ?")
        params.append(machine_id)

    if ssh_host:
        sets.append("ssh_host = ?")
        params.append(ssh_host)

    if ssh_port:
        sets.append("ssh_port = ?")
        params.append(int(ssh_port))

    if ssh_user:
        sets.append("ssh_user = ?")
        params.append(ssh_user)

    if runtime_limit_hours:
        sets.append("runtime_limit_hours = ?")
        params.append(int(runtime_limit_hours))

    params.append(vm_id)
    query = f"UPDATE managed_vms SET {', '.join(sets)} WHERE id = ?"

    try:
        with get_db(db_path) as conn:
            cur = conn.execute(query, params)
            return cur.rowcount > 0
    except Exception as e:
        logger.error(f"Gagal memperbarui status VM {vm_id}: {e}")
        return False



