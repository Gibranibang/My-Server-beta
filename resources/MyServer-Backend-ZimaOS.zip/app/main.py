"""
MyServer Native Backend - FastAPI Application Entrypoint
100% Native & Proprietary Backup Daemon Engine for Project Algitha
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import SERVER_VERSION, DB_PATH
from app.database import init_db
from app.routers import system, auth, devices, tasks, backup, storage, vms
from app.services.vm_scheduler import start_vm_scheduler, stop_vm_scheduler

# Konfigurasi Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s"
)
logger = logging.getLogger("myserver.main")


import threading
import time

def _bg_temp_garbage_collector():
    while True:
        try:
            time.sleep(1800)  # Tiap 30 menit
            from app.routers.storage import cleanup_temp_storage
            cleanup_temp_storage(max_age_hours=1.0)
        except Exception:
            pass

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Siklus hidup aplikasi: inisialisasi database SQLite, scheduler VM 24/7, dan pembersih sampah otomatis."""
    logger.info("Memulai MyServer Native Backend Engine...")
    init_db(DB_PATH)
    logger.info("Database SQLite backup_meta.db siap digunakan.")
    gc_t = threading.Thread(target=_bg_temp_garbage_collector, daemon=True)
    gc_t.start()
    start_vm_scheduler()
    yield
    stop_vm_scheduler()
    logger.info("Menghentikan MyServer Native Backend Engine.")


app = FastAPI(
    title="MyServer Native Backup API",
    description=(
        "API Service Backend Mandiri untuk Sinkronisasi & Pencadangan Berkas Project Algitha. "
        "Mendukung streaming chunked upload, deduplikasi cerdas berbasis hash SHA-256, "
        "koneksi multi-device (Windows Desktop & Mobile Flutter), serta restorasi data."
    ),
    version=SERVER_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Middleware CORS untuk akses aman dari klien lokal, LAN, dan domain Algitha
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.\d+\.\d+\.\d+|.*\.algitha\.my\.id)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registrasi Router Endpoints
app.include_router(system.router)
app.include_router(auth.router)
app.include_router(devices.router)
app.include_router(tasks.router)
app.include_router(backup.router)
app.include_router(storage.router)
app.include_router(vms.router)


if __name__ == "__main__":
    import uvicorn
    from app.config import HOST, PORT
    uvicorn.run("app.main:app", host=HOST, port=PORT, reload=True)
