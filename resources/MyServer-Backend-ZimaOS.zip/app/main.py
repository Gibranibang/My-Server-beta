"""
MyServer Native Backend - FastAPI Application Entrypoint
100% Native & Proprietary Backup Daemon Engine for Project Algitha
"""

import asyncio
import json
import logging
import os
import threading
import time
import uuid
from contextlib import asynccontextmanager
from typing import Tuple
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse, StreamingResponse

from app.auth import (
    get_current_user,
    subscribe_realtime_events,
    unsubscribe_realtime_events,
    verify_active_jwt_user,
)
from app.config import SERVER_VERSION, DB_PATH
from app.database import init_db, cleanup_database_retention, backup_sqlite_database
from app.routers import system, auth, devices, tasks, backup, storage, vms, smb, share
from app.services.vm_scheduler import start_vm_scheduler, stop_vm_scheduler
from app.services.smb_manager import (
    initialize_smb_on_startup,
    stop_backend_smbd,
    ensure_smb_watchdog_and_mount_sync,
    shutdown_smb_on_exit,
    resolve_static_bundle_asset,
)

# Konfigurasi Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s"
)
logger = logging.getLogger("myserver.main")

_STOP_MAINTENANCE = threading.Event()
_METRICS_LOCK = threading.Lock()
_HTTP_METRICS = {
    "requests_total": 0,
    "errors_5xx_total": 0,
    "started_at": time.time(),
}


def _bg_maintenance_worker():
    """Worker pemeliharaan latar belakang: watchdog SMB/mount (15s), retensi GC (30m), hot backup SQLite (24h)."""
    last_gc = time.monotonic()
    last_backup = time.monotonic()
    while not _STOP_MAINTENANCE.is_set():
        try:
            ensure_smb_watchdog_and_mount_sync(db_path=DB_PATH)
        except Exception as exc:
            logger.debug(f"SMB watchdog step skipped: {exc}")

        now_mono = time.monotonic()
        if (now_mono - last_gc) >= 1800.0:
            last_gc = now_mono
            try:
                from app.routers.storage import cleanup_temp_storage
                cleanup_temp_storage(max_age_hours=1.0)
            except Exception:
                pass
            try:
                cleanup_database_retention(db_path=DB_PATH)
            except Exception as exc:
                logger.warning(f"Database retention cleanup gagal: {exc}")

        if (now_mono - last_backup) >= 86400.0:
            last_backup = now_mono
            try:
                backup_sqlite_database(db_path=DB_PATH)
            except Exception as exc:
                logger.warning(f"Online SQLite backup gagal: {exc}")

        _STOP_MAINTENANCE.wait(timeout=15.0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Siklus hidup aplikasi: inisialisasi database SQLite, scheduler VM 24/7, SMB engine, dan pemeliharaan."""
    logger.info("Memulai MyServer Native Backend Engine...")
    _STOP_MAINTENANCE.clear()
    init_db(DB_PATH)
    logger.info("Database SQLite backup_meta.db siap digunakan.")
    try:
        initialize_smb_on_startup()
    except Exception as exc:
        logger.warning(f"Inisialisasi layanan SMB saat startup dilewati: {exc}")
    gc_t = threading.Thread(target=_bg_maintenance_worker, daemon=True, name="myserver-maintenance")
    gc_t.start()
    start_vm_scheduler()
    yield
    _STOP_MAINTENANCE.set()
    stop_vm_scheduler()
    try:
        stop_backend_smbd()
        shutdown_smb_on_exit(DB_PATH)
    except Exception as exc:
        logger.warning(f"Gagal menghentikan smbd backend saat shutdown: {exc}")
    logger.info("Menghentikan MyServer Native Backend Engine.")


app = FastAPI(
    title="MyServer Native Backup API",
    description=(
        "API Service Backend Mandiri untuk Sinkronisasi & Pencadangan Berkas Project Algitha. "
        "Mendukung streaming chunked upload, deduplikasi cerdas berbasis hash SHA-256, "
        "koneksi multi-device (Windows Desktop & Mobile Flutter), serta restorasi data."
    ),
    version=SERVER_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Middleware CORS untuk akses aman dari klien lokal, LAN, maupun origin kustom via env MYSERVER_CORS_ORIGINS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.getenv("MYSERVER_CORS_ORIGINS", "").split(",") if o.strip()],
    allow_origin_regex=os.getenv(
        "MYSERVER_CORS_ORIGIN_REGEX",
        r"(https?://(localhost|127\.0\.0\.1|\[::1\]|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.\d+\.\d+\.\d+|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+|[^/:\s]+\.(local|lan|localhost))(:\d+)?|tauri://localhost)",
    ),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def request_id_and_metrics_middleware(request: Request, call_next):
    req_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
    start_ts = time.monotonic()
    response = await call_next(request)
    elapsed_ms = round((time.monotonic() - start_ts) * 1000.0, 2)
    response.headers["X-Request-ID"] = req_id
    with _METRICS_LOCK:
        _HTTP_METRICS["requests_total"] += 1
        if getattr(response, "status_code", 200) >= 500:
            _HTTP_METRICS["errors_5xx_total"] += 1
    if os.getenv("MYSERVER_JSON_ACCESS_LOG", "0") == "1":
        logger.info(json.dumps({
            "request_id": req_id,
            "method": request.method,
            "path": request.url.path,
            "status": getattr(response, "status_code", 200),
            "duration_ms": elapsed_ms,
        }))
    return response


@app.get("/metrics", include_in_schema=False)
def get_prometheus_metrics():
    """Endpoint observability Prometheus / plain-text sederhana."""
    with _METRICS_LOCK:
        total_req = _HTTP_METRICS["requests_total"]
        err_5xx = _HTTP_METRICS["errors_5xx_total"]
        uptime_s = max(0, int(time.time() - _HTTP_METRICS["started_at"]))
    lines = [
        f'myserver_info{{version="{SERVER_VERSION}"}} 1',
        f"myserver_uptime_seconds {uptime_s}",
        f"myserver_http_requests_total {total_req}",
        f"myserver_http_errors_5xx_total {err_5xx}",
    ]
    return PlainTextResponse("\n".join(lines) + "\n", media_type="text/plain; version=0.0.4")


@app.get("/api/v1/events/stream", include_in_schema=False)
async def stream_realtime_events(
    request: Request,
    current_user: dict = Depends(get_current_user),
):
    """Kanal real-time Server-Sent Events (SSE) untuk push status SMB, VM, dan job storage."""
    verify_active_jwt_user(current_user, allow_stream_scope=False)
    sub_id = uuid.uuid4().hex[:12]
    q: asyncio.Queue = asyncio.Queue(maxsize=64)
    loop = asyncio.get_running_loop()
    subscribe_realtime_events(sub_id, q, loop=loop)

    async def _event_gen():
        try:
            yield f"event: connected\ndata: {json.dumps({'version': SERVER_VERSION, 'ts': int(time.time())})}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    evt = await asyncio.wait_for(q.get(), timeout=15.0)
                    evt_name = str(evt.get("type") or "update")
                    yield f"event: {evt_name}\ndata: {json.dumps(evt)}\n\n"
                except asyncio.TimeoutError:
                    yield f": keepalive {int(time.time())}\n\n"
        finally:
            unsubscribe_realtime_events(sub_id)

    return StreamingResponse(
        _event_gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )

# Registrasi Router Endpoints
app.include_router(system.router)
app.include_router(auth.router)
app.include_router(devices.router)
app.include_router(tasks.router)
app.include_router(backup.router)
app.include_router(storage.router)
app.include_router(vms.router)
app.include_router(smb.router)
app.include_router(share.router)


def serve_static_bundle(subdir: str, asset_path: str) -> FileResponse:
    """Menyajikan aset statis self-hosted dengan MIME JavaScript eksplisit dan header keamanan."""
    try:
        candidate, media_type = resolve_static_bundle_asset(subdir, asset_path)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return FileResponse(
        candidate,
        media_type=media_type,
        headers={
            "Content-Type": media_type,
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "public, max-age=86400",
        },
    )


@app.get("/static/pdfjs/{asset_path:path}", include_in_schema=False)
def get_pdfjs_static_asset(asset_path: str):
    """Menyajikan aset self-hosted Mozilla PDF.js."""
    return serve_static_bundle("pdfjs", asset_path)


@app.get("/static/vendor/{asset_path:path}", include_in_schema=False)
def get_vendor_static_asset(asset_path: str):
    """Menyajikan aset self-hosted vendor JS (uqr.mjs)."""
    return serve_static_bundle("vendor", asset_path)


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def root_web_ui():
    """Menyajikan portal Web UI Backend (Login, Panel Admin, & Storage Explorer)."""
    return storage.get_storage_explorer_page()


if __name__ == "__main__":
    import uvicorn
    from app.config import HOST, PORT
    uvicorn.run("app.main:app", host=HOST, port=PORT, reload=True)
