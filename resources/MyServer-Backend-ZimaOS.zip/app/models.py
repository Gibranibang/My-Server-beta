"""
Pydantic Request & Response Models for MyServer Native Backend API Contracts
"""

from pydantic import BaseModel, Field, ConfigDict, model_validator
from typing import List, Optional, Dict, Any
from datetime import datetime


# ==============================================================================
# SYSTEM & HEALTH MODELS
# ==============================================================================

class HealthResponse(BaseModel):
    status: str = Field(..., example="ok")
    app: str = Field(..., example="MyServer Native Backend")
    version: str = Field(..., example="1.0.0")
    timestamp: str
    boot_id: str = Field("", description="ID proses unik untuk verifikasi restart nyata pasca-OTA")


class StorageStats(BaseModel):
    total_bytes: int
    used_bytes: int
    free_bytes: int
    percent_used: float


class SystemInfoResponse(BaseModel):
    version: str
    hostname: str
    storage: StorageStats
    total_devices: int
    total_tasks: int
    total_backed_up_files: int
    total_backed_up_bytes: int


class SystemUpdateResponse(BaseModel):
    status: str = Field(..., example="success")
    message: str
    old_version: str
    new_version: str
    backup_dir: Optional[str] = None
    files_extracted: int = 0
    files_removed: int = 0
    rebuild_required: bool = False
    backups_pruned: int = 0
    boot_id: Optional[str] = None


class PowerControlRequest(BaseModel):
    action: str = Field(..., example="restart", description="Aksi daya: restart atau shutdown")


class PowerControlResponse(BaseModel):
    status: str = Field(..., example="success")
    action: str
    message: str


# ==============================================================================
# AUTHENTICATION MODELS
# ==============================================================================

class AuthVerifyRequest(BaseModel):
    username: str
    password: Optional[str] = None
    zimaos_token: Optional[str] = None


class AuthResponse(BaseModel):
    success: bool
    access_token: str
    token_type: str = "bearer"
    user_id: int
    username: str
    expires_in_hours: int
    role: Optional[str] = "staff"
    allowed_disks: Optional[List[str]] = []


class UserCreateRequest(BaseModel):
    username: str = Field(..., description="Nama pengguna baru")
    password: str = Field(..., description="Kata sandi akun")
    role: Optional[str] = Field("staff", description="Peran: admin atau staff")
    allowed_disks: Optional[List[str]] = Field(default=[], description="Daftar nama disk/folder yang diizinkan untuk di-mount")


class UserUpdateRequest(BaseModel):
    password: Optional[str] = Field(None, description="Kata sandi baru (kosongkan jika tidak diubah)")
    role: Optional[str] = Field(None, description="Peran baru: admin atau staff")
    allowed_disks: Optional[List[str]] = Field(None, description="Daftar nama disk baru yang diizinkan")


class UserItemResponse(BaseModel):
    id: int
    username: str
    role: str
    allowed_disks: List[str]
    created_at: Optional[str] = None


class UserListResponse(BaseModel):
    users: List[UserItemResponse]
    total: int


# ==============================================================================
# DEVICE MODELS
# ==============================================================================

class DeviceRegisterRequest(BaseModel):
    device_id: str = Field(..., description="ID unik permanen perangkat (UUID/Hardware hash)")
    device_name: str = Field(..., description="Nama perangkat yang mudah dibaca")
    device_type: str = Field(..., description="windows, android, ios, linux, macos")
    app_version: str = Field(..., description="Versi MyServer Desktop atau Mobile")
    username: Optional[str] = Field("admin", description="Nama pengguna pemilik perangkat")


class DeviceResponse(BaseModel):
    device_id: str
    device_name: str
    device_type: str
    app_version: str
    username: Optional[str] = "admin"
    last_seen: Optional[str] = None
    created_at: Optional[str] = None


class DeviceHeartbeatRequest(BaseModel):
    device_id: str


# ==============================================================================
# BACKUP TASK MODELS
# ==============================================================================

class TaskCreateRequest(BaseModel):
    task_id: str = Field(..., description="ID unik tugas backup")
    device_id: str
    task_name: str
    target_folder: str = Field(..., description="Subdirektori tujuan di server")
    sync_mode: str = Field("one_way", description="one_way (client->server) atau mirror")
    username: Optional[str] = Field("admin", description="Pemilik akun tugas backup untuk isolasi data")


class TaskResponse(BaseModel):
    task_id: str
    device_id: str
    task_name: str
    target_folder: str
    sync_mode: str
    username: Optional[str] = "admin"
    status: str
    total_files: int
    total_bytes: int
    last_run: Optional[str] = None
    created_at: Optional[str] = None


# ==============================================================================
# BACKUP DEDUPLICATION & CHUNKED UPLOAD MODELS
# ==============================================================================

class FileHashItem(BaseModel):
    relative_path: str = Field(..., description="Jalur berkas relatif terhadap root folder backup")
    file_hash: str = Field(..., description="SHA-256 berkas utuh")
    file_size: int = Field(..., description="Ukuran berkas dalam bytes")
    modified_time: int = Field(..., description="Timestamp modifikasi lokal (epoch seconds)")


class CheckHashesRequest(BaseModel):
    task_id: str
    files: List[FileHashItem]


class CheckHashesResponse(BaseModel):
    needed_files: List[FileHashItem] = Field(..., description="Daftar berkas yang belum ada atau berubah di server")
    existing_files: List[str] = Field(..., description="Daftar relative_path yang sudah identik di server (hemat upload)")
    total_checked: int
    skipped_count: int


class InitUploadRequest(BaseModel):
    task_id: str
    relative_path: str
    file_size: int
    file_hash: str
    total_chunks: int


class InitUploadResponse(BaseModel):
    upload_id: str
    total_chunks: int
    uploaded_chunks: List[int]
    missing_chunks: List[int]


class UploadChunkResponse(BaseModel):
    status: str = "chunk_received"
    upload_id: str
    chunk_index: int
    bytes_received: int


class CommitFileRequest(BaseModel):
    upload_id: str
    modified_time: int


class CommitFileResponse(BaseModel):
    status: str = "file_committed"
    file_id: int
    task_id: str
    relative_path: str
    file_size: int
    file_hash: str
    storage_path: str
    version: int


class FileItemResponse(BaseModel):
    file_id: int
    task_id: str
    relative_path: str
    file_size: int
    file_hash: str
    modified_time: int
    storage_path: str
    status: str
    version: int
    created_at: str
    updated_at: str


class FileListResponse(BaseModel):
    task_id: str
    total_files: int
    total_bytes: int
    files: List[FileItemResponse]


# ==============================================================================
# STORAGE BROWSE & STREAMING MODELS (TIER 1)
# ==============================================================================

class StorageFileEntry(BaseModel):
    name: str
    relative_path: str
    is_dir: bool
    size: int
    mtime: float
    extension: str
    mime_type: str


class StorageBrowseFilesResponse(BaseModel):
    current_path: str
    parent_path: str
    items: List[StorageFileEntry]
    total_count: int
    folders_count: int
    files_count: int


# ==============================================================================
# STORAGE DISK & MOUNT MODELS (ROLE-BASED ACL)
# ==============================================================================

class StorageDiskItem(BaseModel):
    name: str = Field(..., description="Nama disk, partisi, atau direktori mount storage")
    relative_path: str = Field(..., description="Jalur relatif terhadap root storage")
    label: Optional[str] = Field(None, description="Label disk atau sistem berkas jika ada")
    mount_point: Optional[str] = Field(None, description="Titik mount sistem berkas")
    total_bytes: int = Field(0, description="Total kapasitas penyimpanan dalam bytes")
    used_bytes: int = Field(0, description="Kapasitas penyimpanan yang telah terpakai dalam bytes")
    free_bytes: int = Field(0, description="Kapasitas penyimpanan yang masih tersedia dalam bytes")
    is_accessible: bool = Field(True, description="Status izin akses akun pengguna terhadap disk ini")


DiskEntry = StorageDiskItem


class StorageDisksResponse(BaseModel):
    disks: List[StorageDiskItem] = Field(..., description="Daftar partisi dan mount disk storage")
    total_disks: int = Field(..., description="Total jumlah disk yang ditemukan")
    username: Optional[str] = Field("admin", description="Nama pengguna pemanggil")
    is_admin: bool = Field(True, description="Status hak akses administrator")


# ==============================================================================
# CLOUD STORAGE & GOOGLE DRIVE MULTI-ACCOUNT MODELS
# ==============================================================================

class CloudAccountItemResponse(BaseModel):
    id: int
    user_id: int
    provider: str
    email: str
    display_name: Optional[str] = None
    quota_total: int = 0
    quota_used: int = 0
    status: str = "connected"
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class CloudAccountListResponse(BaseModel):
    accounts: List[CloudAccountItemResponse]
    total_count: int
    username: str


class CloudAccountConnectRequest(BaseModel):
    provider: str = Field("gdrive", description="Provider cloud (gdrive, onedrive, dropbox)")
    email: str = Field(..., description="Alamat email akun Google / Cloud")
    display_name: Optional[str] = Field(None, description="Nama tampilan akun")
    access_token: Optional[str] = Field(None, description="OAuth Access Token")
    refresh_token: Optional[str] = Field(None, description="OAuth Refresh Token")
    token_expiry: Optional[str] = Field(None, description="Waktu kedaluwarsa token")
    quota_total: Optional[int] = Field(16106127360, description="Total kuota cloud (default 15GB)")
    quota_used: Optional[int] = Field(0, description="Kuota terpakai dalam bytes")


# ==============================================================================
# VIRTUAL MACHINE MODELS (v1.2.7 - Server Managed VMs & 24/7 Automation)
# ==============================================================================

DAY_NUM_TO_STR = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}


def normalize_days_list(raw_days: Any) -> List[str]:
    """Konversi daftar hari aktif dari array angka [0..6] atau string ke format ['Sun', 'Mon', ...]."""
    if not isinstance(raw_days, list):
        return ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    res = []
    for d in raw_days:
        if isinstance(d, int) and d in DAY_NUM_TO_STR:
            res.append(DAY_NUM_TO_STR[d])
        elif str(d).strip().isdigit() and int(str(d).strip()) in DAY_NUM_TO_STR:
            res.append(DAY_NUM_TO_STR[int(str(d).strip())])
        elif str(d).strip():
            res.append(str(d).strip())
    return res if res else ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


class VmCreateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str = Field(..., description="Unique VM identifier (e.g. vm_instabox_xxx)")
    name: str = Field(..., description="Nama Virtual Machine")
    provider: str = Field("instabox", description="Provider: instabox atau manual")
    status: str = Field("sleeping", description="Status awal: running, sleeping, stopped")
    ssh_host: Optional[str] = Field("", alias="sshHost", description="Host atau IP gateway SSH")
    ssh_port: int = Field(22, alias="sshPort", description="Port SSH")
    ssh_user: Optional[str] = Field("", alias="sshUser", description="Username SSH")
    token_expiry: Optional[str] = Field("", alias="tokenExpiry", description="Masa berlaku token")
    web_port: Optional[int] = Field(None, alias="webPort", description="Port layanan web opsional")
    web_url: Optional[str] = Field(None, alias="webUrl", description="URL layanan web")
    screen_url: Optional[str] = Field(None, alias="screenUrl", description="URL konsol web / layar virtual")
    screen_target: Optional[str] = Field("ask", alias="screenOpenTarget", description="Target pembukaan layar virtual: ask, window, browser")
    api_key: Optional[str] = Field(None, alias="apiKey", description="API Key InstaBox (ibk_...)")
    machine_id: Optional[str] = Field(None, alias="machineId", description="Machine ID InstaBox untuk auto-connect")
    keep_alive_enabled: bool = Field(False, alias="keepAliveEnabled", description="Mode Always-On 24/7 anti-sleep")
    auto_on_enabled: bool = Field(False, alias="autoOnEnabled", description="Aktifkan jadwal nyala otomatis")
    auto_on_mode: str = Field("clock", description="Mode nyala otomatis: clock atau after_off")
    auto_on_time: str = Field("07:00", description="Jam nyala format HH:MM")
    auto_on_delay_min: int = Field(60, description="Jeda nyala setelah mati")
    auto_on_delay_unit: str = Field("minutes", description="Satuan jeda: seconds, minutes, hours")
    auto_on_days: List[str] = Field(default=["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], description="Hari aktif")
    auto_restart_enabled: bool = Field(False, alias="autoRestartEnabled", description="Aktifkan jadwal restart otomatis")
    auto_restart_mode: str = Field("interval", description="Mode restart: interval atau clock")
    auto_restart_val: int = Field(7, description="Nilai interval restart")
    auto_restart_unit: str = Field("hours", description="Satuan interval: hours, minutes, seconds")
    auto_restart_time: str = Field("03:00", description="Waktu restart jam tertentu format HH:MM")
    smart_reset_cycle: str = Field("sleep_2s", description="Siklus reset runtime 8 jam: sleep_2s atau full_reboot")
    runtime_limit_hours: int = Field(8, description="Batas runtime continuous VM InstaBox")
    runtime_minutes: int = Field(0, alias="runtimeMinutes", description="Waktu runtime berjalan (menit)")
    schedule_timezone: Optional[str] = Field("", alias="scheduleTimezone", description="Timezone IANA untuk jadwal jam VM")
    tz_offset_minutes: Optional[int] = Field(None, alias="tzOffsetMinutes", description="Offset UTC dalam menit (fallback jika IANA tidak tersedia)")
    telemetry: Optional[Dict[str, Any]] = Field(default=None, description="Data metrik CPU, RAM, Disk, Jaringan")

    @model_validator(mode="before")
    @classmethod
    def unpack_nested_schedules(cls, data: Any) -> Any:
        return _unpack_vm_schedule_fields(data)


def _unpack_vm_schedule_fields(data: Any) -> Any:
    """Menormalisasi payload snake_case/camelCase dan struktur jadwal nested untuk create/update VM."""
    if not isinstance(data, dict):
        return data

    if "keepAliveEnabled" in data and data["keepAliveEnabled"] is not None:
        data["keep_alive_enabled"] = bool(data["keepAliveEnabled"])
    elif "keep_alive_enabled" in data and data["keep_alive_enabled"] is not None:
        data["keepAliveEnabled"] = bool(data["keep_alive_enabled"])

    if "timezone" in data and not data.get("schedule_timezone") and not data.get("scheduleTimezone"):
        data["schedule_timezone"] = str(data["timezone"] or "").strip()

    ar = data.get("autoRestart")
    if isinstance(ar, dict):
        if "enabled" in ar and ar["enabled"] is not None:
            data["auto_restart_enabled"] = bool(ar.get("enabled"))
            data["autoRestartEnabled"] = bool(ar.get("enabled"))
        if "mode" in ar:
            data["auto_restart_mode"] = str(ar.get("mode"))
        if "intervalValue" in ar:
            data["auto_restart_val"] = int(ar.get("intervalValue") or 7)
        if "intervalUnit" in ar:
            data["auto_restart_unit"] = str(ar.get("intervalUnit") or "hours")
        if "clockTime" in ar:
            data["auto_restart_time"] = str(ar.get("clockTime") or "03:00")
        if "resetCycleMode" in ar:
            data["smart_reset_cycle"] = str(ar.get("resetCycleMode") or "sleep_2s")
    elif "autoRestartEnabled" in data and data["autoRestartEnabled"] is not None:
        data["auto_restart_enabled"] = bool(data["autoRestartEnabled"])

    ao = data.get("autoOn")
    if isinstance(ao, dict):
        if "enabled" in ao and ao["enabled"] is not None:
            data["auto_on_enabled"] = bool(ao.get("enabled"))
            data["autoOnEnabled"] = bool(ao.get("enabled"))
        if "mode" in ao:
            data["auto_on_mode"] = str(ao.get("mode"))
        if "clockTime" in ao:
            data["auto_on_time"] = str(ao.get("clockTime") or "07:00")
        if "delayValue" in ao:
            data["auto_on_delay_min"] = int(ao.get("delayValue") or 60)
        if "delayUnit" in ao:
            data["auto_on_delay_unit"] = str(ao.get("delayUnit") or "minutes")
        if "days" in ao:
            data["auto_on_days"] = normalize_days_list(ao.get("days"))
    elif "autoOnEnabled" in data and data["autoOnEnabled"] is not None:
        data["auto_on_enabled"] = bool(data["autoOnEnabled"])

    if "auto_on_days" in data:
        data["auto_on_days"] = normalize_days_list(data.get("auto_on_days"))

    return data


class VmUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    name: Optional[str] = None
    status: Optional[str] = None
    ssh_host: Optional[str] = Field(None, alias="sshHost")
    ssh_port: Optional[int] = Field(None, alias="sshPort")
    ssh_user: Optional[str] = Field(None, alias="sshUser")
    token_expiry: Optional[str] = Field(None, alias="tokenExpiry")
    web_port: Optional[int] = Field(None, alias="webPort")
    web_url: Optional[str] = Field(None, alias="webUrl")
    screen_url: Optional[str] = Field(None, alias="screenUrl")
    screen_target: Optional[str] = Field(None, alias="screenOpenTarget")
    api_key: Optional[str] = Field(None, alias="apiKey")
    machine_id: Optional[str] = Field(None, alias="machineId")
    keep_alive_enabled: Optional[bool] = Field(None, alias="keepAliveEnabled")
    auto_on_enabled: Optional[bool] = Field(None, alias="autoOnEnabled")
    auto_on_mode: Optional[str] = None
    auto_on_time: Optional[str] = None
    auto_on_delay_min: Optional[int] = None
    auto_on_delay_unit: Optional[str] = None
    auto_on_days: Optional[List[str]] = None
    auto_restart_enabled: Optional[bool] = Field(None, alias="autoRestartEnabled")
    auto_restart_mode: Optional[str] = None
    auto_restart_val: Optional[int] = None
    auto_restart_unit: Optional[str] = None
    auto_restart_time: Optional[str] = None
    smart_reset_cycle: Optional[str] = None
    runtime_limit_hours: Optional[int] = None
    runtime_minutes: Optional[int] = Field(None, alias="runtimeMinutes")
    schedule_timezone: Optional[str] = Field(None, alias="scheduleTimezone")
    tz_offset_minutes: Optional[int] = Field(None, alias="tzOffsetMinutes")
    telemetry: Optional[Dict[str, Any]] = None

    @model_validator(mode="before")
    @classmethod
    def unpack_nested_schedules_update(cls, data: Any) -> Any:
        return _unpack_vm_schedule_fields(data)


class VmItemResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    id: str
    name: str
    provider: str
    status: str
    ssh_host: str = Field(..., alias="sshHost")
    ssh_port: int = Field(22, alias="sshPort")
    ssh_user: str = Field("", alias="sshUser")
    token_expiry: Optional[str] = Field("", alias="tokenExpiry")
    web_port: Optional[int] = Field(None, alias="webPort")
    web_url: Optional[str] = Field(None, alias="webUrl")
    screen_url: Optional[str] = Field(None, alias="screenUrl")
    screen_target: Optional[str] = Field("ask", alias="screenOpenTarget")
    api_key: Optional[str] = Field(None, alias="apiKey")
    machine_id: Optional[str] = Field(None, alias="machineId")
    keep_alive_enabled: bool = Field(False, alias="keepAliveEnabled")
    auto_on_enabled: bool = Field(False, alias="autoOnEnabled")
    auto_on_mode: str = "clock"
    auto_on_time: str = "07:00"
    auto_on_delay_min: int = 60
    auto_on_delay_unit: str = "minutes"
    auto_on_days: List[str] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    auto_restart_enabled: bool = Field(False, alias="autoRestartEnabled")
    auto_restart_mode: str = "interval"
    auto_restart_val: int = 7
    auto_restart_unit: str = "hours"
    auto_restart_time: str = "03:00"
    smart_reset_cycle: str = "sleep_2s"
    runtime_limit_hours: int = 8
    runtime_minutes: int = Field(0, alias="runtimeMinutes")
    schedule_timezone: Optional[str] = Field("", alias="scheduleTimezone")
    tz_offset_minutes: Optional[int] = Field(None, alias="tzOffsetMinutes")
    telemetry: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    autoRestart: Optional[Dict[str, Any]] = None
    autoOn: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def populate_schedules_and_camel(self):
        if getattr(self, "__pydantic_extra__", None):
            self.__pydantic_extra__.pop("_db_snapshot", None)
        if not self.autoRestart:
            self.autoRestart = {
                "enabled": self.auto_restart_enabled,
                "mode": self.auto_restart_mode,
                "intervalValue": self.auto_restart_val,
                "intervalUnit": self.auto_restart_unit,
                "clockTime": self.auto_restart_time,
                "resetCycleMode": self.smart_reset_cycle,
            }
        if not self.autoOn:
            self.autoOn = {
                "enabled": self.auto_on_enabled,
                "mode": self.auto_on_mode,
                "clockTime": self.auto_on_time,
                "delayValue": self.auto_on_delay_min,
                "delayUnit": self.auto_on_delay_unit or "minutes",
                "days": self.auto_on_days,
            }
        return self


class VmListResponse(BaseModel):
    vms: List[VmItemResponse]
    server_time: str


class VmActionResponse(BaseModel):
    status: str = Field(..., example="ok")
    message: str
    vm_id: str
    action: str
    details: Optional[Dict[str, Any]] = None





