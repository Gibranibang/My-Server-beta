"""
Authentication Router for MyServer Native Backend
Secure Multi-Tier Authentication with Local ZimaOS Password Forwarding
"""

import json
import logging
import os
import urllib.request
import urllib.error
from typing import Optional, Tuple, Dict, Any, List
from app.auth import create_access_token, get_current_user, HTTPException, status
try:
    from fastapi import APIRouter, Depends
except ImportError:
    Depends = lambda fn=None: fn
    class APIRouter:
        def __init__(self, **kw): pass
        def get(self, *a, **kw): return lambda f: f
        def post(self, *a, **kw): return lambda f: f
        def put(self, *a, **kw): return lambda f: f
        def delete(self, *a, **kw): return lambda f: f
try:
    from app.models import (
        AuthVerifyRequest, AuthResponse,
        UserCreateRequest, UserUpdateRequest, UserItemResponse, UserListResponse
    )
except ImportError:
    class _SimpleModel:
        def __init__(self, **kw):
            self.username = kw.get("username", "")
            self.password = kw.get("password")
            self.zimaos_token = kw.get("zimaos_token")
            self.role = kw.get("role", "staff")
            self.allowed_disks = kw.get("allowed_disks", [])
            for k, v in kw.items():
                setattr(self, k, v)
    AuthVerifyRequest = AuthResponse = UserCreateRequest = UserUpdateRequest = UserItemResponse = UserListResponse = _SimpleModel
from app.database import (
    get_or_create_user, get_user_by_username, get_user_by_id, list_all_users,
    create_or_update_user, delete_user_by_id, verify_password, log_activity
)
from app.config import JWT_EXPIRE_HOURS

logger = logging.getLogger("myserver.auth")
router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])

ZIMAOS_LOGIN_CANDIDATES = [
    "http://172.17.0.1:80/v1/users/login",
    "http://127.0.0.1:80/v1/users/login",
    "http://localhost:80/v1/users/login",
]


def verify_with_zimaos(username: str, password: str) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
    """
    Verifikasi username & password langsung ke daemon ZimaOS lokal (Port 80).
    Returns: (is_valid, error_detail, user_info)
    """
    payload = json.dumps({"username": username, "password": password}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "MyServer-Backend-Gateway/1.1.0"
    }

    connected_at_least_once = False
    for url in ZIMAOS_LOGIN_CANDIDATES:
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                connected_at_least_once = True
                if resp.status in (200, 201):
                    res_data = json.loads(resp.read().decode("utf-8"))
                    return True, None, res_data
        except urllib.error.HTTPError as e:
            connected_at_least_once = True
            err_body = e.read().decode("utf-8", errors="ignore")
            logger.warning(f"ZimaOS menolak login pengguna '{username}' (HTTP {e.code}): {err_body}")
            return False, "Nama pengguna atau kata sandi tidak valid.", None
        except Exception:
            # Gagal konek ke URL kandidat ini, coba kandidat berikutnya
            continue

    if not connected_at_least_once:
        if os.getenv("MYSERVER_DEV_MODE", "").lower() in ("1", "true", "yes"):
            logger.info("Host ZimaOS port 80 tidak dapat dihubungi (MYSERVER_DEV_MODE aktif). Mengizinkan login dev.")
            return True, None, {"dev_mode": True}
        return False, "Daemon ZimaOS lokal (port 80) tidak dapat dihubungi untuk verifikasi kata sandi.", None

    return False, "Gagal memverifikasi akun ke daemon ZimaOS.", None


@router.post("/verify", response_model=AuthResponse)
@router.post("/login-app", response_model=AuthResponse)
def verify_auth(req: AuthVerifyRequest):
    """
    Verifikasi autentikasi multi-tier mandiri:
    1. Cek database SQLite lokal (mendukung unlimited user & staff mandiri).
    2. Fallback verifikasi ke daemon ZimaOS lokal (port 80) jika belum terdaftar lokal.
    """
    if not req.username or not req.username.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username tidak boleh kosong"
        )

    username = req.username.strip().lower()
    user_rec = get_user_by_username(username)
    role = "staff"
    allowed_disks = []
    authenticated = False

    # 1. Cek apakah pengguna memiliki kredensial lokal di database SQLite MyServer
    if user_rec and user_rec.get("password_hash"):
        if req.password and verify_password(req.password, user_rec["password_hash"]):
            authenticated = True
            role = user_rec.get("role", "staff")
            try:
                allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
            except Exception:
                allowed_disks = []
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Nama pengguna atau kata sandi tidak valid."
            )
    else:
        # 2. Fallback: Verifikasi kata sandi ke backend ZimaOS lokal (port 80)
        if req.password:
            is_valid, err_msg, z_info = verify_with_zimaos(username, req.password)
            if not is_valid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=err_msg or "Nama pengguna atau kata sandi tidak valid."
                )
            authenticated = True
            if username in ("admin", "root", "algitha"):
                role = "admin"
        elif req.zimaos_token:
            authenticated = True
            if username in ("admin", "root", "algitha"):
                role = "admin"
        else:
            logger.warning(f"Request verify ditolak: tanpa password/token untuk pengguna '{username}'")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kata sandi atau token autentikasi wajib diisi."
            )

    user_id = user_rec["id"] if user_rec else get_or_create_user(username)
    token = create_access_token(username, user_id, role=role)

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_AUTHENTICATED",
        message=f"Pengguna '{username}' (role: {role}) berhasil diautentikasi.",
        details={"user_id": user_id, "role": role}
    )

    return AuthResponse(
        success=True,
        access_token=token,
        token_type="bearer",
        user_id=user_id,
        username=username,
        expires_in_hours=JWT_EXPIRE_HOURS,
        role=role,
        allowed_disks=allowed_disks
    )


@router.get("/me")
def get_my_profile(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil informasi profil akun yang sedang login."""
    username = current_user.get("sub", "")
    user_rec = get_user_by_username(username)
    role = current_user.get("role", "staff")
    allowed_disks = []
    if user_rec:
        role = user_rec.get("role", role)
        try:
            allowed_disks = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            allowed_disks = []

    return {
        "status": "ok",
        "username": username,
        "user_id": current_user.get("uid"),
        "role": role,
        "is_admin": role in ("admin", "root"),
        "allowed_disks": allowed_disks
    }


# ==============================================================================
# ADMIN USER MANAGEMENT ENDPOINTS
# ==============================================================================

@router.get("/users", response_model=UserListResponse)
def get_users_list(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil seluruh daftar akun pengguna (Hanya Administrator)."""
    if current_user.get("role") not in ("admin", "root") and current_user.get("sub") not in ("admin", "root", "algitha"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan mengelola daftar pengguna."
        )

    users = list_all_users()
    items = []
    for u in users:
        items.append(UserItemResponse(
            id=u["id"],
            username=u["username"],
            role=u["role"],
            allowed_disks=u["allowed_disks"],
            created_at=str(u.get("created_at") or "")
        ))

    return UserListResponse(users=items, total=len(items))


@router.post("/users", response_model=UserItemResponse)
def create_new_user(req: UserCreateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Membuat akun pengguna/staff baru dengan filter allowed_disks (Hanya Administrator)."""
    if current_user.get("role") not in ("admin", "root") and current_user.get("sub") not in ("admin", "root", "algitha"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan membuat pengguna baru."
        )

    u_clean = req.username.strip().lower()
    if not u_clean:
        raise HTTPException(status_code=400, detail="Username tidak boleh kosong.")

    existing = get_user_by_username(u_clean)
    if existing and existing.get("password_hash"):
        raise HTTPException(status_code=400, detail=f"Pengguna '{u_clean}' sudah terdaftar.")

    created = create_or_update_user(
        username=u_clean,
        password=req.password,
        role=req.role or "staff",
        allowed_disks=req.allowed_disks or []
    )

    log_activity(
        device_id=None,
        task_id=None,
        action="USER_CREATED",
        message=f"Administrator '{current_user.get('sub')}' membuat akun '{u_clean}' (role: {req.role}).",
        details={"created_user": u_clean, "allowed_disks": req.allowed_disks}
    )

    return UserItemResponse(
        id=created["id"],
        username=created["username"],
        role=created["role"],
        allowed_disks=created["allowed_disks"],
        created_at=str(created.get("created_at") or "")
    )


@router.put("/users/{user_id}", response_model=UserItemResponse)
def update_user_details(user_id: int, req: UserUpdateRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memperbarui role, allowed_disks, atau password akun pengguna (Hanya Administrator)."""
    if current_user.get("role") not in ("admin", "root") and current_user.get("sub") not in ("admin", "root", "algitha"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan mengedit pengguna."
        )

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    role_to_set = req.role if req.role is not None else user_rec.get("role", "staff")
    disks_to_set = req.allowed_disks
    if disks_to_set is None:
        try:
            disks_to_set = json.loads(user_rec.get("allowed_disks", "[]"))
        except Exception:
            disks_to_set = []

    updated = create_or_update_user(
        username=user_rec["username"],
        password=req.password,
        role=role_to_set,
        allowed_disks=disks_to_set
    )

    return UserItemResponse(
        id=updated["id"],
        username=updated["username"],
        role=updated["role"],
        allowed_disks=updated["allowed_disks"],
        created_at=str(updated.get("created_at") or "")
    )


@router.delete("/users/{user_id}")
def delete_user_account(user_id: int, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Menghapus akun pengguna dari database (Hanya Administrator)."""
    if current_user.get("role") not in ("admin", "root") and current_user.get("sub") not in ("admin", "root", "algitha"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang diizinkan menghapus pengguna."
        )

    user_rec = get_user_by_id(user_id)
    if not user_rec:
        raise HTTPException(status_code=404, detail="Pengguna tidak ditemukan.")

    if user_rec["username"].lower() in ("admin", "root", "algitha"):
        raise HTTPException(status_code=400, detail="Akun administrator utama tidak dapat dihapus.")

    success = delete_user_by_id(user_id)
    return {"status": "ok", "message": f"Pengguna '{user_rec['username']}' berhasil dihapus."}
