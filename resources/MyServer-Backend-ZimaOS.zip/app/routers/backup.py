"""
Backup Engine Router for MyServer Native Backend
Core Endpoints: Deduplication, Chunked Streaming Upload, File Merge & Commit
"""

import os
import shutil
import hashlib
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, status, UploadFile, File, Form, Query, Depends
from fastapi.responses import FileResponse
from app.auth import get_current_user

from app.models import (
    CheckHashesRequest, CheckHashesResponse,
    InitUploadRequest, InitUploadResponse,
    UploadChunkResponse,
    CommitFileRequest, CommitFileResponse,
    FileListResponse, FileItemResponse
)
from app.database import (
    check_hashes_bulk, create_upload_session, save_chunk_record,
    commit_file_record, get_db, log_activity, DB_PATH
)
from app.config import STORAGE_DIR, TEMP_DIR

router = APIRouter(prefix="/api/v1/backup", tags=["Backup Engine"])


@router.post("/check-hashes", response_model=CheckHashesResponse)
def check_hashes(req: CheckHashesRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Deduplikasi Berkas Cerdas (Smart Deduplication):
    Memeriksa batch hash SHA-256 berkas lokal klien terhadap database server.
    Berkas yang sudah ada dengan hash identik langsung diskip (hemat bandwidth & waktu).
    """
    entries = [f.model_dump() for f in req.files]
    result = check_hashes_bulk(req.task_id, entries)
    return CheckHashesResponse(**result)


@router.post("/init-upload", response_model=InitUploadResponse)
def init_upload(req: InitUploadRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Inisialisasi Sesi Unggah Potongan:
    Mempersiapkan server untuk menerima file berukuran besar dalam potongan (chunks).
    Mendukung resume upload jika sebelumnya sempat terputus.
    """
    # Gunakan hash berkas + task_id sebagai upload_id unik stabil
    upload_id = hashlib.sha256(f"{req.task_id}:{req.relative_path}:{req.file_hash}".encode("utf-8")).hexdigest()[:32]
    
    session_data = create_upload_session(
        upload_id=upload_id,
        task_id=req.task_id,
        relative_path=req.relative_path,
        file_size=req.file_size,
        file_hash=req.file_hash,
        total_chunks=req.total_chunks
    )
    
    # Buat direktori temp untuk chunk upload_id ini
    session_temp_dir = os.path.join(TEMP_DIR, upload_id)
    os.makedirs(session_temp_dir, exist_ok=True)
    
    return InitUploadResponse(**session_data)


@router.post("/upload-chunk", response_model=UploadChunkResponse)
async def upload_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    chunk_hash: str = Form(...),
    file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Unggah Potongan Berkas (Chunk):
    Menerima potongan biner (misal 4MB) dan memverifikasi integritas hash SHA-256 chunk.
    """
    session_temp_dir = os.path.join(TEMP_DIR, upload_id)
    os.makedirs(session_temp_dir, exist_ok=True)
    
    chunk_file_path = os.path.join(session_temp_dir, f"chunk_{chunk_index:06d}.part")
    
    # Tulis chunk ke disk dan hitung hash verifikasi
    sha = hashlib.sha256()
    bytes_count = 0
    
    with open(chunk_file_path, "wb") as f_out:
        while True:
            chunk_data = await file.read(65536)  # 64KB stream buffer
            if not chunk_data:
                break
            sha.update(chunk_data)
            f_out.write(chunk_data)
            bytes_count += len(chunk_data)
            
    calc_hash = sha.hexdigest()
    if calc_hash.lower() != chunk_hash.lower():
        # Hapus chunk corrupt
        if os.path.exists(chunk_file_path):
            os.remove(chunk_file_path)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Hash chunk tidak cocok! Dikirim: {chunk_hash}, Dihitung: {calc_hash}"
        )
        
    # Simpan record chunk ke database
    save_chunk_record(upload_id, chunk_index, calc_hash, bytes_count)
    
    return UploadChunkResponse(
        status="chunk_received",
        upload_id=upload_id,
        chunk_index=chunk_index,
        bytes_received=bytes_count
    )


@router.post("/commit-file", response_model=CommitFileResponse)
def commit_file(req: CommitFileRequest, current_user: Dict[str, Any] = Depends(get_current_user)):
    """
    Penggabungan & Finalisasi Berkas (Merge & Commit):
    Menggabungkan seluruh potongan chunk yang tersimpan menjadi berkas utuh di direktori HDD server.
    """
    with get_db(DB_PATH) as conn:
        session = conn.execute("SELECT * FROM upload_sessions WHERE upload_id = ?", (req.upload_id,)).fetchone()
        if not session:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sesi unggah tidak ditemukan")
            
        task = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (session["task_id"],)).fetchone()
        if not task:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas backup terkait tidak ditemukan")

    total_chunks = session["total_chunks"]
    session_temp_dir = os.path.join(TEMP_DIR, req.upload_id)
    
    # Verifikasi seluruh chunk ada di disk
    for i in range(total_chunks):
        c_path = os.path.join(session_temp_dir, f"chunk_{i:06d}.part")
        if not os.path.exists(c_path):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Potongan chunk ke-{i} belum lengkap atau hilang!"
            )
            
    # Tentukan jalur berkas final pada media penyimpanan
    # Contoh struktur: /DATA/Backups/{target_folder}/{relative_path}
    target_rel = os.path.normpath(session["relative_path"]).lstrip("/\\")
    final_storage_rel = os.path.join(task["target_folder"], target_rel)
    final_full_path = os.path.join(STORAGE_DIR, final_storage_rel)
    
    os.makedirs(os.path.dirname(final_full_path), exist_ok=True)
    
    # Gabungkan chunks secara berurutan dan verifikasi hash total
    sha_total = hashlib.sha256()
    with open(final_full_path, "wb") as f_out:
        for i in range(total_chunks):
            c_path = os.path.join(session_temp_dir, f"chunk_{i:06d}.part")
            with open(c_path, "rb") as f_in:
                while True:
                    b = f_in.read(65536)
                    if not b:
                        break
                    sha_total.update(b)
                    f_out.write(b)
                    
    final_hash = sha_total.hexdigest()
    if final_hash.lower() != session["file_hash"].lower():
        if os.path.exists(final_full_path):
            os.remove(final_full_path)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Hash berkas gabungan tidak cocok dengan ekspektasi sesi!"
        )
        
    # Bersihkan folder chunks sementara
    shutil.rmtree(session_temp_dir, ignore_errors=True)
    
    # Simpan status komit ke database
    committed = commit_file_record(req.upload_id, final_storage_rel, req.modified_time)
    if not committed:
        raise HTTPException(status_code=500, detail="Gagal mencatat berkas ke katalog database")
        
    log_activity(
        device_id=task["device_id"],
        task_id=task["task_id"],
        action="FILE_COMMITTED",
        message=f"Berkas '{session['relative_path']}' ({session['file_size']} bytes) berhasil dicadangkan.",
        details={"storage_path": final_storage_rel}
    )
    
    return CommitFileResponse(
        status="file_committed",
        file_id=committed["file_id"],
        task_id=committed["task_id"],
        relative_path=committed["relative_path"],
        file_size=committed["file_size"],
        file_hash=committed["file_hash"],
        storage_path=committed["storage_path"],
        version=committed["version"]
    )


@router.get("/files", response_model=FileListResponse)
def list_files(task_id: str = Query(...), current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengambil daftar berkas yang telah berhasil dicadangkan untuk satu tugas."""
    with get_db(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT * FROM files WHERE task_id = ? AND status = 'active' ORDER BY relative_path ASC",
            (task_id,)
        ).fetchall()
        
        file_items = [FileItemResponse(**dict(r)) for r in rows]
        total_bytes = sum(f.file_size for f in file_items)
        
        return FileListResponse(
            task_id=task_id,
            total_files=len(file_items),
            total_bytes=total_bytes,
            files=file_items
        )


@router.get("/download-file")
def download_file(file_id: int = Query(...), current_user: Dict[str, Any] = Depends(get_current_user)):
    """Mengunduh berkas cadangan untuk proses restore."""
    with get_db(DB_PATH) as conn:
        row = conn.execute("SELECT * FROM files WHERE file_id = ?", (file_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
            
    full_path = os.path.join(STORAGE_DIR, row["storage_path"])
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="Berkas fisik tidak ditemukan di media penyimpanan")
        
    filename = os.path.basename(row["relative_path"])
    return FileResponse(path=full_path, filename=filename, media_type="application/octet-stream")
