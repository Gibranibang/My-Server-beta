"""
Device Management Router for MyServer Native Backend
"""

from typing import List, Optional
from fastapi import APIRouter, HTTPException, status, Query
from app.models import DeviceRegisterRequest, DeviceResponse, DeviceHeartbeatRequest
from app.database import upsert_device, update_device_heartbeat, get_or_create_user, get_db, log_activity, DB_PATH

router = APIRouter(prefix="/api/v1/devices", tags=["Devices"])


@router.post("/register", response_model=DeviceResponse)
def register_device(req: DeviceRegisterRequest):
    """Mendaftarkan atau memperbarui metadata perangkat klien."""
    username = req.username or "admin"
    user_id = get_or_create_user(username)
    device_data = upsert_device(
        device_id=req.device_id,
        user_id=user_id,
        device_name=req.device_name,
        device_type=req.device_type,
        app_version=req.app_version
    )
    
    log_activity(
        device_id=req.device_id,
        task_id=None,
        action="DEVICE_REGISTERED",
        message=f"Perangkat '{req.device_name}' ({req.device_type}) terdaftar untuk user '{username}'.",
        details={"version": req.app_version, "username": username}
    )
    
    return DeviceResponse(**device_data)


@router.post("/heartbeat")
def heartbeat_device(req: DeviceHeartbeatRequest):
    """Memperbarui tanda waktu aktif terakhir perangkat."""
    success = update_device_heartbeat(req.device_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perangkat tidak ditemukan"
        )
    return {"status": "ok", "device_id": req.device_id}


@router.get("", response_model=List[DeviceResponse])
def list_devices(username: Optional[str] = Query(None)):
    """Mengambil daftar seluruh perangkat yang terhubung, dengan dukungan multi-user filter."""
    with get_db(DB_PATH) as conn:
        if username and username.lower() not in ("admin", "root", "algitha"):
            user_id = get_or_create_user(username)
            rows = conn.execute("""
                SELECT d.*, u.username 
                FROM devices d 
                LEFT JOIN users u ON d.user_id = u.id 
                WHERE d.user_id = ? 
                ORDER BY d.last_seen DESC
            """, (user_id,)).fetchall()
        else:
            rows = conn.execute("""
                SELECT d.*, u.username 
                FROM devices d 
                LEFT JOIN users u ON d.user_id = u.id 
                ORDER BY d.last_seen DESC
            """).fetchall()
        return [DeviceResponse(**dict(r)) for r in rows]


@router.delete("/{device_id}")
def delete_device(device_id: str):
    """Menghapus pendaftaran perangkat dan sesi terkait dari sistem."""
    with get_db(DB_PATH) as conn:
        cursor = conn.execute("DELETE FROM devices WHERE device_id = ?", (device_id,))
        if cursor.rowcount == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perangkat tidak ditemukan")

    log_activity(
        device_id=device_id,
        task_id=None,
        action="DEVICE_DELETED",
        message=f"Perangkat '{device_id}' telah dihapus dari sistem."
    )
    return {"status": "ok", "message": f"Perangkat {device_id} berhasil dihapus"}

