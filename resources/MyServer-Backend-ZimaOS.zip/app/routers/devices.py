"""
Device Management Router for MyServer Native Backend
"""

from typing import List, Optional, Dict, Any
try:
    from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
except ImportError:
    Depends = lambda fn=None: fn
    Query = lambda default=..., **kw: default
    Request = object

    class APIRouter:
        def __init__(self, **kw):
            pass

        def _reg(self, *args, **kwargs):
            return lambda fn: fn

        get = post = put = delete = patch = _reg

    class HTTPException(Exception):
        def __init__(self, status_code: int = 500, detail: Any = None):
            self.status_code = status_code
            self.detail = detail
            super().__init__(detail)

    class _Status:
        HTTP_200_OK = 200
        HTTP_201_CREATED = 201
        HTTP_400_BAD_REQUEST = 400
        HTTP_401_UNAUTHORIZED = 401
        HTTP_403_FORBIDDEN = 403
        HTTP_404_NOT_FOUND = 404

    status = _Status()

from app.auth import get_control_plane_user
from app.models import DeviceRegisterRequest, DeviceResponse, DeviceHeartbeatRequest
from app.config import is_admin_username
from app.database import upsert_device, update_device_heartbeat, get_or_create_user, get_db, log_activity, DB_PATH

router = APIRouter(
    prefix="/api/v1/devices",
    tags=["Devices"],
    dependencies=[Depends(get_control_plane_user)],
)


def _lookup_lan_mac_from_arp(ip: str, arp_path: str = "/proc/net/arp") -> str:
    """Mencari alamat MAC perangkat LAN dari tabel ARP kernel berdasarkan IP klien."""
    clean_ip = str(ip or "").strip()
    if clean_ip.startswith("::ffff:"):
        clean_ip = clean_ip[7:]
    if not clean_ip:
        return ""
    try:
        with open(arp_path, "r", encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()
        for line in lines[1:]:
            parts = line.split()
            if len(parts) >= 4 and parts[0] == clean_ip:
                mac = parts[3].strip().upper()
                if mac and mac != "00:00:00:00:00:00":
                    return mac
    except Exception:
        pass
    return ""


def _resolve_client_ip(request: Optional[Any], fallback: Optional[str] = "") -> str:
    explicit = str(fallback or "").strip()
    if explicit:
        return explicit[7:] if explicit.startswith("::ffff:") else explicit
    if request is not None:
        try:
            headers = getattr(request, "headers", None)
            if headers is not None:
                for hdr_name in ("cf-connecting-ip", "CF-Connecting-IP", "x-real-ip", "X-Real-IP", "x-forwarded-for", "X-Forwarded-For"):
                    raw_hdr = headers.get(hdr_name) or ""
                    if raw_hdr:
                        first_ip = raw_hdr.split(",")[0].strip()
                        if first_ip:
                            return first_ip[7:] if first_ip.startswith("::ffff:") else first_ip
            client = getattr(request, "client", None)
            if client and getattr(client, "host", None):
                host = str(client.host).strip()
                return host[7:] if host.startswith("::ffff:") else host
        except Exception:
            pass
    return ""


@router.post("/register", response_model=DeviceResponse)
def register_device(
    req: DeviceRegisterRequest,
    request: Request = None,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mendaftarkan atau memperbarui metadata perangkat klien dengan isolasi kepemilikan."""
    caller_name = str(caller["username"]).strip().lower()
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])

    fields_set = getattr(req, "model_fields_set", None) or getattr(req, "__fields_set__", None)
    raw_req_user = getattr(req, "username", None)
    req_user_clean = str(raw_req_user).strip().lower() if raw_req_user is not None else ""
    username_supplied = ("username" in fields_set) if fields_set is not None else (raw_req_user is not None)

    if not is_admin:
        if username_supplied and req_user_clean and req_user_clean != caller_name:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan mendaftarkan perangkat untuk pengguna lain.",
            )
        with get_db(DB_PATH) as conn:
            existing_dev = conn.execute(
                "SELECT user_id FROM devices WHERE device_id = ?",
                (req.device_id,),
            ).fetchone()
        if existing_dev is not None and int(existing_dev["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="ID perangkat sudah terdaftar milik pengguna lain.",
            )
        eff_username = caller_name
        user_id = caller_uid
    else:
        eff_username = req_user_clean or caller_name
        user_id = caller_uid if eff_username == caller_name else get_or_create_user(eff_username)

    client_ip = _resolve_client_ip(request, getattr(req, "ip_address", ""))
    mac_addr = str(getattr(req, "mac_address", "") or "").strip() or _lookup_lan_mac_from_arp(client_ip)
    device_data = upsert_device(
        device_id=req.device_id,
        user_id=user_id,
        device_name=req.device_name,
        device_type=req.device_type,
        app_version=req.app_version,
        ip_address=client_ip,
        mac_address=mac_addr,
    )

    log_activity(
        device_id=req.device_id,
        task_id=None,
        action="DEVICE_REGISTERED",
        message=f"Perangkat '{req.device_name}' ({req.device_type}) terdaftar untuk user '{eff_username}'.",
        details={"version": req.app_version, "username": eff_username},
    )

    return DeviceResponse(**device_data)


@router.post("/heartbeat")
def heartbeat_device(
    req: DeviceHeartbeatRequest,
    request: Request = None,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Memperbarui tanda waktu aktif terakhir perangkat (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (req.device_id,),
        ).fetchone()
    if not dev_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perangkat tidak ditemukan",
        )
    if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan memperbarui perangkat milik pengguna lain.",
        )
    client_ip = _resolve_client_ip(request, getattr(req, "ip_address", ""))
    mac_addr = str(getattr(req, "mac_address", "") or "").strip() or _lookup_lan_mac_from_arp(client_ip)
    update_device_heartbeat(req.device_id, ip_address=client_ip, mac_address=mac_addr)
    return {"status": "ok", "device_id": req.device_id}


@router.get("", response_model=List[DeviceResponse])
def list_devices(
    username: Optional[str] = Query(None),
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mengambil daftar perangkat terhubung dengan isolasi multi-user."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        if not is_admin:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE d.user_id = ?
                ORDER BY d.last_seen DESC
                """,
                (caller_uid,),
            ).fetchall()
        elif username and username.strip():
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                WHERE LOWER(u.username) = LOWER(?)
                ORDER BY d.last_seen DESC
                """,
                (username.strip(),),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT d.*, u.username
                FROM devices d
                LEFT JOIN users u ON d.user_id = u.id
                ORDER BY d.last_seen DESC
                """
            ).fetchall()
        return [DeviceResponse(**dict(r)) for r in rows]


@router.delete("/{device_id}")
def delete_device(
    device_id: str,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Menghapus pendaftaran perangkat dan sesi terkait dari sistem (hanya pemilik atau admin)."""
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        dev_row = conn.execute(
            "SELECT user_id FROM devices WHERE device_id = ?",
            (device_id,),
        ).fetchone()
        if not dev_row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perangkat tidak ditemukan")
        if not is_admin and int(dev_row["user_id"] or -1) != caller_uid:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan menghapus perangkat milik pengguna lain.",
            )
        conn.execute("DELETE FROM devices WHERE device_id = ?", (device_id,))

    log_activity(
        device_id=device_id,
        task_id=None,
        action="DEVICE_DELETED",
        message=f"Perangkat '{device_id}' telah dihapus dari sistem.",
    )
    return {"status": "ok", "message": f"Perangkat {device_id} berhasil dihapus"}

