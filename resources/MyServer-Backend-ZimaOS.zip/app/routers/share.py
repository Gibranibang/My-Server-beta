"""
Public Share Link Router & Standalone Dark Viewer for MyServer Native Backend (SHL-01, SHL-02).
Serves unauthenticated public share links (/s/{token} and /api/v1/share/{token}/{auth,meta,stream,download})
with PBKDF2 password verification, HMAC-SHA256 unlock cookies, strict os.path.commonpath subtree
confinement, HTTP 206 Partial Content Range streaming, and spooled streaming .zip folder downloads.
"""

import asyncio
import hashlib
import hmac
import html
import http.cookies
import inspect
import io
import json
import logging
import mimetypes
import os
import queue
import secrets
import shutil
import tempfile
import threading
import time
import urllib.parse
import uuid
import zipfile
from typing import Any, Dict, Iterator, List, Optional, Tuple

logger = logging.getLogger("myserver.share")

try:
    from fastapi import APIRouter, File, Form, HTTPException, Query, Request, Response, UploadFile
    from fastapi.responses import HTMLResponse, StreamingResponse
except ImportError:
    class APIRouter:
        def __init__(self, *a, **k):
            pass

        def __getattr__(self, name):
            return lambda *a, **k: (lambda f: f)

    from app.auth import HTTPException

    Query = File = Form = lambda default=None, **kw: default
    Request = Response = UploadFile = object

    class _FallbackResponse:
        def __init__(self, content=None, status_code=200, headers=None, media_type=None, path=None):
            self.content = content
            self.body = content.encode("utf-8") if isinstance(content, str) else content
            self.status_code = status_code
            self.headers = headers or {}
            self.media_type = media_type
            self.path = path

    StreamingResponse = HTMLResponse = _FallbackResponse

import app.config as _app_config
from app.auth import enforce_rate_limit, reset_rate_limit_bucket
from app.config import DB_PATH, STORAGE_DIR, is_admin_username
from app.database import (
    get_public_share,
    get_user_by_username,
    increment_share_download_count,
    is_public_share_owned_by_session,
    list_public_share_owned_paths,
    log_activity,
    normalize_user_role,
    record_public_share_upload,
    remove_public_share_upload_records,
    verify_password,
)
from app.models import PublicShareAuthRequest, ShareDeleteRequest, ShareMkdirRequest
from app.routers.storage import (
    _parse_allowed_disks_value,
    is_forbidden_for_user,
    resolve_effective_path_permission,
    stream_file_range,
    validate_public_share_role_and_limit,
)
from app.services.smb_manager import (
    _UPLOAD_RENAME_LOCK,
    build_content_disposition,
    resolve_non_colliding_target,
    resolve_safe_storage_target,
)

router = APIRouter(tags=["Public Share Links"])

SHARE_SESSION_TTL_SECONDS = 86400
UPLOADER_COOKIE_NAME = "myserver_uploader_sid"
UPLOADER_COOKIE_TTL_SECONDS = 30 * 86400


def _storage_dir() -> str:
    return str(getattr(_app_config, "STORAGE_DIR", STORAGE_DIR))


def _db_path() -> str:
    return str(getattr(_app_config, "DB_PATH", DB_PATH))


def share_cookie_name(token: str) -> str:
    """Return canonical cookie name for a share link unlock session."""
    clean_tok = "".join(ch for ch in str(token or "").strip() if ch.isalnum() or ch in ("_", "-"))
    return f"myserver_share_{clean_tok}"


def _share_hmac_digest(token: str, exp_ts: int, password_hash: str) -> str:
    secret = str(getattr(_app_config, "JWT_SECRET", "") or "").encode("utf-8")
    pwd_digest = hashlib.sha256((password_hash or "").encode("utf-8")).hexdigest()[:16]
    msg = f"share-auth-v1:{token}:{exp_ts}:{pwd_digest}".encode("utf-8")
    return hmac.new(secret, msg, hashlib.sha256).hexdigest()


def create_share_access_token(
    token: str,
    password_hash: str,
    ttl_seconds: int = SHARE_SESSION_TTL_SECONDS,
) -> str:
    """Create an HMAC-SHA256 signed share access token bound to share token, expiry, and password hash."""
    exp_ts = int(time.time()) + max(60, int(ttl_seconds))
    sig = _share_hmac_digest(token, exp_ts, password_hash or "")
    return f"{exp_ts}.{sig}"


def verify_share_access_token(
    token: str,
    password_hash: Optional[str],
    candidate_token: Optional[str],
) -> bool:
    """Verify HMAC-SHA256 share access token in constant time."""
    clean_hash = str(password_hash or "").strip()
    if not clean_hash:
        return True
    raw_cand = str(candidate_token or "").strip()
    if not raw_cand or "." not in raw_cand:
        return False
    try:
        exp_str, sig_hex = raw_cand.split(".", 1)
        exp_ts = int(exp_str)
        if exp_ts < int(time.time()):
            return False
        expected_sig = _share_hmac_digest(token, exp_ts, clean_hash)
        return hmac.compare_digest(sig_hex.lower(), expected_sig.lower())
    except Exception:
        return False


def extract_share_access_token(
    token: str,
    request: Any = None,
    query_token: Optional[str] = None,
    header_token: Optional[str] = None,
    cookie_header: Optional[str] = None,
) -> str:
    """Extract share unlock token from query params, X-Share-Auth header, or myserver_share_{token} cookie."""
    if query_token and str(query_token).strip():
        return str(query_token).strip()
    if header_token and str(header_token).strip():
        return str(header_token).strip()

    cookie_key = share_cookie_name(token)

    if request is not None:
        qp = getattr(request, "query_params", None)
        if qp and hasattr(qp, "get"):
            q_val = qp.get("access_token") or qp.get("share_token")
            if q_val and str(q_val).strip():
                return str(q_val).strip()

        hdrs = getattr(request, "headers", None)
        if hdrs and hasattr(hdrs, "get"):
            h_val = hdrs.get("x-share-auth") or hdrs.get("X-Share-Auth")
            if h_val and str(h_val).strip():
                return str(h_val).strip()
            if not cookie_header:
                cookie_header = hdrs.get("cookie") or hdrs.get("Cookie")

        cookies_dict = getattr(request, "cookies", None)
        if cookies_dict and hasattr(cookies_dict, "get"):
            c_val = cookies_dict.get(cookie_key)
            if c_val and str(c_val).strip():
                return str(c_val).strip()

    if cookie_header:
        try:
            sc = http.cookies.SimpleCookie()
            sc.load(str(cookie_header))
            if cookie_key in sc and sc[cookie_key].value:
                return str(sc[cookie_key].value).strip()
        except Exception:
            for part in str(cookie_header).split(";"):
                k, _, v = part.strip().partition("=")
                if k.strip() == cookie_key and v.strip():
                    return v.strip()

    return ""


def is_share_request_unlocked(
    share: Dict[str, Any],
    request: Any = None,
    query_token: Optional[str] = None,
    header_token: Optional[str] = None,
    cookie_header: Optional[str] = None,
) -> bool:
    """Return True if share has no password or request carries a valid HMAC unlock cookie/token."""
    if not share.get("password_protected"):
        return True
    candidate = extract_share_access_token(
        share["token"],
        request=request,
        query_token=query_token,
        header_token=header_token,
        cookie_header=cookie_header,
    )
    return verify_share_access_token(share["token"], share.get("password_hash"), candidate)


def _sign_uploader_sid(sid_hex: str) -> str:
    """Sign an anonymous uploader session ID with HMAC-SHA256 bound to JWT_SECRET."""
    secret = str(getattr(_app_config, "JWT_SECRET", "") or "").encode("utf-8")
    clean_sid = str(sid_hex or "").strip().lower()
    sig = hmac.new(secret, f"uploader-sid-v1:{clean_sid}".encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{clean_sid}.{sig}"


def verify_uploader_cookie(raw_cookie_val: Optional[str]) -> Optional[str]:
    """Verify myserver_uploader_sid cookie value in constant time and return sid_hex if valid."""
    val = str(raw_cookie_val or "").strip()
    if "." not in val:
        return None
    sid_hex, sig_hex = val.split(".", 1)
    clean_sid = sid_hex.strip().lower()
    if (
        not clean_sid
        or len(clean_sid) < 16
        or len(clean_sid) > 64
        or not all(c in "0123456789abcdef" for c in clean_sid)
    ):
        return None
    expected_sig = _sign_uploader_sid(clean_sid).split(".", 1)[1]
    if hmac.compare_digest(sig_hex.strip().lower(), expected_sig.lower()):
        return clean_sid
    return None


def extract_uploader_sid(
    request: Any = None,
    cookie_header: Optional[str] = None,
) -> Optional[str]:
    """Extract and verify myserver_uploader_sid from Request cookies/headers or Cookie header string."""
    raw_val = None
    if request is not None:
        cookies_dict = getattr(request, "cookies", None)
        if cookies_dict and hasattr(cookies_dict, "get"):
            c_val = cookies_dict.get(UPLOADER_COOKIE_NAME)
            if c_val and str(c_val).strip():
                raw_val = str(c_val).strip()
        if not raw_val and not cookie_header:
            hdrs = getattr(request, "headers", None)
            if hdrs and hasattr(hdrs, "get"):
                cookie_header = hdrs.get("cookie") or hdrs.get("Cookie")

    if not raw_val and cookie_header:
        try:
            sc = http.cookies.SimpleCookie()
            sc.load(str(cookie_header))
            if UPLOADER_COOKIE_NAME in sc and sc[UPLOADER_COOKIE_NAME].value:
                raw_val = str(sc[UPLOADER_COOKIE_NAME].value).strip()
        except Exception:
            for part in str(cookie_header).split(";"):
                k, _, v = part.strip().partition("=")
                if k.strip() == UPLOADER_COOKIE_NAME and v.strip():
                    raw_val = v.strip()
                    break

    return verify_uploader_cookie(raw_val) if raw_val else None


def issue_uploader_sid() -> Tuple[str, str]:
    """Generate a new 128-bit anonymous uploader session ID and its signed cookie value."""
    sid_hex = secrets.token_hex(16)
    return sid_hex, _sign_uploader_sid(sid_hex)


def _extract_client_ip(request: Any = None) -> str:
    if request is None:
        return "unknown"
    client = getattr(request, "client", None)
    host = getattr(client, "host", None) if client is not None else None
    return str(host or "unknown")


def resolve_share_write_dir(
    storage_root: str,
    share: Dict[str, Any],
    subpath: Optional[str] = "",
    db_path: Optional[str] = None,
) -> Tuple[str, str, str]:
    """Verify public share has role='editor' on a directory and confine write subpath inside share_root_abs."""
    share_role = str(share.get("role") or "viewer").strip().lower()
    if share_role != "editor" or not bool(share.get("is_dir")):
        raise HTTPException(
            status_code=403,
            detail="Tautan berbagi ini hanya memiliki izin lihat (Viewer).",
        )
    target_rel, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        db_path=db_path,
    )
    if not os.path.isdir(target_abs):
        raise HTTPException(status_code=400, detail="Target direktori unggahan tidak valid.")
    return target_rel, target_abs, clean_sub


def check_session_can_delete_target(
    share_token: str,
    target_rel: str,
    target_abs: str,
    uploader_sid: Optional[str],
    db_path: Optional[str] = None,
) -> bool:
    """
    Verify target_rel belongs to uploader_sid in public_share_uploads; if directory,
    recursively verify every descendant file/subdir is also owned by uploader_sid (followlinks=False).
    """
    clean_sid = str(uploader_sid or "").strip().lower()
    norm_target_rel = str(target_rel or "").strip().replace("\\", "/").strip("/")
    if not clean_sid or not norm_target_rel:
        return False

    target_db = db_path or _db_path()
    owned_paths = list_public_share_owned_paths(share_token, clean_sid, db_path=target_db)
    if norm_target_rel not in owned_paths:
        return False

    if os.path.islink(target_abs):
        return False

    if os.path.isdir(target_abs):
        for root, dirs, files in os.walk(target_abs, followlinks=False):
            for d in dirs:
                d_abs = os.path.join(root, d)
                if os.path.islink(d_abs):
                    return False
                rel_from_target = os.path.relpath(d_abs, target_abs).replace("\\", "/")
                child_rel = f"{norm_target_rel}/{rel_from_target}"
                if child_rel not in owned_paths:
                    return False
            for f in files:
                f_abs = os.path.join(root, f)
                if os.path.islink(f_abs):
                    return False
                rel_from_target = os.path.relpath(f_abs, target_abs).replace("\\", "/")
                child_rel = f"{norm_target_rel}/{rel_from_target}"
                if child_rel not in owned_paths:
                    return False
    return True


def _build_share_item_dict(
    token: str,
    name: str,
    item_sub: str,
    is_dir: bool,
    size: int,
    mtime: int,
    can_delete: bool = False,
) -> Dict[str, Any]:
    q_item_sub = urllib.parse.quote(item_sub)
    ext = "" if is_dir else os.path.splitext(name)[1].lower()
    mime_type = (
        "inode/directory"
        if is_dir
        else (mimetypes.guess_type(name)[0] or "application/octet-stream")
    )
    return {
        "name": name,
        "subpath": item_sub,
        "is_dir": is_dir,
        "size": size,
        "mtime": mtime,
        "extension": ext,
        "mime_type": mime_type,
        "preview_kind": classify_preview_kind(name, is_dir=is_dir),
        "stream_url": f"/api/v1/share/{token}/stream?subpath={q_item_sub}",
        "download_url": f"/api/v1/share/{token}/download?subpath={q_item_sub}",
        "can_delete": bool(can_delete),
    }


def classify_preview_kind(filename: str, is_dir: bool = False) -> str:
    """Classify a file or folder into viewer preview kind."""
    if is_dir:
        return "folder"
    ext = os.path.splitext(str(filename or ""))[1].lower()
    if ext in (
        ".png", ".jpg", ".jpeg", ".jpe", ".jfif", ".gif", ".webp", ".bmp",
        ".svg", ".ico", ".avif", ".heic", ".heif", ".hif", ".tif", ".tiff",
        ".jxl", ".jp2", ".j2k", ".psd", ".tga", ".dds",
        ".dng", ".raw", ".cr2", ".cr3", ".nef", ".arw", ".orf", ".rw2", ".raf", ".pef", ".srw",
    ):
        return "image"
    if ext in (
        ".mp4", ".webm", ".mkv", ".mov", ".avi", ".m4v", ".3gp", ".3g2",
        ".ts", ".m2ts", ".mts", ".flv", ".f4v", ".wmv", ".asf",
        ".mpg", ".mpeg", ".mpe", ".mpv", ".ogv", ".vob", ".rm", ".rmvb",
        ".divx", ".xvid", ".mxf",
    ):
        return "video"
    if ext in (
        ".mp3", ".wav", ".ogg", ".oga", ".flac", ".m4a", ".m4b", ".m4p",
        ".aac", ".opus", ".wma", ".alac", ".aif", ".aiff", ".ape", ".amr",
        ".ac3", ".dts", ".wv", ".mka", ".mid", ".midi", ".caf", ".dsf",
    ):
        return "audio"
    if ext == ".pdf":
        return "pdf"
    if ext in (
        ".txt", ".md", ".json", ".log", ".py", ".js", ".ts", ".tsx", ".jsx",
        ".html", ".css", ".yml", ".yaml", ".xml", ".csv", ".ini", ".conf",
        ".sh", ".toml", ".sql",
    ):
        return "text"
    return "file"


def load_active_share_or_raise(
    token: str,
    db_path: Optional[str] = None,
    include_secret: bool = True,
) -> Dict[str, Any]:
    """Load share record and raise 404 if unknown or 410 if expired/revoked/owner-deleted."""
    target_db = db_path or _db_path()
    share = get_public_share(token, db_path=target_db, include_secret=include_secret)
    if not share:
        raise HTTPException(status_code=404, detail="Tautan berbagi tidak ditemukan.")
    if share.get("revoked") or share.get("is_expired") or share.get("status") != "active":
        raise HTTPException(status_code=410, detail="Tautan berbagi sudah kedaluwarsa atau telah dicabut.")
    owner_username = str(share.get("owner_username") or "").strip()
    if owner_username:
        owner_rec = get_user_by_username(owner_username, db_path=target_db)
        if owner_rec is None:
            raise HTTPException(
                status_code=410,
                detail="Akun pemilik tautan berbagi telah dihapus sehingga tautan tidak lagi aktif.",
            )
    return share


def resolve_share_subpath_target(
    storage_root: str,
    share: Dict[str, Any],
    subpath: Optional[str] = "",
    db_path: Optional[str] = None,
) -> Tuple[str, str, str]:
    """
    Resolve and confine a public share request strictly inside the shared file or directory root.
    Blocks relative path traversal ('..') and symlink escapes outside share_root_abs.
    """
    try:
        share_rel, share_root_abs = resolve_safe_storage_target(storage_root, share.get("target_path"))
    except ValueError:
        raise HTTPException(status_code=400, detail="Jalur target tautan berbagi tidak valid.")

    if not share_rel:
        raise HTTPException(status_code=403, detail="Pembagian root penyimpanan secara langsung tidak diizinkan.")

    # Verify owner exists and still has permission on share_rel in SQLite (owner, system_admin, or Scoped Folder Admin)
    owner_username = str(share.get("owner_username") or "").strip()
    if owner_username:
        resolved_db = db_path or _db_path()
        owner_rec = get_user_by_username(owner_username, db_path=resolved_db)
        if not owner_rec:
            raise HTTPException(
                status_code=410,
                detail="Akun pemilik tautan berbagi telah dihapus sehingga tautan tidak lagi aktif.",
            )
        owner_role = normalize_user_role(owner_rec.get("role"))
        owner_is_admin = bool(owner_role in ("admin", "root") or is_admin_username(owner_username))
        owner_disks = _parse_allowed_disks_value(owner_rec.get("allowed_disks", "[]"))
        perm = resolve_effective_path_permission(
            share_rel,
            owner_rec,
            owner_disks,
            owner_is_admin,
            db_path=resolved_db,
        )
        if perm["level"] not in ("system_admin", "owner", "administrator"):
            raise HTTPException(
                status_code=403,
                detail="Izin akses penyimpanan pemilik tautan telah dicabut.",
            )

    if not os.path.exists(share_root_abs):
        raise HTTPException(status_code=404, detail="Berkas atau direktori yang dibagikan tidak ditemukan di server.")

    raw_sub = str(subpath or "").strip().replace("\\", "/").strip("/")
    if not share.get("is_dir"):
        if raw_sub:
            raise HTTPException(status_code=400, detail="Subpath tidak berlaku untuk tautan berkas tunggal.")
        return share_rel, share_root_abs, ""

    if "\x00" in raw_sub:
        raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")
    if raw_sub:
        segments = [seg for seg in raw_sub.split("/") if seg]
        if any(seg in (".", "..") for seg in segments):
            raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")
        combined_rel = f"{share_rel}/{'/'.join(segments)}"
    else:
        combined_rel = share_rel

    try:
        target_rel, target_abs = resolve_safe_storage_target(storage_root, combined_rel)
    except ValueError:
        raise HTTPException(status_code=400, detail="Subpath tidak diizinkan.")

    # Strict subtree confinement inside share_root_abs (blocks symlink escape to sibling folders)
    try:
        if os.path.commonpath([share_root_abs, target_abs]) != share_root_abs:
            raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")
    except ValueError:
        raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau sub-folder tidak ditemukan.")

    clean_sub = "" if target_abs == share_root_abs else os.path.relpath(target_abs, share_root_abs).replace("\\", "/")
    return target_rel, target_abs, clean_sub


def build_share_meta_payload(
    storage_root: str,
    share: Dict[str, Any],
    subpath: Optional[str] = "",
    unlocked: bool = True,
    db_path: Optional[str] = None,
    uploader_sid: Optional[str] = None,
) -> Dict[str, Any]:
    """Build metadata or directory listing payload for GET /api/v1/share/{token}/meta."""
    token = share["token"]
    raw_sub = str(subpath or "").strip().replace("\\", "/").strip("/")
    share_role = "editor" if (str(share.get("role") or "viewer").strip().lower() == "editor" and bool(share.get("is_dir"))) else "viewer"
    max_upload_bytes = share.get("max_upload_bytes")
    max_upload_mb = share.get("max_upload_mb")
    can_upload = bool(share_role == "editor" and bool(share.get("is_dir")))

    if share.get("password_protected") and not unlocked:
        if raw_sub:
            raise HTTPException(
                status_code=401,
                detail="Tautan ini dilindungi kata sandi. Silakan buka kunci tautan terlebih dahulu.",
            )
        return {
            "token": token,
            "label": share["label"],
            "is_dir": bool(share["is_dir"]),
            "target_is_dir": bool(share["is_dir"]),
            "role": share_role,
            "max_upload_bytes": max_upload_bytes,
            "max_upload_mb": max_upload_mb,
            "can_upload": False,
            "password_required": True,
            "unlocked": False,
            "expires_at": share.get("expires_at"),
            "status": share.get("status", "active"),
            "download_count": int(share.get("download_count") or 0),
            "subpath": "",
            "parent_subpath": "",
            "items": [],
        }

    share_rel, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    target_rel, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root, share, subpath=raw_sub, db_path=db_path
    )

    owned_paths: set = set()
    if can_upload and uploader_sid:
        owned_paths = list_public_share_owned_paths(token, uploader_sid, db_path=db_path or _db_path())

    is_target_dir = os.path.isdir(target_abs)
    parent_sub = os.path.dirname(clean_sub).replace("\\", "/") if clean_sub else ""
    q_clean_sub = f"?subpath={urllib.parse.quote(clean_sub)}" if clean_sub else ""

    if is_target_dir:
        items: List[Dict[str, Any]] = []
        try:
            for entry in os.scandir(target_abs):
                if entry.name.startswith(".") or entry.name.endswith(".part"):
                    continue
                entry_real = os.path.realpath(entry.path)
                try:
                    if os.path.commonpath([share_root_abs, entry_real]) != share_root_abs:
                        continue
                except ValueError:
                    continue
                try:
                    st = entry.stat()
                    entry_is_dir = entry.is_dir()
                    size = 0 if entry_is_dir else int(st.st_size)
                    mtime = int(st.st_mtime)
                except Exception:
                    continue

                item_sub = f"{clean_sub}/{entry.name}" if clean_sub else entry.name
                item_rel = f"{share_rel}/{item_sub}" if share_rel else item_sub
                can_del = bool(can_upload and uploader_sid and item_rel in owned_paths)
                items.append(
                    _build_share_item_dict(
                        token=token,
                        name=entry.name,
                        item_sub=item_sub,
                        is_dir=entry_is_dir,
                        size=size,
                        mtime=mtime,
                        can_delete=can_del,
                    )
                )
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Gagal membaca isi folder: {exc}")

        items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
        return {
            "token": token,
            "label": share["label"],
            "name": os.path.basename(target_abs) if clean_sub else share["label"],
            "is_dir": bool(share["is_dir"]),
            "target_is_dir": True,
            "role": share_role,
            "max_upload_bytes": max_upload_bytes,
            "max_upload_mb": max_upload_mb,
            "can_upload": can_upload,
            "password_required": bool(share.get("password_protected")),
            "unlocked": True,
            "expires_at": share.get("expires_at"),
            "status": share.get("status", "active"),
            "download_count": int(share.get("download_count") or 0),
            "subpath": clean_sub,
            "parent_subpath": parent_sub,
            "preview_kind": "folder",
            "download_url": f"/api/v1/share/{token}/download{q_clean_sub}",
            "items": items,
        }

    # Single file target (either root file share or file inside shared directory)
    st = os.stat(target_abs)
    fname = os.path.basename(target_abs)
    ext = os.path.splitext(fname)[1].lower()
    mime_type = mimetypes.guess_type(fname)[0] or "application/octet-stream"
    p_kind = classify_preview_kind(fname, is_dir=False)
    text_preview: Optional[str] = None
    if p_kind == "text" and st.st_size <= 256 * 1024:
        try:
            with open(target_abs, "rb") as f:
                raw_bytes = f.read(65536)
            text_preview = raw_bytes.decode("utf-8", errors="replace")
        except Exception:
            text_preview = None

    can_del_single = bool(can_upload and uploader_sid and target_rel != share_rel and target_rel in owned_paths)
    return {
        "token": token,
        "label": share["label"],
        "name": fname,
        "is_dir": bool(share["is_dir"]),
        "target_is_dir": False,
        "role": share_role,
        "max_upload_bytes": max_upload_bytes,
        "max_upload_mb": max_upload_mb,
        "can_upload": can_upload,
        "can_delete": can_del_single,
        "password_required": bool(share.get("password_protected")),
        "unlocked": True,
        "expires_at": share.get("expires_at"),
        "status": share.get("status", "active"),
        "download_count": int(share.get("download_count") or 0),
        "subpath": clean_sub,
        "parent_subpath": parent_sub,
        "size": int(st.st_size),
        "mtime": int(st.st_mtime),
        "extension": ext,
        "mime_type": mime_type,
        "preview_kind": p_kind,
        "text_preview": text_preview,
        "stream_url": f"/api/v1/share/{token}/stream{q_clean_sub}",
        "download_url": f"/api/v1/share/{token}/download{q_clean_sub}",
        "items": [],
    }


def _iter_confined_zip_entries(share_root_abs: str, target_dir_abs: str, safe_root: str) -> Iterator[Tuple[str, str]]:
    """Menghasilkan pasangan (entry_real_abs, arcname) secara aman di dalam batas share_root_abs."""
    for root, dirs, files in os.walk(target_dir_abs, followlinks=False):
        valid_dirs = []
        for d in sorted(dirs):
            if d.startswith("."):
                continue
            d_full = os.path.join(root, d)
            if os.path.islink(d_full):
                continue
            d_real = os.path.realpath(d_full)
            try:
                if os.path.commonpath([share_root_abs, d_real]) == share_root_abs:
                    valid_dirs.append(d)
            except ValueError:
                continue
        dirs[:] = valid_dirs

        for f in sorted(files):
            if f.startswith(".") or f.endswith(".part"):
                continue
            full_entry = os.path.join(root, f)
            if os.path.islink(full_entry):
                continue
            entry_real = os.path.realpath(full_entry)
            try:
                if os.path.commonpath([share_root_abs, entry_real]) != share_root_abs:
                    continue
            except ValueError:
                continue
            if not os.path.isfile(entry_real):
                continue
            rel_in_target = os.path.relpath(entry_real, target_dir_abs).replace("\\", "/")
            yield entry_real, f"{safe_root}/{rel_in_target}"


class _QueueZipSink(io.RawIOBase):
    """Writable non-seekable sink yang meneruskan byte arsip ZIP langsung ke bounded Queue."""

    def __init__(self, out_q: "queue.Queue[Optional[bytes]]") -> None:
        self._q = out_q
        self._pos = 0
        self._aborted = threading.Event()

    def writable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    def tell(self) -> int:
        return self._pos

    def abort(self) -> None:
        self._aborted.set()

    def write(self, b) -> int:
        data = bytes(b)
        if not data:
            return 0
        self._pos += len(data)
        while not self._aborted.is_set():
            try:
                self._q.put(data, timeout=0.5)
                return len(data)
            except queue.Full:
                continue
        raise BrokenPipeError("Klien unduhan memutus koneksi.")


def iter_directory_as_zip_bytes(
    share_root_abs: str,
    target_dir_abs: str,
    archive_root_name: str,
) -> Iterator[bytes]:
    """Streaming ZIP on-the-fly berbasis generator tanpa memakan ruang /tmp atau RAM besar."""
    safe_root = (
        os.path.basename(str(archive_root_name or "shared_folder").strip().rstrip("/\\"))
        or "shared_folder"
    )
    out_q: "queue.Queue[Optional[bytes]]" = queue.Queue(maxsize=16)
    sink = _QueueZipSink(out_q)
    errors: List[BaseException] = []

    def _producer() -> None:
        try:
            with zipfile.ZipFile(sink, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
                written = 0
                for entry_real, arcname in _iter_confined_zip_entries(share_root_abs, target_dir_abs, safe_root):
                    zf.write(entry_real, arcname=arcname)
                    written += 1
                if written == 0:
                    zf.writestr(f"{safe_root}/", b"")
        except BaseException as exc:
            errors.append(exc)
        finally:
            try:
                out_q.put(None, timeout=1.0)
            except queue.Full:
                pass

    prod = threading.Thread(target=_producer, daemon=True, name="share-zip-stream")
    prod.start()
    try:
        while True:
            chunk = out_q.get()
            if chunk is None:
                break
            yield chunk
        if errors:
            raise errors[0]
    finally:
        sink.abort()
        prod.join(timeout=2.0)


def stream_directory_as_zip_file(
    share_root_abs: str,
    target_dir_abs: str,
    archive_root_name: str,
):
    """
    Create a spooled temporary .zip archive (in-memory up to 16 MB, spilling to disk above 16 MB)
    containing only files strictly confined inside share_root_abs.
    Returns (spooled_file, total_zip_bytes).
    """
    safe_root = (
        os.path.basename(str(archive_root_name or "shared_folder").strip().rstrip("/\\"))
        or "shared_folder"
    )
    spooled = tempfile.SpooledTemporaryFile(max_size=16 * 1024 * 1024, mode="w+b")
    written_entries = 0

    with zipfile.ZipFile(spooled, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for entry_real, arcname in _iter_confined_zip_entries(share_root_abs, target_dir_abs, safe_root):
            zf.write(entry_real, arcname=arcname)
            written_entries += 1

        if written_entries == 0:
            zf.writestr(f"{safe_root}/", b"")

    spooled.seek(0, os.SEEK_END)
    total_zip_bytes = int(spooled.tell())
    spooled.seek(0)
    return spooled, total_zip_bytes


def render_public_share_viewer_html(
    share: Optional[Dict[str, Any]],
    status_code: int = 200,
    error_title: str = "",
    error_message: str = "",
) -> str:
    """Render standalone mobile-first Setup-Wizard-styled Public Share Viewer/Editor HTML (12-UI-SPEC E4/E5/E6)."""
    if status_code != 200 or not share:
        raw_err_title = error_title or (
            "Tautan Tidak Ditemukan" if status_code == 404 else "Tautan Kedaluwarsa"
        )
        raw_err_msg = error_message or (
            "Tautan tidak valid atau sudah dihapus. Minta tautan baru ke pengirim."
            if status_code == 404
            else "Tautan sudah kedaluwarsa atau dicabut. Minta tautan baru ke pengirim."
        )
        safe_err_title = html.escape(raw_err_title, quote=True)
        safe_err_msg = html.escape(raw_err_msg, quote=True)
        code_int = int(status_code)
        return f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{safe_err_title} - MyServer Share</title>
    <style>
        :root {{
            --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
            --bg-base: #0B0E09;
            --bg-surface: #11150D;
            --bg-card: #171C12;
            --ink: #F8FAFC;
            --ink-subtle: #94A3B8;
            --line: rgba(255, 255, 255, 0.13);
            --accent: #7BC504;
            --btn-sec-bg: rgba(255, 255, 255, 0.08);
            --btn-sec-border: rgba(255, 255, 255, 0.18);
            --btn-sec-ink: #F1F5F9;
            --seg-track: rgba(11, 14, 9, 0.90);
            --seg-active: rgba(255, 255, 255, 0.15);
            --seg-active-ink: #FFFFFF;
            --danger-bg: rgba(69, 10, 10, 0.90);
            --danger-border: rgba(248, 113, 113, 0.48);
            --danger-ink: #FEE2E2;
        }}
        html[data-theme="light"] {{
            --bg-base: #FFFFFF;
            --bg-surface: #F8FAFC;
            --bg-card: #FFFFFF;
            --ink: #0F172A;
            --ink-subtle: #475569;
            --line: rgba(15, 23, 42, 0.12);
            --accent: #46720C;
            --btn-sec-bg: #FFFFFF;
            --btn-sec-border: #CBD5E1;
            --btn-sec-ink: #0F172A;
            --seg-track: #E9EFF4;
            --seg-active: #FFFFFF;
            --seg-active-ink: #0F172A;
            --danger-bg: #FEF2F2;
            --danger-border: #FCA5A5;
            --danger-ink: #991B1B;
        }}
        *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
        html, body {{ overflow-x: hidden; }}
        body {{
            background: var(--bg-base);
            color: var(--ink);
            font-family: var(--font-sans);
            min-height: 100dvh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }}
        .error-card {{
            background: var(--bg-surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            max-width: 400px;
            width: 100%;
            padding: 24px;
            text-align: center;
        }}
        .util-row {{
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
            margin-bottom: 16px;
        }}
        .icon-btn {{
            min-width: 36px;
            min-height: 36px;
            border-radius: 8px;
            border: 1px solid var(--btn-sec-border);
            background: var(--btn-sec-bg);
            color: var(--btn-sec-ink);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }}
        .seg-group {{
            display: inline-flex;
            padding: 3px;
            border-radius: 8px;
            background: var(--seg-track);
            border: 1px solid var(--line);
            gap: 2px;
        }}
        .seg-btn {{
            min-height: 30px;
            padding: 0 10px;
            border: none;
            border-radius: 6px;
            background: transparent;
            color: var(--ink-subtle);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }}
        .seg-btn.active {{
            background: var(--seg-active);
            color: var(--seg-active-ink);
        }}
        .status-badge {{
            display: inline-block;
            background: var(--danger-bg);
            color: var(--danger-ink);
            border: 1px solid var(--danger-border);
            font-family: var(--font-mono);
            font-variant-numeric: tabular-nums;
            font-size: 12px;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 16px;
        }}
        h1 {{ font-size: 20px; font-weight: 600; line-height: 1.2; margin-bottom: 8px; }}
        p {{ font-size: 14px; font-weight: 400; color: var(--ink-subtle); line-height: 1.43; }}
        @media (max-width: 767px) {{
            .icon-btn {{ min-width: 44px; min-height: 44px; }}
            .seg-btn {{ min-height: 36px; }}
        }}
        @media (prefers-reduced-motion: reduce) {{
            *, *::before, *::after {{ transition: none !important; animation: none !important; }}
        }}
    </style>
</head>
<body>
    <main class="error-card">
        <div class="util-row">
            <button type="button" class="icon-btn" id="btnErrTheme" aria-label="Switch theme">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
            </button>
            <div class="seg-group" role="group" aria-label="Language">
                <button type="button" class="seg-btn" id="btnErrLangId">ID</button>
                <button type="button" class="seg-btn" id="btnErrLangEn">EN</button>
            </div>
        </div>
        <span class="status-badge">HTTP {code_int}</span>
        <h1 id="errHeading">{safe_err_title}</h1>
        <p id="errMessage">{safe_err_msg}</p>
    </main>
    <script>
        (function () {{
            const STATUS = {code_int};
            const ERR_COPY = {{
                id: {{
                    404: {{ t: "Tautan Tidak Ditemukan", m: "Tautan tidak valid atau sudah dihapus. Minta tautan baru ke pengirim." }},
                    410: {{ t: "Tautan Kedaluwarsa", m: "Tautan sudah kedaluwarsa atau dicabut. Minta tautan baru ke pengirim." }}
                }},
                en: {{
                    404: {{ t: "Link Not Found", m: "This link is invalid or removed. Ask the sender for a new link." }},
                    410: {{ t: "Link Expired", m: "This link has expired or been revoked. Ask the sender for a new link." }}
                }}
            }};
            function applyTheme(theme) {{
                const t = theme === "light" ? "light" : "dark";
                document.documentElement.setAttribute("data-theme", t);
                try {{ localStorage.myserver_theme = t; }} catch (e) {{}}
            }}
            function applyLang(lang) {{
                const l = lang === "id" ? "id" : "en";
                document.documentElement.lang = l;
                try {{ localStorage.myserver_lang = l; }} catch (e) {{}}
                document.getElementById("btnErrLangId").classList.toggle("active", l === "id");
                document.getElementById("btnErrLangEn").classList.toggle("active", l === "en");
                const pack = (ERR_COPY[l] && ERR_COPY[l][STATUS]) || ERR_COPY[l][410];
                if (pack) {{
                    document.getElementById("errHeading").textContent = pack.t;
                    document.getElementById("errMessage").textContent = pack.m;
                }}
            }}
            let savedTheme = "dark";
            let savedLang = (navigator.language || "").toLowerCase().startsWith("id") ? "id" : "en";
            try {{
                if (localStorage.myserver_theme === "light" || localStorage.myserver_theme === "dark") savedTheme = localStorage.myserver_theme;
                if (localStorage.myserver_lang === "id" || localStorage.myserver_lang === "en") savedLang = localStorage.myserver_lang;
            }} catch (e) {{}}
            applyTheme(savedTheme);
            applyLang(savedLang);
            document.getElementById("btnErrTheme").addEventListener("click", () => {{
                const cur = document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
                applyTheme(cur === "light" ? "dark" : "light");
            }});
            document.getElementById("btnErrLangId").addEventListener("click", () => applyLang("id"));
            document.getElementById("btnErrLangEn").addEventListener("click", () => applyLang("en"));
        }})();
    </script>
</body>
</html>"""

    safe_token = html.escape(str(share["token"]), quote=True)
    safe_label = html.escape(str(share.get("label") or "Shared Item"), quote=True)
    is_dir = bool(share.get("is_dir"))
    share_role = "editor" if (is_dir and str(share.get("role") or "viewer").lower() == "editor") else "viewer"
    max_upload_bytes = share.get("max_upload_bytes")
    max_upload_mb = int(max_upload_bytes // (1024 * 1024)) if (share_role == "editor" and max_upload_bytes and int(max_upload_bytes) > 0) else 0
    raw_expires = str(share.get("expires_at") or "").strip()
    safe_expires = html.escape(raw_expires or "No expiry", quote=True)
    dl_count = int(share.get("download_count") or 0)
    dl_btn_label = "Download ZIP" if is_dir else "Download File"
    role_label = "Editor" if share_role == "editor" else "Viewer"
    role_badge_cls = "pill pill-ok" if share_role == "editor" else "pill"
    max_size_style = "" if (share_role == "editor" and max_upload_mb > 0) else "display: none;"
    token_js_json = json.dumps(str(share["token"]))
    expires_js_json = json.dumps(raw_expires)
    init_role_js_json = json.dumps(share_role)
    init_is_dir_js = "true" if is_dir else "false"
    init_max_bytes_js = str(int(max_upload_bytes)) if (share_role == "editor" and max_upload_bytes and int(max_upload_bytes) > 0) else "0"
    init_dl_count_js = str(dl_count)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{safe_label} - MyServer Share</title>
    <style>
        :root {{
            --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
            --bg-base: #0B0E09;
            --bg-surface: #11150D;
            --bg-card: #171C12;
            --bg-hover: #1E2518;
            --ink: #F8FAFC;
            --ink-muted: #CBD5E1;
            --ink-subtle: #94A3B8;
            --line: rgba(255, 255, 255, 0.13);
            --line-strong: rgba(255, 255, 255, 0.24);
            --accent: #7BC504;
            --accent-soft: rgba(123, 197, 4, 0.16);
            --accent-border: rgba(132, 204, 22, 0.42);
            --btn-primary-bg: linear-gradient(180deg, #8CE012 0%, #6CB402 100%);
            --btn-primary-border: rgba(217, 249, 157, 0.45);
            --btn-primary-ink: #081202;
            --btn-primary-shadow: 0 4px 14px rgba(123, 197, 4, 0.28), inset 0 1px 0 rgba(255, 255, 255, 0.42);
            --btn-sec-bg: rgba(255, 255, 255, 0.08);
            --btn-sec-border: rgba(255, 255, 255, 0.18);
            --btn-sec-ink: #F1F5F9;
            --btn-sec-hover-bg: rgba(255, 255, 255, 0.15);
            --input-bg: rgba(11, 14, 9, 0.92);
            --input-border: rgba(255, 255, 255, 0.18);
            --input-focus: rgba(132, 204, 22, 0.58);
            --seg-track: rgba(11, 14, 9, 0.90);
            --seg-active: rgba(255, 255, 255, 0.15);
            --seg-active-ink: #FFFFFF;
            --ok-bg: rgba(20, 38, 6, 0.90);
            --ok-border: rgba(132, 204, 22, 0.44);
            --ok-ink: #ECFCCB;
            --warn-bg: rgba(69, 26, 3, 0.90);
            --warn-border: rgba(251, 191, 36, 0.45);
            --warn-ink: #FEF3C7;
            --danger: #EF4444;
            --danger-bg: rgba(69, 10, 10, 0.90);
            --danger-border: rgba(248, 113, 113, 0.48);
            --danger-ink: #FEE2E2;
            --danger-text: #FCA5A5;
            --folder-tint: #F59E0B;
            --progress-track: rgba(255, 255, 255, 0.18);
            --scrim: rgba(0, 0, 0, 0.64);
        }}
        html[data-theme="light"] {{
            --bg-base: #FFFFFF;
            --bg-surface: #F8FAFC;
            --bg-card: #FFFFFF;
            --bg-hover: #F1F5F9;
            --ink: #0F172A;
            --ink-muted: #334155;
            --ink-subtle: #475569;
            --line: rgba(15, 23, 42, 0.12);
            --line-strong: rgba(15, 23, 42, 0.24);
            --accent: #46720C;
            --accent-soft: rgba(101, 163, 13, 0.14);
            --accent-border: rgba(77, 124, 15, 0.42);
            --btn-primary-bg: linear-gradient(180deg, #46720C 0%, #365314 100%);
            --btn-primary-border: #2D4610;
            --btn-primary-ink: #FFFFFF;
            --btn-primary-shadow: 0 4px 12px rgba(54, 83, 20, 0.24), inset 0 1px 0 rgba(255, 255, 255, 0.22);
            --btn-sec-bg: #FFFFFF;
            --btn-sec-border: #CBD5E1;
            --btn-sec-ink: #0F172A;
            --btn-sec-hover-bg: #F8FAFC;
            --input-bg: #FFFFFF;
            --input-border: #CBD5E1;
            --input-focus: rgba(70, 114, 12, 0.45);
            --seg-track: #E9EFF4;
            --seg-active: #FFFFFF;
            --seg-active-ink: #0F172A;
            --ok-bg: #F7FEE7;
            --ok-border: #A3E635;
            --ok-ink: #365314;
            --warn-bg: #FFFBEB;
            --warn-border: #FCD34D;
            --warn-ink: #92400E;
            --danger: #DC2626;
            --danger-bg: #FEF2F2;
            --danger-border: #FCA5A5;
            --danger-ink: #991B1B;
            --danger-text: #B91C1C;
            --folder-tint: #D97706;
            --progress-track: rgba(15, 23, 42, 0.16);
            --scrim: rgba(15, 23, 42, 0.52);
        }}
        *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
        html, body {{ overflow-x: hidden; }}
        body {{
            background: var(--bg-base);
            color: var(--ink);
            font-family: var(--font-sans);
            font-size: 14px;
            font-weight: 400;
            line-height: 1.43;
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }}
        button, input, a {{ font-family: inherit; }}
        button:focus-visible, a:focus-visible, input:focus-visible, [tabindex]:focus-visible {{
            outline: 2px solid var(--accent);
            outline-offset: 2px;
            box-shadow: 0 0 0 3px var(--input-focus);
        }}
        .mono {{ font-family: var(--font-mono); font-variant-numeric: tabular-nums; }}
        .truncate {{ overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
        .t-label {{ font-size: 12px; font-weight: 600; line-height: 1.33; }}
        .t-meta {{ font-size: 12px; font-weight: 400; line-height: 1.33; color: var(--ink-subtle); }}
        .t-body {{ font-size: 14px; font-weight: 400; line-height: 1.43; }}
        .t-body-strong {{ font-size: 14px; font-weight: 600; line-height: 1.43; }}
        .t-heading {{ font-size: 16px; font-weight: 600; line-height: 1.25; }}
        .t-display {{ font-size: 20px; font-weight: 600; line-height: 1.2; }}

        /* 52px Slim Topbar */
        .topbar {{
            position: sticky;
            top: 0;
            z-index: 40;
            height: 52px;
            background: var(--bg-surface);
            border-bottom: 1px solid var(--line);
            padding: 0 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
        }}
        .brand-wrap {{
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            min-width: 0;
        }}
        .brand-mark {{
            width: 28px;
            height: 28px;
            border-radius: 8px;
            background: var(--accent-soft);
            border: 1px solid var(--accent-border);
            color: var(--accent);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }}
        .header-actions {{
            display: flex;
            align-items: center;
            gap: 8px;
            flex-shrink: 0;
        }}
        .btn {{
            min-height: 36px;
            padding: 0 14px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
            border: 1px solid transparent;
            white-space: nowrap;
            transition: background-color 150ms ease, border-color 150ms ease;
        }}
        .btn-sm {{ min-height: 32px; padding: 0 10px; font-size: 12px; }}
        .btn-primary {{
            background: var(--btn-primary-bg);
            border-color: var(--btn-primary-border);
            color: var(--btn-primary-ink);
            box-shadow: var(--btn-primary-shadow);
        }}
        .btn-sec {{
            background: var(--btn-sec-bg);
            border-color: var(--btn-sec-border);
            color: var(--btn-sec-ink);
        }}
        .btn-sec:hover {{ background: var(--btn-sec-hover-bg); }}
        .btn-danger {{
            background: var(--danger-bg);
            border-color: var(--danger-border);
            color: var(--danger-ink);
        }}
        .icon-btn {{
            min-width: 36px;
            min-height: 36px;
            border-radius: 8px;
            border: 1px solid var(--btn-sec-border);
            background: var(--btn-sec-bg);
            color: var(--btn-sec-ink);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }}
        .icon-btn:hover {{ background: var(--btn-sec-hover-bg); }}
        .seg-group {{
            display: inline-flex;
            padding: 3px;
            border-radius: 8px;
            background: var(--seg-track);
            border: 1px solid var(--line);
            gap: 2px;
        }}
        .seg-btn {{
            min-height: 28px;
            padding: 0 8px;
            border: none;
            border-radius: 6px;
            background: transparent;
            color: var(--ink-subtle);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }}
        .seg-btn.active {{
            background: var(--seg-active);
            color: var(--seg-active-ink);
        }}

        /* Main Container */
        .container {{
            max-width: 1040px;
            width: 100%;
            margin: 0 auto;
            padding: 12px 16px 40px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }}
        .container.has-fab {{ padding-bottom: 88px; }}
        .meta-strip {{
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            padding: 4px 0 12px;
        }}
        .pill {{
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            background: var(--bg-card);
            color: var(--ink-muted);
            border: 1px solid var(--line);
        }}
        .pill-ok {{
            background: var(--ok-bg);
            border-color: var(--ok-border);
            color: var(--ok-ink);
        }}
        .card {{
            background: var(--bg-surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            padding: 20px;
        }}

        /* Unlock Gate */
        .unlock-card {{
            max-width: 400px;
            width: 100%;
            margin: 40px auto;
            padding: 24px;
            text-align: center;
        }}
        .unlock-icon {{
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--accent-soft);
            border: 1px solid var(--accent-border);
            color: var(--accent);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
        }}
        .input-wrap {{
            position: relative;
            margin: 16px 0 12px;
        }}
        .form-input {{
            width: 100%;
            height: 36px;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--ink);
            padding: 0 40px 0 12px;
            border-radius: 8px;
            font-size: 14px;
        }}
        .pwd-eye {{
            position: absolute;
            right: 4px;
            top: 50%;
            transform: translateY(-50%);
            width: 32px;
            height: 32px;
            border: none;
            background: transparent;
            color: var(--ink-subtle);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border-radius: 6px;
        }}
        .alert-inline {{
            display: none;
            padding: 10px 12px;
            border-radius: 8px;
            background: var(--danger-bg);
            border: 1px solid var(--danger-border);
            color: var(--danger-ink);
            font-size: 12px;
            font-weight: 600;
            text-align: left;
            margin-bottom: 12px;
        }}

        /* Single File Stage */
        .preview-stage {{
            min-height: 280px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 16px;
            background: var(--bg-base);
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 16px;
            overflow: hidden;
        }}
        .preview-stage img, .preview-stage video {{
            max-width: 100%;
            max-height: 68dvh;
            border-radius: 8px;
        }}
        .preview-stage pre {{
            width: 100%;
            max-height: 65dvh;
            overflow: auto;
            padding: 16px;
            background: var(--bg-surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            font-size: 12px;
            white-space: pre-wrap;
            word-break: break-word;
            text-align: left;
        }}
        .inline-pdf-wrap {{
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }}
        .inline-pdf-bar {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
            padding: 8px 12px;
            background: var(--bg-surface);
            border: 1px solid var(--line);
            border-radius: 8px;
        }}
        .inline-pdf-canvas-box {{
            max-height: 68dvh;
            overflow: auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            padding: 8px;
            background: #080A06;
            border-radius: 8px;
        }}

        /* Folder Browser */
        .folder-toolbar {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 12px;
        }}
        .breadcrumbs {{
            display: flex;
            align-items: center;
            gap: 4px;
            flex-wrap: wrap;
            min-width: 0;
            flex: 1;
        }}
        .crumb-btn {{
            min-height: 32px;
            padding: 0 8px;
            border-radius: 6px;
            border: none;
            background: transparent;
            color: var(--ink-muted);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            max-width: 180px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .crumb-btn:hover {{ background: var(--bg-hover); color: var(--ink); }}
        .crumb-btn.current {{ color: var(--ink); }}
        .folder-controls {{
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }}
        .search-wrap {{
            position: relative;
            width: 180px;
        }}
        .search-input {{
            width: 100%;
            height: 36px;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--ink);
            border-radius: 8px;
            padding: 0 28px 0 10px;
            font-size: 14px;
        }}
        .search-clear {{
            position: absolute;
            right: 4px;
            top: 50%;
            transform: translateY(-50%);
            width: 24px;
            height: 24px;
            border: none;
            background: transparent;
            color: var(--ink-subtle);
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
        }}
        .editor-desktop-btns {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .folder-drop-area {{
            position: relative;
            min-height: 200px;
        }}
        .drop-overlay {{
            display: none;
            position: absolute;
            inset: 0;
            z-index: 20;
            background: rgba(11, 14, 9, 0.84);
            border: 2px dashed var(--accent);
            border-radius: 12px;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 24px;
            pointer-events: none;
        }}
        .drop-overlay.active {{ display: flex; }}

        /* Grid & List */
        .files-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(168px, 1fr));
            gap: 16px;
        }}
        .file-card {{
            background: var(--bg-card);
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 10px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            cursor: pointer;
            transition: background-color 150ms ease, border-color 150ms ease;
        }}
        .file-card:hover {{ background: var(--bg-hover); border-color: var(--line-strong); }}
        .card-thumb {{
            aspect-ratio: 4 / 3;
            border-radius: 8px;
            background: var(--bg-base);
            border: 1px solid var(--line);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }}
        .card-thumb img {{ width: 100%; height: 100%; object-fit: cover; }}
        .ext-chip {{
            position: absolute;
            left: 6px;
            bottom: 6px;
            padding: 2px 6px;
            border-radius: 4px;
            background: rgba(8, 10, 6, 0.82);
            color: #F8FAFC;
            font-family: var(--font-mono);
            font-size: 12px;
            font-weight: 600;
        }}
        .card-footer {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 6px;
            min-width: 0;
        }}
        .card-meta-col {{ min-width: 0; flex: 1; }}
        .more-btn {{
            min-width: 32px;
            min-height: 32px;
            border-radius: 8px;
            border: none;
            background: transparent;
            color: var(--ink-subtle);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            flex-shrink: 0;
        }}
        .more-btn:hover {{ background: var(--bg-hover); color: var(--ink); }}

        .files-table {{ width: 100%; border-collapse: collapse; }}
        .files-table th {{
            font-size: 12px;
            font-weight: 600;
            color: var(--ink-subtle);
            text-align: left;
            padding: 8px 12px;
            border-bottom: 1px solid var(--line);
        }}
        .list-row {{
            cursor: pointer;
            border-bottom: 1px solid var(--line);
            transition: background-color 150ms ease;
        }}
        .list-row:hover {{ background: var(--bg-hover); }}
        .list-row td {{ padding: 10px 12px; vertical-align: middle; }}
        .row-name-cell {{
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
        }}
        .mobile-list {{ display: none; flex-direction: column; }}
        .mobile-row {{
            min-height: 56px;
            padding: 8px 4px;
            border-bottom: 1px solid var(--line);
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }}

        /* Empty & Loading */
        .state-center {{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            gap: 8px;
            padding: 40px 16px;
        }}
        .spinner {{
            width: 28px;
            height: 28px;
            border-radius: 999px;
            border: 3px solid var(--line-strong);
            border-top-color: var(--accent);
            animation: spin 0.8s linear infinite;
        }}
        @keyframes spin {{ to {{ transform: rotate(360deg); }} }}

        /* Popover, Bottom Sheet, Modals & FAB */
        .popover-menu {{
            position: fixed;
            z-index: 900;
            min-width: 196px;
            background: var(--bg-surface);
            border: 1px solid var(--line-strong);
            border-radius: 10px;
            padding: 6px;
            display: none;
            flex-direction: column;
            gap: 2px;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.45);
        }}
        .popover-menu.active {{ display: flex; }}
        .pop-item {{
            width: 100%;
            min-height: 36px;
            padding: 0 10px;
            border: none;
            border-radius: 6px;
            background: transparent;
            color: var(--ink);
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            text-align: left;
            cursor: pointer;
            text-decoration: none;
        }}
        .pop-item:hover {{ background: var(--bg-hover); }}
        .pop-item.danger {{ color: var(--danger-text); }}

        .sheet-backdrop {{
            position: fixed;
            inset: 0;
            z-index: 1100;
            background: var(--scrim);
            display: none;
            align-items: flex-end;
            justify-content: center;
        }}
        .sheet-backdrop.active {{ display: flex; }}
        .bottom-sheet {{
            width: 100%;
            max-width: 520px;
            background: var(--bg-surface);
            border-top: 1px solid var(--line-strong);
            border-radius: 16px 16px 0 0;
            padding: 8px 16px calc(16px + env(safe-area-inset-bottom));
            display: flex;
            flex-direction: column;
            gap: 6px;
            max-height: 82dvh;
            overflow-y: auto;
        }}
        .sheet-handle {{
            width: 36px;
            height: 4px;
            border-radius: 999px;
            background: var(--line-strong);
            margin: 0 auto 6px;
        }}
        .sheet-action-btn {{
            width: 100%;
            min-height: 48px;
            padding: 0 12px;
            border-radius: 10px;
            border: none;
            background: transparent;
            color: var(--ink);
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
            text-align: left;
            cursor: pointer;
            text-decoration: none;
        }}
        .sheet-action-btn:hover {{ background: var(--bg-hover); }}
        .sheet-action-btn.danger {{ color: var(--danger-text); }}

        .modal-backdrop {{
            position: fixed;
            inset: 0;
            z-index: 1050;
            background: var(--scrim);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }}
        .modal-backdrop.active {{ display: flex; }}
        .modal-card {{
            width: 100%;
            max-width: 400px;
            background: var(--bg-surface);
            border: 1px solid var(--line-strong);
            border-radius: 16px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 14px;
        }}
        .modal-actions {{
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            flex-wrap: wrap;
        }}

        .mobile-fab {{
            display: none;
            position: fixed;
            right: 16px;
            bottom: calc(16px + env(safe-area-inset-bottom));
            z-index: 60;
            width: 56px;
            height: 56px;
            border-radius: 999px;
            border: 1px solid var(--btn-primary-border);
            background: var(--btn-primary-bg);
            color: var(--btn-primary-ink);
            box-shadow: var(--btn-primary-shadow);
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }}

        /* Upload HUD & Toasts */
        .upload-hud {{
            position: fixed;
            left: 16px;
            bottom: 16px;
            z-index: 950;
            width: calc(100vw - 32px);
            max-width: 360px;
            background: var(--bg-surface);
            border: 1px solid var(--line-strong);
            border-radius: 12px;
            padding: 12px 14px;
            display: none;
            flex-direction: column;
            gap: 8px;
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.45);
        }}
        .upload-hud.active {{ display: flex; }}
        .progress-track {{
            width: 100%;
            height: 4px;
            border-radius: 999px;
            background: var(--progress-track);
            overflow: hidden;
        }}
        .progress-fill {{
            height: 100%;
            width: 0%;
            background: var(--accent);
            transition: width 150ms ease;
        }}
        .toast-stack {{
            position: fixed;
            top: 64px;
            right: 16px;
            z-index: 1200;
            display: flex;
            flex-direction: column;
            gap: 8px;
            max-width: min(360px, calc(100vw - 32px));
        }}
        .toast {{
            padding: 10px 14px;
            border-radius: 10px;
            border: 1px solid var(--line-strong);
            background: var(--bg-surface);
            color: var(--ink);
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
        }}
        .toast.ok {{ background: var(--ok-bg); border-color: var(--ok-border); color: var(--ok-ink); }}
        .toast.warn {{ background: var(--warn-bg); border-color: var(--warn-border); color: var(--warn-ink); }}
        .toast.danger {{ background: var(--danger-bg); border-color: var(--danger-border); color: var(--danger-ink); }}

        /* E5/E6 100dvh Media & PDF.js Modal */
        .viewer-modal {{
            position: fixed;
            inset: 0;
            z-index: 1300;
            height: 100dvh;
            width: 100vw;
            background: #080A06;
            color: #F8FAFC;
            display: none;
            flex-direction: column;
        }}
        .viewer-modal.active {{ display: flex; }}
        .viewer-bar {{
            height: 48px;
            flex-shrink: 0;
            padding: 0 12px;
            background: #11150D;
            border-bottom: 1px solid rgba(255, 255, 255, 0.14);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
        }}
        .viewer-btn-dark {{
            min-width: 36px;
            min-height: 36px;
            padding: 0 10px;
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            background: rgba(255, 255, 255, 0.08);
            color: #F8FAFC;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
        }}
        .viewer-btn-dark:disabled {{ opacity: 0.4; cursor: not-allowed; }}
        .viewer-stage {{
            flex: 1;
            min-height: 0;
            position: relative;
            overflow: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }}
        .viewer-content {{
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .viewer-content img {{
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 150ms ease;
            cursor: zoom-in;
        }}
        .viewer-content img.zoomed {{
            transform: scale(2);
            cursor: zoom-out;
        }}
        .viewer-content video {{
            max-width: 100%;
            max-height: 100%;
            background: #000000;
            border-radius: 8px;
        }}
        .lightbox-arrow {{
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 10;
            width: 44px;
            height: 44px;
            border-radius: 999px;
            border: 1px solid rgba(255, 255, 255, 0.24);
            background: rgba(17, 21, 13, 0.84);
            color: #F8FAFC;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }}
        .lightbox-arrow:disabled {{ opacity: 0.35; cursor: not-allowed; }}
        .lightbox-prev {{ left: 12px; }}
        .lightbox-next {{ right: 12px; }}
        .pdf-pages-col {{
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            width: 100%;
        }}
        .pdf-page-slot {{
            min-height: 220px;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .pdf-page-slot canvas {{
            border-radius: 6px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
            background: #FFFFFF;
        }}

        @media (max-width: 767px) {{
            .icon-btn, .viewer-btn-dark, .more-btn {{ min-width: 44px; min-height: 44px; }}
            .form-input, .search-input {{ height: 44px; }}
            .editor-desktop-btns {{ display: none !important; }}
            .files-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }}
            .files-table {{ display: none; }}
            .mobile-list {{ display: flex; }}
            .mobile-fab.visible {{ display: inline-flex; }}
            .upload-hud {{ bottom: 88px; }}
            .search-wrap {{ width: 100%; flex: 1 1 100%; }}
        }}
        @media (max-width: 479px) {{
            .hide-xs {{ display: none !important; }}
            .btn-primary.compact-xs {{ padding: 0 10px; }}
        }}
        @media (prefers-reduced-motion: reduce) {{
            *, *::before, *::after {{ transition: none !important; animation: none !important; }}
        }}
    </style>
</head>
<body>
    <header class="topbar">
        <div class="brand-wrap">
            <div class="brand-mark" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg>
            </div>
            <div class="t-heading truncate" id="shareHeaderTitle" title="{safe_label}">{safe_label}</div>
        </div>
        <div class="header-actions">
            <button type="button" class="icon-btn" id="btnShareTheme" aria-label="Switch theme">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
            </button>
            <div class="seg-group" role="group" aria-label="Language">
                <button type="button" class="seg-btn" id="btnLangId">ID</button>
                <button type="button" class="seg-btn" id="btnLangEn">EN</button>
            </div>
            <a class="btn btn-primary compact-xs" id="btnSharePrimaryDownload" href="/api/v1/share/{safe_token}/download">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                <span class="hide-xs" id="lblPrimaryDownload">{dl_btn_label}</span>
            </a>
        </div>
    </header>

    <main class="container" id="shareMainContainer">
        <div class="meta-strip" id="shareMetaStrip">
            <span class="{role_badge_cls}" id="shareRoleBadge">{role_label}</span>
            <span class="pill mono" id="shareMaxSizeBadge" style="{max_size_style}">Max {max_upload_mb} MB</span>
            <span class="pill" id="shareExpiryBadge">{safe_expires}</span>
            <span class="pill mono" id="shareDownloadCountBadge">{dl_count} downloads</span>
        </div>

        <section class="card unlock-card" id="shareUnlockCard" style="display: none;">
            <div class="unlock-icon" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <h1 class="t-display" id="unlockHeading">Password Required</h1>
            <p class="t-meta" id="unlockPrompt" style="margin-top: 6px;">Enter the password to view or download this share.</p>
            <form id="shareUnlockForm">
                <div class="input-wrap">
                    <input type="password" class="form-input" id="sharePasswordInput" autocomplete="current-password" placeholder="Link password">
                    <button type="button" class="pwd-eye" id="btnTogglePassword" aria-label="Show password">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    </button>
                </div>
                <div class="alert-inline" id="shareUnlockError" role="alert"></div>
                <button type="submit" class="btn btn-primary" id="btnUnlockShare" style="width: 100%;">Unlock Link</button>
            </form>
        </section>

        <section class="card" id="shareViewerSection" style="display: none;">
            <div class="preview-stage" id="sharePreviewStage"></div>
        </section>

        <section class="card" id="shareFolderSection" style="display: none;">
            <div class="folder-toolbar">
                <nav class="breadcrumbs" id="shareBreadcrumbs" aria-label="Breadcrumb"></nav>
                <div class="folder-controls">
                    <div class="search-wrap">
                        <input type="search" class="search-input" id="shareSearchInput" aria-label="Search files" placeholder="Search files">
                        <button type="button" class="search-clear" id="btnClearSearch" aria-label="Clear search">&times;</button>
                    </div>
                    <div class="seg-group" role="group" aria-label="View mode">
                        <button type="button" class="seg-btn" id="btnViewGrid" aria-label="Grid view">Grid</button>
                        <button type="button" class="seg-btn" id="btnViewList" aria-label="List view">List</button>
                    </div>
                    <div class="editor-desktop-btns" id="editorToolbarActions" style="display: none;">
                        <button type="button" class="btn btn-sec btn-sm" id="btnEditorNewFolder">New Folder</button>
                        <button type="button" class="btn btn-primary btn-sm" id="btnEditorUpload">Upload Files</button>
                        <input type="file" id="editorFileInput" multiple style="display: none;">
                    </div>
                </div>
            </div>
            <div class="folder-drop-area" id="shareFolderDropArea">
                <div class="drop-overlay" id="shareDropOverlay">
                    <div class="t-heading" id="dropOverlayText">Drop files to upload</div>
                </div>
                <div id="shareFolderContent"></div>
            </div>
        </section>
    </main>

    <button type="button" class="mobile-fab" id="mobileEditorFab" aria-label="Add files or folder">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    </button>

    <div class="popover-menu" id="itemPopover" role="menu"></div>

    <div class="sheet-backdrop" id="fabSheetBackdrop">
        <div class="bottom-sheet" id="fabSheetBox">
            <div class="sheet-handle"></div>
            <button type="button" class="sheet-action-btn" id="fabSheetUpload">Upload Files</button>
            <button type="button" class="sheet-action-btn" id="fabSheetMkdir">New Folder</button>
        </div>
    </div>

    <div class="sheet-backdrop" id="actionSheetBackdrop">
        <div class="bottom-sheet" id="actionSheetBody"></div>
    </div>

    <div class="modal-backdrop" id="mkdirModal" role="dialog" aria-modal="true">
        <div class="modal-card">
            <h2 class="t-heading" id="mkdirModalTitle">New Folder</h2>
            <form id="mkdirForm">
                <input type="text" class="form-input" id="mkdirNameInput" placeholder="Folder name" style="padding: 0 12px; margin-bottom: 10px;">
                <div class="alert-inline" id="mkdirError" role="alert"></div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-sec" id="btnMkdirCancel">Close</button>
                    <button type="submit" class="btn btn-primary" id="btnMkdirSubmit">Create Folder</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-backdrop" id="deleteModal" role="dialog" aria-modal="true">
        <div class="modal-card">
            <h2 class="t-heading" id="deleteModalTitle">Delete item?</h2>
            <p class="t-body" id="deleteModalBody"></p>
            <div class="modal-actions">
                <button type="button" class="btn btn-sec" id="btnDeleteKeep">Keep File</button>
                <button type="button" class="btn btn-danger" id="btnDeleteConfirm">Delete Item</button>
            </div>
        </div>
    </div>

    <div class="upload-hud" id="uploadHud" role="status">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
            <span class="t-body-strong truncate" id="uploadHudName">Uploading...</span>
            <span class="t-label mono" id="uploadHudPct">0%</span>
        </div>
        <div class="progress-track"><div class="progress-fill" id="uploadHudBar"></div></div>
    </div>

    <div class="toast-stack" id="toastContainer" aria-live="polite"></div>

    <div class="viewer-modal" id="mediaViewerModal" role="dialog" aria-modal="true">
        <div class="viewer-bar">
            <div style="display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1;">
                <span class="t-body-strong truncate" id="viewerTitle"></span>
                <span class="t-label mono" id="viewerCounter" style="color: #CBD5E1; flex-shrink: 0;"></span>
            </div>
            <div id="pdfToolbarControls" style="display: none; align-items: center; gap: 4px; flex-shrink: 0;">
                <button type="button" class="viewer-btn-dark" id="btnPdfPrev" aria-label="Previous page">&lsaquo;</button>
                <span class="t-label mono" id="pdfPageIndicator" style="padding: 0 4px;">1 / 1</span>
                <button type="button" class="viewer-btn-dark" id="btnPdfNext" aria-label="Next page">&rsaquo;</button>
                <button type="button" class="viewer-btn-dark hide-xs" id="btnPdfZoomOut" aria-label="Zoom out">-</button>
                <button type="button" class="viewer-btn-dark hide-xs" id="btnPdfFit" aria-label="Fit width">Fit</button>
                <button type="button" class="viewer-btn-dark hide-xs" id="btnPdfZoomIn" aria-label="Zoom in">+</button>
                <a class="viewer-btn-dark" id="btnPdfOpenTab" href="#" target="_blank" rel="noopener noreferrer" aria-label="Open in New Tab">
                    <span class="hide-xs" id="lblPdfOpenTab">New Tab</span>
                </a>
            </div>
            <div style="display: flex; align-items: center; gap: 6px; flex-shrink: 0;">
                <button type="button" class="viewer-btn-dark" id="btnPhotoZoom" style="display: none;" aria-label="Zoom in">1x/2x</button>
                <a class="viewer-btn-dark" id="btnViewerDownload" href="#" aria-label="Download file">
                    <span class="hide-xs" id="lblViewerDownload">Download File</span>
                </a>
                <button type="button" class="viewer-btn-dark" id="btnViewerClose" aria-label="Close preview">&times;</button>
            </div>
        </div>
        <div class="viewer-stage" id="viewerStage">
            <button type="button" class="lightbox-arrow lightbox-prev" id="btnLightboxPrev" aria-label="Previous photo">&lsaquo;</button>
            <div class="viewer-content" id="viewerContent"></div>
            <button type="button" class="lightbox-arrow lightbox-next" id="btnLightboxNext" aria-label="Next photo">&rsaquo;</button>
        </div>
    </div>

    <script>
        (function () {{
            const SHARE_TOKEN = {token_js_json};
            const INIT_ROLE = {init_role_js_json};
            const INIT_IS_DIR = {init_is_dir_js};
            const INIT_MAX_BYTES = {init_max_bytes_js};
            const INIT_EXPIRES = {expires_js_json};
            const INIT_DL_COUNT = {init_dl_count_js};

            const I18N = {{
                en: {{
                    viewer: "Viewer",
                    editor: "Editor",
                    maxPrefix: "Max ",
                    noExpiry: "No expiry",
                    downloads: "downloads",
                    downloadFile: "Download File",
                    downloadZip: "Download ZIP",
                    unlockTitle: "Password Required",
                    unlockPrompt: "Enter the password to view or download this share.",
                    unlockPlaceholder: "Link password",
                    unlockBtn: "Unlock Link",
                    wrongPassword: "Incorrect password. Check with the sender and try again.",
                    searchPlaceholder: "Search files",
                    newFolder: "New Folder",
                    uploadFiles: "Upload Files",
                    dropText: "Drop files to upload",
                    emptyFolder: "Empty folder",
                    emptyWritable: "Upload files or create a folder to get started.",
                    emptyReadOnly: "This folder has no files yet.",
                    noMatches: "No matching files",
                    noMatchesSub: "Try a different file name.",
                    folder: "Folder",
                    deleteItem: "Delete Item",
                    keepFile: "Keep File",
                    deleteConfirm: "Delete",
                    deleteBody: "This item will be permanently removed from this shared folder.",
                    close: "Close",
                    createFolder: "Create Folder",
                    folderNamePlaceholder: "Folder name",
                    fullScreen: "Full Screen",
                    copyText: "Copy",
                    copied: "Copied",
                    loadingPdf: "Loading PDF...",
                    pdfFailed: "Could not render PDF inline. Open in New Tab or Download File instead.",
                    openInNewTab: "Open in New Tab",
                    mediaUnsupported: "Browser cannot play this media format. Download File to view locally.",
                    fileTooLarge: "File exceeds the {{max}} MB upload limit. Choose a smaller file.",
                    autoRenamed: "File existed. Saved as {{name}}",
                    uploadDone: "Uploaded {{count}} file(s)",
                    loadFailed: "Connection failed. Click Refresh to try again.",
                    refresh: "Refresh"
                }},
                id: {{
                    viewer: "Penampil",
                    editor: "Editor",
                    maxPrefix: "Maks ",
                    noExpiry: "Tanpa batas",
                    downloads: "unduhan",
                    downloadFile: "Unduh Berkas",
                    downloadZip: "Unduh ZIP",
                    unlockTitle: "Kata Sandi Diperlukan",
                    unlockPrompt: "Masukkan kata sandi untuk melihat atau mengunduh tautan ini.",
                    unlockPlaceholder: "Kata sandi tautan",
                    unlockBtn: "Buka Tautan",
                    wrongPassword: "Kata sandi salah. Periksa kembali lalu coba lagi.",
                    searchPlaceholder: "Cari berkas",
                    newFolder: "Folder Baru",
                    uploadFiles: "Unggah Berkas",
                    dropText: "Lepaskan berkas untuk mengunggah",
                    emptyFolder: "Folder kosong",
                    emptyWritable: "Unggah berkas atau buat folder baru.",
                    emptyReadOnly: "Belum ada berkas di folder ini.",
                    noMatches: "Berkas tidak ditemukan",
                    noMatchesSub: "Coba kata kunci nama berkas lain.",
                    folder: "Folder",
                    deleteItem: "Hapus Item",
                    keepFile: "Pertahankan Berkas",
                    deleteConfirm: "Hapus",
                    deleteBody: "Item ini akan dihapus dari folder berbagi ini.",
                    close: "Tutup",
                    createFolder: "Buat Folder",
                    folderNamePlaceholder: "Nama folder",
                    fullScreen: "Layar Penuh",
                    copyText: "Salin",
                    copied: "Disalin",
                    loadingPdf: "Memuat PDF...",
                    pdfFailed: "Gagal menampilkan PDF. Gunakan Buka di Tab Baru atau Unduh Berkas.",
                    openInNewTab: "Buka di Tab Baru",
                    mediaUnsupported: "Browser tidak mendukung format ini. Unduh Berkas untuk memutar lokal.",
                    fileTooLarge: "Berkas melebihi batas unggah {{max}} MB. Pilih berkas yang lebih kecil.",
                    autoRenamed: "Nama sudah ada. Disimpan sebagai {{name}}",
                    uploadDone: "{{count}} berkas berhasil diunggah",
                    loadFailed: "Koneksi gagal. Klik Muat Ulang untuk mencoba lagi.",
                    refresh: "Muat Ulang"
                }}
            }};

            let currentLang = (navigator.language || "").toLowerCase().startsWith("id") ? "id" : "en";
            let currentTheme = "dark";
            let viewMode = "grid";
            let currentSubpath = "";
            let currentMeta = null;
            let metaSeq = 0;
            let viewerOpenSeq = 0;
            let galleryImages = [];
            let activeMediaIndex = -1;
            let activeViewerItem = null;
            let pendingDeleteItem = null;
            let lastTapTime = 0;
            let touchStartX = 0;
            let savedScrollY = 0;

            let pdfDocProxy = null;
            let pdfScale = 1.0;
            let pdfFitBaseScale = 1.0;
            let pdfCurrentPage = 1;
            let pdfTotalPages = 1;
            let pdfObserver = null;
            let pdfRenderTasks = new Map();

            try {{
                if (localStorage.myserver_theme === "light" || localStorage.myserver_theme === "dark") currentTheme = localStorage.myserver_theme;
                if (localStorage.myserver_lang === "id" || localStorage.myserver_lang === "en") currentLang = localStorage.myserver_lang;
                if (localStorage.myserver_share_view === "list" || localStorage.myserver_share_view === "grid") viewMode = localStorage.myserver_share_view;
            }} catch (e) {{}}

            function t(key) {{
                return (I18N[currentLang] && I18N[currentLang][key]) || I18N.en[key] || key;
            }}

            function escapeHtml(str) {{
                return String(str == null ? "" : str)
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&#39;");
            }}

            function formatBytes(bytes) {{
                const n = Number(bytes || 0);
                if (n <= 0) return "0 B";
                const units = ["B", "KB", "MB", "GB", "TB"];
                const i = Math.min(units.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
                return (n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + " " + units[i];
            }}

            function formatDate(ts) {{
                if (!ts) return "";
                try {{
                    return new Date(Number(ts) * 1000).toLocaleDateString(currentLang === "id" ? "id-ID" : "en-US", {{
                        year: "numeric", month: "short", day: "numeric"
                    }});
                }} catch (e) {{ return ""; }}
            }}

            function showToast(msg, kind) {{
                const stack = document.getElementById("toastContainer");
                const el = document.createElement("div");
                el.className = "toast" + (kind ? " " + kind : "");
                el.textContent = msg;
                stack.appendChild(el);
                setTimeout(() => {{ el.remove(); }}, 4200);
            }}

            function applyTheme(theme) {{
                currentTheme = theme === "light" ? "light" : "dark";
                document.documentElement.setAttribute("data-theme", currentTheme);
                try {{ localStorage.myserver_theme = currentTheme; }} catch (e) {{}}
            }}

            function applyLang(lang) {{
                currentLang = lang === "id" ? "id" : "en";
                document.documentElement.lang = currentLang;
                try {{ localStorage.myserver_lang = currentLang; }} catch (e) {{}}
                document.getElementById("btnLangId").classList.toggle("active", currentLang === "id");
                document.getElementById("btnLangEn").classList.toggle("active", currentLang === "en");
                document.getElementById("unlockHeading").textContent = t("unlockTitle");
                document.getElementById("unlockPrompt").textContent = t("unlockPrompt");
                document.getElementById("sharePasswordInput").placeholder = t("unlockPlaceholder");
                document.getElementById("btnUnlockShare").textContent = t("unlockBtn");
                document.getElementById("shareSearchInput").placeholder = t("searchPlaceholder");
                document.getElementById("btnEditorNewFolder").textContent = t("newFolder");
                document.getElementById("btnEditorUpload").textContent = t("uploadFiles");
                document.getElementById("fabSheetUpload").textContent = t("uploadFiles");
                document.getElementById("fabSheetMkdir").textContent = t("newFolder");
                document.getElementById("dropOverlayText").textContent = t("dropText");
                document.getElementById("mkdirModalTitle").textContent = t("newFolder");
                document.getElementById("mkdirNameInput").placeholder = t("folderNamePlaceholder");
                document.getElementById("btnMkdirCancel").textContent = t("close");
                document.getElementById("btnMkdirSubmit").textContent = t("createFolder");
                document.getElementById("btnDeleteKeep").textContent = t("keepFile");
                document.getElementById("btnDeleteConfirm").textContent = t("deleteItem");
                document.getElementById("lblPdfOpenTab").textContent = t("openInNewTab");
                document.getElementById("lblViewerDownload").textContent = t("downloadFile");
                renderMetaStrip(currentMeta);
                if (currentMeta) {{
                    if (currentMeta.target_is_dir) renderFolderNavigator(currentMeta);
                    else if (!currentMeta.password_required || currentMeta.unlocked) renderFilePreview(currentMeta);
                }}
            }}

            function renderMetaStrip(meta) {{
                const role = meta ? meta.role : INIT_ROLE;
                const isDir = meta ? Boolean(meta.is_dir) : INIT_IS_DIR;
                const maxBytes = meta ? Number(meta.max_upload_bytes || 0) : INIT_MAX_BYTES;
                const expires = meta ? (meta.expires_at || "") : INIT_EXPIRES;
                const dlCount = meta ? Number(meta.download_count || 0) : INIT_DL_COUNT;
                const targetIsDir = meta ? Boolean(meta.target_is_dir) : INIT_IS_DIR;

                const roleEl = document.getElementById("shareRoleBadge");
                roleEl.textContent = role === "editor" ? t("editor") : t("viewer");
                roleEl.className = role === "editor" ? "pill pill-ok" : "pill";

                const maxEl = document.getElementById("shareMaxSizeBadge");
                if (role === "editor" && isDir && maxBytes > 0) {{
                    maxEl.style.display = "inline-flex";
                    maxEl.textContent = t("maxPrefix") + Math.round(maxBytes / (1024 * 1024)) + " MB";
                }} else {{
                    maxEl.style.display = "none";
                }}

                document.getElementById("shareExpiryBadge").textContent = expires || t("noExpiry");
                document.getElementById("shareDownloadCountBadge").textContent = dlCount + " " + t("downloads");
                document.getElementById("lblPrimaryDownload").textContent = targetIsDir ? t("downloadZip") : t("downloadFile");
            }}

            function categorySvg(item) {{
                if (item.is_dir) {{
                    return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--folder-tint)" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
                }}
                return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--ink-muted)" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
            }}

            function isEditorDirectory(meta) {{
                return Boolean(meta && meta.is_dir && meta.target_is_dir && meta.role === "editor" && meta.can_upload);
            }}

            async function loadShareMeta(subpath) {{
                currentSubpath = subpath || "";
                const seq = ++metaSeq;
                const q = currentSubpath ? ("?subpath=" + encodeURIComponent(currentSubpath)) : "";
                try {{
                    const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/meta" + q, {{
                        credentials: "same-origin"
                    }});
                    if (seq !== metaSeq) return;
                    if (!resp.ok) {{
                        showToast(t("loadFailed"), "danger");
                        return;
                    }}
                    const data = await resp.json();
                    if (seq !== metaSeq) return;
                    currentMeta = data;
                    renderMetaStrip(data);

                    const unlockCard = document.getElementById("shareUnlockCard");
                    const viewerSec = document.getElementById("shareViewerSection");
                    const folderSec = document.getElementById("shareFolderSection");
                    const dlBtn = document.getElementById("btnSharePrimaryDownload");
                    const mainCont = document.getElementById("shareMainContainer");
                    const fab = document.getElementById("mobileEditorFab");
                    const editorBtns = document.getElementById("editorToolbarActions");

                    if (data.password_required && !data.unlocked) {{
                        unlockCard.style.display = "block";
                        viewerSec.style.display = "none";
                        folderSec.style.display = "none";
                        fab.classList.remove("visible");
                        mainCont.classList.remove("has-fab");
                        return;
                    }}

                    unlockCard.style.display = "none";
                    if (dlBtn && data.download_url) dlBtn.href = data.download_url;

                    if (data.target_is_dir) {{
                        folderSec.style.display = "block";
                        viewerSec.style.display = "none";
                        const canEdit = isEditorDirectory(data);
                        editorBtns.style.display = canEdit ? "flex" : "none";
                        fab.classList.toggle("visible", canEdit);
                        mainCont.classList.toggle("has-fab", canEdit);
                        renderFolderNavigator(data);
                    }} else {{
                        folderSec.style.display = "none";
                        viewerSec.style.display = "block";
                        editorBtns.style.display = "none";
                        fab.classList.remove("visible");
                        mainCont.classList.remove("has-fab");
                        renderFilePreview(data);
                    }}
                }} catch (e) {{
                    if (seq === metaSeq) showToast(t("loadFailed"), "danger");
                }}
            }}

            function renderFilePreview(meta) {{
                const stage = document.getElementById("sharePreviewStage");
                stage.innerHTML = "";
                const kind = meta.preview_kind || "file";
                if (kind === "image") {{
                    galleryImages = [meta];
                    const img = document.createElement("img");
                    img.src = meta.stream_url;
                    img.alt = meta.name || meta.label || "";
                    stage.appendChild(img);
                    const fsBtn = document.createElement("button");
                    fsBtn.type = "button";
                    fsBtn.className = "btn btn-sec";
                    fsBtn.textContent = t("fullScreen");
                    fsBtn.addEventListener("click", () => openLightbox(meta));
                    stage.appendChild(fsBtn);
                }} else if (kind === "video") {{
                    const vid = document.createElement("video");
                    vid.controls = true;
                    vid.playsInline = true;
                    vid.preload = "metadata";
                    vid.src = meta.stream_url;
                    vid.onerror = () => {{
                        stage.innerHTML = '<div class="state-center"><p class="t-body">' + escapeHtml(t("mediaUnsupported")) + '</p><a class="btn btn-primary" href="' + escapeHtml(meta.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div>';
                    }};
                    stage.appendChild(vid);
                }} else if (kind === "audio") {{
                    const box = document.createElement("div");
                    box.style.cssText = "max-width:420px;width:100%;padding:20px;border-radius:12px;background:#11150D;color:#F8FAFC;border:1px solid rgba(255,255,255,0.14);display:flex;flex-direction:column;gap:12px;align-items:center;";
                    box.innerHTML = '<div class="t-heading truncate" style="width:100%;text-align:center;">' + escapeHtml(meta.name || meta.label || "") + '</div><div class="t-meta mono">' + escapeHtml(formatBytes(meta.size)) + '</div>';
                    const aud = document.createElement("audio");
                    aud.controls = true;
                    aud.preload = "metadata";
                    aud.style.width = "100%";
                    aud.src = meta.stream_url;
                    aud.onerror = () => {{
                        const errP = document.createElement("p");
                        errP.className = "t-meta";
                        errP.textContent = t("mediaUnsupported");
                        box.appendChild(errP);
                    }};
                    box.appendChild(aud);
                    stage.appendChild(box);
                }} else if (kind === "pdf") {{
                    renderInlinePdfStage(stage, meta);
                }} else if (kind === "text" && meta.text_preview != null) {{
                    const copyBtn = document.createElement("button");
                    copyBtn.type = "button";
                    copyBtn.className = "btn btn-sec btn-sm";
                    copyBtn.style.alignSelf = "flex-end";
                    copyBtn.textContent = t("copyText");
                    copyBtn.addEventListener("click", () => {{
                        if (navigator.clipboard) navigator.clipboard.writeText(meta.text_preview || "").catch(() => {{}});
                        copyBtn.textContent = t("copied");
                        setTimeout(() => {{ copyBtn.textContent = t("copyText"); }}, 1500);
                    }});
                    const pre = document.createElement("pre");
                    pre.className = "mono";
                    pre.textContent = meta.text_preview;
                    stage.appendChild(copyBtn);
                    stage.appendChild(pre);
                }} else {{
                    const box = document.createElement("div");
                    box.className = "state-center";
                    box.innerHTML = '<div class="t-body-strong">' + escapeHtml(meta.name || meta.label || "File") + '</div><div class="t-meta mono">' + escapeHtml(formatBytes(meta.size)) + '</div><a class="btn btn-primary" href="' + escapeHtml(meta.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a>';
                    stage.appendChild(box);
                }}
            }}

            async function renderInlinePdfStage(stage, meta) {{
                const inlineUrl = meta.stream_url + (meta.stream_url.includes("?") ? "&" : "?") + "inline=1";
                const wrap = document.createElement("div");
                wrap.className = "inline-pdf-wrap";
                wrap.innerHTML = '<div class="inline-pdf-bar"><span class="t-label mono">PDF</span><div style="display:flex;gap:8px;flex-wrap:wrap;"><a class="btn btn-sec btn-sm" href="' + escapeHtml(inlineUrl) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(t("openInNewTab")) + '</a><a class="btn btn-primary btn-sm" href="' + escapeHtml(meta.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div></div>';
                const box = document.createElement("div");
                box.className = "inline-pdf-canvas-box";
                box.innerHTML = '<div class="state-center"><div class="spinner"></div><span class="t-body" style="color:#F8FAFC;">' + escapeHtml(t("loadingPdf")) + '</span></div>';
                wrap.appendChild(box);
                stage.appendChild(wrap);
                try {{
                    const pdfjsLib = await import("/static/pdfjs/pdf.min.mjs");
                    pdfjsLib.GlobalWorkerOptions.workerSrc = "/static/pdfjs/pdf.worker.min.mjs";
                    const doc = await pdfjsLib.getDocument({{ url: meta.stream_url, withCredentials: true }}).promise;
                    box.innerHTML = "";
                    const maxW = Math.max(260, box.clientWidth - 24);
                    const dpr = Math.min(2, window.devicePixelRatio || 1);
                    for (let p = 1; p <= doc.numPages; p++) {{
                        const page = await doc.getPage(p);
                        const baseVp = page.getViewport({{ scale: 1 }});
                        const sc = Math.min(2.0, Math.max(0.5, maxW / baseVp.width));
                        const vp = page.getViewport({{ scale: sc }});
                        const canvas = document.createElement("canvas");
                        canvas.width = Math.floor(vp.width * dpr);
                        canvas.height = Math.floor(vp.height * dpr);
                        canvas.style.width = Math.floor(vp.width) + "px";
                        canvas.style.height = Math.floor(vp.height) + "px";
                        box.appendChild(canvas);
                        const ctx = canvas.getContext("2d");
                        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                        await page.render({{ canvasContext: ctx, viewport: vp }}).promise;
                    }}
                }} catch (e) {{
                    box.innerHTML = '<div class="state-center"><p class="t-body" style="color:#F8FAFC;max-width:340px;">' + escapeHtml(t("pdfFailed")) + '</p><div style="display:flex;gap:8px;flex-wrap:wrap;"><a class="btn btn-sec" href="' + escapeHtml(inlineUrl) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(t("openInNewTab")) + '</a><a class="btn btn-primary" href="' + escapeHtml(meta.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div></div>';
                }}
            }}

            function renderFolderNavigator(meta) {{
                const crumbsEl = document.getElementById("shareBreadcrumbs");
                crumbsEl.innerHTML = "";
                const rootBtn = document.createElement("button");
                rootBtn.type = "button";
                rootBtn.className = "crumb-btn" + (!meta.subpath ? " current" : "");
                rootBtn.textContent = meta.label || "Root";
                rootBtn.addEventListener("click", () => loadShareMeta(""));
                crumbsEl.appendChild(rootBtn);

                if (meta.subpath) {{
                    const parts = meta.subpath.split("/").filter(Boolean);
                    let acc = "";
                    parts.forEach((part, idx) => {{
                        acc = acc ? (acc + "/" + part) : part;
                        const targetSub = acc;
                        const sep = document.createElement("span");
                        sep.className = "t-meta";
                        sep.textContent = "/";
                        crumbsEl.appendChild(sep);
                        const btn = document.createElement("button");
                        btn.type = "button";
                        btn.className = "crumb-btn" + (idx === parts.length - 1 ? " current" : "");
                        btn.textContent = part;
                        btn.addEventListener("click", () => loadShareMeta(targetSub));
                        crumbsEl.appendChild(btn);
                    }});
                }}

                document.getElementById("btnViewGrid").classList.toggle("active", viewMode === "grid");
                document.getElementById("btnViewList").classList.toggle("active", viewMode === "list");

                const query = (document.getElementById("shareSearchInput").value || "").trim().toLowerCase();
                document.getElementById("btnClearSearch").style.display = query ? "inline-flex" : "none";
                const allItems = meta.items || [];
                const items = query ? allItems.filter((it) => (it.name || "").toLowerCase().includes(query)) : allItems;
                galleryImages = allItems.filter((it) => !it.is_dir && it.preview_kind === "image");

                const container = document.getElementById("shareFolderContent");
                container.innerHTML = "";

                if (items.length === 0) {{
                    const empty = document.createElement("div");
                    empty.className = "state-center";
                    if (query) {{
                        empty.innerHTML = '<div class="t-heading">' + escapeHtml(t("noMatches")) + '</div><div class="t-meta">' + escapeHtml(t("noMatchesSub")) + '</div>';
                    }} else {{
                        const sub = isEditorDirectory(meta) ? t("emptyWritable") : t("emptyReadOnly");
                        empty.innerHTML = '<div class="t-heading">' + escapeHtml(t("emptyFolder")) + '</div><div class="t-meta">' + escapeHtml(sub) + '</div>';
                    }}
                    container.appendChild(empty);
                    return;
                }}

                if (viewMode === "grid") {{
                    const grid = document.createElement("div");
                    grid.className = "files-grid";
                    items.forEach((item) => {{
                        const card = document.createElement("div");
                        card.className = "file-card";
                        card.tabIndex = 0;
                        const extText = item.is_dir ? "" : String(item.extension || "").replace(".", "").toUpperCase();
                        const thumbHtml = item.preview_kind === "image"
                            ? '<img src="' + escapeHtml(item.stream_url) + '" alt="" loading="lazy">'
                            : categorySvg(item) + (extText ? '<span class="ext-chip">' + escapeHtml(extText) + '</span>' : '');
                        const subLine = item.is_dir ? t("folder") : formatBytes(item.size);
                        card.innerHTML = '<div class="card-thumb">' + thumbHtml + '</div><div class="card-footer"><div class="card-meta-col"><div class="t-body-strong truncate" title="' + escapeHtml(item.name) + '">' + escapeHtml(item.name) + '</div><div class="t-meta mono">' + escapeHtml(subLine) + '</div></div><button type="button" class="more-btn" aria-label="Actions for ' + escapeHtml(item.name) + '">&#8942;</button></div>';
                        card.addEventListener("click", () => handleItemOpen(item));
                        card.addEventListener("keydown", (ev) => {{
                            if (ev.key === "Enter" || ev.key === " ") {{ ev.preventDefault(); handleItemOpen(item); }}
                        }});
                        const moreBtn = card.querySelector(".more-btn");
                        moreBtn.addEventListener("click", (ev) => {{
                            ev.stopPropagation();
                            openItemMenu(item, moreBtn);
                        }});
                        grid.appendChild(card);
                    }});
                    container.appendChild(grid);
                }} else {{
                    const table = document.createElement("table");
                    table.className = "files-table";
                    table.innerHTML = '<thead><tr><th>Name</th><th>Size</th><th>Modified</th><th style="width:44px;"></th></tr></thead>';
                    const tbody = document.createElement("tbody");
                    const mList = document.createElement("div");
                    mList.className = "mobile-list";

                    items.forEach((item) => {{
                        const subLine = item.is_dir ? t("folder") : formatBytes(item.size);
                        const dateStr = formatDate(item.mtime);

                        const tr = document.createElement("tr");
                        tr.className = "list-row";
                        tr.tabIndex = 0;
                        tr.innerHTML = '<td><div class="row-name-cell">' + categorySvg(item) + '<span class="t-body-strong truncate" title="' + escapeHtml(item.name) + '">' + escapeHtml(item.name) + '</span></div></td><td class="t-meta mono">' + escapeHtml(subLine) + '</td><td class="t-meta mono">' + escapeHtml(dateStr) + '</td><td><button type="button" class="more-btn" aria-label="Actions for ' + escapeHtml(item.name) + '">&#8942;</button></td>';
                        tr.addEventListener("click", () => handleItemOpen(item));
                        const deskMore = tr.querySelector(".more-btn");
                        deskMore.addEventListener("click", (ev) => {{ ev.stopPropagation(); openItemMenu(item, deskMore); }});
                        tbody.appendChild(tr);

                        const mRow = document.createElement("div");
                        mRow.className = "mobile-row";
                        mRow.innerHTML = categorySvg(item) + '<div style="flex:1;min-width:0;"><div class="t-body-strong truncate">' + escapeHtml(item.name) + '</div><div class="t-meta mono">' + escapeHtml(subLine + (dateStr ? " · " + dateStr : "")) + '</div></div><button type="button" class="more-btn" aria-label="Actions for ' + escapeHtml(item.name) + '">&#8942;</button>';
                        mRow.addEventListener("click", () => handleItemOpen(item));
                        const mobMore = mRow.querySelector(".more-btn");
                        mobMore.addEventListener("click", (ev) => {{ ev.stopPropagation(); openItemMenu(item, mobMore); }});
                        mList.appendChild(mRow);
                    }});
                    table.appendChild(tbody);
                    container.appendChild(table);
                    container.appendChild(mList);
                }}
            }}

            function handleItemOpen(item) {{
                if (item.is_dir) {{
                    loadShareMeta(item.subpath);
                    return;
                }}
                savedScrollY = window.scrollY || 0;
                const kind = item.preview_kind || "file";
                if (kind === "image") openLightbox(item);
                else if (kind === "video" || kind === "audio") openMediaPlayer(item);
                else if (kind === "pdf") openPdfViewer(item);
                else if (kind === "text") openTextPreview(item);
                else window.location.href = item.download_url;
            }}

            function closeItemMenus() {{
                document.getElementById("itemPopover").classList.remove("active");
                document.getElementById("actionSheetBackdrop").classList.remove("active");
            }}

            function openItemMenu(item, anchorEl) {{
                closeItemMenus();
                const canDelete = Boolean(isEditorDirectory(currentMeta) && item.can_delete === true);
                const dlLabel = item.is_dir ? t("downloadZip") : t("downloadFile");

                if (window.innerWidth < 768) {{
                    const body = document.getElementById("actionSheetBody");
                    body.innerHTML = '<div class="sheet-handle"></div><div class="t-body-strong truncate" style="padding:4px 12px 8px;border-bottom:1px solid var(--line);">' + escapeHtml(item.name) + '</div>';
                    const dlLink = document.createElement("a");
                    dlLink.className = "sheet-action-btn";
                    dlLink.href = item.download_url;
                    dlLink.textContent = dlLabel;
                    dlLink.addEventListener("click", closeItemMenus);
                    body.appendChild(dlLink);
                    if (canDelete) {{
                        const delBtn = document.createElement("button");
                        delBtn.type = "button";
                        delBtn.className = "sheet-action-btn danger";
                        delBtn.textContent = t("deleteItem");
                        delBtn.addEventListener("click", () => {{ closeItemMenus(); openDeleteModal(item); }});
                        body.appendChild(delBtn);
                    }}
                    document.getElementById("actionSheetBackdrop").classList.add("active");
                }} else {{
                    const pop = document.getElementById("itemPopover");
                    pop.innerHTML = "";
                    const dlLink = document.createElement("a");
                    dlLink.className = "pop-item";
                    dlLink.href = item.download_url;
                    dlLink.textContent = dlLabel;
                    dlLink.addEventListener("click", closeItemMenus);
                    pop.appendChild(dlLink);
                    if (canDelete) {{
                        const delBtn = document.createElement("button");
                        delBtn.type = "button";
                        delBtn.className = "pop-item danger";
                        delBtn.textContent = t("deleteItem");
                        delBtn.addEventListener("click", () => {{ closeItemMenus(); openDeleteModal(item); }});
                        pop.appendChild(delBtn);
                    }}
                    const rect = anchorEl.getBoundingClientRect();
                    pop.style.left = Math.max(12, Math.min(window.innerWidth - 208, rect.right - 196)) + "px";
                    pop.style.top = Math.min(window.innerHeight - 120, rect.bottom + 4) + "px";
                    pop.classList.add("active");
                }}
            }}

            function openDeleteModal(item) {{
                pendingDeleteItem = item;
                document.getElementById("deleteModalTitle").textContent = t("deleteConfirm") + ' "' + item.name + '"?';
                document.getElementById("deleteModalBody").textContent = t("deleteBody");
                document.getElementById("deleteModal").classList.add("active");
            }}

            async function confirmDeleteItem() {{
                if (!pendingDeleteItem) return;
                const item = pendingDeleteItem;
                const btn = document.getElementById("btnDeleteConfirm");
                btn.disabled = true;
                try {{
                    const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/delete", {{
                        method: "POST",
                        headers: {{ "Content-Type": "application/json" }},
                        credentials: "same-origin",
                        body: JSON.stringify({{ subpath: item.subpath }})
                    }});
                    if (!resp.ok) {{
                        const err = await resp.json().catch(() => ({{}}));
                        showToast(err.detail || t("loadFailed"), "danger");
                    }} else {{
                        document.getElementById("deleteModal").classList.remove("active");
                        pendingDeleteItem = null;
                        await loadShareMeta(currentSubpath);
                    }}
                }} catch (e) {{
                    showToast(t("loadFailed"), "danger");
                }} finally {{
                    btn.disabled = false;
                }}
            }}

            async function submitMkdir(ev) {{
                ev.preventDefault();
                const name = (document.getElementById("mkdirNameInput").value || "").trim();
                const errEl = document.getElementById("mkdirError");
                errEl.style.display = "none";
                if (!name) return;
                const btn = document.getElementById("btnMkdirSubmit");
                btn.disabled = true;
                try {{
                    const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/mkdir", {{
                        method: "POST",
                        headers: {{ "Content-Type": "application/json" }},
                        credentials: "same-origin",
                        body: JSON.stringify({{ subpath: currentSubpath, name: name }})
                    }});
                    if (!resp.ok) {{
                        const err = await resp.json().catch(() => ({{}}));
                        errEl.textContent = err.detail || t("loadFailed");
                        errEl.style.display = "block";
                    }} else {{
                        document.getElementById("mkdirModal").classList.remove("active");
                        document.getElementById("mkdirNameInput").value = "";
                        await loadShareMeta(currentSubpath);
                    }}
                }} catch (e) {{
                    errEl.textContent = t("loadFailed");
                    errEl.style.display = "block";
                }} finally {{
                    btn.disabled = false;
                }}
            }}

            function uploadSingleFile(file) {{
                return new Promise((resolve) => {{
                    const maxBytes = Number((currentMeta && currentMeta.max_upload_bytes) || 0);
                    const maxMb = maxBytes > 0 ? Math.round(maxBytes / (1024 * 1024)) : 0;
                    if (maxBytes > 0 && file.size > maxBytes) {{
                        showToast(t("fileTooLarge").replace("{{max}}", String(maxMb)), "danger");
                        resolve(false);
                        return;
                    }}
                    const hud = document.getElementById("uploadHud");
                    document.getElementById("uploadHudName").textContent = file.name;
                    document.getElementById("uploadHudPct").textContent = "0%";
                    document.getElementById("uploadHudBar").style.width = "0%";
                    hud.classList.add("active");

                    const xhr = new XMLHttpRequest();
                    xhr.open("POST", "/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/upload");
                    xhr.withCredentials = true;
                    xhr.upload.onprogress = (ev) => {{
                        if (ev.lengthComputable && ev.total > 0) {{
                            const pct = Math.min(100, Math.round((ev.loaded / ev.total) * 100));
                            document.getElementById("uploadHudPct").textContent = pct + "%";
                            document.getElementById("uploadHudBar").style.width = pct + "%";
                        }}
                    }};
                    xhr.onload = () => {{
                        if (xhr.status === 413) {{
                            showToast(t("fileTooLarge").replace("{{max}}", String(maxMb || "?")), "danger");
                            resolve(false);
                            return;
                        }}
                        if (xhr.status >= 200 && xhr.status < 300) {{
                            try {{
                                const data = JSON.parse(xhr.responseText || "{{}}");
                                if (data.renamed && data.saved_name) {{
                                    showToast(t("autoRenamed").replace("{{name}}", data.saved_name), "warn");
                                }}
                            }} catch (e) {{}}
                            resolve(true);
                        }} else {{
                            let msg = t("loadFailed");
                            try {{ msg = JSON.parse(xhr.responseText || "{{}}").detail || msg; }} catch (e) {{}}
                            showToast(msg, "danger");
                            resolve(false);
                        }}
                    }};
                    xhr.onerror = () => {{
                        showToast(t("loadFailed"), "danger");
                        resolve(false);
                    }};
                    const fd = new FormData();
                    fd.append("subpath", currentSubpath || "");
                    fd.append("file", file);
                    xhr.send(fd);
                }});
            }}

            async function handleUploadFiles(fileList) {{
                const files = Array.from(fileList || []);
                if (!files.length || !isEditorDirectory(currentMeta)) return;
                let okCount = 0;
                for (const f of files) {{
                    const ok = await uploadSingleFile(f);
                    if (ok) okCount++;
                }}
                document.getElementById("uploadHud").classList.remove("active");
                if (okCount > 0) {{
                    showToast(t("uploadDone").replace("{{count}}", String(okCount)), "ok");
                    await loadShareMeta(currentSubpath);
                }}
            }}

            /* E5 / E6 Shared Media & PDF.js Modal */
            function resetViewerState() {{
                viewerOpenSeq++;
                const content = document.getElementById("viewerContent");
                const v = content.querySelector("video");
                const a = content.querySelector("audio");
                if (v) v.pause();
                if (a) a.pause();
                if (pdfObserver) {{ pdfObserver.disconnect(); pdfObserver = null; }}
                pdfRenderTasks.forEach((task) => {{ try {{ task.cancel(); }} catch (e) {{}} }});
                pdfRenderTasks.clear();
                if (pdfDocProxy) {{ try {{ pdfDocProxy.destroy(); }} catch (e) {{}} pdfDocProxy = null; }}
                content.innerHTML = "";
                content.style.alignItems = "center";
                document.getElementById("pdfToolbarControls").style.display = "none";
                document.getElementById("btnPhotoZoom").style.display = "none";
                document.getElementById("btnLightboxPrev").style.display = "none";
                document.getElementById("btnLightboxNext").style.display = "none";
                document.getElementById("viewerCounter").textContent = "";
            }}

            function closeMediaViewer() {{
                resetViewerState();
                activeViewerItem = null;
                document.getElementById("mediaViewerModal").classList.remove("active");
                if (savedScrollY) window.scrollTo(0, savedScrollY);
            }}

            function openLightbox(item) {{
                resetViewerState();
                activeViewerItem = item;
                activeMediaIndex = galleryImages.findIndex((x) => x.subpath === item.subpath && x.name === item.name);
                if (activeMediaIndex < 0) {{
                    galleryImages = [item];
                    activeMediaIndex = 0;
                }}
                document.getElementById("btnPhotoZoom").style.display = "inline-flex";
                document.getElementById("mediaViewerModal").classList.add("active");
                renderActiveLightboxImage();
            }}

            function renderActiveLightboxImage() {{
                if (activeMediaIndex < 0 || activeMediaIndex >= galleryImages.length) return;
                const seq = viewerOpenSeq;
                const imgItem = galleryImages[activeMediaIndex];
                activeViewerItem = imgItem;
                document.getElementById("viewerTitle").textContent = imgItem.name || imgItem.label || "";
                document.getElementById("btnViewerDownload").href = imgItem.download_url;
                document.getElementById("viewerCounter").textContent = galleryImages.length > 1 ? (activeMediaIndex + 1) + " / " + galleryImages.length : "";

                const prevBtn = document.getElementById("btnLightboxPrev");
                const nextBtn = document.getElementById("btnLightboxNext");
                if (galleryImages.length > 1) {{
                    prevBtn.style.display = "inline-flex";
                    nextBtn.style.display = "inline-flex";
                    prevBtn.disabled = activeMediaIndex <= 0;
                    nextBtn.disabled = activeMediaIndex >= galleryImages.length - 1;
                }} else {{
                    prevBtn.style.display = "none";
                    nextBtn.style.display = "none";
                }}

                const content = document.getElementById("viewerContent");
                content.innerHTML = '<div class="spinner"></div>';
                const img = document.createElement("img");
                img.src = imgItem.stream_url;
                img.alt = imgItem.name || "";
                img.onload = () => {{
                    if (seq !== viewerOpenSeq) return;
                    content.innerHTML = "";
                    content.appendChild(img);
                }};
                img.onerror = () => {{
                    if (seq !== viewerOpenSeq) return;
                    content.innerHTML = '<div class="state-center"><p class="t-body" style="color:#F8FAFC;">' + escapeHtml(t("mediaUnsupported")) + '</p><a class="btn btn-primary" href="' + escapeHtml(imgItem.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div>';
                }};
                img.addEventListener("click", () => {{
                    const now = Date.now();
                    if (now - lastTapTime < 300) togglePhotoZoom();
                    lastTapTime = now;
                }});
            }}

            function togglePhotoZoom() {{
                const img = document.getElementById("viewerContent").querySelector("img");
                if (!img) return;
                img.classList.toggle("zoomed");
            }}

            function navigateLightbox(dir) {{
                const nextIdx = activeMediaIndex + dir;
                if (nextIdx < 0 || nextIdx >= galleryImages.length) return;
                activeMediaIndex = nextIdx;
                renderActiveLightboxImage();
            }}

            function openMediaPlayer(item) {{
                resetViewerState();
                activeViewerItem = item;
                document.getElementById("viewerTitle").textContent = item.name || "";
                document.getElementById("btnViewerDownload").href = item.download_url;
                const content = document.getElementById("viewerContent");
                if (item.preview_kind === "video") {{
                    const vid = document.createElement("video");
                    vid.controls = true;
                    vid.playsInline = true;
                    vid.preload = "metadata";
                    vid.src = item.stream_url;
                    vid.onerror = () => {{
                        content.innerHTML = '<div class="state-center"><p class="t-body" style="color:#F8FAFC;">' + escapeHtml(t("mediaUnsupported")) + '</p><a class="btn btn-primary" href="' + escapeHtml(item.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div>';
                    }};
                    content.appendChild(vid);
                }} else {{
                    const box = document.createElement("div");
                    box.style.cssText = "max-width:420px;width:100%;padding:24px;border-radius:14px;background:#11150D;border:1px solid rgba(255,255,255,0.15);display:flex;flex-direction:column;gap:14px;align-items:center;";
                    box.innerHTML = '<div class="t-heading truncate" style="width:100%;text-align:center;">' + escapeHtml(item.name) + '</div><div class="t-meta mono">' + escapeHtml(formatBytes(item.size)) + '</div>';
                    const aud = document.createElement("audio");
                    aud.controls = true;
                    aud.preload = "metadata";
                    aud.style.width = "100%";
                    aud.src = item.stream_url;
                    aud.onerror = () => {{
                        const errP = document.createElement("p");
                        errP.className = "t-meta";
                        errP.textContent = t("mediaUnsupported");
                        box.appendChild(errP);
                    }};
                    box.appendChild(aud);
                    content.appendChild(box);
                }}
                document.getElementById("mediaViewerModal").classList.add("active");
            }}

            async function openTextPreview(item) {{
                resetViewerState();
                activeViewerItem = item;
                const seq = viewerOpenSeq;
                document.getElementById("viewerTitle").textContent = item.name || "";
                document.getElementById("btnViewerDownload").href = item.download_url;
                const content = document.getElementById("viewerContent");
                content.innerHTML = '<div class="spinner"></div>';
                document.getElementById("mediaViewerModal").classList.add("active");
                try {{
                    const res = await fetch(item.stream_url, {{ credentials: "same-origin" }});
                    if (seq !== viewerOpenSeq) return;
                    if (!res.ok) throw new Error();
                    const txt = await res.text();
                    if (seq !== viewerOpenSeq) return;
                    const pre = document.createElement("pre");
                    pre.className = "mono";
                    pre.style.cssText = "width:100%;max-width:960px;height:100%;overflow:auto;padding:16px;background:#11150D;border:1px solid rgba(255,255,255,0.13);border-radius:10px;white-space:pre-wrap;word-break:break-word;font-size:12px;color:#F8FAFC;";
                    pre.textContent = txt.slice(0, 262144);
                    content.innerHTML = "";
                    content.appendChild(pre);
                }} catch (e) {{
                    if (seq !== viewerOpenSeq) return;
                    content.innerHTML = '<div class="state-center"><p class="t-body" style="color:#F8FAFC;">' + escapeHtml(t("mediaUnsupported")) + '</p><a class="btn btn-primary" href="' + escapeHtml(item.download_url) + '">' + escapeHtml(t("downloadFile")) + '</a></div>';
                }}
            }}

            async function openPdfViewer(item) {{
                resetViewerState();
                activeViewerItem = item;
                const seq = viewerOpenSeq;
                document.getElementById("viewerTitle").textContent = item.name || "";
                document.getElementById("btnViewerDownload").href = item.download_url;
                document.getElementById("pdfToolbarControls").style.display = "flex";
                const inlineUrl = item.stream_url + (item.stream_url.includes("?") ? "&" : "?") + "inline=1";
                document.getElementById("btnPdfOpenTab").href = inlineUrl;

                const content = document.getElementById("viewerContent");
                content.innerHTML = '<div class="state-center"><div class="spinner"></div><span class="t-body" style="color:#F8FAFC;">' + escapeHtml(t("loadingPdf")) + '</span></div>';
                document.getElementById("mediaViewerModal").classList.add("active");

                try {{
                    const pdfjsLib = await import("/static/pdfjs/pdf.min.mjs");
                    if (seq !== viewerOpenSeq) return;
                    pdfjsLib.GlobalWorkerOptions.workerSrc = "/static/pdfjs/pdf.worker.min.mjs";
                    pdfDocProxy = await pdfjsLib.getDocument({{ url: item.stream_url, withCredentials: true }}).promise;
                    if (seq !== viewerOpenSeq) return;
                    pdfTotalPages = pdfDocProxy.numPages || 1;
                    pdfCurrentPage = 1;
                    const firstPage = await pdfDocProxy.getPage(1);
                    if (seq !== viewerOpenSeq) return;
                    const stageW = Math.max(280, document.getElementById("viewerStage").clientWidth - 48);
                    const baseVp = firstPage.getViewport({{ scale: 1 }});
                    pdfFitBaseScale = Math.min(2.0, Math.max(0.5, stageW / baseVp.width));
                    pdfScale = pdfFitBaseScale;
                    buildPdfPageSlots(seq);
                    updatePdfToolbarState();
                }} catch (e) {{
                    if (seq !== viewerOpenSeq) return;
                    content.innerHTML = '<div class="state-center"><p class="t-body" style="color:#F8FAFC;max-width:360px;">' + escapeHtml(t("pdfFailed")) + '</p><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;"><a href="' + escapeHtml(inlineUrl) + '" target="_blank" rel="noopener noreferrer" class="btn btn-sec">' + escapeHtml(t("openInNewTab")) + '</a><a href="' + escapeHtml(item.download_url) + '" class="btn btn-primary">' + escapeHtml(t("downloadFile")) + '</a></div></div>';
                }}
            }}

            function buildPdfPageSlots(seq) {{
                const content = document.getElementById("viewerContent");
                content.style.alignItems = "flex-start";
                content.innerHTML = "";
                const col = document.createElement("div");
                col.className = "pdf-pages-col";
                content.appendChild(col);
                if (pdfObserver) pdfObserver.disconnect();
                pdfObserver = new IntersectionObserver((entries) => {{
                    entries.forEach((entry) => {{
                        if (entry.isIntersecting) {{
                            const pageNum = Number(entry.target.dataset.page);
                            renderPdfPageSlot(entry.target, pageNum, seq);
                            if (entry.intersectionRatio > 0.4) {{
                                pdfCurrentPage = pageNum;
                                updatePdfToolbarState();
                            }}
                        }}
                    }});
                }}, {{ root: document.getElementById("viewerStage"), threshold: [0.1, 0.5] }});
                for (let p = 1; p <= pdfTotalPages; p++) {{
                    const slot = document.createElement("div");
                    slot.className = "pdf-page-slot";
                    slot.dataset.page = String(p);
                    col.appendChild(slot);
                    pdfObserver.observe(slot);
                }}
            }}

            async function renderPdfPageSlot(slot, pageNum, seq) {{
                if (!pdfDocProxy || seq !== viewerOpenSeq || slot.dataset.renderedScale === String(pdfScale)) return;
                slot.dataset.renderedScale = String(pdfScale);
                try {{
                    const page = await pdfDocProxy.getPage(pageNum);
                    if (seq !== viewerOpenSeq) return;
                    const dpr = Math.min(2, window.devicePixelRatio || 1);
                    const vp = page.getViewport({{ scale: pdfScale }});
                    const canvas = document.createElement("canvas");
                    canvas.width = Math.floor(vp.width * dpr);
                    canvas.height = Math.floor(vp.height * dpr);
                    canvas.style.width = Math.floor(vp.width) + "px";
                    canvas.style.height = Math.floor(vp.height) + "px";
                    slot.innerHTML = "";
                    slot.appendChild(canvas);
                    const prevTask = pdfRenderTasks.get(pageNum);
                    if (prevTask) {{ try {{ prevTask.cancel(); }} catch (e) {{}} }}
                    const ctx = canvas.getContext("2d");
                    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                    const task = page.render({{ canvasContext: ctx, viewport: vp }});
                    pdfRenderTasks.set(pageNum, task);
                    await task.promise;
                }} catch (e) {{}}
            }}

            function updatePdfToolbarState() {{
                document.getElementById("pdfPageIndicator").textContent = pdfCurrentPage + " / " + pdfTotalPages;
                document.getElementById("btnPdfPrev").disabled = pdfCurrentPage <= 1;
                document.getElementById("btnPdfNext").disabled = pdfCurrentPage >= pdfTotalPages;
            }}

            function pdfJumpPage(delta) {{
                const target = Math.max(1, Math.min(pdfTotalPages, pdfCurrentPage + delta));
                pdfCurrentPage = target;
                updatePdfToolbarState();
                const slot = document.querySelector('#viewerContent .pdf-page-slot[data-page="' + target + '"]');
                if (slot) slot.scrollIntoView({{ behavior: "smooth", block: "start" }});
            }}

            async function unlockProtectedShare(ev) {{
                ev.preventDefault();
                const pwdInput = document.getElementById("sharePasswordInput");
                const errEl = document.getElementById("shareUnlockError");
                const btn = document.getElementById("btnUnlockShare");
                errEl.style.display = "none";
                btn.disabled = true;
                try {{
                    const resp = await fetch("/api/v1/share/" + encodeURIComponent(SHARE_TOKEN) + "/auth", {{
                        method: "POST",
                        headers: {{ "Content-Type": "application/json" }},
                        credentials: "same-origin",
                        body: JSON.stringify({{ password: pwdInput.value || "" }})
                    }});
                    if (!resp.ok) {{
                        errEl.textContent = t("wrongPassword");
                        errEl.style.display = "block";
                        return;
                    }}
                    await loadShareMeta(currentSubpath);
                }} finally {{
                    btn.disabled = false;
                }}
            }}

            window.addEventListener("DOMContentLoaded", () => {{
                applyTheme(currentTheme);
                applyLang(currentLang);

                document.getElementById("btnShareTheme").addEventListener("click", () => applyTheme(currentTheme === "light" ? "dark" : "light"));
                document.getElementById("btnLangId").addEventListener("click", () => applyLang("id"));
                document.getElementById("btnLangEn").addEventListener("click", () => applyLang("en"));

                document.getElementById("shareUnlockForm").addEventListener("submit", unlockProtectedShare);
                document.getElementById("btnTogglePassword").addEventListener("click", () => {{
                    const inp = document.getElementById("sharePasswordInput");
                    inp.type = inp.type === "password" ? "text" : "password";
                }});

                document.getElementById("btnViewGrid").addEventListener("click", () => {{
                    viewMode = "grid";
                    try {{ localStorage.myserver_share_view = "grid"; }} catch (e) {{}}
                    if (currentMeta) renderFolderNavigator(currentMeta);
                }});
                document.getElementById("btnViewList").addEventListener("click", () => {{
                    viewMode = "list";
                    try {{ localStorage.myserver_share_view = "list"; }} catch (e) {{}}
                    if (currentMeta) renderFolderNavigator(currentMeta);
                }});
                document.getElementById("shareSearchInput").addEventListener("input", () => {{
                    if (currentMeta) renderFolderNavigator(currentMeta);
                }});
                document.getElementById("btnClearSearch").addEventListener("click", () => {{
                    document.getElementById("shareSearchInput").value = "";
                    if (currentMeta) renderFolderNavigator(currentMeta);
                }});

                document.getElementById("btnEditorUpload").addEventListener("click", () => document.getElementById("editorFileInput").click());
                document.getElementById("editorFileInput").addEventListener("change", (ev) => {{
                    handleUploadFiles(ev.target.files);
                    ev.target.value = "";
                }});
                document.getElementById("btnEditorNewFolder").addEventListener("click", () => {{
                    document.getElementById("mkdirError").style.display = "none";
                    document.getElementById("mkdirModal").classList.add("active");
                    document.getElementById("mkdirNameInput").focus();
                }});

                document.getElementById("mobileEditorFab").addEventListener("click", () => {{
                    document.getElementById("fabSheetBackdrop").classList.add("active");
                }});
                document.getElementById("fabSheetBackdrop").addEventListener("click", (ev) => {{
                    if (ev.target.id === "fabSheetBackdrop") ev.currentTarget.classList.remove("active");
                }});
                document.getElementById("fabSheetUpload").addEventListener("click", () => {{
                    document.getElementById("fabSheetBackdrop").classList.remove("active");
                    document.getElementById("editorFileInput").click();
                }});
                document.getElementById("fabSheetMkdir").addEventListener("click", () => {{
                    document.getElementById("fabSheetBackdrop").classList.remove("active");
                    document.getElementById("mkdirError").style.display = "none";
                    document.getElementById("mkdirModal").classList.add("active");
                }});

                document.getElementById("actionSheetBackdrop").addEventListener("click", (ev) => {{
                    if (ev.target.id === "actionSheetBackdrop") closeItemMenus();
                }});
                document.addEventListener("click", (ev) => {{
                    const pop = document.getElementById("itemPopover");
                    if (pop.classList.contains("active") && !pop.contains(ev.target)) pop.classList.remove("active");
                }});

                document.getElementById("mkdirForm").addEventListener("submit", submitMkdir);
                document.getElementById("btnMkdirCancel").addEventListener("click", () => document.getElementById("mkdirModal").classList.remove("active"));
                document.getElementById("btnDeleteKeep").addEventListener("click", () => document.getElementById("deleteModal").classList.remove("active"));
                document.getElementById("btnDeleteConfirm").addEventListener("click", confirmDeleteItem);

                const dropArea = document.getElementById("shareFolderDropArea");
                const dropOv = document.getElementById("shareDropOverlay");
                dropArea.addEventListener("dragover", (ev) => {{
                    if (!isEditorDirectory(currentMeta)) return;
                    ev.preventDefault();
                    dropOv.classList.add("active");
                }});
                dropArea.addEventListener("dragleave", (ev) => {{
                    if (!dropArea.contains(ev.relatedTarget)) dropOv.classList.remove("active");
                }});
                dropArea.addEventListener("drop", (ev) => {{
                    dropOv.classList.remove("active");
                    if (!isEditorDirectory(currentMeta)) return;
                    ev.preventDefault();
                    if (ev.dataTransfer && ev.dataTransfer.files) handleUploadFiles(ev.dataTransfer.files);
                }});

                document.getElementById("btnViewerClose").addEventListener("click", closeMediaViewer);
                document.getElementById("btnPhotoZoom").addEventListener("click", togglePhotoZoom);
                document.getElementById("btnLightboxPrev").addEventListener("click", () => navigateLightbox(-1));
                document.getElementById("btnLightboxNext").addEventListener("click", () => navigateLightbox(1));
                document.getElementById("btnPdfPrev").addEventListener("click", () => pdfJumpPage(-1));
                document.getElementById("btnPdfNext").addEventListener("click", () => pdfJumpPage(1));
                document.getElementById("btnPdfZoomOut").addEventListener("click", () => {{
                    pdfScale = Math.max(0.5, Number((pdfScale - 0.25).toFixed(2)));
                    buildPdfPageSlots(viewerOpenSeq);
                }});
                document.getElementById("btnPdfFit").addEventListener("click", () => {{
                    pdfScale = pdfFitBaseScale;
                    buildPdfPageSlots(viewerOpenSeq);
                }});
                document.getElementById("btnPdfZoomIn").addEventListener("click", () => {{
                    pdfScale = Math.min(2.5, Number((pdfScale + 0.25).toFixed(2)));
                    buildPdfPageSlots(viewerOpenSeq);
                }});

                const stage = document.getElementById("viewerStage");
                stage.addEventListener("touchstart", (ev) => {{
                    if (ev.touches && ev.touches.length === 1) touchStartX = ev.touches[0].clientX;
                }}, {{ passive: true }});
                stage.addEventListener("touchend", (ev) => {{
                    if (!ev.changedTouches || !ev.changedTouches.length) return;
                    const img = document.getElementById("viewerContent").querySelector("img");
                    if (!img || img.classList.contains("zoomed")) return;
                    const dx = ev.changedTouches[0].clientX - touchStartX;
                    if (Math.abs(dx) >= 48) navigateLightbox(dx < 0 ? 1 : -1);
                }}, {{ passive: true }});

                document.addEventListener("keydown", (ev) => {{
                    if (ev.key === "Escape") {{
                        closeItemMenus();
                        document.getElementById("fabSheetBackdrop").classList.remove("active");
                        document.getElementById("mkdirModal").classList.remove("active");
                        document.getElementById("deleteModal").classList.remove("active");
                        if (document.getElementById("mediaViewerModal").classList.contains("active")) closeMediaViewer();
                    }} else if (document.getElementById("mediaViewerModal").classList.contains("active")) {{
                        if (ev.key === "ArrowLeft") navigateLightbox(-1);
                        else if (ev.key === "ArrowRight") navigateLightbox(1);
                    }}
                }});

                loadShareMeta("");
            }});
        }})();
    </script>
</body>
</html>"""


@router.get("/s/{token}", response_class=HTMLResponse, include_in_schema=False)
def get_public_share_viewer_page(token: str, request: Request = None):
    """Menyajikan halaman HTML Public Share Viewer mandiri (200 aktif, 404 tidak ditemukan, 410 kedaluwarsa/dicabut)."""
    db_path = _db_path()
    share = get_public_share(token, db_path=db_path, include_secret=False)
    if not share:
        html_404 = render_public_share_viewer_html(
            None,
            status_code=404,
            error_title="Tautan Tidak Ditemukan",
            error_message="Tautan berbagi publik yang Anda akses tidak ditemukan atau tidak valid.",
        )
        return HTMLResponse(content=html_404, status_code=404)

    if share.get("revoked") or share.get("is_expired") or share.get("status") != "active":
        html_410 = render_public_share_viewer_html(
            share,
            status_code=410,
            error_title="Tautan Kedaluwarsa",
            error_message="Tautan berbagi publik ini telah melewati masa berlaku atau dicabut oleh pemiliknya.",
        )
        return HTMLResponse(content=html_410, status_code=410)

    html_200 = render_public_share_viewer_html(share, status_code=200)
    resp = HTMLResponse(content=html_200, status_code=200)
    if share.get("role") == "editor" and bool(share.get("is_dir")):
        if not extract_uploader_sid(request=request) and hasattr(resp, "set_cookie"):
            _, cookie_val = issue_uploader_sid()
            resp.set_cookie(
                key=UPLOADER_COOKIE_NAME,
                value=cookie_val,
                max_age=UPLOADER_COOKIE_TTL_SECONDS,
                path="/",
                httponly=True,
                samesite="lax",
            )
    return resp


@router.post("/api/v1/share/{token}/auth")
def authenticate_public_share(
    token: str,
    req: PublicShareAuthRequest,
    response: Response = None,
    request: Request = None,
):
    """Memverifikasi kata sandi tautan berbagi publik dan menerbitkan cookie sesi HMAC."""
    enforce_rate_limit(f"share:auth:{token}", max_attempts=15, window_seconds=60.0)
    db_path = _db_path()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    pwd_hash = str(share.get("password_hash") or "").strip()
    if pwd_hash:
        if not req or not req.password or not verify_password(str(req.password), pwd_hash):
            raise HTTPException(status_code=401, detail="Kata sandi tautan tidak valid.")
    reset_rate_limit_bucket(f"share:auth:{token}")

    access_token = create_share_access_token(
        share["token"],
        pwd_hash,
        ttl_seconds=SHARE_SESSION_TTL_SECONDS,
    )
    cookie_key = share_cookie_name(share["token"])
    if response is not None and hasattr(response, "set_cookie"):
        response.set_cookie(
            key=cookie_key,
            value=access_token,
            max_age=SHARE_SESSION_TTL_SECONDS,
            path="/",
            httponly=True,
            samesite="lax",
        )
        if share.get("role") == "editor" and bool(share.get("is_dir")):
            if not extract_uploader_sid(request=request):
                _, uploader_cookie_val = issue_uploader_sid()
                response.set_cookie(
                    key=UPLOADER_COOKIE_NAME,
                    value=uploader_cookie_val,
                    max_age=UPLOADER_COOKIE_TTL_SECONDS,
                    path="/",
                    httponly=True,
                    samesite="lax",
                )
    return {
        "success": True,
        "token": share["token"],
        "access_token": access_token,
        "cookie_name": cookie_key,
        "expires_in": SHARE_SESSION_TTL_SECONDS,
    }


@router.get("/api/v1/share/{token}/meta")
def get_public_share_metadata(
    token: str,
    subpath: Optional[str] = Query(default=""),
    request: Request = None,
):
    """Mengembalikan metadata berkas atau daftar isi sub-folder di dalam direktori yang dibagikan."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    unlocked = is_share_request_unlocked(share, request=request)
    uploader_sid = extract_uploader_sid(request=request)
    return build_share_meta_payload(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        unlocked=unlocked,
        db_path=db_path,
        uploader_sid=uploader_sid,
    )


@router.get("/api/v1/share/{token}/stream")
def stream_public_share_content(
    token: str,
    subpath: Optional[str] = Query(default=""),
    inline: bool = Query(default=False),
    request: Request = None,
):
    """Menyajikan konten berkas inline dengan dukungan HTTP Range (206 Partial Content) dan header keamanan CSP."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    _, target_abs, _ = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        db_path=db_path,
    )
    if os.path.isdir(target_abs):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    range_header = None
    req_headers = None
    req_method = "GET"
    if request is not None:
        req_headers = getattr(request, "headers", None)
        req_method = getattr(request, "method", "GET") or "GET"
        if req_headers and hasattr(req_headers, "get"):
            range_header = req_headers.get("range") or req_headers.get("Range")

    return stream_file_range(target_abs, range_header=range_header, request_headers=req_headers, method=req_method, inline=inline)


@router.get("/api/v1/share/{token}/download")
@router.head("/api/v1/share/{token}/download")
def download_public_share_content(
    token: str,
    subpath: Optional[str] = Query(default=""),
    request: Request = None,
):
    """Mengunduh berkas tunggal atau melakukan streaming arsip .zip on-the-fly untuk folder, sembari menambah download_count."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    _, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    target_rel, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=subpath,
        db_path=db_path,
    )

    head_only = request is not None and str(getattr(request, "method", "GET")).upper() == "HEAD"
    if not head_only:
        increment_share_download_count(share["token"], db_path=db_path)
        try:
            log_activity(
                None,
                None,
                "PUBLIC_SHARE_DOWNLOAD",
                f"Unduhan publik pada tautan '{share['token']}' ({target_rel})",
                {"token": share["token"], "path": target_rel, "subpath": clean_sub},
                db_path=db_path,
            )
        except Exception:
            pass

    if os.path.isdir(target_abs):
        archive_base = os.path.basename(target_abs) if clean_sub else (share.get("label") or os.path.basename(target_abs))
        safe_zip_name = (
            os.path.basename(str(archive_base or "shared_folder").strip())
            .replace('"', "_")
            .replace("\r", "")
            .replace("\n", "")
        )
        if not safe_zip_name.lower().endswith(".zip"):
            safe_zip_name = f"{safe_zip_name}.zip"

        zip_gen = iter(()) if head_only else iter_directory_as_zip_bytes(
            share_root_abs=share_root_abs,
            target_dir_abs=target_abs,
            archive_root_name=os.path.splitext(safe_zip_name)[0],
        )

        headers = {
            "Content-Disposition": build_content_disposition("attachment", safe_zip_name),
            "Content-Type": "application/zip",
            "X-Content-Type-Options": "nosniff",
        }
        return StreamingResponse(zip_gen, status_code=200, headers=headers)

    filename = os.path.basename(target_abs)
    file_size = os.path.getsize(target_abs)
    mime_type = mimetypes.guess_type(target_abs)[0] or "application/octet-stream"

    def file_streamer():
        fadv_offset = 0
        fadv_bytes = 0
        fadv_fn = getattr(os, "posix_fadvise", None)
        fadv_flag = getattr(os, "POSIX_FADV_DONTNEED", None)
        with open(target_abs, "rb") as f:
            fd = f.fileno()
            try:
                while chunk := f.read(128 * 1024):
                    fadv_bytes += len(chunk)
                    if fadv_fn is not None and fadv_flag is not None and fadv_bytes >= 2 * 1024 * 1024:
                        try:
                            fadv_fn(fd, fadv_offset, fadv_bytes, fadv_flag)
                        except OSError:
                            pass
                        fadv_offset += fadv_bytes
                        fadv_bytes = 0
                    yield chunk
            finally:
                if fadv_fn is not None and fadv_flag is not None and fadv_bytes > 0:
                    try:
                        fadv_fn(fd, fadv_offset, fadv_bytes, fadv_flag)
                    except OSError:
                        pass

    headers = {
        "Content-Disposition": build_content_disposition("attachment", filename),
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        "Accept-Ranges": "bytes",
        "X-Content-Type-Options": "nosniff",
    }
    return StreamingResponse(iter(()) if head_only else file_streamer(), status_code=200, headers=headers)


@router.post("/api/v1/share/{token}/upload")
async def upload_to_public_share(
    token: str,
    file: UploadFile = File(...),
    subpath: Optional[str] = Form(default=None),
    subpath_query: Optional[str] = Query(default=None, alias="subpath"),
    filename: Optional[str] = Query(default=None),
    filename_form: Optional[str] = Form(default=None, alias="filename"),
    request: Request = None,
    response: Response = None,
):
    """Mengunggah berkas ke tautan berbagi publik Editor dengan streaming byte limit, auto-rename (1), dan pelacakan sesi."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    resolved_sub = subpath if subpath is not None else (subpath_query or "")
    _, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    dir_rel, dir_abs, clean_sub = resolve_share_write_dir(
        storage_root=storage_root,
        share=share,
        subpath=resolved_sub,
        db_path=db_path,
    )

    chosen_name = filename or filename_form or getattr(file, "filename", "") or ""
    raw_name = str(chosen_name).strip().replace("\\", "/")
    if "\x00" in raw_name:
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid.")
    clean_filename = os.path.basename(raw_name)
    if not clean_filename or clean_filename in (".", ".."):
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid.")

    global_max = int(getattr(_app_config, "MAX_UPLOAD_SIZE_BYTES", 4096 * 1024 * 1024))
    share_max = share.get("max_upload_bytes")
    effective_max = min(global_max, int(share_max)) if share_max is not None else global_max

    tmp_file = os.path.join(dir_abs, f".share_upload_{uuid.uuid4().hex[:12]}.tmp")
    bytes_written = 0
    f_out = await asyncio.to_thread(open, tmp_file, "wb")
    try:
        while True:
            chunk = file.read(256 * 1024)
            if inspect.isawaitable(chunk):
                chunk = await chunk
            if not chunk:
                break
            bytes_written += len(chunk)
            if bytes_written > effective_max:
                raise HTTPException(
                    status_code=413,
                    detail=f"Ukuran berkas melebihi batas unggahan tautan ({effective_max} byte).",
                )
            await asyncio.to_thread(f_out.write, chunk)

        def _finalize_atomic() -> Tuple[str, str, bool]:
            f_out.flush()
            os.fsync(f_out.fileno())
            f_out.close()
            with _UPLOAD_RENAME_LOCK:
                saved_name, final_abs, was_renamed = resolve_non_colliding_target(
                    dir_abs, clean_filename, is_dir=False
                )
                final_real = os.path.realpath(final_abs)
                if os.path.commonpath([share_root_abs, final_real]) != share_root_abs:
                    raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")
                os.replace(tmp_file, final_abs)
                return saved_name, final_abs, was_renamed

        saved_name, final_abs, renamed = await asyncio.to_thread(_finalize_atomic)
    except Exception:
        try:
            f_out.close()
        except Exception:
            pass
        if os.path.exists(tmp_file):
            try:
                await asyncio.to_thread(os.remove, tmp_file)
            except Exception:
                pass
        raise

    uploader_sid = extract_uploader_sid(request=request)
    if not uploader_sid:
        uploader_sid, cookie_val = issue_uploader_sid()
        if response is not None and hasattr(response, "set_cookie"):
            response.set_cookie(
                key=UPLOADER_COOKIE_NAME,
                value=cookie_val,
                max_age=UPLOADER_COOKIE_TTL_SECONDS,
                path="/",
                httponly=True,
                samesite="lax",
            )

    item_rel = f"{dir_rel}/{saved_name}" if dir_rel else saved_name
    item_sub = f"{clean_sub}/{saved_name}" if clean_sub else saved_name
    record_public_share_upload(share["token"], item_rel, uploader_sid, is_dir=False, db_path=db_path)

    client_ip = _extract_client_ip(request)
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_UPLOAD",
            f"Unggahan publik pada tautan '{share['token']}' ({item_rel})",
            {
                "token": share["token"],
                "role": share.get("role", "editor"),
                "client_ip": client_ip,
                "rel_path": item_rel,
                "bytes": bytes_written,
            },
            db_path=db_path,
        )
    except Exception:
        pass

    st = os.stat(final_abs)
    item_payload = _build_share_item_dict(
        token=share["token"],
        name=saved_name,
        item_sub=item_sub,
        is_dir=False,
        size=int(st.st_size),
        mtime=int(st.st_mtime),
        can_delete=True,
    )
    return {
        "success": True,
        "filename": clean_filename,
        "saved_name": saved_name,
        "renamed": renamed,
        "bytes_written": bytes_written,
        "subpath": item_sub,
        "rel_path": item_rel,
        "item": item_payload,
    }


@router.post("/api/v1/share/{token}/mkdir")
def create_public_share_folder(
    token: str,
    req: ShareMkdirRequest,
    request: Request = None,
    response: Response = None,
):
    """Membuat sub-folder baru pada tautan berbagi publik Editor dengan auto-rename (1)."""
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    _, share_root_abs = resolve_safe_storage_target(storage_root, share["target_path"])
    dir_rel, dir_abs, clean_sub = resolve_share_write_dir(
        storage_root=storage_root,
        share=share,
        subpath=(req.subpath if req else "") or "",
        db_path=db_path,
    )

    raw_name = req.name if req else ""
    try:
        with _UPLOAD_RENAME_LOCK:
            saved_name, final_abs, renamed = resolve_non_colliding_target(
                dir_abs, raw_name, is_dir=True
            )
            final_real = os.path.realpath(final_abs)
            if os.path.commonpath([share_root_abs, final_real]) != share_root_abs:
                raise HTTPException(status_code=403, detail="Akses keluar dari folder yang dibagikan ditolak.")
            os.makedirs(final_abs, exist_ok=False)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    uploader_sid = extract_uploader_sid(request=request)
    if not uploader_sid:
        uploader_sid, cookie_val = issue_uploader_sid()
        if response is not None and hasattr(response, "set_cookie"):
            response.set_cookie(
                key=UPLOADER_COOKIE_NAME,
                value=cookie_val,
                max_age=UPLOADER_COOKIE_TTL_SECONDS,
                path="/",
                httponly=True,
                samesite="lax",
            )

    item_rel = f"{dir_rel}/{saved_name}" if dir_rel else saved_name
    item_sub = f"{clean_sub}/{saved_name}" if clean_sub else saved_name
    record_public_share_upload(share["token"], item_rel, uploader_sid, is_dir=True, db_path=db_path)

    client_ip = _extract_client_ip(request)
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_MKDIR",
            f"Pembuatan folder publik pada tautan '{share['token']}' ({item_rel})",
            {
                "token": share["token"],
                "role": share.get("role", "editor"),
                "client_ip": client_ip,
                "rel_path": item_rel,
            },
            db_path=db_path,
        )
    except Exception:
        pass

    return {
        "success": True,
        "name": saved_name,
        "saved_name": saved_name,
        "renamed": renamed,
        "subpath": item_sub,
        "rel_path": item_rel,
    }


def _delete_public_share_item_impl(
    token: str,
    subpath: Optional[str],
    request: Request = None,
) -> Dict[str, Any]:
    db_path = _db_path()
    storage_root = _storage_dir()
    share = load_active_share_or_raise(token, db_path=db_path, include_secret=True)
    if not is_share_request_unlocked(share, request=request):
        raise HTTPException(status_code=401, detail="Tautan ini dilindungi kata sandi.")

    share_role = str(share.get("role") or "viewer").strip().lower()
    if share_role != "editor" or not bool(share.get("is_dir")):
        raise HTTPException(
            status_code=403,
            detail="Tautan berbagi ini tidak mengizinkan penghapusan.",
        )

    raw_sub = str(subpath or "").strip().replace("\\", "/").strip("/")
    if not raw_sub:
        raise HTTPException(
            status_code=403,
            detail="Tidak diizinkan menghapus folder root tautan berbagi.",
        )

    target_rel, target_abs, clean_sub = resolve_share_subpath_target(
        storage_root=storage_root,
        share=share,
        subpath=raw_sub,
        db_path=db_path,
    )
    if not clean_sub:
        raise HTTPException(
            status_code=403,
            detail="Tidak diizinkan menghapus folder root tautan berbagi.",
        )

    uploader_sid = extract_uploader_sid(request=request)
    if not uploader_sid or not check_session_can_delete_target(
        share["token"], target_rel, target_abs, uploader_sid, db_path=db_path
    ):
        raise HTTPException(
            status_code=403,
            detail="Hanya item yang diunggah dari sesi peramban ini yang dapat dihapus.",
        )

    is_dir = os.path.isdir(target_abs)
    if is_dir:
        shutil.rmtree(target_abs)
    else:
        os.remove(target_abs)
    remove_public_share_upload_records(share["token"], target_rel, is_dir=is_dir, db_path=db_path)

    client_ip = _extract_client_ip(request)
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_ITEM_DELETE",
            f"Penghapusan item publik pada tautan '{share['token']}' ({target_rel})",
            {
                "token": share["token"],
                "role": share.get("role", "editor"),
                "client_ip": client_ip,
                "rel_path": target_rel,
                "is_dir": is_dir,
            },
            db_path=db_path,
        )
    except Exception:
        pass

    return {
        "success": True,
        "deleted_subpath": clean_sub,
        "rel_path": target_rel,
        "is_dir": is_dir,
    }


@router.post("/api/v1/share/{token}/delete")
def delete_public_share_item_post(
    token: str,
    req: ShareDeleteRequest,
    request: Request = None,
):
    """Menghapus berkas/folder milik sesi pengunggah pada tautan berbagi publik Editor."""
    return _delete_public_share_item_impl(
        token=token,
        subpath=(req.subpath if req else ""),
        request=request,
    )


@router.delete("/api/v1/share/{token}/item")
def delete_public_share_item_delete(
    token: str,
    subpath: str = Query(...),
    request: Request = None,
):
    """Menghapus berkas/folder milik sesi pengunggah melalui metode HTTP DELETE."""
    return _delete_public_share_item_impl(
        token=token,
        subpath=subpath,
        request=request,
    )
