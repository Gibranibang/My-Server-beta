"""
Storage & Directory Browsing Router for MyServer Native Backend
Provides remote folder exploration and directory creation for Remote Folder Picker UI.
"""

import os
import shutil
import time
import mimetypes
import hashlib
import html
import urllib.parse
from typing import Optional, List, Dict, Any, Union
import logging
logger = logging.getLogger(__name__)
try:
    from fastapi import APIRouter, HTTPException, Query, Request, Response, File, UploadFile, Form
    from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
except ImportError:
    class APIRouter:
        def __init__(self, *a, **k): pass
        def __getattr__(self, name): return lambda *a, **k: (lambda f: f)
    HTTPException = Exception
    Query = lambda default=None, **kw: default
    File = Form = lambda default=None, **kw: default
    Request = Response = UploadFile = object
    StreamingResponse = FileResponse = HTMLResponse = object
from pydantic import BaseModel

import app.config
from app.config import STORAGE_DIR, TEMP_DIR, DATA_DIR, DB_PATH
from app.models import (
    StorageBrowseFilesResponse, StorageDiskItem, StorageDisksResponse, DiskEntry,
    CloudAccountItemResponse, CloudAccountListResponse, CloudAccountConnectRequest
)
from app.database import (
    log_activity, track_session, get_active_sessions, get_activity_logs, get_db,
    create_or_update_cloud_account, get_cloud_accounts_by_user, get_cloud_account_by_id,
    delete_cloud_account, get_or_create_user, get_user_by_username
)

router = APIRouter(prefix="/api/v1/storage", tags=["Storage & Folder Picker"])




class MkdirRequest(BaseModel):
    path: str
    username: Optional[str] = None


def is_forbidden_for_user(rel_path: str, username: Optional[str], allowed_disks: Optional[list] = None) -> bool:
    """Memeriksa apakah jalur mencoba mengakses namespace user lain yang privat atau disk yang tidak diizinkan di ZimaOS."""
    if not username or username.lower() in ("admin", "root", "algitha"):
        return False
    parts = [p.lower() for p in rel_path.replace("\\", "/").strip("/").split("/") if p]
    if not parts:
        return False

    # 1. Proteksi isolasi direktori privat PC_Backups
    if "pc_backups" in parts:
        idx = parts.index("pc_backups")
        if len(parts) > idx + 1:
            owner = parts[idx + 1]
            if owner != username.lower():
                return True
            return False
        # rel_path adalah partisi root "PC_Backups" (parts == ['pc_backups'])
        # Pengguna non-admin DILARANG mengakses root PC_Backups KECUALI jika secara eksplisit ada di allowed_disks
        if allowed_disks is not None:
            allowed_norms = set()
            for a in allowed_disks:
                clean_a = a.lower().replace("/media/", "").replace("/data/", "").strip("/").replace(" ", "_")
                root_a = clean_a.split("/")[0] if clean_a else ""
                if root_a:
                    allowed_norms.add(root_a)
                if clean_a:
                    allowed_norms.add(clean_a)
            if "pc_backups" in allowed_norms:
                return False
        return True

    # 2. Proteksi disk ZimaOS: periksa apakah root disk diizinkan (ACL eksplisit)
    root_part = parts[0].replace(" ", "_")
    if allowed_disks is not None:
        allowed_norms = set()
        for a in allowed_disks:
            clean_a = a.lower().replace("/media/", "").replace("/data/", "").strip("/").replace(" ", "_")
            root_a = clean_a.split("/")[0] if clean_a else ""
            if root_a:
                allowed_norms.add(root_a)
            if clean_a:
                allowed_norms.add(clean_a)
        if root_part not in allowed_norms:
            return True
        return False

    # User non-admin tanpa allowed_disks eksplisit: dilarang mengakses partisi lain di luar pc_backups
    return True


@router.get("/disks", response_model=StorageDisksResponse)
def get_storage_disks(
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Mengembalikan daftar mount storage/partisi fisik & virtual dan status izin akses akun (Role-Based ACL).
    """
    safe_user = username.strip() if username else "admin"
    is_admin = bool(not safe_user or safe_user.lower() in ("admin", "root", "algitha"))
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    # Jika allowed_disks tidak dipasok via query parameter, ambil otomatis dari profil pengguna di database
    if allowed_list is None and not is_admin:
        try:
            from app.database import get_user_by_username
            user_rec = get_user_by_username(safe_user)
            if user_rec and user_rec.get("allowed_disks"):
                raw_d = json.loads(user_rec["allowed_disks"]) if isinstance(user_rec["allowed_disks"], str) else user_rec["allowed_disks"]
                if isinstance(raw_d, list):
                    allowed_list = [str(x).strip() for x in raw_d if str(x).strip()]
        except Exception:
            pass

    disks: List[StorageDiskItem] = []
    seen_names = set()

    target_storage = getattr(app.config, "STORAGE_DIR", STORAGE_DIR)
    os.makedirs(target_storage, exist_ok=True)

    # 1. Pindai subdirektori langsung di dalam target_storage (partisi / storage pool lokal)
    try:
        for entry in os.scandir(target_storage):
            if entry.is_dir():
                sub_rel = entry.name
                is_accessible = not is_forbidden_for_user(sub_rel, safe_user, allowed_list)

                # Jika pengguna non-admin: irisan ketat dengan disk yang diizinkan (jangan loloskan PC_Backups tanpa izin)
                if not is_admin and not is_accessible:
                    continue

                total_b, used_b, free_b = 0, 0, 0
                try:
                    usage = shutil.disk_usage(entry.path)
                    total_b, used_b, free_b = usage.total, usage.used, usage.free
                except Exception:
                    pass

                disks.append(StorageDiskItem(
                    name=entry.name,
                    relative_path=sub_rel,
                    label=entry.name,
                    mount_point=entry.path,
                    total_bytes=total_b,
                    used_bytes=used_b,
                    free_bytes=free_b,
                    is_accessible=is_accessible
                ))
                seen_names.add(entry.name.lower())
    except Exception as e:
        logger.warning(f"Gagal memindai subdirektori storage: {e}")

    # 2. Jika tidak ada subdirektori atau disk sama sekali di target_storage, daftarkan sebagai root disk default (hanya untuk admin)
    if not disks and is_admin:
        try:
            usage = shutil.disk_usage(target_storage)
            total_b, used_b, free_b = usage.total, usage.used, usage.free
        except Exception:
            total_b, used_b, free_b = 0, 0, 0

        disks.append(StorageDiskItem(
            name="Storage",
            relative_path="",
            label="Storage Utama",
            mount_point=os.path.abspath(target_storage),
            total_bytes=total_b,
            used_bytes=used_b,
            free_bytes=free_b,
            is_accessible=True
        ))

    disks.sort(key=lambda d: d.name.lower())

    return StorageDisksResponse(
        disks=disks,
        total_disks=len(disks),
        username=safe_user,
        is_admin=is_admin
    )


# ==============================================================================
# CLOUD / GOOGLE DRIVE MULTI-ACCOUNT ENDPOINTS
# ==============================================================================

@router.get("/cloud-accounts", response_model=CloudAccountListResponse)
def get_cloud_accounts(
    username: Optional[str] = Query(default="admin"),
    provider: Optional[str] = Query(default=None)
):
    """Mengambil daftar akun cloud (Google Drive, OneDrive) yang tersimpan untuk user yang bersangkutan."""
    u = get_user_by_username(username)
    user_id = u["id"] if u else get_or_create_user(username)
    accounts = get_cloud_accounts_by_user(user_id, provider=provider)
    
    items = [
        CloudAccountItemResponse(
            id=a["id"],
            user_id=a["user_id"],
            provider=a["provider"],
            email=a["email"],
            display_name=a.get("display_name"),
            quota_total=a.get("quota_total", 0),
            quota_used=a.get("quota_used", 0),
            status=a.get("status", "connected"),
            created_at=str(a.get("created_at") or ""),
            updated_at=str(a.get("updated_at") or "")
        )
        for a in accounts
    ]
    return CloudAccountListResponse(
        accounts=items,
        total_count=len(items),
        username=username
    )


@router.post("/cloud-accounts", response_model=CloudAccountItemResponse)
def connect_cloud_account(
    req: CloudAccountConnectRequest,
    username: Optional[str] = Query(default="admin")
):
    """Menyambungkan atau memperbarui akun Google Drive / Cloud storage untuk akun pengguna."""
    u = get_user_by_username(username)
    user_id = u["id"] if u else get_or_create_user(username)
    
    account = create_or_update_cloud_account(
        user_id=user_id,
        email=req.email,
        provider=req.provider,
        display_name=req.display_name,
        access_token=req.access_token,
        refresh_token=req.refresh_token,
        token_expiry=req.token_expiry,
        quota_total=req.quota_total or 16106127360,
        quota_used=req.quota_used or 0,
        status="connected"
    )
    return CloudAccountItemResponse(
        id=account["id"],
        user_id=account["user_id"],
        provider=account["provider"],
        email=account["email"],
        display_name=account.get("display_name"),
        quota_total=account.get("quota_total", 0),
        quota_used=account.get("quota_used", 0),
        status=account.get("status", "connected"),
        created_at=str(account.get("created_at") or ""),
        updated_at=str(account.get("updated_at") or "")
    )


@router.delete("/cloud-accounts/{account_id}")
def remove_cloud_account(
    account_id: int,
    username: Optional[str] = Query(default="admin")
):
    """Memutus koneksi akun cloud storage."""
    u = get_user_by_username(username)
    user_id = u["id"] if u else None
    
    is_admin = bool(not username or username.lower() in ("admin", "root", "algitha") or (u and u.get("role") == "admin"))
    del_user_id = None if is_admin else user_id
    
    ok = delete_cloud_account(account_id, user_id=del_user_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Akun cloud tidak ditemukan atau tidak memiliki akses")
    return {"status": "success", "message": "Akun cloud berhasil diputus", "account_id": account_id}




@router.get("/browse")
def browse_storage(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Menjelajahi direktori folder & disk yang ada di server storage.
    Mendukung penjelajahan multi-disk dan proteksi isolasi multi-user berbasis API ZimaOS.
    """
    rel_req = path.strip().replace("\\", "/").strip("/") if path else ""
    is_regular_user = bool(username and username.lower() not in ("admin", "root", "algitha"))

    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    # Proteksi: cegah akses ke ruang privat user lain atau disk terlarang
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")

    target_dir = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_dir.startswith(os.path.abspath(STORAGE_DIR)):
        target_dir = os.path.abspath(STORAGE_DIR)
        rel_req = ""

    os.makedirs(target_dir, exist_ok=True)

    dirs = []
    try:
        for entry in os.scandir(target_dir):
            if entry.is_dir():
                sub_rel = (f"{rel_req}/{entry.name}" if rel_req else entry.name).replace("\\", "/")
                # Sembunyikan folder user lain atau disk yang tidak diotorisasi
                if is_forbidden_for_user(sub_rel, username, allowed_list):
                    continue
                dirs.append({
                    "name": entry.name,
                    "relative_path": sub_rel
                })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori: {e}")

    dirs.sort(key=lambda x: x["name"].lower())
    parent = os.path.dirname(rel_req).replace("\\", "/") if rel_req else ""

    return {
        "current_path": rel_req,
        "parent_path": parent,
        "directories": dirs
    }


@router.post("/mkdir")
def make_directory(
    req: MkdirRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Membuat direktori baru di dalam storage server dengan proteksi hak akses multi-user."""
    dir_name = req.path.strip().replace("\\", "/").strip("/")
    if not dir_name:
        raise HTTPException(status_code=400, detail="Path direktori tidak boleh kosong")

    eff_user = username or req.username
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(dir_name, eff_user, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat direktori di dalam ruang akun pengguna lain atau disk yang tidak diotorisasi.")

    target_dir = os.path.normpath(os.path.join(STORAGE_DIR, dir_name))
    if not target_dir.startswith(os.path.abspath(STORAGE_DIR)):
        raise HTTPException(status_code=400, detail="Akses path tidak diizinkan")

    os.makedirs(target_dir, exist_ok=True)
    try:
        log_activity(None, None, "STORAGE_MKDIR", f"User '{eff_user or 'anonymous'}' membuat direktori '{dir_name}'", {"path": dir_name})
    except Exception:
        pass
    return {"success": True, "created_path": dir_name}


@router.get("/browse-files", response_model=StorageBrowseFilesResponse)
def browse_files_and_folders(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Menjelajahi berkas dan folder (metadata lengkap: ukuran, ekstensi, mime_type, mtime) di server storage.
    Mendukung isolasi hak akses multi-user dan integrasi ZimaOS multi-disk.
    """
    rel_req = path.strip().replace("\\", "/").strip("/") if path else ""
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")

    target_dir = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_dir.startswith(os.path.abspath(STORAGE_DIR)):
        target_dir = os.path.abspath(STORAGE_DIR)
        rel_req = ""

    os.makedirs(target_dir, exist_ok=True)

    items = []
    try:
        for entry in os.scandir(target_dir):
            sub_rel = (f"{rel_req}/{entry.name}" if rel_req else entry.name).replace("\\", "/")
            if is_forbidden_for_user(sub_rel, username, allowed_list):
                continue

            try:
                st = entry.stat()
                is_dir = entry.is_dir()
                size = 0 if is_dir else st.st_size
                mtime = int(st.st_mtime)
            except Exception:
                is_dir = entry.is_dir()
                size = 0
                mtime = 0

            ext = "" if is_dir else os.path.splitext(entry.name)[1].lower()
            mime_type = "inode/directory" if is_dir else (mimetypes.guess_type(entry.name)[0] or "application/octet-stream")

            items.append({
                "name": entry.name,
                "relative_path": sub_rel,
                "is_dir": is_dir,
                "size": size,
                "mtime": mtime,
                "extension": ext,
                "mime_type": mime_type
            })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori berkas: {e}")

    items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    parent = os.path.dirname(rel_req).replace("\\", "/") if rel_req else ""
    folders_count = sum(1 for x in items if x["is_dir"])
    files_count = len(items) - folders_count

    return {
        "current_path": rel_req,
        "parent_path": parent,
        "items": items,
        "total_count": len(items),
        "folders_count": folders_count,
        "files_count": files_count
    }


def stream_file_range(full_path: str, range_header: Optional[str] = None):
    """Membangun StreamingResponse dengan dukungan HTTP Range 206 Partial Content."""
    file_size = os.path.getsize(full_path)
    mime_type, _ = mimetypes.guess_type(full_path)
    if not mime_type:
        ext = os.path.splitext(full_path)[1].lower()
        if ext in (".mkv", ".webm"):
            mime_type = "video/webm" if ext == ".webm" else "video/x-matroska"
        elif ext in (".flac", ".m4a"):
            mime_type = "audio/flac" if ext == ".flac" else "audio/mp4"
        else:
            mime_type = "application/octet-stream"

    CHUNK_SIZE = 256 * 1024

    if range_header:
        try:
            h_val = range_header.strip()
            if h_val.startswith("bytes="):
                range_spec = h_val[6:].strip()
                parts = range_spec.split("-")
                start = int(parts[0]) if parts[0] else 0
                end = int(parts[1]) if len(parts) > 1 and parts[1] else file_size - 1
                if 0 <= start <= end and end < file_size:
                    content_length = end - start + 1

                    def range_generator(start_pos, length):
                        with open(full_path, "rb") as f:
                            f.seek(start_pos)
                            remaining = length
                            while remaining > 0:
                                read_bytes = min(CHUNK_SIZE, remaining)
                                data = f.read(read_bytes)
                                if not data:
                                    break
                                remaining -= len(data)
                                yield data

                    headers = {
                        "Content-Range": f"bytes {start}-{end}/{file_size}",
                        "Accept-Ranges": "bytes",
                        "Content-Length": str(content_length),
                        "Content-Type": mime_type,
                    }
                    return StreamingResponse(range_generator(start, content_length), status_code=206, headers=headers)
        except Exception:
            pass

    def full_generator():
        with open(full_path, "rb") as f:
            while chunk := f.read(CHUNK_SIZE):
                yield chunk

    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
    }
    return StreamingResponse(full_generator(), status_code=200, headers=headers)


@router.get("/stream")
def stream_media(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Streaming HTTP Range 206 Partial Content untuk pemutaran video, audio, dan dokumen langsung dari server.
    Mendukung seeking posisi pada pemutar media bawaan (VLC, Windows Media Player, Browser).
    """
    rel_req = path.strip().replace("\\", "/").strip("/")
    if not rel_req:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas dari direktori terlarang.")

    target_file = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_file.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    range_header = request.headers.get("range")
    session_id = request.headers.get("x-session-id") or f"sess_{abs(hash(target_file))}_{int(time.time() // 60)}"
    client_ip = request.client.host if (request.client and request.client.host) else "unknown"
    try:
        track_session(session_id, username or "anonymous", rel_req, client_ip, session_type="stream")
        if not range_header or range_header.startswith("bytes=0-"):
            log_activity(None, None, "STORAGE_STREAM", f"User '{username or 'anonymous'}' memutar stream '{os.path.basename(target_file)}'", {"path": rel_req, "ip": client_ip})
    except Exception:
        pass
    return stream_file_range(target_file, range_header)


@router.get("/player", response_class=HTMLResponse)
def get_media_player(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Menyediakan UI Web Player modern (HTML5) yang seragam antara Browser dan Native Desktop App (Edge App Mode).
    Mendukung video, audio, gambar dengan keyboard shortcuts, range seeking, dan responsif.
    """
    rel_req = path.strip().replace("\\", "/").strip("/")
    if not rel_req:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    target_file = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_file.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    filename = os.path.basename(target_file)
    ext = os.path.splitext(filename)[1].lower()
    stream_url = f"/api/v1/storage/stream?path={urllib.parse.quote(rel_req)}"
    if username:
        stream_url += f"&username={urllib.parse.quote(username)}"
    if allowed_disks:
        stream_url += f"&allowed_disks={urllib.parse.quote(allowed_disks)}"

    download_url = f"/api/v1/storage/download?path={urllib.parse.quote(rel_req)}"
    if username:
        download_url += f"&username={urllib.parse.quote(username)}"

    is_video = ext in (".mp4", ".mkv", ".webm", ".mov", ".avi", ".ts")
    is_audio = ext in (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".wma")
    is_image = ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg")

    if is_video:
        media_tag = f"""<video id="player" controls autoplay playsinline preload="metadata">
            <source src="{stream_url}">
            Peramban Anda tidak mendukung pemutaran video HTML5.
        </video>"""
    elif is_audio:
        media_tag = f"""<div class="audio-card">
            <div class="audio-icon">🎵</div>
            <div class="audio-title">{html.escape(filename)}</div>
            <div class="audio-path">{html.escape(rel_req)}</div>
            <audio id="player" controls autoplay preload="metadata" src="{stream_url}"></audio>
        </div>"""
    elif is_image:
        media_tag = f"""<div class="img-container">
            <img id="imgViewer" src="{stream_url}" alt="{html.escape(filename)}" />
        </div>"""
    else:
        media_tag = f"""<div class="fallback-card">
            <div class="icon">📄</div>
            <h2>{html.escape(filename)}</h2>
            <p>Format berkas ini ({ext}) tidak dapat diputar langsung di pemutar web.</p>
            <a href="{download_url}" class="btn-download" download>Unduh Berkas</a>
        </div>"""

    html_content = f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyServer Media Player - {html.escape(filename)}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background-color: #0b0f19;
            color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
            user-select: none;
        }}
        .header {{
            background-color: #111827;
            border-bottom: 1px solid #1f2937;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 52px;
            z-index: 10;
        }}
        .brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 600;
            color: #38bdf8;
        }}
        .file-info {{
            display: flex;
            flex-direction: column;
            max-width: 60%;
            overflow: hidden;
        }}
        .file-title {{
            font-size: 14px;
            font-weight: 600;
            color: #f1f5f9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .file-sub {{
            font-size: 11px;
            color: #94a3b8;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .actions {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .btn {{
            background-color: #1f2937;
            border: 1px solid #374151;
            color: #e2e8f0;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            text-decoration: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }}
        .btn:hover {{
            background-color: #374151;
            color: #ffffff;
        }}
        .player-viewport {{
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #030712;
            position: relative;
            overflow: hidden;
        }}
        video {{
            width: 100%;
            height: 100%;
            max-width: 100vw;
            max-height: calc(100vh - 52px);
            outline: none;
            background: #000;
        }}
        .audio-card {{
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 16px;
            padding: 36px 44px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
            max-width: 480px;
            width: 90%;
        }}
        .audio-icon {{
            font-size: 48px;
            background: #1e293b;
            width: 90px;
            height: 90px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(56, 189, 248, 0.2);
        }}
        .audio-title {{
            font-size: 17px;
            font-weight: 600;
            color: #f8fafc;
            text-align: center;
            word-break: break-all;
        }}
        .audio-path {{
            font-size: 12px;
            color: #64748b;
            text-align: center;
        }}
        audio {{
            width: 320px;
            outline: none;
            margin-top: 10px;
        }}
        .img-container {{
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        .img-container img {{
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 4px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.7);
        }}
        .fallback-card {{
            background: #111827;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            max-width: 420px;
        }}
        .fallback-card .icon {{ font-size: 48px; margin-bottom: 12px; }}
        .fallback-card h2 {{ font-size: 16px; margin-bottom: 8px; }}
        .fallback-card p {{ font-size: 13px; color: #94a3b8; margin-bottom: 20px; }}
        .btn-download {{
            background: #0284c7;
            color: white;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">
            <span>⚡ MyServer Player</span>
        </div>
        <div class="file-info">
            <span class="file-title">{html.escape(filename)}</span>
            <span class="file-sub">{html.escape(rel_req)}</span>
        </div>
        <div class="actions">
            <a href="{download_url}" class="btn" title="Unduh berkas">⬇️ Unduh</a>
            <button class="btn" onclick="toggleFullscreen()" title="Layar Penuh (F)">⛶ Layar Penuh</button>
        </div>
    </div>
    <div class="player-viewport">
        {media_tag}
    </div>
    <script>
        const p = document.getElementById('player');
        function toggleFullscreen() {{
            if (!document.fullscreenElement) {{
                document.documentElement.requestFullscreen().catch(() => {{}});
            }} else {{
                document.exitFullscreen().catch(() => {{}});
            }}
        }}
        window.addEventListener('keydown', (e) => {{
            if (!p) return;
            if (e.key === ' ' || e.code === 'Space') {{
                e.preventDefault();
                p.paused ? p.play() : p.pause();
            }} else if (e.key === 'ArrowRight') {{
                p.currentTime = Math.min(p.duration || 0, p.currentTime + 5);
            }} else if (e.key === 'ArrowLeft') {{
                p.currentTime = Math.max(0, p.currentTime - 5);
            }} else if (e.key === 'ArrowUp') {{
                e.preventDefault();
                p.volume = Math.min(1, p.volume + 0.1);
            }} else if (e.key === 'ArrowDown') {{
                e.preventDefault();
                p.volume = Math.max(0, p.volume - 0.1);
            }} else if (e.key.toLowerCase() === 'f') {{
                toggleFullscreen();
            }} else if (e.key.toLowerCase() === 'm') {{
                p.muted = !p.muted;
            }}
        }});
    </script>
</body>
</html>"""
    return HTMLResponse(content=html_content)


@router.get("/download")
def download_file(
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Mengunduh berkas langsung dari server storage tanpa kompresi ZIP."""
    rel_req = path.strip().replace("\\", "/").strip("/")
    if not rel_req:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunduh berkas dari direktori terlarang.")

    target_file = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_file.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    filename = os.path.basename(target_file)
    file_size = os.path.getsize(target_file)
    mime_type, _ = mimetypes.guess_type(target_file)
    mime_type = mime_type or "application/octet-stream"

    try:
        log_activity(None, None, "STORAGE_DOWNLOAD", f"User '{username or 'anonymous'}' mengunduh '{filename}'", {"path": rel_req, "size": file_size})
    except Exception:
        pass

    def file_streamer():
        with open(target_file, "rb") as f:
            while chunk := f.read(256 * 1024):
                yield chunk

    headers = {
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        "Accept-Ranges": "bytes",
    }
    return StreamingResponse(file_streamer(), headers=headers)


@router.post("/upload")
async def upload_direct_file(
    file: UploadFile = File(...),
    path: Optional[str] = Form(default=None),
    path_param: Optional[str] = Query(default=None, alias="path"),
    filename: Optional[str] = Query(default=None),
    filename_form: Optional[str] = Form(default=None, alias="filename"),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Mengunggah berkas langsung ke direktori storage yang ditentukan."""
    resolved_path = (path if path is not None else path_param) or ""
    rel_req = resolved_path.strip().replace("\\", "/").strip("/")
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah berkas ke direktori terlarang.")

    target_dir = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_dir.startswith(os.path.abspath(STORAGE_DIR)):
        raise HTTPException(status_code=400, detail="Akses path tidak diizinkan")

    os.makedirs(target_dir, exist_ok=True)
    # Gunakan filename eksplisit jika tersedia agar tidak bergantung pada nama snapshot lokal
    chosen_name = filename or filename_form or file.filename
    clean_filename = os.path.basename(chosen_name.strip().replace("\\", "/"))
    target_file = os.path.join(target_dir, clean_filename)

    bytes_written = 0
    with open(target_file, "wb") as f_out:
        while True:
            chunk = await file.read(256 * 1024)
            if not chunk:
                break
            f_out.write(chunk)
            bytes_written += len(chunk)

    try:
        log_activity(None, None, "STORAGE_UPLOAD", f"User '{username or 'anonymous'}' mengunggah '{clean_filename}'", {"path": f"{rel_req}/{clean_filename}".strip("/"), "bytes": bytes_written})
    except Exception:
        pass

    return {
        "success": True,
        "filename": clean_filename,
        "bytes_written": bytes_written,
        "relative_path": f"{rel_req}/{clean_filename}".strip("/")
    }


@router.get("/activity-logs")
def get_storage_activity_logs(
    limit: int = Query(default=50, ge=1, le=500),
    username: Optional[str] = Query(default=None),
    action: Optional[str] = Query(default=None)
):
    """Mengambil riwayat log aktivitas dan operasi storage (upload, download, stream, dll)."""
    logs = get_activity_logs(limit=limit, username=username, action=action)
    return {"logs": logs, "total": len(logs)}


@router.get("/sessions")
def get_storage_sessions():
    """Mengambil daftar sesi aktif streaming dan akses berkas."""
    sessions = get_active_sessions()
    return {"sessions": sessions, "active_count": len(sessions)}


@router.api_route("/cleanup-temp", methods=["GET", "POST"])
def cleanup_temp_storage(
    max_age_hours: float = Query(default=1.0, ge=0.01)
):
    """
    Membersihkan berkas sementara, potongan chunk kadaluarsa (.part),
    dan sesi unggah terputus yang lebih tua dari batas jam yang ditentukan (default 1 jam).
    """
    cutoff_time = time.time() - (max_age_hours * 3600)
    deleted_files = []
    freed_bytes = 0

    if os.path.exists(TEMP_DIR):
        for root, dirs, files in os.walk(TEMP_DIR, topdown=False):
            for f in files:
                fpath = os.path.join(root, f)
                try:
                    st = os.stat(fpath)
                    if st.st_mtime < cutoff_time or f.endswith(".part"):
                        fsize = st.st_size
                        os.remove(fpath)
                        deleted_files.append(f)
                        freed_bytes += fsize
                except Exception:
                    pass
            if root != TEMP_DIR:
                try:
                    if not os.listdir(root):
                        os.rmdir(root)
                except Exception:
                    pass

    if os.path.exists(STORAGE_DIR):
        for root, _, files in os.walk(STORAGE_DIR):
            for f in files:
                if f.endswith(".part"):
                    fpath = os.path.join(root, f)
                    try:
                        st = os.stat(fpath)
                        if st.st_mtime < cutoff_time:
                            fsize = st.st_size
                            os.remove(fpath)
                            deleted_files.append(f)
                            freed_bytes += fsize
                    except Exception:
                        pass

    try:
        with get_db(DB_PATH) as conn:
            conn.execute("""
                UPDATE upload_sessions 
                SET status = 'failed' 
                WHERE status IN ('pending', 'uploading') 
                AND strftime('%s', 'now') - strftime('%s', created_at) > ?
            """, (int(max_age_hours * 3600),))
    except Exception:
        pass

    try:
        log_activity(
            device_id=None,
            task_id=None,
            action="TEMP_CLEANUP",
            message=f"Pembersihan temp chunk: {len(deleted_files)} berkas dihapus ({freed_bytes} bytes dibebaskan).",
            details={"deleted_count": len(deleted_files), "freed_bytes": freed_bytes}
        )
    except Exception:
        pass

    return {
        "success": True,
        "total_deleted": len(deleted_files),
        "freed_bytes": freed_bytes,
        "deleted_files": deleted_files[:100]
    }


@router.get("/thumbnail")
def get_file_thumbnail(
    path: str = Query(...),
    size: int = Query(default=256, ge=32, le=1024),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """
    Menghasilkan dan mengembalikan thumbnail gambar atau berkas dengan cache cerdas.
    """
    rel_req = path.strip().replace("\\", "/").strip("/")
    if not rel_req:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, username, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    target_file = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_file.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    ext = os.path.splitext(target_file)[1].lower()
    valid_img_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".ico", ".tiff", ".jfif"}
    
    thumb_dir = os.path.join(DATA_DIR, ".thumbnails")
    os.makedirs(thumb_dir, exist_ok=True)

    file_mtime = int(os.path.getmtime(target_file))
    cache_key = hashlib.md5(f"{rel_req}_{file_mtime}_{size}".encode("utf-8")).hexdigest()
    cache_path = os.path.join(thumb_dir, f"{cache_key}.jpg")

    if os.path.exists(cache_path) and os.path.getsize(cache_path) > 0:
        return FileResponse(cache_path, media_type="image/jpeg")

    if ext in valid_img_exts:
        try:
            from PIL import Image, ImageOps
            # Hindari DecompressionBombError pada banner/spanduk/poster beresolusi sangat tinggi
            Image.MAX_IMAGE_PIXELS = None
            with Image.open(target_file) as im:
                im = ImageOps.exif_transpose(im)
                resample_filter = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                im.thumbnail((size, size), resample=resample_filter)
                if im.mode in ("RGBA", "LA", "P"):
                    # Buat canvas putih bersih untuk transparansi PNG
                    background = Image.new("RGB", im.size, (255, 255, 255))
                    if im.mode == "P":
                        im = im.convert("RGBA")
                    if im.mode in ("RGBA", "LA"):
                        background.paste(im, mask=im.split()[-1])
                    else:
                        background.paste(im)
                    im = background
                elif im.mode != "RGB":
                    im = im.convert("RGB")
                im.save(cache_path, format="JPEG", quality=85, optimize=True)
            return FileResponse(cache_path, media_type="image/jpeg")
        except Exception as e:
            logger.error(f"Gagal generate thumbnail untuk {target_file}: {e}")
            raise HTTPException(status_code=500, detail=f"Gagal membuat thumbnail: {str(e)}")
    else:
        raise HTTPException(status_code=415, detail=f"Pembuatan thumbnail tidak didukung untuk tipe berkas {ext}")


class DeleteRequest(BaseModel):
    path: Optional[str] = None
    paths: Optional[List[str]] = None
    username: Optional[str] = None


class CopyMoveRequest(BaseModel):
    src_paths: List[str]
    dest_dir: str
    username: Optional[str] = None


class TouchRequest(BaseModel):
    path: str
    username: Optional[str] = None


@router.post("/touch")
def create_empty_file(
    req: TouchRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Membuat berkas baru kosong di dalam direktori target storage."""
    rel_req = req.path.strip().replace("\\", "/").strip("/")
    if not rel_req:
        raise HTTPException(status_code=400, detail="Path berkas tidak boleh kosong")

    eff_user = username or req.username
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if is_forbidden_for_user(rel_req, eff_user, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")

    target_path = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
    if not target_path.startswith(os.path.abspath(STORAGE_DIR)):
        raise HTTPException(status_code=400, detail="Akses path tidak diizinkan")

    parent_dir = os.path.dirname(target_path)
    os.makedirs(parent_dir, exist_ok=True)

    base_dir = os.path.dirname(rel_req)
    orig_name = os.path.basename(rel_req)
    name_no_ext, ext = os.path.splitext(orig_name)
    counter = 1
    actual_rel = rel_req
    actual_path = target_path
    while os.path.exists(actual_path):
        new_name = f"{name_no_ext} ({counter}){ext}"
        actual_rel = os.path.normpath(os.path.join(base_dir, new_name)).replace("\\", "/")
        actual_path = os.path.normpath(os.path.join(STORAGE_DIR, actual_rel))
        counter += 1

    with open(actual_path, "w", encoding="utf-8") as f:
        pass

    try:
        log_activity(None, None, "STORAGE_TOUCH", f"User '{eff_user or 'anonymous'}' membuat berkas baru '{actual_rel}'", {"path": actual_rel})
    except Exception:
        pass

    return {"success": True, "created_path": actual_rel, "filename": os.path.basename(actual_rel)}


@router.post("/copy")
def copy_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Menyalin berkas atau direktori (Ctrl+C & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    eff_user = username or req.username
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    dest_rel = req.dest_dir.strip().replace("\\", "/").strip("/")
    if is_forbidden_for_user(dest_rel, eff_user, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin ke direktori tujuan.")

    dest_full = os.path.normpath(os.path.join(STORAGE_DIR, dest_rel)) if dest_rel else os.path.abspath(STORAGE_DIR)
    if not dest_full.startswith(os.path.abspath(STORAGE_DIR)):
        raise HTTPException(status_code=400, detail="Akses path tujuan tidak diizinkan")
    os.makedirs(dest_full, exist_ok=True)

    copied_items = []
    import shutil
    for s in req.src_paths:
        src_rel = s.strip().replace("\\", "/").strip("/")
        if not src_rel or is_forbidden_for_user(src_rel, eff_user, allowed_list):
            continue

        src_full = os.path.normpath(os.path.join(STORAGE_DIR, src_rel))
        if not src_full.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(src_full):
            continue

        base_name = os.path.basename(src_full)
        target_item = os.path.join(dest_full, base_name)

        if os.path.exists(target_item):
            name_no_ext, ext = os.path.splitext(base_name)
            counter = 1
            if os.path.dirname(src_full) == dest_full:
                target_item = os.path.join(dest_full, f"{name_no_ext} - Copy{ext}")
            while os.path.exists(target_item):
                target_item = os.path.join(dest_full, f"{name_no_ext} - Copy ({counter}){ext}")
                counter += 1

        try:
            if os.path.isdir(src_full):
                shutil.copytree(src_full, target_item)
            else:
                shutil.copy2(src_full, target_item)
            copied_items.append(os.path.basename(target_item))
        except Exception as e:
            logger.error(f"Gagal menyalin {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_COPY", f"User '{eff_user or 'anonymous'}' menyalin {len(copied_items)} item ke '{dest_rel}'", {"count": len(copied_items), "dest": dest_rel})
    except Exception:
        pass

    return {"success": True, "copied_count": len(copied_items), "items": copied_items}


@router.post("/move")
def move_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Memindahkan berkas atau direktori (Ctrl+X & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    eff_user = username or req.username
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    dest_rel = req.dest_dir.strip().replace("\\", "/").strip("/")
    if is_forbidden_for_user(dest_rel, eff_user, allowed_list):
        raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan ke direktori tujuan.")

    dest_full = os.path.normpath(os.path.join(STORAGE_DIR, dest_rel)) if dest_rel else os.path.abspath(STORAGE_DIR)
    if not dest_full.startswith(os.path.abspath(STORAGE_DIR)):
        raise HTTPException(status_code=400, detail="Akses path tujuan tidak diizinkan")
    os.makedirs(dest_full, exist_ok=True)

    moved_items = []
    import shutil
    for s in req.src_paths:
        src_rel = s.strip().replace("\\", "/").strip("/")
        if not src_rel or is_forbidden_for_user(src_rel, eff_user, allowed_list):
            continue

        src_full = os.path.normpath(os.path.join(STORAGE_DIR, src_rel))
        if not src_full.startswith(os.path.abspath(STORAGE_DIR)) or not os.path.exists(src_full):
            continue

        if os.path.isdir(src_full):
            if dest_full == src_full or dest_full.startswith(src_full + os.sep):
                continue

        base_name = os.path.basename(src_full)
        if os.path.dirname(src_full) == dest_full:
            continue

        target_item = os.path.join(dest_full, base_name)
        if os.path.exists(target_item):
            name_no_ext, ext = os.path.splitext(base_name)
            counter = 1
            while os.path.exists(target_item):
                target_item = os.path.join(dest_full, f"{name_no_ext} ({counter}){ext}")
                counter += 1

        try:
            shutil.move(src_full, target_item)
            moved_items.append(os.path.basename(target_item))
        except Exception as e:
            logger.error(f"Gagal memindahkan {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_MOVE", f"User '{eff_user or 'anonymous'}' memindahkan {len(moved_items)} item ke '{dest_rel}'", {"count": len(moved_items), "dest": dest_rel})
    except Exception:
        pass

    return {"success": True, "moved_count": len(moved_items), "items": moved_items}


@router.post("/delete")
def delete_file_or_folder(
    req: DeleteRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None)
):
    """Menghapus berkas atau direktori (single maupun batch) secara aman dari server storage."""
    target_paths = []
    if req.paths:
        target_paths = [p.strip().replace("\\", "/").strip("/") for p in req.paths if p.strip()]
    elif req.path:
        target_paths = [req.path.strip().replace("\\", "/").strip("/")]

    if not target_paths:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user = username or req.username
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None

    deleted_paths = []
    import shutil
    for rel_req in target_paths:
        if is_forbidden_for_user(rel_req, eff_user, allowed_list):
            continue

        target_path = os.path.normpath(os.path.join(STORAGE_DIR, rel_req))
        if not target_path.startswith(os.path.abspath(STORAGE_DIR)):
            continue

        if not os.path.exists(target_path) or target_path == os.path.abspath(STORAGE_DIR):
            continue

        is_dir = os.path.isdir(target_path)
        try:
            if is_dir:
                shutil.rmtree(target_path)
            else:
                os.remove(target_path)
            deleted_paths.append(rel_req)
        except Exception as e:
            logger.error(f"Gagal menghapus target: {str(e)}")

    try:
        log_activity(None, None, "STORAGE_DELETE", f"User '{eff_user or 'anonymous'}' menghapus {len(deleted_paths)} target", {"deleted_paths": deleted_paths})
    except Exception:
        pass

    return {"success": True, "deleted_count": len(deleted_paths), "deleted_paths": deleted_paths}


@router.get("/explorer", response_class=HTMLResponse)
def get_storage_explorer_page(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None)
):
    """
    Menyajikan Modern Storage Explorer Web Single-Page Application.
    Mendukung tampilan Kartu Grid & List, dynamic thumbnails, video streaming player,
    drag-and-drop upload, dan aksi cepat 'Salin untuk WhatsApp'.
    """
    template_paths = [
        os.path.join(os.path.dirname(__file__), "..", "templates", "explorer.html"),
        os.path.join(os.path.dirname(__file__), "templates", "explorer.html"),
        os.path.join(DATA_DIR, "templates", "explorer.html"),
    ]
    html_content = None
    for p in template_paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    html_content = f.read()
                break
            except Exception:
                pass

    if not html_content:
        html_content = "<html><body><h3>MyServer Explorer: template not found</h3></body></html>"

    return HTMLResponse(content=html_content, status_code=200)







