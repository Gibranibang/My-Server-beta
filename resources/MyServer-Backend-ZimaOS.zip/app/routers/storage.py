"""
Storage & Directory Browsing Router for MyServer Native Backend
Provides remote folder exploration and directory creation for Remote Folder Picker UI.
"""

import asyncio
import concurrent.futures
import email.utils
import os
import json
import re
import shutil
import threading
import time
import mimetypes
import hashlib
import html
import urllib.parse
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any, Union, Tuple
import logging
logger = logging.getLogger(__name__)
try:
    from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, File, UploadFile, Form
    from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
except ImportError:
    Depends = lambda fn=None: fn

    class APIRouter:
        def __init__(self, *a, **k): pass
        def __getattr__(self, name): return lambda *a, **k: (lambda f: f)

    from app.auth import HTTPException
    Query = lambda default=None, **kw: default
    File = Form = lambda default=None, **kw: default
    Request = Response = UploadFile = object

    class _FallbackResponse:
        def __init__(self, content=None, status_code=200, headers=None, media_type=None, path=None):
            self.content = content
            self.body = content.encode("utf-8") if isinstance(content, str) else content
            self.status_code = status_code
            self.headers = headers or {}
            self.media_type = media_type
            self.path = path

    StreamingResponse = FileResponse = HTMLResponse = _FallbackResponse

import app.config
from app.config import STORAGE_DIR, TEMP_DIR, DATA_DIR, DB_PATH, is_admin_username
from app.auth import create_stream_token, get_current_user, verify_active_jwt_user
from app.models import BaseModel
from app.models import (
    StorageBrowseFilesResponse, StorageDiskItem, StorageDisksResponse, DiskEntry,
    CloudAccountItemResponse, CloudAccountListResponse, CloudAccountConnectRequest,
    PublicShareCreateRequest, PublicShareSettingsRequest,
)
from app.database import (
    log_activity, track_session, get_active_sessions, get_activity_logs, get_db,
    create_or_update_cloud_account, get_cloud_accounts_by_user, get_cloud_account_by_id,
    delete_cloud_account, get_or_create_user, get_user_by_username, normalize_user_role,
    create_public_share, get_public_share, list_public_shares, revoke_public_share,
    get_public_base_url, set_public_base_url,
)
from app.services.smb_manager import (
    build_stream_security_headers,
    is_fuse_or_remote_mount,
    is_storage_path_forbidden,
    render_media_player_html,
    resolve_safe_storage_target,
)

router = APIRouter(prefix="/api/v1/storage", tags=["Storage & Folder Picker"])

DISK_USAGE_CACHE_TTL_SEC = 12.0
DISK_USAGE_FUSE_CACHE_TTL_SEC = 60.0
DISK_USAGE_PROBE_TIMEOUT_SEC = 2.5
SCANDIR_FUSE_TIMEOUT_SEC = 4.0
_DISK_USAGE_CACHE_LOCK = threading.Lock()
_DISK_USAGE_CACHE: Dict[str, Tuple[int, int, int, float]] = {}
_DISK_USAGE_INFLIGHT: Dict[str, threading.Thread] = {}
_THUMB_SEMAPHORE = threading.BoundedSemaphore(2)
_THUMB_LAST_PRUNE_TS = 0.0
_STORAGE_JOBS_LOCK = threading.Lock()
_STORAGE_JOBS: Dict[str, Dict[str, Any]] = {}
_STORAGE_CHUNK_UPLOAD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")


def _scandir_bounded(target_dir: str, include_stat: bool = False, timeout_sec: float = SCANDIR_FUSE_TIMEOUT_SEC) -> List[Dict[str, Any]]:
    """Membaca direktori secara aman dengan batas waktu saat target berada di mount FUSE/remote."""
    def _collect() -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        with os.scandir(target_dir) as it:
            for entry in it:
                try:
                    is_dir = entry.is_dir()
                    size = 0
                    mtime = 0
                    if include_stat:
                        try:
                            st = entry.stat()
                            size = 0 if is_dir else int(st.st_size)
                            mtime = int(st.st_mtime)
                        except Exception:
                            pass
                    rows.append({
                        "name": entry.name,
                        "is_dir": is_dir,
                        "size": size,
                        "mtime": mtime,
                    })
                except Exception:
                    continue
        return rows

    if not is_fuse_or_remote_mount(target_dir):
        return _collect()

    pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    fut = pool.submit(_collect)
    try:
        return fut.result(timeout=max(0.5, float(timeout_sec)))
    except concurrent.futures.TimeoutError as exc:
        raise TimeoutError(f"Pembacaan direktori '{target_dir}' timeout (>{timeout_sec}s).") from exc
    finally:
        pool.shutdown(wait=False)


def invalidate_disk_usage_cache(path: Optional[str] = None) -> None:
    """Invalidate cached shutil.disk_usage() entries (all or by canonical path)."""
    with _DISK_USAGE_CACHE_LOCK:
        if path is None:
            _DISK_USAGE_CACHE.clear()
        else:
            _DISK_USAGE_CACHE.pop(os.path.realpath(path), None)


def _get_cached_disk_usage(path: str, ttl_sec: float = DISK_USAGE_CACHE_TTL_SEC) -> Tuple[int, int, int]:
    """Return cached (total, used, free) byte tuple keyed strictly by os.path.realpath(path) with timeout guard."""
    canon = os.path.realpath(path)
    effective_ttl = (
        DISK_USAGE_FUSE_CACHE_TTL_SEC
        if ttl_sec == DISK_USAGE_CACHE_TTL_SEC and is_fuse_or_remote_mount(canon)
        else ttl_sec
    )
    now_mono = time.monotonic()
    stale_entry: Optional[Tuple[int, int, int]] = None
    existing_thread: Optional[threading.Thread] = None
    with _DISK_USAGE_CACHE_LOCK:
        entry = _DISK_USAGE_CACHE.get(canon)
        if entry is not None:
            stale_entry = (entry[0], entry[1], entry[2])
            if (now_mono - entry[3]) < effective_ttl:
                return stale_entry
        cand_thread = _DISK_USAGE_INFLIGHT.get(canon)
        if cand_thread is not None and cand_thread.is_alive():
            existing_thread = cand_thread

    if existing_thread is not None:
        existing_thread.join(timeout=DISK_USAGE_PROBE_TIMEOUT_SEC)
        with _DISK_USAGE_CACHE_LOCK:
            refreshed = _DISK_USAGE_CACHE.get(canon)
            if refreshed is not None:
                return (refreshed[0], refreshed[1], refreshed[2])
        return stale_entry if stale_entry is not None else (0, 0, 0)

    result_box: Dict[str, Any] = {}

    def _probe() -> None:
        try:
            usage = shutil.disk_usage(path)
            vals = (int(usage.total), int(usage.used), int(usage.free))
            result_box["vals"] = vals
            # Warm cache even if caller already returned on timeout so next poll succeeds immediately.
            with _DISK_USAGE_CACHE_LOCK:
                _DISK_USAGE_CACHE[canon] = (vals[0], vals[1], vals[2], time.monotonic())
        except Exception as exc:
            result_box["err"] = exc
        finally:
            with _DISK_USAGE_CACHE_LOCK:
                if _DISK_USAGE_INFLIGHT.get(canon) is threading.current_thread():
                    _DISK_USAGE_INFLIGHT.pop(canon, None)

    t = threading.Thread(target=_probe, daemon=True)
    with _DISK_USAGE_CACHE_LOCK:
        _DISK_USAGE_INFLIGHT[canon] = t
    t.start()
    t.join(timeout=DISK_USAGE_PROBE_TIMEOUT_SEC)
    if t.is_alive() or "err" in result_box or "vals" not in result_box:
        return stale_entry if stale_entry is not None else (0, 0, 0)

    return result_box["vals"]


def _storage_dir() -> str:
    return str(getattr(app.config, "STORAGE_DIR", STORAGE_DIR))


def _data_dir() -> str:
    return str(getattr(app.config, "DATA_DIR", DATA_DIR))


def _temp_dir() -> str:
    cfg_temp = getattr(app.config, "TEMP_DIR", None)
    if cfg_temp and cfg_temp != TEMP_DIR:
        return str(cfg_temp)
    data_d = _data_dir()
    if data_d != DATA_DIR:
        return os.path.join(data_d, "temp_chunks")
    return str(TEMP_DIR)


def _db_path() -> str:
    return str(getattr(app.config, "DB_PATH", DB_PATH))


def _resolve_storage_or_400(storage_root: str, raw_rel: Optional[str]) -> Tuple[str, str]:
    try:
        return resolve_safe_storage_target(storage_root, raw_rel)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


class MkdirRequest(BaseModel):
    path: str
    username: Optional[str] = None


def is_forbidden_for_user(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """Memeriksa apakah jalur mencoba mengakses namespace user lain yang privat atau disk yang tidak diizinkan di ZimaOS."""
    return is_storage_path_forbidden(rel_path, username, allowed_disks, is_admin=is_admin)


def _parse_allowed_disks_value(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(x).strip() for x in parsed if str(x).strip()]
        except Exception:
            return [x.strip() for x in raw.split(",") if x.strip()]
    return []


def _resolve_authenticated_acl(
    current_user: Any,
    username: Optional[str],
    allowed_disks: Optional[str],
    allow_stream_scope: bool = False,
    target_path: Optional[str] = None,
) -> Tuple[str, Optional[List[str]], bool]:
    """
    Menentukan identitas efektif, allowed_disks, dan status admin secara fail-closed & anti-spoofing:
    - Bila current_user berupa payload dict JWT (FastAPI DI): akun aktif, role & allowed_disks wajib ada di SQLite.
    - Bila current_user bukan dict (pemanggilan langsung dari unit test Python): fallback kompatibel ke argumen.
    """
    if isinstance(current_user, dict):
        user_rec = verify_active_jwt_user(
            current_user,
            allow_stream_scope=allow_stream_scope,
            target_path=target_path,
        )
        jwt_user = str(user_rec.get("username") or "").strip().lower()
        caller_role = normalize_user_role(user_rec.get("role"))
        caller_is_admin = bool(caller_role in ("admin", "root") or is_admin_username(jwt_user))

        if caller_is_admin and username and username.strip():
            eff_user = username.strip()
            if eff_user.lower() == jwt_user:
                eff_is_admin = True
                target_rec = user_rec
            else:
                target_rec = get_user_by_username(eff_user)
                target_role = normalize_user_role(target_rec.get("role") if target_rec else None)
                eff_is_admin = bool(target_role in ("admin", "root") or is_admin_username(eff_user))
        else:
            eff_user = jwt_user
            eff_is_admin = caller_is_admin
            target_rec = user_rec

        if not eff_is_admin:
            if caller_is_admin and allowed_disks:
                allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()]
            else:
                raw = target_rec.get("allowed_disks", "[]") if target_rec else "[]"
                allowed_list = _parse_allowed_disks_value(raw)
        else:
            allowed_list = None
        return eff_user, allowed_list, eff_is_admin

    # Fallback kompatibilitas pemanggilan langsung dari Python unit test (tanpa DI FastAPI)
    safe_user = username.strip() if username else "admin"
    user_rec_direct = None
    try:
        user_rec_direct = get_user_by_username(safe_user) if safe_user else None
    except Exception:
        user_rec_direct = None
    direct_role = str((user_rec_direct.get("role") if user_rec_direct else None) or "").strip().lower()
    is_admin = bool(
        not safe_user
        or is_admin_username(safe_user)
        or direct_role in ("admin", "root")
    )
    allowed_list = [x.strip() for x in allowed_disks.split(",") if x.strip()] if allowed_disks else None
    if allowed_list is None and not is_admin and user_rec_direct and user_rec_direct.get("allowed_disks"):
        parsed = _parse_allowed_disks_value(user_rec_direct.get("allowed_disks"))
        if parsed:
            allowed_list = parsed
    return safe_user, allowed_list, is_admin


def _resolve_simple_user(
    current_user: Any,
    username: Optional[str],
    default_user: str = "admin",
) -> Tuple[str, bool]:
    if isinstance(current_user, dict):
        u_rec = verify_active_jwt_user(current_user, allow_stream_scope=False)
        jwt_user = str(u_rec.get("username") or "").strip().lower()
        role = normalize_user_role(u_rec.get("role"))
        caller_is_admin = bool(role in ("admin", "root") or is_admin_username(jwt_user))
        if caller_is_admin and username and username.strip():
            return username.strip(), caller_is_admin
        return jwt_user, caller_is_admin
    safe_u = username.strip() if username else default_user
    return safe_u, bool(not safe_u or is_admin_username(safe_u))


@router.get("/disks", response_model=StorageDisksResponse)
def get_storage_disks(
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Mengembalikan daftar mount storage/partisi fisik & virtual dan status izin akses akun (Role-Based ACL).
    """
    safe_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)

    disks: List[StorageDiskItem] = []
    seen_names = set()

    target_storage = _storage_dir()
    os.makedirs(target_storage, exist_ok=True)

    # 1. Pindai subdirektori langsung di dalam target_storage (partisi / storage pool lokal)
    try:
        for entry in os.scandir(target_storage):
            if entry.is_dir():
                sub_rel = entry.name
                is_accessible = True if is_admin else (not is_forbidden_for_user(sub_rel, safe_user, allowed_list, is_admin=is_admin))

                # Jika pengguna non-admin: irisan ketat dengan disk yang diizinkan (jangan loloskan PC_Backups tanpa izin)
                if not is_admin and not is_accessible:
                    continue

                total_b, used_b, free_b = _get_cached_disk_usage(entry.path)
                is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(entry.path)))

                disks.append(StorageDiskItem(
                    name=entry.name,
                    relative_path=sub_rel,
                    label=entry.name,
                    mount_point=entry.path,
                    total_bytes=total_b,
                    used_bytes=used_b,
                    free_bytes=free_b,
                    is_accessible=is_accessible,
                    is_remote=is_remote,
                ))
                seen_names.add(entry.name.lower())
    except Exception as e:
        logger.warning(f"Gagal memindai subdirektori storage: {e}")

    # 2. Jika tidak ada subdirektori atau disk sama sekali di target_storage, daftarkan sebagai root disk default (hanya untuk admin)
    if not disks and is_admin:
        total_b, used_b, free_b = _get_cached_disk_usage(target_storage)
        is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(target_storage)))

        disks.append(StorageDiskItem(
            name="Storage",
            relative_path="",
            label="Storage Utama",
            mount_point=os.path.abspath(target_storage),
            total_bytes=total_b,
            used_bytes=used_b,
            free_bytes=free_b,
            is_accessible=True,
            is_remote=is_remote,
        ))

    disks.sort(key=lambda d: d.name.lower())

    return StorageDisksResponse(
        disks=disks,
        total_disks=len(disks),
        username=safe_user,
        is_admin=is_admin
    )


# ==============================================================================
# CLOUD / GOOGLE DRIVE MULTI-ACCOUNT ENDPOINTS
# ==============================================================================

@router.get("/cloud-accounts", response_model=CloudAccountListResponse)
def get_cloud_accounts(
    username: Optional[str] = Query(default="admin"),
    provider: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil daftar akun cloud (Google Drive, OneDrive) yang tersimpan untuk user yang bersangkutan."""
    eff_user, _ = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else get_or_create_user(eff_user)
    accounts = get_cloud_accounts_by_user(user_id, provider=provider)
    
    items = [
        CloudAccountItemResponse(
            id=a["id"],
            user_id=a["user_id"],
            provider=a["provider"],
            email=a["email"],
            display_name=a.get("display_name"),
            quota_total=a.get("quota_total", 0),
            quota_used=a.get("quota_used", 0),
            status=a.get("status", "connected"),
            created_at=str(a.get("created_at") or ""),
            updated_at=str(a.get("updated_at") or "")
        )
        for a in accounts
    ]
    return CloudAccountListResponse(
        accounts=items,
        total_count=len(items),
        username=eff_user
    )


@router.post("/cloud-accounts", response_model=CloudAccountItemResponse)
def connect_cloud_account(
    req: CloudAccountConnectRequest,
    username: Optional[str] = Query(default="admin"),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyambungkan atau memperbarui akun Google Drive / Cloud storage untuk akun pengguna."""
    eff_user, _ = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else get_or_create_user(eff_user)
    
    account = create_or_update_cloud_account(
        user_id=user_id,
        email=req.email,
        provider=req.provider,
        display_name=req.display_name,
        access_token=req.access_token,
        refresh_token=req.refresh_token,
        token_expiry=req.token_expiry,
        quota_total=req.quota_total or 16106127360,
        quota_used=req.quota_used or 0,
        status="connected"
    )
    return CloudAccountItemResponse(
        id=account["id"],
        user_id=account["user_id"],
        provider=account["provider"],
        email=account["email"],
        display_name=account.get("display_name"),
        quota_total=account.get("quota_total", 0),
        quota_used=account.get("quota_used", 0),
        status=account.get("status", "connected"),
        created_at=str(account.get("created_at") or ""),
        updated_at=str(account.get("updated_at") or "")
    )


@router.delete("/cloud-accounts/{account_id}")
def remove_cloud_account(
    account_id: int,
    username: Optional[str] = Query(default="admin"),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memutus koneksi akun cloud storage."""
    eff_user, caller_is_admin = _resolve_simple_user(current_user, username, default_user="admin")
    u = get_user_by_username(eff_user)
    user_id = u["id"] if u else None
    
    is_admin = bool(caller_is_admin or not eff_user or is_admin_username(eff_user) or (u and u.get("role") in ("admin", "root")))
    del_user_id = None if is_admin else user_id
    
    ok = delete_cloud_account(account_id, user_id=del_user_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Akun cloud tidak ditemukan atau tidak memiliki akses")
    return {"status": "success", "message": "Akun cloud berhasil diputus", "account_id": account_id}




@router.get("/browse")
def browse_storage(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menjelajahi direktori folder & disk yang ada di server storage.
    Mendukung penjelajahan multi-disk dan proteksi isolasi multi-user berbasis API ZimaOS.
    """
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)

    # Proteksi: cegah akses ke ruang privat user lain atau disk terlarang
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")

    os.makedirs(target_dir, exist_ok=True)

    dirs = []
    try:
        for entry in _scandir_bounded(target_dir, include_stat=False):
            if entry["is_dir"]:
                raw_sub = f"{canonical_rel}/{entry['name']}" if canonical_rel else entry["name"]
                try:
                    sub_rel, _ = resolve_safe_storage_target(storage_root, raw_sub)
                except ValueError:
                    continue
                if is_forbidden_for_user(sub_rel, eff_user, allowed_list, is_admin=is_admin):
                    continue
                dirs.append({
                    "name": entry["name"],
                    "relative_path": sub_rel
                })
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori: {e}")

    dirs.sort(key=lambda x: x["name"].lower())
    parent = os.path.dirname(canonical_rel).replace("\\", "/") if canonical_rel else ""

    return {
        "current_path": canonical_rel,
        "parent_path": parent,
        "directories": dirs
    }


@router.post("/mkdir")
def make_directory(
    req: MkdirRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat direktori baru di dalam storage server dengan proteksi hak akses multi-user."""
    storage_root = _storage_dir()
    dir_name, target_dir = _resolve_storage_or_400(storage_root, req.path)
    if not dir_name:
        raise HTTPException(status_code=400, detail="Path direktori tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    if is_forbidden_for_user(dir_name, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat direktori di dalam ruang akun pengguna lain atau disk yang tidak diotorisasi.")

    os.makedirs(target_dir, exist_ok=True)
    invalidate_disk_usage_cache()
    try:
        log_activity(None, None, "STORAGE_MKDIR", f"User '{eff_user or 'anonymous'}' membuat direktori '{dir_name}'", {"path": dir_name})
    except Exception:
        pass
    return {"success": True, "created_path": dir_name}


@router.get("/browse-files", response_model=StorageBrowseFilesResponse)
def browse_files_and_folders(
    path: Optional[str] = Query(default=""),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menjelajahi berkas dan folder (metadata lengkap: ukuran, ekstensi, mime_type, mtime) di server storage.
    Mendukung isolasi hak akses multi-user dan integrasi ZimaOS multi-disk.
    """
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)

    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses direktori milik pengguna lain atau disk yang tidak diotorisasi.")

    os.makedirs(target_dir, exist_ok=True)

    items = []
    try:
        for entry in _scandir_bounded(target_dir, include_stat=True):
            raw_sub = f"{canonical_rel}/{entry['name']}" if canonical_rel else entry["name"]
            try:
                sub_rel, _ = resolve_safe_storage_target(storage_root, raw_sub)
            except ValueError:
                continue
            if is_forbidden_for_user(sub_rel, eff_user, allowed_list, is_admin=is_admin):
                continue

            is_dir = entry["is_dir"]
            size = entry["size"]
            mtime = entry["mtime"]

            ext = "" if is_dir else os.path.splitext(entry["name"])[1].lower()
            mime_type = "inode/directory" if is_dir else (mimetypes.guess_type(entry["name"])[0] or "application/octet-stream")

            items.append({
                "name": entry["name"],
                "relative_path": sub_rel,
                "is_dir": is_dir,
                "size": size,
                "mtime": mtime,
                "extension": ext,
                "mime_type": mime_type
            })
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gagal membaca direktori berkas: {e}")

    items.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    parent = os.path.dirname(canonical_rel).replace("\\", "/") if canonical_rel else ""
    folders_count = sum(1 for x in items if x["is_dir"])
    files_count = len(items) - folders_count

    return {
        "current_path": canonical_rel,
        "parent_path": parent,
        "items": items,
        "total_count": len(items),
        "folders_count": folders_count,
        "files_count": files_count
    }


def _parse_single_byte_range(range_header: str, file_size: int) -> Tuple[str, Optional[Tuple[int, int]]]:
    """
    Parser HTTP Range RFC 9110:
    Mengembalikan ('ok', (start, end)) | ('unsatisfiable', None) | ('ignore', None).
    Mendukung bytes=start-end (termasuk clamping end >= file_size), bytes=start-, dan suffix bytes=-N.
    """
    h_val = str(range_header or "").strip()
    if not h_val:
        return "ignore", None
    if not h_val.lower().startswith("bytes="):
        return "ignore", None
    range_spec = h_val[6:].strip()
    if not range_spec or "," in range_spec:
        return "ignore", None
    parts = range_spec.split("-")
    if len(parts) != 2:
        return "unsatisfiable", None
    start_str, end_str = parts[0].strip(), parts[1].strip()
    if file_size <= 0:
        return "unsatisfiable", None
    try:
        if not start_str and not end_str:
            return "unsatisfiable", None
        if not start_str:
            # Suffix range bytes=-N
            suffix_len = int(end_str)
            if suffix_len <= 0:
                return "unsatisfiable", None
            start = max(0, file_size - suffix_len)
            end = file_size - 1
            return "ok", (start, end)
        start = int(start_str)
        end = int(end_str) if end_str else (file_size - 1)
        if start < 0 or start >= file_size:
            return "unsatisfiable", None
        if end < start:
            return "unsatisfiable", None
        end = min(end, file_size - 1)
        return "ok", (start, end)
    except ValueError:
        return "unsatisfiable", None


def stream_file_range(
    full_path: str,
    range_header: Optional[str] = None,
    request_headers: Optional[Any] = None,
    method: str = "GET",
):
    """Membangun StreamingResponse dengan dukungan penuh HTTP Range 206, 416, ETag, Last-Modified, If-Range, dan HEAD."""
    st = os.stat(full_path)
    file_size = int(st.st_size)
    mtime_epoch = int(st.st_mtime)
    etag = f'"{file_size:x}-{mtime_epoch:x}"'
    last_modified = email.utils.formatdate(mtime_epoch, usegmt=True)

    mime_type, _ = mimetypes.guess_type(full_path)
    if not mime_type:
        ext = os.path.splitext(full_path)[1].lower()
        if ext in (".mkv", ".webm"):
            mime_type = "video/webm" if ext == ".webm" else "video/x-matroska"
        elif ext in (".flac", ".m4a"):
            mime_type = "audio/flac" if ext == ".flac" else "audio/mp4"
        else:
            mime_type = "application/octet-stream"

    sec_headers = build_stream_security_headers(full_path)
    base_cache_headers = {
        "Accept-Ranges": "bytes",
        "ETag": etag,
        "Last-Modified": last_modified,
        **sec_headers,
    }
    head_only = str(method or "GET").strip().upper() == "HEAD"
    CHUNK_SIZE = 256 * 1024

    def _hdr_get(name: str) -> Optional[str]:
        if request_headers is None:
            return None
        getter = getattr(request_headers, "get", None)
        if callable(getter):
            return getter(name) or getter(name.lower())
        return None

    if_none_match = str(_hdr_get("if-none-match") or "").strip()
    if if_none_match and (if_none_match == "*" or etag in if_none_match):
        return StreamingResponse(iter(()), status_code=304, headers=base_cache_headers)

    if_range = str(_hdr_get("if-range") or "").strip()
    effective_range = range_header
    if if_range and effective_range:
        if if_range != etag and if_range != last_modified:
            effective_range = None

    if effective_range:
        kind, bounds = _parse_single_byte_range(effective_range, file_size)
        if kind == "unsatisfiable":
            return StreamingResponse(
                iter(()),
                status_code=416,
                headers={
                    "Content-Range": f"bytes */{file_size}",
                    "Accept-Ranges": "bytes",
                    "Content-Type": mime_type,
                    **sec_headers,
                },
            )
        if kind == "ok" and bounds is not None:
            start, end = bounds
            content_length = end - start + 1

            def range_generator(start_pos, length):
                with open(full_path, "rb") as f:
                    f.seek(start_pos)
                    remaining = length
                    while remaining > 0:
                        read_bytes = min(CHUNK_SIZE, remaining)
                        data = f.read(read_bytes)
                        if not data:
                            break
                        remaining -= len(data)
                        yield data

            headers = {
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Content-Length": str(content_length),
                "Content-Type": mime_type,
                **base_cache_headers,
            }
            body_gen = iter(()) if head_only else range_generator(start, content_length)
            return StreamingResponse(body_gen, status_code=206, headers=headers)

    def full_generator():
        with open(full_path, "rb") as f:
            while chunk := f.read(CHUNK_SIZE):
                yield chunk

    headers = {
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        **base_cache_headers,
    }
    body_gen = iter(()) if head_only else full_generator()
    return StreamingResponse(body_gen, status_code=200, headers=headers)


@router.get("/stream")
@router.head("/stream")
def stream_media(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Streaming HTTP Range 206 Partial Content untuk pemutaran video, audio, dan dokumen langsung dari server.
    Mendukung SEEK, ETag/If-Range, 416, serta metode HEAD.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user,
        username,
        allowed_disks,
        allow_stream_scope=True,
        target_path=canonical_rel,
    )
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas dari direktori terlarang.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    req_headers = getattr(request, "headers", None) if request is not None else None
    req_method = getattr(request, "method", "GET") if request is not None else "GET"
    range_header = req_headers.get("range") if req_headers is not None else None
    session_id = (req_headers.get("x-session-id") if req_headers is not None else None) or f"sess_{abs(hash(target_file))}_{int(time.time() // 60)}"
    client_ip = request.client.host if (request is not None and request.client and request.client.host) else "unknown"
    try:
        if str(req_method).upper() != "HEAD":
            track_session(session_id, eff_user or "anonymous", canonical_rel, client_ip, session_type="stream")
            if not range_header or range_header.startswith("bytes=0-"):
                log_activity(None, None, "STORAGE_STREAM", f"User '{eff_user or 'anonymous'}' memutar stream '{os.path.basename(target_file)}'", {"path": canonical_rel, "ip": client_ip})
    except Exception:
        pass
    return stream_file_range(target_file, range_header, request_headers=req_headers, method=req_method)


@router.get("/player", response_class=HTMLResponse)
def get_media_player(
    request: Request,
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menyediakan UI Web Player modern (HTML5) yang seragam antara Browser dan Native Desktop App (Edge App Mode).
    Mendukung video, audio, gambar dengan keyboard shortcuts, range seeking, dan responsif.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    scoped_token = ""
    if isinstance(current_user, dict):
        uid_val = current_user.get("uid")
        if uid_val is None and eff_user:
            u_rec = get_user_by_username(eff_user)
            if u_rec:
                uid_val = u_rec.get("id")
        if eff_user and uid_val is not None:
            try:
                scoped_token = create_stream_token(eff_user, int(uid_val), canonical_rel, ttl_seconds=300)
            except Exception:
                scoped_token = ""

    raw_token = scoped_token
    if not raw_token and isinstance(current_user, dict) and request is not None:
        qp = getattr(request, "query_params", None)
        if qp and hasattr(qp, "get"):
            raw_token = str(qp.get("token") or "").strip()
        if not raw_token:
            hdrs = getattr(request, "headers", None)
            if hdrs and hasattr(hdrs, "get"):
                auth_hdr = str(hdrs.get("authorization") or hdrs.get("Authorization") or "").strip()
                if auth_hdr.lower().startswith("bearer "):
                    raw_token = auth_hdr[7:].strip()

    filename = os.path.basename(target_file)
    stream_url = f"/api/v1/storage/stream?path={urllib.parse.quote(canonical_rel)}"
    download_url = f"/api/v1/storage/download?path={urllib.parse.quote(canonical_rel)}"
    if raw_token:
        tok_q = f"&token={urllib.parse.quote(raw_token)}"
        stream_url += tok_q
        download_url += tok_q

    html_content = render_media_player_html(filename, canonical_rel, stream_url, download_url)
    return HTMLResponse(content=html_content)


@router.get("/download")
@router.head("/download")
def download_file(
    path: str = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
    request: Request = None,
):
    """Mengunduh berkas langsung dari server storage tanpa kompresi ZIP."""
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user,
        username,
        allowed_disks,
        allow_stream_scope=True,
        target_path=canonical_rel,
    )
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunduh berkas dari direktori terlarang.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    filename = os.path.basename(target_file)
    safe_disp = filename.replace('"', "_").replace("\r", "").replace("\n", "")
    file_size = os.path.getsize(target_file)
    mime_type, _ = mimetypes.guess_type(target_file)
    mime_type = mime_type or "application/octet-stream"

    try:
        log_activity(None, None, "STORAGE_DOWNLOAD", f"User '{eff_user or 'anonymous'}' mengunduh '{filename}'", {"path": canonical_rel, "size": file_size})
    except Exception:
        pass

    def file_streamer():
        with open(target_file, "rb") as f:
            while chunk := f.read(256 * 1024):
                yield chunk

    headers = {
        "Content-Disposition": f'attachment; filename="{safe_disp}"',
        "Content-Length": str(file_size),
        "Content-Type": mime_type,
        "Accept-Ranges": "bytes",
        "X-Content-Type-Options": "nosniff",
    }
    head_only = request is not None and str(getattr(request, "method", "GET")).upper() == "HEAD"
    body_stream = iter(()) if head_only else file_streamer()
    return StreamingResponse(body_stream, headers=headers)


@router.post("/upload")
async def upload_direct_file(
    file: UploadFile = File(...),
    path: Optional[str] = Form(default=None),
    path_param: Optional[str] = Query(default=None, alias="path"),
    filename: Optional[str] = Query(default=None),
    filename_form: Optional[str] = Form(default=None, alias="filename"),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengunggah berkas langsung ke direktori storage secara non-blocking & atomik."""
    resolved_path = (path if path is not None else path_param) or ""
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, resolved_path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    if (not is_admin and not canonical_rel) or is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah berkas ke direktori terlarang.")

    chosen_name = filename or filename_form or getattr(file, "filename", "") or ""
    clean_filename = os.path.basename(chosen_name.strip().replace("\\", "/"))
    if not clean_filename or clean_filename in (".", ".."):
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid")

    file_candidate_rel = f"{canonical_rel}/{clean_filename}" if canonical_rel else clean_filename
    actual_rel, target_file = _resolve_storage_or_400(storage_root, file_candidate_rel)
    if (not is_admin and not actual_rel) or is_forbidden_for_user(actual_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah berkas ke direktori terlarang.")

    max_upload = int(getattr(app.config, "MAX_UPLOAD_SIZE_BYTES", 4096 * 1024 * 1024))
    tmp_file = f"{target_file}.tmp.{uuid.uuid4().hex[:8]}"
    await asyncio.to_thread(os.makedirs, target_dir, exist_ok=True)

    bytes_written = 0
    f_out = await asyncio.to_thread(open, tmp_file, "wb")
    try:
        while True:
            chunk = await file.read(256 * 1024)
            if not chunk:
                break
            bytes_written += len(chunk)
            if bytes_written > max_upload:
                raise HTTPException(
                    status_code=413,
                    detail=f"Ukuran unggahan melebihi batas maksimal ({max_upload // (1024 * 1024)} MB).",
                )
            await asyncio.to_thread(f_out.write, chunk)

        def _finalize_atomic():
            f_out.flush()
            os.fsync(f_out.fileno())
            f_out.close()
            os.replace(tmp_file, target_file)

        await asyncio.to_thread(_finalize_atomic)
    except Exception:
        try:
            f_out.close()
        except Exception:
            pass
        if os.path.exists(tmp_file):
            try:
                await asyncio.to_thread(os.remove, tmp_file)
            except Exception:
                pass
        raise

    try:
        await asyncio.to_thread(
            log_activity,
            None,
            None,
            "STORAGE_UPLOAD",
            f"User '{eff_user or 'anonymous'}' mengunggah '{clean_filename}'",
            {"path": actual_rel, "bytes": bytes_written},
        )
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {
        "success": True,
        "filename": clean_filename,
        "bytes_written": bytes_written,
        "relative_path": actual_rel
    }


@router.post("/upload-chunk")
async def upload_explorer_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    file: UploadFile = File(...),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Endpoint upload chunked untuk Web Explorer agar file besar tahan timeout Cloudflare/WAN."""
    verify_active_jwt_user(current_user, allow_stream_scope=False)
    clean_uid = str(upload_id or "").strip()
    if not _STORAGE_CHUNK_UPLOAD_ID_RE.match(clean_uid):
        raise HTTPException(status_code=400, detail="Format upload_id tidak valid.")
    if total_chunks <= 0 or chunk_index < 0 or chunk_index >= total_chunks or total_chunks > 10000:
        raise HTTPException(status_code=400, detail="Indeks chunk tidak valid.")

    chunk_dir = os.path.join(_temp_dir(), f"web_{clean_uid}")
    chunk_path = os.path.join(chunk_dir, f"part_{chunk_index:06d}.tmp")
    stage_path = f"{chunk_path}.{uuid.uuid4().hex[:6]}"
    await asyncio.to_thread(os.makedirs, chunk_dir, exist_ok=True)
    bytes_written = 0
    fh = await asyncio.to_thread(open, stage_path, "wb")
    try:
        while True:
            part = await file.read(256 * 1024)
            if not part:
                break
            bytes_written += len(part)
            await asyncio.to_thread(fh.write, part)

        def _commit_chunk():
            fh.flush()
            os.fsync(fh.fileno())
            fh.close()
            os.replace(stage_path, chunk_path)

        await asyncio.to_thread(_commit_chunk)
    except Exception:
        try:
            fh.close()
        except Exception:
            pass
        if os.path.exists(stage_path):
            try:
                await asyncio.to_thread(os.remove, stage_path)
            except Exception:
                pass
        raise
    return {"success": True, "upload_id": clean_uid, "chunk_index": chunk_index, "bytes_written": bytes_written}


@router.post("/upload-commit")
def commit_explorer_chunked_upload(
    upload_id: str = Query(...),
    path: str = Query(default=""),
    filename: str = Query(...),
    total_chunks: int = Query(...),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menggabungkan seluruh chunk upload Web Explorer menjadi berkas atomik di storage."""
    clean_uid = str(upload_id or "").strip()
    if not _STORAGE_CHUNK_UPLOAD_ID_RE.match(clean_uid):
        raise HTTPException(status_code=400, detail="Format upload_id tidak valid.")
    storage_root = _storage_dir()
    canonical_rel, target_dir = _resolve_storage_or_400(storage_root, path)
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    clean_filename = os.path.basename(filename.strip().replace("\\", "/"))
    if not clean_filename or clean_filename in (".", ".."):
        raise HTTPException(status_code=400, detail="Nama berkas tidak valid.")
    actual_rel, target_file = _resolve_storage_or_400(
        storage_root, f"{canonical_rel}/{clean_filename}" if canonical_rel else clean_filename
    )
    if (not is_admin and not actual_rel) or is_forbidden_for_user(actual_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengunggah ke direktori terlarang.")

    chunk_dir = os.path.join(_temp_dir(), f"web_{clean_uid}")
    for idx in range(total_chunks):
        if not os.path.isfile(os.path.join(chunk_dir, f"part_{idx:06d}.tmp")):
            raise HTTPException(status_code=400, detail=f"Potongan chunk ke-{idx} belum tersedia.")

    os.makedirs(target_dir, exist_ok=True)
    tmp_target = f"{target_file}.tmp.{uuid.uuid4().hex[:8]}"
    bytes_written = 0
    try:
        with open(tmp_target, "wb") as f_out:
            for idx in range(total_chunks):
                with open(os.path.join(chunk_dir, f"part_{idx:06d}.tmp"), "rb") as f_in:
                    while buf := f_in.read(256 * 1024):
                        f_out.write(buf)
                        bytes_written += len(buf)
            f_out.flush()
            os.fsync(f_out.fileno())
        os.replace(tmp_target, target_file)
    except Exception:
        if os.path.exists(tmp_target):
            try:
                os.remove(tmp_target)
            except Exception:
                pass
        raise
    shutil.rmtree(chunk_dir, ignore_errors=True)
    try:
        log_activity(None, None, "STORAGE_UPLOAD", f"User '{eff_user or 'anonymous'}' mengunggah (chunked) '{clean_filename}'", {"path": actual_rel, "bytes": bytes_written})
    except Exception:
        pass
    invalidate_disk_usage_cache()
    return {"success": True, "filename": clean_filename, "bytes_written": bytes_written, "relative_path": actual_rel}


@router.get("/activity-logs")
def get_storage_activity_logs(
    limit: int = Query(default=50, ge=1, le=500),
    username: Optional[str] = Query(default=None),
    action: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil riwayat log aktivitas dan operasi storage (upload, download, stream, dll)."""
    if isinstance(current_user, dict):
        eff_user, caller_is_admin = _resolve_simple_user(current_user, username, default_user="")
        query_user = username if (caller_is_admin and username is not None) else (None if caller_is_admin else eff_user)
    else:
        query_user = username
    logs = get_activity_logs(limit=limit, username=query_user, action=action)
    return {"logs": logs, "total": len(logs)}


@router.get("/sessions")
def get_storage_sessions(
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mengambil daftar sesi aktif streaming dan akses berkas."""
    sessions = get_active_sessions()
    if isinstance(current_user, dict):
        eff_user, caller_is_admin = _resolve_simple_user(current_user, None, default_user="")
        if not caller_is_admin:
            sessions = [s for s in sessions if str(s.get("username") or "").strip().lower() == eff_user]
    return {"sessions": sessions, "active_count": len(sessions)}


@router.api_route("/cleanup-temp", methods=["GET", "POST"])
def cleanup_temp_storage(
    max_age_hours: float = Query(default=1.0, ge=0.01),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Membersihkan berkas sementara, potongan chunk kadaluarsa (.part),
    dan sesi unggah terputus yang lebih tua dari batas jam yang ditentukan (default 1 jam).
    """
    if isinstance(current_user, dict):
        _, caller_is_admin = _resolve_simple_user(current_user, None, default_user="")
        if not caller_is_admin:
            raise HTTPException(status_code=403, detail="Hanya administrator yang diizinkan membersihkan cache sementara.")

    cutoff_time = time.time() - (max_age_hours * 3600)
    deleted_files = []
    freed_bytes = 0

    temp_root = _temp_dir()

    if os.path.exists(temp_root):
        for root, dirs, files in os.walk(temp_root, topdown=False):
            for f in files:
                fpath = os.path.join(root, f)
                try:
                    st = os.stat(fpath)
                    if st.st_mtime < cutoff_time:
                        fsize = st.st_size
                        os.remove(fpath)
                        deleted_files.append(f)
                        freed_bytes += fsize
                except Exception:
                    pass
            if root != temp_root:
                try:
                    if not os.listdir(root):
                        os.rmdir(root)
                except Exception:
                    pass

    # Potongan unggahan (.part) hanya dibuat di temp_root; jangan pernah melakukan os.walk()
    # terhadap storage_root karena share FUSE/cloud (mis. Google Drive ZimaOS) akan ter-crawl penuh
    # setiap 30 menit dan memicu rate-limit/freeze File Explorer.

    try:
        with get_db(_db_path()) as conn:
            conn.execute("""
                UPDATE upload_sessions 
                SET status = 'failed' 
                WHERE status IN ('pending', 'uploading') 
                AND strftime('%s', 'now') - strftime('%s', created_at) > ?
            """, (int(max_age_hours * 3600),))
    except Exception:
        pass

    try:
        log_activity(
            device_id=None,
            task_id=None,
            action="TEMP_CLEANUP",
            message=f"Pembersihan temp chunk: {len(deleted_files)} berkas dihapus ({freed_bytes} bytes dibebaskan).",
            details={"deleted_count": len(deleted_files), "freed_bytes": freed_bytes}
        )
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {
        "success": True,
        "total_deleted": len(deleted_files),
        "freed_bytes": freed_bytes,
        "deleted_files": deleted_files[:100]
    }


@router.get("/thumbnail")
def get_file_thumbnail(
    path: str = Query(...),
    size: int = Query(default=256, ge=32, le=1024),
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Menghasilkan dan mengembalikan thumbnail gambar atau berkas dengan cache cerdas.
    """
    storage_root = _storage_dir()
    canonical_rel, target_file = _resolve_storage_or_400(storage_root, path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, username, allowed_disks)
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan mengakses berkas.")

    if not os.path.exists(target_file):
        raise HTTPException(status_code=404, detail="Berkas tidak ditemukan")
    if os.path.isdir(target_file):
        raise HTTPException(status_code=400, detail="Target adalah direktori, bukan berkas.")

    ext = os.path.splitext(target_file)[1].lower()
    valid_img_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".ico", ".tiff", ".jfif"}

    thumb_dir = os.path.join(_data_dir(), ".thumbnails")
    os.makedirs(thumb_dir, exist_ok=True)

    file_mtime = int(os.path.getmtime(target_file))
    cache_key = hashlib.md5(f"{canonical_rel}_{file_mtime}_{size}".encode("utf-8")).hexdigest()
    cache_path = os.path.join(thumb_dir, f"{cache_key}.jpg")

    if os.path.exists(cache_path) and os.path.getsize(cache_path) > 0:
        return FileResponse(cache_path, media_type="image/jpeg", headers={"X-Content-Type-Options": "nosniff"})

    if ext in valid_img_exts:
        global _THUMB_LAST_PRUNE_TS
        tmp_cache = f"{cache_path}.tmp.{uuid.uuid4().hex[:6]}"
        acquired = _THUMB_SEMAPHORE.acquire(timeout=10.0)
        if not acquired:
            raise HTTPException(status_code=503, detail="Generator thumbnail sedang sibuk, coba sebentar lagi.")
        try:
            from PIL import Image, ImageOps
            # Batas aman anti-decompression-bomb (~89 megapiksel) agar kontainer NAS tidak OOM
            Image.MAX_IMAGE_PIXELS = 89_478_485
            with Image.open(target_file) as im:
                im = ImageOps.exif_transpose(im)
                resample_filter = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                im.thumbnail((size, size), resample=resample_filter)
                if im.mode in ("RGBA", "LA", "P"):
                    # Buat canvas putih bersih untuk transparansi PNG
                    background = Image.new("RGB", im.size, (255, 255, 255))
                    if im.mode == "P":
                        im = im.convert("RGBA")
                    if im.mode in ("RGBA", "LA"):
                        background.paste(im, mask=im.split()[-1])
                    else:
                        background.paste(im)
                    im = background
                elif im.mode != "RGB":
                    im = im.convert("RGB")
                im.save(tmp_cache, format="JPEG", quality=85, optimize=True)
            os.replace(tmp_cache, cache_path)
            now_mono = time.monotonic()
            if (now_mono - _THUMB_LAST_PRUNE_TS) > 300.0:
                _THUMB_LAST_PRUNE_TS = now_mono
                try:
                    thumbs = sorted(
                        [
                            os.path.join(thumb_dir, fn)
                            for fn in os.listdir(thumb_dir)
                            if fn.endswith(".jpg")
                        ],
                        key=lambda p: os.path.getatime(p),
                    )
                    if len(thumbs) > 1000:
                        for stale_p in thumbs[: len(thumbs) - 800]:
                            try:
                                os.remove(stale_p)
                            except OSError:
                                pass
                except Exception:
                    pass
            return FileResponse(cache_path, media_type="image/jpeg", headers={"X-Content-Type-Options": "nosniff"})
        except Exception as e:
            if os.path.exists(tmp_cache):
                try:
                    os.remove(tmp_cache)
                except OSError:
                    pass
            logger.error(f"Gagal generate thumbnail untuk {target_file}: {e}")
            raise HTTPException(status_code=500, detail=f"Gagal membuat thumbnail: {str(e)}")
        finally:
            _THUMB_SEMAPHORE.release()
    else:
        raise HTTPException(status_code=415, detail=f"Pembuatan thumbnail tidak didukung untuk tipe berkas {ext}")


class DeleteRequest(BaseModel):
    path: Optional[str] = None
    paths: Optional[List[str]] = None
    username: Optional[str] = None


class CopyMoveRequest(BaseModel):
    src_paths: List[str]
    dest_dir: str
    username: Optional[str] = None


class TouchRequest(BaseModel):
    path: str
    username: Optional[str] = None


@router.post("/touch")
def create_empty_file(
    req: TouchRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat berkas baru kosong di dalam direktori target storage."""
    storage_root = _storage_dir()
    canonical_rel, target_path = _resolve_storage_or_400(storage_root, req.path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path berkas tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )
    if (not is_admin and not canonical_rel) or is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")

    parent_dir = os.path.dirname(target_path)
    os.makedirs(parent_dir, exist_ok=True)

    base_dir = os.path.dirname(canonical_rel)
    orig_name = os.path.basename(canonical_rel)
    name_no_ext, ext = os.path.splitext(orig_name)
    counter = 1
    actual_rel = canonical_rel
    actual_path = target_path
    while os.path.exists(actual_path):
        new_name = f"{name_no_ext} ({counter}){ext}"
        cand_rel = f"{base_dir}/{new_name}" if base_dir else new_name
        actual_rel, actual_path = _resolve_storage_or_400(storage_root, cand_rel)
        if (not is_admin and not actual_rel) or is_forbidden_for_user(actual_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")
        counter += 1

    actual_rel, actual_path = _resolve_storage_or_400(storage_root, actual_rel)
    if (not is_admin and not actual_rel) or is_forbidden_for_user(actual_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan membuat berkas di luar otorisasi pengguna.")

    with open(actual_path, "w", encoding="utf-8") as f:
        pass
    invalidate_disk_usage_cache()

    try:
        log_activity(None, None, "STORAGE_TOUCH", f"User '{eff_user or 'anonymous'}' membuat berkas baru '{actual_rel}'", {"path": actual_rel})
    except Exception:
        pass

    return {"success": True, "created_path": actual_rel, "filename": os.path.basename(actual_rel)}


@router.post("/copy")
def copy_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyalin berkas atau direktori (Ctrl+C & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    storage_root = _storage_dir()
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )

    dest_rel, dest_full = _resolve_storage_or_400(storage_root, req.dest_dir)
    if (not is_admin and not dest_rel) or is_forbidden_for_user(dest_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin ke direktori tujuan.")

    validated_srcs = []
    for s in req.src_paths:
        src_rel, src_full = _resolve_storage_or_400(storage_root, s)
        if (not is_admin and not src_rel) or is_forbidden_for_user(src_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin berkas dari direktori sumber terlarang.")
        if src_rel:
            validated_srcs.append((src_rel, src_full))

    os.makedirs(dest_full, exist_ok=True)

    copied_items = []
    for src_rel, src_full in validated_srcs:
        if not os.path.exists(src_full):
            continue

        base_name = os.path.basename(src_full)
        target_rel = f"{dest_rel}/{base_name}" if dest_rel else base_name
        target_rel_checked, target_item = _resolve_storage_or_400(storage_root, target_rel)
        if is_forbidden_for_user(target_rel_checked, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan menyalin ke target terlarang.")

        if os.path.exists(target_item):
            name_no_ext, ext = os.path.splitext(base_name)
            counter = 1
            if os.path.dirname(src_full) == dest_full:
                cand = f"{name_no_ext} - Copy{ext}"
                _, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
            while os.path.exists(target_item):
                cand = f"{name_no_ext} - Copy ({counter}){ext}"
                _, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
                counter += 1

        try:
            if os.path.isdir(src_full):
                shutil.copytree(src_full, target_item)
            else:
                shutil.copy2(src_full, target_item)
            copied_items.append(os.path.basename(target_item))
        except Exception as e:
            logger.error(f"Gagal menyalin {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_COPY", f"User '{eff_user or 'anonymous'}' menyalin {len(copied_items)} item ke '{dest_rel}'", {"count": len(copied_items), "dest": dest_rel})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {"success": True, "copied_count": len(copied_items), "items": copied_items}


@router.post("/move")
def move_files_or_folders(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Memindahkan berkas atau direktori (Ctrl+X & Ctrl+V) ke direktori tujuan."""
    if not req.src_paths:
        raise HTTPException(status_code=400, detail="Daftar berkas sumber tidak boleh kosong")

    storage_root = _storage_dir()
    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )

    dest_rel, dest_full = _resolve_storage_or_400(storage_root, req.dest_dir)
    if (not is_admin and not dest_rel) or is_forbidden_for_user(dest_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan ke direktori tujuan.")

    validated_srcs = []
    for s in req.src_paths:
        src_rel, src_full = _resolve_storage_or_400(storage_root, s)
        if (not is_admin and not src_rel) or is_forbidden_for_user(src_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan berkas dari direktori sumber terlarang.")
        if src_rel:
            validated_srcs.append((src_rel, src_full))

    os.makedirs(dest_full, exist_ok=True)

    moved_items = []
    for src_rel, src_full in validated_srcs:
        if not os.path.exists(src_full):
            continue

        if os.path.isdir(src_full):
            if dest_full == src_full or dest_full.startswith(src_full + os.sep):
                continue

        base_name = os.path.basename(src_full)
        if os.path.dirname(src_full) == dest_full:
            continue

        target_rel = f"{dest_rel}/{base_name}" if dest_rel else base_name
        target_rel_checked, target_item = _resolve_storage_or_400(storage_root, target_rel)
        if is_forbidden_for_user(target_rel_checked, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan memindahkan ke target terlarang.")

        if os.path.exists(target_item):
            name_no_ext, ext = os.path.splitext(base_name)
            counter = 1
            while os.path.exists(target_item):
                cand = f"{name_no_ext} ({counter}){ext}"
                _, target_item = _resolve_storage_or_400(storage_root, f"{dest_rel}/{cand}" if dest_rel else cand)
                counter += 1

        try:
            shutil.move(src_full, target_item)
            moved_items.append(os.path.basename(target_item))
        except Exception as e:
            logger.error(f"Gagal memindahkan {src_full} -> {target_item}: {e}")

    try:
        log_activity(None, None, "STORAGE_MOVE", f"User '{eff_user or 'anonymous'}' memindahkan {len(moved_items)} item ke '{dest_rel}'", {"count": len(moved_items), "dest": dest_rel})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {"success": True, "moved_count": len(moved_items), "items": moved_items}


@router.post("/delete")
def delete_file_or_folder(
    req: DeleteRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menghapus berkas atau direktori (single maupun batch) secara aman dari server storage."""
    raw_paths = []
    if req.paths:
        raw_paths = [p for p in req.paths if p and str(p).strip()]
    elif req.path and str(req.path).strip():
        raw_paths = [req.path]

    if not raw_paths:
        raise HTTPException(status_code=400, detail="Path tidak boleh kosong")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(
        current_user, username or req.username, allowed_disks
    )

    storage_root = _storage_dir()
    root_real = os.path.realpath(storage_root)
    resolved_targets = []
    for raw_p in raw_paths:
        canonical_rel, target_path = _resolve_storage_or_400(storage_root, raw_p)
        if (not is_admin and not canonical_rel) or is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
            raise HTTPException(status_code=403, detail="Tidak diizinkan menghapus berkas atau direktori terlarang.")
        resolved_targets.append((canonical_rel, target_path))

    deleted_paths = []
    for canonical_rel, target_path in resolved_targets:
        if not canonical_rel or not os.path.exists(target_path) or target_path == root_real:
            continue

        is_dir = os.path.isdir(target_path)
        try:
            if is_dir:
                shutil.rmtree(target_path)
            else:
                os.remove(target_path)
            deleted_paths.append(canonical_rel)
        except Exception as e:
            logger.error(f"Gagal menghapus target: {str(e)}")

    try:
        log_activity(None, None, "STORAGE_DELETE", f"User '{eff_user or 'anonymous'}' menghapus {len(deleted_paths)} target", {"deleted_paths": deleted_paths})
    except Exception:
        pass

    invalidate_disk_usage_cache()
    return {"success": True, "deleted_count": len(deleted_paths), "deleted_paths": deleted_paths}


def _launch_storage_job(op_name: str, worker_fn) -> Dict[str, Any]:
    """Menjalankan operasi storage besar (copy/move/delete) sebagai background job terpantau."""
    job_id = uuid.uuid4().hex[:16]
    rec = {
        "job_id": job_id,
        "operation": op_name,
        "status": "running",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "result": None,
        "error": None,
    }
    with _STORAGE_JOBS_LOCK:
        if len(_STORAGE_JOBS) > 200:
            done_keys = [k for k, v in _STORAGE_JOBS.items() if v.get("status") != "running"]
            for k in done_keys[: max(0, len(done_keys) - 50)]:
                _STORAGE_JOBS.pop(k, None)
        _STORAGE_JOBS[job_id] = rec

    def _runner():
        try:
            res = worker_fn()
            with _STORAGE_JOBS_LOCK:
                rec["status"] = "completed"
                rec["result"] = res
        except Exception as exc:
            with _STORAGE_JOBS_LOCK:
                rec["status"] = "failed"
                rec["error"] = str(exc)

    threading.Thread(target=_runner, daemon=True, name=f"storage-job-{job_id}").start()
    return dict(rec)


@router.get("/jobs/{job_id}")
def get_storage_job_status(job_id: str, current_user: Dict[str, Any] = Depends(get_current_user)):
    """Memeriksa status dan progres background job copy/move/delete."""
    verify_active_jwt_user(current_user, allow_stream_scope=False)
    with _STORAGE_JOBS_LOCK:
        job = _STORAGE_JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job storage tidak ditemukan.")
        return dict(job)


@router.post("/jobs/copy")
def enqueue_copy_job(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "copy",
        lambda: copy_files_or_folders(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.post("/jobs/move")
def enqueue_move_job(
    req: CopyMoveRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "move",
        lambda: move_files_or_folders(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.post("/jobs/delete")
def enqueue_delete_job(
    req: DeleteRequest,
    username: Optional[str] = Query(default=None),
    allowed_disks: Optional[str] = Query(default=None),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    return _launch_storage_job(
        "delete",
        lambda: delete_file_or_folder(req, username=username, allowed_disks=allowed_disks, current_user=current_user),
    )


@router.get("/explorer", response_class=HTMLResponse)
def get_storage_explorer_page(
    path: Optional[str] = Query(default=""),
):
    """
    Menyajikan Modern Storage Explorer Web Single-Page Application.
    Mendukung tampilan Kartu Grid & List, dynamic thumbnails, video streaming player,
    drag-and-drop upload, dan aksi cepat 'Salin untuk WhatsApp'.
    """
    template_paths = [
        os.path.join(os.path.dirname(__file__), "..", "templates", "explorer.html"),
        os.path.join(os.path.dirname(__file__), "templates", "explorer.html"),
        os.path.join(_data_dir(), "templates", "explorer.html"),
    ]
    html_content = None
    for p in template_paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    html_content = f.read()
                break
            except Exception:
                pass

    if not html_content:
        html_content = "<html><body><h3>MyServer Explorer: template not found</h3></body></html>"

    return HTMLResponse(content=html_content, status_code=200)


# ==============================================================================
# PUBLIC SHARE LINK MANAGEMENT ENDPOINTS (JWT-AUTHENTICATED - SHL-01)
# ==============================================================================

@router.post("/shares")
def create_storage_public_share(
    req: PublicShareCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Membuat tautan berbagi publik baru untuk berkas atau folder di dalam allowed_disks pengguna."""
    storage_root = _storage_dir()
    canonical_rel, target_abs = _resolve_storage_or_400(storage_root, req.path)
    if not canonical_rel:
        raise HTTPException(status_code=400, detail="Path berkas atau folder tidak boleh kosong.")

    eff_user, allowed_list, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if is_forbidden_for_user(canonical_rel, eff_user, allowed_list, is_admin=is_admin):
        raise HTTPException(
            status_code=403,
            detail="Tidak diizinkan membagikan berkas atau direktori di luar otorisasi akun.",
        )

    if not os.path.exists(target_abs):
        raise HTTPException(status_code=404, detail="Berkas atau direktori tidak ditemukan.")

    db_path = _db_path()
    if req.public_base_url is not None:
        raw_base = str(req.public_base_url or "").strip().rstrip("/")
        if not is_admin:
            current_base = get_public_base_url(db_path=db_path).strip().rstrip("/")
            if raw_base and raw_base != current_base:
                raise HTTPException(
                    status_code=403,
                    detail="Hanya administrator yang diizinkan mengubah Public Base URL.",
                )
        else:
            try:
                set_public_base_url(req.public_base_url, db_path=db_path)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    expires_at = None
    if req.expires_in_hours is not None:
        try:
            hrs = float(req.expires_in_hours)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Nilai expires_in_hours tidak valid.")
        if hrs > 0:
            now_utc = datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)
            expires_at = (now_utc + timedelta(hours=hrs)).isoformat() + "Z"
    elif req.expires_at and str(req.expires_at).strip():
        expires_at = str(req.expires_at).strip()

    owner_uid = None
    if isinstance(current_user, dict):
        owner_uid = current_user.get("user_id") or current_user.get("uid")
    if owner_uid is None:
        u_rec = get_user_by_username(eff_user, db_path=db_path)
        owner_uid = u_rec["id"] if u_rec else None

    clean_pwd = str(req.password).strip() if (req.password and str(req.password).strip()) else None
    share_rec = create_public_share(
        owner_username=eff_user,
        owner_user_id=owner_uid,
        target_path=canonical_rel,
        is_dir=os.path.isdir(target_abs),
        label=(req.label or os.path.basename(canonical_rel)),
        expires_at=expires_at,
        password=clean_pwd,
        db_path=db_path,
    )
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_CREATED",
            f"User '{eff_user}' membuat tautan berbagi publik '{canonical_rel}'",
            {"token": share_rec["token"], "path": canonical_rel, "is_dir": share_rec["is_dir"]},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "share": share_rec}


@router.get("/shares")
def list_storage_public_shares(
    include_revoked: bool = Query(default=False),
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menampilkan daftar tautan berbagi publik milik pengguna (atau seluruhnya untuk admin)."""
    eff_user, _, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    shares = list_public_shares(
        owner_username=eff_user,
        is_admin=is_admin,
        include_revoked=bool(include_revoked),
        db_path=db_path,
    )
    return {
        "shares": shares,
        "total": len(shares),
        "public_base_url": get_public_base_url(db_path=db_path),
        "username": eff_user,
        "is_admin": is_admin,
    }


@router.put("/shares/settings")
def update_storage_public_share_settings(
    req: PublicShareSettingsRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Menyimpan pengaturan Public Base URL untuk tautan berbagi publik (Hanya Administrator)."""
    _, _, is_admin = _resolve_authenticated_acl(current_user, None, None)
    if not is_admin:
        raise HTTPException(
            status_code=403,
            detail="Hanya administrator yang diizinkan mengubah Public Base URL.",
        )
    db_path = _db_path()
    try:
        clean_url = set_public_base_url(req.public_base_url or "", db_path=db_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"success": True, "public_base_url": clean_url}


@router.delete("/shares/{share_token}")
def delete_storage_public_share(
    share_token: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
):
    """Mencabut (revoke) tautan berbagi publik berdasarkan token (hanya pemilik atau admin)."""
    eff_user, _, is_admin = _resolve_authenticated_acl(current_user, None, None)
    db_path = _db_path()
    ok, reason = revoke_public_share(
        token=share_token,
        requester_username=eff_user,
        is_admin=is_admin,
        db_path=db_path,
    )
    if not ok and reason == "not_found":
        raise HTTPException(status_code=404, detail="Tautan berbagi tidak ditemukan.")
    if not ok and reason == "forbidden":
        raise HTTPException(status_code=403, detail="Tidak diizinkan mencabut tautan milik pengguna lain.")
    try:
        log_activity(
            None,
            None,
            "PUBLIC_SHARE_REVOKED",
            f"User '{eff_user}' mencabut tautan berbagi publik '{share_token}'",
            {"token": share_token},
            db_path=db_path,
        )
    except Exception:
        pass
    return {"success": True, "token": share_token, "status": "revoked"}








