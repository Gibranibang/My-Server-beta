import os
import shutil
import socket
import zipfile
import threading
import time
import glob
import logging
import urllib.request
import urllib.error
from datetime import datetime
from typing import Optional, Dict, Any
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status, Depends
from app.config import SERVER_VERSION, STORAGE_DIR, DATA_DIR, DB_PATH
from app.models import (
    HealthResponse, SystemInfoResponse, StorageStats, SystemUpdateResponse,
    PowerControlRequest, PowerControlResponse
)
from app.auth import get_current_user
from app.database import get_db, log_activity
from app.services.ota_utils import apply_ota_zip, get_process_boot_id

logger = logging.getLogger("myserver.system")

router = APIRouter(tags=["System"])


@router.get("/health", response_model=HealthResponse)
@router.get("/api/v1/health", response_model=HealthResponse)
def get_health():
    """Uji status operasional server backup."""
    return HealthResponse(
        status="ok",
        app="MyServer Native Backend",
        version=SERVER_VERSION,
        timestamp=datetime.utcnow().isoformat() + "Z",
        boot_id=get_process_boot_id()
    )


@router.get("/api/v1/system/info", response_model=SystemInfoResponse)
def get_system_info():
    # Menghitung agregasi kapasitas dari seluruh disk yang terpasang di STORAGE_DIR
    seen_devs = set()
    total = 0
    used = 0
    free = 0

    try:
        st = os.stat(STORAGE_DIR)
        seen_devs.add(st.st_dev)
        r_tot, r_usd, r_fre = shutil.disk_usage(STORAGE_DIR)
        total += r_tot
        used += r_usd
        free += r_fre
    except Exception:
        pass

    if os.path.exists(STORAGE_DIR):
        for entry in os.scandir(STORAGE_DIR):
            if entry.is_dir():
                try:
                    st = os.stat(entry.path)
                    if st.st_dev not in seen_devs:
                        seen_devs.add(st.st_dev)
                        d_tot, d_usd, d_fre = shutil.disk_usage(entry.path)
                        total += d_tot
                        used += d_usd
                        free += d_fre
                except Exception:
                    pass

    if total == 0:
        total, used, free = shutil.disk_usage(STORAGE_DIR)

    percent = (used / total * 100.0) if total > 0 else 0.0
    
    with get_db(DB_PATH) as conn:
        devices_count = conn.execute("SELECT COUNT(*) AS c FROM devices").fetchone()["c"]
        tasks_count = conn.execute("SELECT COUNT(*) AS c FROM backup_tasks").fetchone()["c"]
        files_count = conn.execute("SELECT COUNT(*) AS c FROM files WHERE status = 'active'").fetchone()["c"]
        bytes_count = conn.execute("SELECT COALESCE(SUM(file_size), 0) AS s FROM files WHERE status = 'active'").fetchone()["s"]

    return SystemInfoResponse(
        version=SERVER_VERSION,
        hostname=socket.gethostname(),
        storage=StorageStats(
            total_bytes=total,
            used_bytes=used,
            free_bytes=free,
            percent_used=round(percent, 2)
        ),
        total_devices=devices_count,
        total_tasks=tasks_count,
        total_backed_up_files=files_count,
        total_backed_up_bytes=bytes_count
    )


@router.post("/api/v1/system/update", response_model=SystemUpdateResponse)
async def update_system_backend(
    file: UploadFile = File(..., description="Berkas arsip .zip pembaruan modul backend (berisi folder app/)"),
    username: Optional[str] = Form("admin"),
    secret_key: Optional[str] = Form(None)
):
    """
    Endpoint One-Click OTA (Over-The-Air) Pembaruan Backend:
    Menerima file ZIP kode backend, membuat backup timestamped kode lama,
    mengekstrak pembaruan ke direktori aplikasi, dan memicu restart aman kontainer Docker.
    """
    if username and username.lower() not in ("admin", "root", "algitha"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya pengguna administrator yang diizinkan memperbarui sistem backend."
        )

    # 1. Validasi ekstensi berkas
    fname = file.filename or "update.zip"
    if not fname.lower().endswith(".zip"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Paket pembaruan harus berformat berkas .zip."
        )

    # 2. Baca isi ke penyimpanan sementara
    content = await file.read()
    if len(content) < 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Berkas pembaruan kosong atau tidak lengkap."
        )

    temp_zip = os.path.join(DATA_DIR, f"update_{int(time.time())}.zip")
    try:
        with open(temp_zip, "wb") as f:
            f.write(content)

        # 3. Verifikasi integritas ZIP
        if not zipfile.is_zipfile(temp_zip):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Berkas bukan arsip ZIP yang valid."
            )

        # 4. Tentukan direktori aplikasi target
        # file ini di: .../app/routers/system.py
        current_routers_dir = os.path.dirname(os.path.abspath(__file__))
        app_dir = os.path.dirname(current_routers_dir)
        base_dir = os.path.dirname(app_dir)

        # 5-7. Ekstraksi staged, deteksi rebuild container, backup & sinkronisasi bersih app/
        try:
            ota_res = apply_ota_zip(
                temp_zip=temp_zip,
                app_dir=app_dir,
                base_dir=base_dir,
                data_dir=DATA_DIR,
                current_version=SERVER_VERSION,
                keep_backups=3,
            )
        except ValueError as ve:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(ve)
            )

        extracted_files = ota_res["extracted_files"]
        new_version = ota_res["new_version"]
        backup_target_dir = ota_res["backup_dir"]

        log_activity(
            device_id=None,
            task_id=None,
            action="SYSTEM_OTA_UPDATE",
            message=(
                f"Pembaruan OTA berhasil diterapkan ({ota_res['files_extracted']} berkas disalin, "
                f"{ota_res['files_removed']} berkas usang dihapus). Versi: {SERVER_VERSION} -> {new_version}."
            ),
            details={
                "old_version": SERVER_VERSION,
                "new_version": new_version,
                "files_count": ota_res["files_extracted"],
                "files_removed": ota_res["files_removed"],
                "rebuild_required": ota_res["rebuild_required"],
                "backups_pruned": ota_res["backups_pruned"],
            }
        )

        # 8. Hentikan scheduler secara bersih & keluar dengan exit code 1 agar
        #    Docker (unless-stopped / on-failure) dan systemd (on-failure) me-restart proses
        def _delayed_restart():
            time.sleep(1.25)
            logger.info("Memicu restart proses untuk pembaruan OTA (stopping scheduler, exit code 1)...")
            try:
                from app.services.vm_scheduler import stop_vm_scheduler
                stop_vm_scheduler()
            except Exception as sched_err:
                logger.warning(f"Peringatan saat menghentikan vm_scheduler sebelum restart: {sched_err}")
            time.sleep(0.25)
            os._exit(1)

        threading.Thread(target=_delayed_restart, daemon=True).start()

        restart_msg = (
            f"Pembaruan berhasil disinkronkan ({len(extracted_files)} berkas). "
            "Server akan merestart otomatis dalam 2 detik."
        )
        if ota_res["rebuild_required"]:
            restart_msg += " Perubahan Dockerfile/requirements.txt terdeteksi; disarankan rebuild image container."

        return SystemUpdateResponse(
            status="success",
            message=restart_msg,
            old_version=SERVER_VERSION,
            new_version=new_version,
            backup_dir=backup_target_dir,
            files_extracted=ota_res["files_extracted"],
            files_removed=ota_res["files_removed"],
            rebuild_required=ota_res["rebuild_required"],
            backups_pruned=ota_res["backups_pruned"],
            boot_id=ota_res["boot_id"]
        )

    finally:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass


def _read_cpu_percent() -> float:
    """Membaca persentase penggunaan CPU dari /proc/stat atau fallback psutil."""
    try:
        import psutil
        return round(float(psutil.cpu_percent(interval=0.1)), 1)
    except Exception:
        pass

    try:
        with open("/proc/stat", "r") as f:
            line1 = f.readline()
        f1 = [float(x) for x in line1.strip().split()[1:]]
        time.sleep(0.08)
        with open("/proc/stat", "r") as f:
            line2 = f.readline()
        f2 = [float(x) for x in line2.strip().split()[1:]]
        idle1 = f1[3] + (f1[4] if len(f1) > 4 else 0.0)
        total1 = sum(f1)
        idle2 = f2[3] + (f2[4] if len(f2) > 4 else 0.0)
        total2 = sum(f2)
        diff_total = total2 - total1
        diff_idle = idle2 - idle1
        if diff_total > 0:
            pct = (1.0 - (diff_idle / diff_total)) * 100.0
            return round(max(0.0, min(100.0, pct)), 1)
    except Exception:
        pass
    return 0.0


def _read_cpu_temperature() -> Optional[float]:
    """Membaca suhu CPU dari sensor thermal Linux / sysfs."""
    for p in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            with open(p, "r") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue

    for p in glob.glob("/sys/class/hwmon/hwmon*/temp*_input"):
        try:
            with open(p, "r") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue
    return None


def _read_memory_info() -> Dict[str, Any]:
    """Membaca status RAM dari /proc/meminfo."""
    try:
        import psutil
        v = psutil.virtual_memory()
        return {
            "total": int(v.total),
            "used": int(v.used),
            "free": int(v.available),
            "usedPercent": round(float(v.percent), 1)
        }
    except Exception:
        pass

    total = 0
    available = 0
    free = 0
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    if key == "MemTotal":
                        total = int(val) * 1024
                    elif key == "MemAvailable":
                        available = int(val) * 1024
                    elif key == "MemFree":
                        free = int(val) * 1024
    except Exception:
        pass

    if total > 0:
        used = total - (available if available > 0 else free)
        pct = round((used / total) * 100.0, 1)
    else:
        used = 0
        pct = 0.0

    return {
        "total": total,
        "used": used,
        "free": available if available > 0 else free,
        "usedPercent": pct
    }


def _read_network_io() -> Dict[str, Any]:
    """Membaca metrik traffic jaringan dari /proc/net/dev."""
    bytes_recv = 0
    bytes_sent = 0
    try:
        with open("/proc/net/dev", "r") as f:
            lines = f.readlines()[2:]
            for line in lines:
                parts = line.strip().split(":")
                if len(parts) == 2:
                    iface = parts[0].strip()
                    if iface == "lo":
                        continue
                    stats = parts[1].split()
                    bytes_recv += int(stats[0])
                    bytes_sent += int(stats[8])
    except Exception:
        pass
    return {"bytes_sent": bytes_sent, "bytes_recv": bytes_recv}


@router.get("/api/v1/system/vitals")
def get_system_vitals():
    """
    Mengambil telemetri vitalitas sistem host secara real-time (CPU, RAM, HDD, Jaringan, Suhu).
    Klien desktop dan mobile membaca endpoint ini melalui port 8080 (api.algitha.my.id:8080).
    """
    cpu_pct = _read_cpu_percent()
    cpu_temp = _read_cpu_temperature()
    mem_info = _read_memory_info()
    net_info = _read_network_io()

    seen_devs = set()
    total = 0
    used = 0
    free = 0
    try:
        st = os.stat(STORAGE_DIR)
        seen_devs.add(st.st_dev)
        r_tot, r_usd, r_fre = shutil.disk_usage(STORAGE_DIR)
        total += r_tot
        used += r_usd
        free += r_fre
    except Exception:
        pass

    if os.path.exists(STORAGE_DIR):
        for entry in os.scandir(STORAGE_DIR):
            if entry.is_dir():
                try:
                    st = os.stat(entry.path)
                    if st.st_dev not in seen_devs:
                        seen_devs.add(st.st_dev)
                        d_tot, d_usd, d_fre = shutil.disk_usage(entry.path)
                        total += d_tot
                        used += d_usd
                        free += d_fre
                except Exception:
                    pass

    if total == 0:
        total, used, free = shutil.disk_usage(STORAGE_DIR)

    disk_pct = round((used / total * 100.0) if total > 0 else 0.0, 1)

    uptime_sec = 0.0
    try:
        with open("/proc/uptime", "r") as f:
            uptime_sec = float(f.readline().split()[0])
    except Exception:
        pass

    return {
        "status": "ok",
        "data": {
            "cpu": {
                "percent": cpu_pct,
                "usage": cpu_pct,
                "temperature": cpu_temp,
                "temp": cpu_temp
            },
            "mem": mem_info,
            "sys_disk": {
                "total": total,
                "size": total,
                "used": used,
                "free": free,
                "percent": disk_pct
            },
            "network": net_info,
            "uptime_seconds": uptime_sec,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
    }


@router.post("/api/v1/system/power", response_model=PowerControlResponse)
def control_system_power(
    req: PowerControlRequest,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Kontrol Daya Server (Reboot / Shutdown) dengan otorisasi Bearer token Admin.
    Meneruskan perintah ke D-Bus host / systemd atau ZimaOS internal endpoint.
    """
    role = current_user.get("role", "admin")
    if role not in ("admin", "root"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya administrator yang memiliki izin mematikan atau merestart server."
        )

    act = req.action.lower().strip()
    if act in ("restart", "reboot"):
        target_action = "restart"
    elif act in ("shutdown", "poweroff", "off"):
        target_action = "off"
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Aksi daya '{req.action}' tidak valid. Pilihan yang didukung: restart, shutdown."
        )

    log_activity(
        device_id=None,
        task_id=None,
        action="SYSTEM_POWER_CONTROL",
        message=f"Perintah daya '{target_action}' dipicu oleh pengguna '{current_user.get('sub')}'.",
        details={"action": target_action, "user": current_user}
    )

    success = False
    # 1. Coba forward ke ZimaOS internal endpoint (Port 80)
    for host in ["http://172.17.0.1:80", "http://127.0.0.1:80", "http://localhost:80"]:
        url = f"{host}/v1/sys/state/{target_action}"
        try:
            req_z = urllib.request.Request(url, method="PUT")
            with urllib.request.urlopen(req_z, timeout=3.0) as resp:
                if resp.status in (200, 201, 204):
                    success = True
                    break
        except Exception:
            continue

    # 2. Coba via systemctl jika di host Linux
    if not success:
        try:
            import subprocess
            if target_action == "restart":
                subprocess.Popen(["reboot"])
            else:
                subprocess.Popen(["poweroff"])
            success = True
        except Exception:
            pass

    return PowerControlResponse(
        status="success" if success else "pending",
        action=target_action,
        message=f"Perintah daya '{target_action}' berhasil diteruskan ke sistem host."
    )


