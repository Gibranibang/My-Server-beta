"""
Backup Tasks Router for MyServer Native Backend
"""

from typing import List, Optional
from fastapi import APIRouter, HTTPException, status, Query
from app.models import TaskCreateRequest, TaskResponse
from app.database import upsert_task, get_db, log_activity, DB_PATH

router = APIRouter(prefix="/api/v1/tasks", tags=["Backup Tasks"])


@router.post("", response_model=TaskResponse)
def create_or_update_task(req: TaskCreateRequest):
    """Membuat atau memperbarui konfigurasi tugas cadangan."""
    task_data = upsert_task(
        task_id=req.task_id,
        device_id=req.device_id,
        task_name=req.task_name,
        target_folder=req.target_folder,
        sync_mode=req.sync_mode,
        username=req.username or "admin"
    )
    
    log_activity(
        device_id=req.device_id,
        task_id=req.task_id,
        action="TASK_CONFIGURED",
        message=f"Tugas '{req.task_name}' dikonfigurasi ke folder '{req.target_folder}'.",
        details={"mode": req.sync_mode, "username": req.username or "admin"}
    )
    
    return TaskResponse(**task_data)


@router.get("", response_model=List[TaskResponse])
def list_tasks(device_id: Optional[str] = Query(None), username: Optional[str] = Query(None)):
    """Mengambil daftar tugas cadangan dengan isolasi multi-user."""
    with get_db(DB_PATH) as conn:
        if username and username.lower() not in ("admin", "root", "algitha"):
            # Multi-user isolation: regular users can only see their own tasks
            if device_id:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE device_id = ? AND LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (device_id, username)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (username,)
                ).fetchall()
        elif device_id:
            rows = conn.execute("SELECT * FROM backup_tasks WHERE device_id = ? ORDER BY created_at DESC", (device_id,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM backup_tasks ORDER BY created_at DESC").fetchall()
        return [TaskResponse(**dict(r)) for r in rows]


@router.get("/{task_id}", response_model=TaskResponse)
def get_task(task_id: str):
    """Mengambil detail satu tugas cadangan."""
    with get_db(DB_PATH) as conn:
        row = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas tidak ditemukan")
        return TaskResponse(**dict(row))


@router.delete("/{task_id}")
def delete_task(task_id: str):
    """Menghapus tugas cadangan beserta berkas dan sesi terkait."""
    with get_db(DB_PATH) as conn:
        conn.execute("DELETE FROM files WHERE task_id = ?", (task_id,))
        conn.execute("DELETE FROM upload_sessions WHERE task_id = ?", (task_id,))
        cursor = conn.execute("DELETE FROM backup_tasks WHERE task_id = ?", (task_id,))
        if cursor.rowcount == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas tidak ditemukan")
    return {"status": "deleted", "task_id": task_id}
