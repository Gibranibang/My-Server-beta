"""
Backup Tasks Router for MyServer Native Backend
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from app.auth import get_control_plane_user
from app.models import TaskCreateRequest, TaskResponse
from app.config import is_admin_username
from app.database import upsert_task, get_db, log_activity, DB_PATH

router = APIRouter(
    prefix="/api/v1/tasks",
    tags=["Backup Tasks"],
    dependencies=[Depends(get_control_plane_user)],
)


@router.post("", response_model=TaskResponse)
def create_or_update_task(
    req: TaskCreateRequest,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Membuat atau memperbarui konfigurasi tugas cadangan dengan isolasi kepemilikan."""
    caller_name = str(caller["username"]).strip().lower()
    caller_uid = int(caller["user_id"])
    is_admin = bool(caller["is_admin"])

    fields_set = getattr(req, "model_fields_set", None) or getattr(req, "__fields_set__", None)
    raw_req_user = getattr(req, "username", None)
    req_user_clean = str(raw_req_user).strip().lower() if raw_req_user is not None else ""
    username_supplied = ("username" in fields_set) if fields_set is not None else (raw_req_user is not None)

    if not is_admin and username_supplied and req_user_clean and req_user_clean != caller_name:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Tidak diizinkan membuat tugas untuk pengguna lain.",
        )

    with get_db(DB_PATH) as conn:
        existing_task = conn.execute(
            "SELECT username FROM backup_tasks WHERE task_id = ?",
            (req.task_id,),
        ).fetchone()
        if not is_admin and existing_task is not None:
            task_owner = str(existing_task["username"] or "").strip().lower()
            if task_owner != caller_name:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Tidak diizinkan mengubah tugas atau perangkat milik pengguna lain.",
                )

        dev_row = conn.execute(
            "SELECT d.user_id, u.username FROM devices d LEFT JOIN users u ON d.user_id = u.id WHERE d.device_id = ?",
            (req.device_id,),
        ).fetchone()
        if not is_admin and dev_row is not None:
            dev_owner = str(dev_row["username"] or "").strip().lower()
            if int(dev_row["user_id"] or -1) != caller_uid and dev_owner != caller_name:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Tidak diizinkan mengubah tugas atau perangkat milik pengguna lain.",
                )

    eff_username = req_user_clean if (is_admin and req_user_clean) else caller_name
    task_data = upsert_task(
        task_id=req.task_id,
        device_id=req.device_id,
        task_name=req.task_name,
        target_folder=req.target_folder,
        sync_mode=req.sync_mode,
        username=eff_username,
    )

    log_activity(
        device_id=req.device_id,
        task_id=req.task_id,
        action="TASK_CONFIGURED",
        message=f"Tugas '{req.task_name}' dikonfigurasi ke folder '{req.target_folder}'.",
        details={"mode": req.sync_mode, "username": eff_username},
    )

    return TaskResponse(**task_data)


@router.get("", response_model=List[TaskResponse])
def list_tasks(
    device_id: Optional[str] = Query(None),
    username: Optional[str] = Query(None),
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mengambil daftar tugas cadangan dengan isolasi multi-user."""
    caller_name = str(caller["username"]).strip().lower()
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        if not is_admin:
            if device_id:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE device_id = ? AND LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (device_id, caller_name),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (caller_name,),
                ).fetchall()
        else:
            req_user = str(username or "").strip()
            if req_user and device_id:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE device_id = ? AND LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (device_id, req_user),
                ).fetchall()
            elif req_user:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE LOWER(username) = LOWER(?) ORDER BY created_at DESC",
                    (req_user,),
                ).fetchall()
            elif device_id:
                rows = conn.execute(
                    "SELECT * FROM backup_tasks WHERE device_id = ? ORDER BY created_at DESC",
                    (device_id,),
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM backup_tasks ORDER BY created_at DESC").fetchall()
        return [TaskResponse(**dict(r)) for r in rows]


@router.get("/{task_id}", response_model=TaskResponse)
def get_task(
    task_id: str,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Mengambil detail satu tugas cadangan (hanya pemilik atau admin)."""
    caller_name = str(caller["username"]).strip().lower()
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        row = conn.execute("SELECT * FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas tidak ditemukan")
        row_dict = dict(row)
        if not is_admin and str(row_dict.get("username") or "").strip().lower() != caller_name:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan mengakses tugas milik pengguna lain.",
            )
        return TaskResponse(**row_dict)


@router.delete("/{task_id}")
def delete_task(
    task_id: str,
    caller: Dict[str, Any] = Depends(get_control_plane_user),
):
    """Menghapus tugas cadangan beserta berkas dan sesi terkait (hanya pemilik atau admin)."""
    caller_name = str(caller["username"]).strip().lower()
    is_admin = bool(caller["is_admin"])
    with get_db(DB_PATH) as conn:
        row = conn.execute("SELECT username FROM backup_tasks WHERE task_id = ?", (task_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tugas tidak ditemukan")
        if not is_admin and str(row["username"] or "").strip().lower() != caller_name:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tidak diizinkan menghapus tugas milik pengguna lain.",
            )
        conn.execute("DELETE FROM files WHERE task_id = ?", (task_id,))
        conn.execute("DELETE FROM upload_sessions WHERE task_id = ?", (task_id,))
        conn.execute("DELETE FROM backup_tasks WHERE task_id = ?", (task_id,))
    return {"status": "deleted", "task_id": task_id}
