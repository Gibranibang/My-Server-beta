"""
Router Endpoints for Managed Virtual Machines & 24/7 Automation (v1.2.0)
API contracts for MyServer Desktop & Mobile clients connecting to ZimaOS
"""

import asyncio
from fastapi import APIRouter, HTTPException, Depends, status
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

from app.models import (
    VmCreateRequest,
    VmUpdateRequest,
    VmItemResponse,
    VmListResponse,
    VmActionResponse
)
from app.database import (
    get_all_managed_vms,
    get_managed_vm,
    upsert_managed_vm,
    delete_managed_vm,
    update_vm_runtime_and_status
)
from app.services.vm_scheduler import (
    wake_vm_provider,
    sleep_vm_provider,
    execute_smart_reset,
    inspect_and_sync_vm
)

router = APIRouter(prefix="/api/v1/vms", tags=["Virtual Machines"])


@router.get("", response_model=VmListResponse)
async def list_vms():
    """Mengambil daftar seluruh VM yang tersimpan & dikelola di server ZimaOS."""
    vms_raw = get_all_managed_vms()
    vms = [VmItemResponse(**vm) for vm in vms_raw]
    return VmListResponse(
        vms=vms,
        server_time=datetime.now(timezone.utc).isoformat()
    )


@router.get("/{vm_id}", response_model=VmItemResponse)
async def get_vm_detail(vm_id: str):
    """Mengambil detail satu VM berdasarkan ID."""
    vm = get_managed_vm(vm_id)
    if not vm:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")
    return VmItemResponse(**vm)


@router.post("", response_model=VmItemResponse, status_code=status.HTTP_201_CREATED)
async def create_or_register_vm(payload: VmCreateRequest):
    """Mendaftarkan atau memigrasikan VM baru ke server ZimaOS."""
    vm_dict = payload.model_dump()
    saved = upsert_managed_vm(vm_dict)
    if not saved:
        raise HTTPException(status_code=409, detail=f"Virtual Machine '{payload.id}' baru saja dihapus (tombstone aktif)")
    return VmItemResponse(**saved)


@router.put("/{vm_id}", response_model=VmItemResponse)
async def update_vm(vm_id: str, payload: VmUpdateRequest):
    """Memperbarui pengaturan, jadwal, atau kredensial VM yang dikelola server."""
    existing = get_managed_vm(vm_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")

    update_data = {k: v for k, v in payload.model_dump().items() if v is not None}
    merged = {**existing, **update_data}
    saved = upsert_managed_vm(merged)
    if not saved:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' telah dihapus")
    return VmItemResponse(**saved)


@router.delete("/{vm_id}", response_model=VmActionResponse)
async def delete_vm(vm_id: str):
    """Menghapus VM dari server ZimaOS (idempoten dengan tombstone anti-zombie)."""
    existing = get_managed_vm(vm_id)
    delete_managed_vm(vm_id)
    vm_name = existing.get("name") if existing else vm_id

    return VmActionResponse(
        status="ok",
        message=f"Virtual Machine '{vm_name}' berhasil dihapus dari server.",
        vm_id=vm_id,
        action="delete"
    )


@router.post("/{vm_id}/wake", response_model=VmActionResponse)
async def trigger_wake(vm_id: str):
    """Memicu perintah bangun/nyalakan VM melalui daemon server."""
    vm = get_managed_vm(vm_id)
    if not vm:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")

    success = await wake_vm_provider(vm)
    return VmActionResponse(
        status="ok" if success else "error",
        message="Sinyal wake berhasil dikirim ke VM." if success else "Gagal mengirim sinyal wake.",
        vm_id=vm_id,
        action="wake"
    )


@router.post("/{vm_id}/sleep", response_model=VmActionResponse)
async def trigger_sleep(vm_id: str):
    """Memicu perintah tidurkan/pause VM melalui daemon server."""
    vm = get_managed_vm(vm_id)
    if not vm:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")

    success = await sleep_vm_provider(vm)
    return VmActionResponse(
        status="ok" if success else "error",
        message="Sinyal sleep berhasil dikirim ke VM." if success else "Gagal mengirim sinyal sleep.",
        vm_id=vm_id,
        action="sleep"
    )


@router.post("/{vm_id}/smart-reset", response_model=VmActionResponse)
async def trigger_smart_reset(vm_id: str):
    """Mengeksekusi reset batas runtime InstaBox secara instan."""
    vm = get_managed_vm(vm_id)
    if not vm:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")

    success = await execute_smart_reset(vm)
    return VmActionResponse(
        status="ok" if success else "error",
        message="Smart reset berhasil dieksekusi. Counter runtime di-reset ke 0." if success else "Gagal mengeksekusi smart reset.",
        vm_id=vm_id,
        action="smart_reset"
    )


@router.post("/{vm_id}/sync", response_model=VmItemResponse)
async def trigger_sync(vm_id: str):
    """Sinkronisasi status, runtime riil, dan telemetri VM dari provider InstaBox ke database server."""
    vm = get_managed_vm(vm_id)
    if not vm:
        raise HTTPException(status_code=404, detail=f"Virtual Machine '{vm_id}' tidak ditemukan")

    updated = await asyncio.to_thread(inspect_and_sync_vm, vm_id)
    if updated:
        vm = updated

    return VmItemResponse(**vm)

