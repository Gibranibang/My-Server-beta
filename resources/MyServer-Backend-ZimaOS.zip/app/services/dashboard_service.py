"""
Stdlib-only RBAC Dashboard Telemetry, Storage Summary, and PWA Shell Service.
Shared by FastAPI (app/routers/system.py, app/main.py) and dev_server.py
so both runtimes emit identical schemas and enforce SECH-03 boundaries.
"""

import glob
import json
import logging
import os
import shutil
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import app.config as _app_config
from app.config import DB_PATH, SERVER_VERSION, STORAGE_DIR, is_admin_username
from app.database import get_db, normalize_user_role
from app.services.smb_manager import (
    get_smb_status,
    is_fuse_or_remote_mount,
    is_storage_path_forbidden,
)

logger = logging.getLogger("myserver.dashboard")

_CPU_SAMPLE_LOCK = threading.Lock()
_CPU_LAST_SNAPSHOT: Dict[str, Any] = {"total": 0.0, "idle": 0.0, "pct": 0.0}

_DISK_CACHE_LOCK = threading.Lock()
_DISK_CACHE: Dict[str, Tuple[int, int, int, float]] = {}
_DISK_INFLIGHT: Dict[str, threading.Thread] = {}
_DISK_CACHE_TTL_SEC = 5.0
_DISK_FUSE_CACHE_TTL_SEC = 30.0
_DISK_PROBE_TIMEOUT_SEC = 1.5


def _get_cached_disk_usage(path: str, ttl_sec: float = _DISK_CACHE_TTL_SEC) -> Tuple[int, int, int]:
    """Return cached (total, used, free) byte tuple keyed by os.path.realpath(path) with timeout guard."""
    canon = os.path.realpath(path)
    effective_ttl = (
        _DISK_FUSE_CACHE_TTL_SEC
        if ttl_sec == _DISK_CACHE_TTL_SEC and is_fuse_or_remote_mount(canon)
        else ttl_sec
    )
    now_mono = time.monotonic()
    stale_entry: Optional[Tuple[int, int, int]] = None
    existing_thread: Optional[threading.Thread] = None
    with _DISK_CACHE_LOCK:
        entry = _DISK_CACHE.get(canon)
        if entry is not None:
            stale_entry = (entry[0], entry[1], entry[2])
            if (now_mono - entry[3]) < effective_ttl:
                return stale_entry
        cand_thread = _DISK_INFLIGHT.get(canon)
        if cand_thread is not None and cand_thread.is_alive():
            existing_thread = cand_thread

    if existing_thread is not None:
        existing_thread.join(timeout=_DISK_PROBE_TIMEOUT_SEC)
        with _DISK_CACHE_LOCK:
            refreshed = _DISK_CACHE.get(canon)
            if refreshed is not None:
                return (refreshed[0], refreshed[1], refreshed[2])
        return stale_entry if stale_entry is not None else (0, 0, 0)

    result_box: Dict[str, Any] = {}

    def _probe() -> None:
        try:
            usage = shutil.disk_usage(path)
            vals = (int(usage.total), int(usage.used), int(usage.free))
            result_box["vals"] = vals
            with _DISK_CACHE_LOCK:
                _DISK_CACHE[canon] = (vals[0], vals[1], vals[2], time.monotonic())
        except Exception as exc:
            result_box["err"] = exc
        finally:
            with _DISK_CACHE_LOCK:
                if _DISK_INFLIGHT.get(canon) is threading.current_thread():
                    _DISK_INFLIGHT.pop(canon, None)

    t = threading.Thread(target=_probe, daemon=True)
    with _DISK_CACHE_LOCK:
        _DISK_INFLIGHT[canon] = t
    t.start()
    t.join(timeout=_DISK_PROBE_TIMEOUT_SEC)
    if t.is_alive() or "err" in result_box or "vals" not in result_box:
        return stale_entry if stale_entry is not None else (0, 0, 0)

    return result_box["vals"]


def _read_cpu_percent() -> float:
    """Read non-blocking CPU utilization percentage from /proc/stat delta."""
    try:
        with open("/proc/stat", "r", encoding="utf-8") as f:
            line = f.readline()
        vals = [float(x) for x in line.strip().split()[1:]]
        if len(vals) >= 4:
            idle = vals[3] + (vals[4] if len(vals) > 4 else 0.0)
            total = sum(vals)
            with _CPU_SAMPLE_LOCK:
                prev_tot = float(_CPU_LAST_SNAPSHOT["total"])
                prev_idle = float(_CPU_LAST_SNAPSHOT["idle"])
                _CPU_LAST_SNAPSHOT["total"] = total
                _CPU_LAST_SNAPSHOT["idle"] = idle
                if prev_tot > 0.0 and total > prev_tot:
                    diff_tot = total - prev_tot
                    diff_idle = idle - prev_idle
                    pct = (1.0 - (diff_idle / diff_tot)) * 100.0
                    _CPU_LAST_SNAPSHOT["pct"] = round(max(0.0, min(100.0, pct)), 1)
                return float(_CPU_LAST_SNAPSHOT["pct"])
    except Exception:
        pass
    return 0.0


def _read_cpu_temperature() -> Optional[float]:
    """Read CPU thermal sensor temperature in Celsius, or None if unavailable."""
    for p in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            with open(p, "r", encoding="utf-8") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue

    for p in glob.glob("/sys/class/hwmon/hwmon*/temp*_input"):
        try:
            with open(p, "r", encoding="utf-8") as f:
                val = float(f.read().strip())
                if val >= 1000.0:
                    val /= 1000.0
                if 0.0 < val < 130.0:
                    return round(val, 1)
        except Exception:
            continue
    return None


def _read_memory_info() -> Dict[str, Any]:
    """Read RAM metrics from /proc/meminfo with safe zero defaults."""
    total = 0
    available = 0
    free = 0
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    if key == "MemTotal":
                        total = int(val) * 1024
                    elif key == "MemAvailable":
                        available = int(val) * 1024
                    elif key == "MemFree":
                        free = int(val) * 1024
    except Exception:
        pass

    if total > 0:
        avail_or_free = available if available > 0 else free
        used = max(0, total - avail_or_free)
        pct = round((used / total) * 100.0, 1)
    else:
        avail_or_free = 0
        used = 0
        pct = 0.0

    return {
        "total": total,
        "used": used,
        "free": avail_or_free,
        "usedPercent": pct,
    }


def _read_network_io() -> Dict[str, int]:
    """Read cumulative network RX/TX bytes from /proc/net/dev excluding loopback."""
    bytes_recv = 0
    bytes_sent = 0
    try:
        with open("/proc/net/dev", "r", encoding="utf-8") as f:
            lines = f.readlines()[2:]
            for line in lines:
                parts = line.strip().split(":")
                if len(parts) == 2:
                    iface = parts[0].strip()
                    if iface == "lo":
                        continue
                    stats = parts[1].split()
                    if len(stats) >= 9:
                        bytes_recv += int(stats[0])
                        bytes_sent += int(stats[8])
    except Exception:
        pass
    return {"bytes_sent": bytes_sent, "bytes_recv": bytes_recv}


def _read_uptime_seconds(started_at: float) -> float:
    """Read host uptime from /proc/uptime, falling back to server elapsed uptime."""
    try:
        with open("/proc/uptime", "r", encoding="utf-8") as f:
            val = float(f.readline().strip().split()[0])
            if val >= 0.0:
                return round(val, 1)
    except Exception:
        pass
    try:
        return round(max(0.0, time.time() - float(started_at)), 1)
    except Exception:
        return 0.0


def _parse_allowed_disks(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    if isinstance(raw, str):
        stripped = raw.strip()
        if not stripped:
            return []
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, list):
                return [str(x).strip() for x in parsed if str(x).strip()]
        except Exception:
            return [x.strip() for x in stripped.split(",") if x.strip()]
    return []


def _collect_permitted_disks(
    username: str,
    allowed_list: Optional[List[str]],
    is_admin: bool,
    storage_dir: str,
) -> List[Dict[str, Any]]:
    """Scan storage_dir and return only disks permitted for the caller."""
    disks: List[Dict[str, Any]] = []
    target_storage = str(storage_dir or getattr(_app_config, "STORAGE_DIR", STORAGE_DIR))
    try:
        os.makedirs(target_storage, exist_ok=True)
    except Exception:
        pass

    try:
        for entry in os.scandir(target_storage):
            if entry.is_dir():
                if entry.name == ".trash":
                    continue
                sub_rel = entry.name
                is_accessible = not is_storage_path_forbidden(sub_rel, username, allowed_list, is_admin=is_admin)
                if not is_accessible:
                    continue

                total_b, used_b, free_b = _get_cached_disk_usage(entry.path)
                is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(entry.path)))
                pct = round((used_b / total_b) * 100.0, 1) if total_b > 0 else 0.0
                disks.append({
                    "name": entry.name,
                    "relative_path": sub_rel,
                    "label": entry.name,
                    "mount_point": entry.path,
                    "total_bytes": int(total_b),
                    "used_bytes": int(used_b),
                    "free_bytes": int(free_b),
                    "percent": pct,
                    "is_accessible": True,
                    "is_remote": is_remote,
                })
    except Exception as exc:
        logger.warning("Failed to scan storage subdirectories: %s", exc)

    # Root disk fallback ONLY for unrestricted admins; never expose host root disk to restricted accounts.
    if not disks and is_admin and not allowed_list:
        total_b, used_b, free_b = _get_cached_disk_usage(target_storage)
        is_remote = bool(is_fuse_or_remote_mount(os.path.realpath(target_storage)))
        pct = round((used_b / total_b) * 100.0, 1) if total_b > 0 else 0.0
        disks.append({
            "name": "Storage",
            "relative_path": "",
            "label": "Storage Utama",
            "mount_point": os.path.abspath(target_storage),
            "total_bytes": int(total_b),
            "used_bytes": int(used_b),
            "free_bytes": int(free_b),
            "percent": pct,
            "is_accessible": True,
            "is_remote": is_remote,
        })

    disks.sort(key=lambda d: str(d.get("name", "")).lower())
    return disks


def _query_devices_summary(db_path: str) -> Dict[str, int]:
    try:
        from app.database import deduplicate_devices_by_ip
        try:
            deduplicate_devices_by_ip(db_path)
        except Exception:
            pass
        with get_db(db_path) as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(DISTINCT CASE
                        WHEN COALESCE(TRIM(ip_address), '') = '' THEN device_id
                        WHEN LOWER(TRIM(REPLACE(ip_address, '::ffff:', ''))) IN ('127.0.0.1', '::1', 'localhost')
                            THEN LOWER(TRIM(REPLACE(ip_address, '::ffff:', ''))) || '|' || user_id
                        ELSE LOWER(TRIM(REPLACE(ip_address, '::ffff:', '')))
                    END) AS total,
                    COUNT(DISTINCT CASE
                        WHEN last_seen IS NOT NULL AND last_seen >= datetime('now', '-120 seconds') THEN
                            CASE
                                WHEN COALESCE(TRIM(ip_address), '') = '' THEN device_id
                                WHEN LOWER(TRIM(REPLACE(ip_address, '::ffff:', ''))) IN ('127.0.0.1', '::1', 'localhost')
                                    THEN LOWER(TRIM(REPLACE(ip_address, '::ffff:', ''))) || '|' || user_id
                                ELSE LOWER(TRIM(REPLACE(ip_address, '::ffff:', '')))
                            END
                    END) AS online
                FROM devices
                """
            ).fetchone()
            total = int((row["total"] if row else 0) or 0)
            online = int((row["online"] if row else 0) or 0)
            return {"online": online, "total": total}
    except Exception:
        return {"online": 0, "total": 0}


def _query_backups_summary(db_path: str) -> Dict[str, int]:
    try:
        with get_db(db_path) as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN LOWER(COALESCE(status, '')) IN ('error', 'failed') THEN 1 ELSE 0 END) AS err_cnt,
                    SUM(CASE WHEN LOWER(COALESCE(status, '')) NOT IN ('error', 'failed')
                              AND (LOWER(COALESCE(status, '')) IN ('completed', 'syncing')
                                   OR last_run IS NOT NULL
                                   OR COALESCE(total_files, 0) > 0)
                        THEN 1 ELSE 0 END) AS ok_cnt
                FROM backup_tasks
                """
            ).fetchone()
            total = int((row["total"] if row else 0) or 0)
            err_cnt = int((row["err_cnt"] if row else 0) or 0)
            ok_cnt = int((row["ok_cnt"] if row else 0) or 0)
            return {"ok": ok_cnt, "error": err_cnt, "total": total}
    except Exception:
        return {"ok": 0, "error": 0, "total": 0}


def _query_vms_summary(db_path: str) -> Dict[str, int]:
    try:
        with get_db(db_path) as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN LOWER(COALESCE(status, '')) IN ('running', 'awake', 'online', 'active') THEN 1 ELSE 0 END) AS running_cnt
                FROM managed_vms
                """
            ).fetchone()
            total = int((row["total"] if row else 0) or 0)
            running_cnt = int((row["running_cnt"] if row else 0) or 0)
            return {"running": running_cnt, "total": total}
    except Exception:
        return {"running": 0, "total": 0}


def _query_user_shared_summary(db_path: str, username: str) -> Dict[str, Any]:
    clean_u = str(username or "").strip()
    if not clean_u:
        return {
            "shared_with_me_count": 0,
            "public_shares_count": 0,
            "recent_shared_with_me": [],
        }
    try:
        with get_db(db_path) as conn:
            cnt_row = conn.execute(
                "SELECT COUNT(*) AS c FROM internal_shares WHERE LOWER(grantee_username) = LOWER(?)",
                (clean_u,),
            ).fetchone()
            shared_with_me_count = int((cnt_row["c"] if cnt_row else 0) or 0)

            pub_row = conn.execute(
                """
                SELECT COUNT(*) AS c FROM public_shares
                WHERE LOWER(owner_username) = LOWER(?) AND COALESCE(revoked, 0) = 0
                """,
                (clean_u,),
            ).fetchone()
            public_shares_count = int((pub_row["c"] if pub_row else 0) or 0)

            recent_rows = conn.execute(
                """
                SELECT id, owner_username, target_path, is_dir, role, updated_at
                FROM internal_shares
                WHERE LOWER(grantee_username) = LOWER(?)
                ORDER BY updated_at DESC, id DESC
                LIMIT 4
                """,
                (clean_u,),
            ).fetchall()
            recent_items = [
                {
                    "id": int(r["id"]),
                    "owner_username": str(r["owner_username"] or ""),
                    "target_path": str(r["target_path"] or ""),
                    "is_dir": bool(r["is_dir"]),
                    "role": str(r["role"] or "viewer").strip().lower(),
                    "updated_at": str(r["updated_at"] or ""),
                }
                for r in recent_rows
            ]
            return {
                "shared_with_me_count": shared_with_me_count,
                "public_shares_count": public_shares_count,
                "recent_shared_with_me": recent_items,
            }
    except Exception:
        return {
            "shared_with_me_count": 0,
            "public_shares_count": 0,
            "recent_shared_with_me": [],
        }


def build_dashboard_summary(
    current_user: Dict[str, Any],
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
    started_at: float = 0.0,
) -> Dict[str, Any]:
    """
    Build RBAC-filtered host telemetry, storage totals, and role-scoped summary.
    SECH-03: Strictly omits 'services' when caller is not an admin.
    """
    target_storage = str(storage_dir or getattr(_app_config, "STORAGE_DIR", STORAGE_DIR))
    target_db = str(db_path or getattr(_app_config, "DB_PATH", DB_PATH))

    username = str((current_user or {}).get("username") or (current_user or {}).get("sub") or "").strip().lower()
    raw_role = normalize_user_role((current_user or {}).get("role"))
    is_admin = bool(raw_role in ("admin", "root") or is_admin_username(username))
    raw_allowed = _parse_allowed_disks((current_user or {}).get("allowed_disks"))
    allowed_list: Optional[List[str]] = (raw_allowed if raw_allowed else None) if is_admin else raw_allowed

    cpu_pct = _read_cpu_percent()
    temp_c = _read_cpu_temperature()
    mem = _read_memory_info()
    net = _read_network_io()

    disks = _collect_permitted_disks(username, allowed_list, is_admin, target_storage)
    total_b = sum(int(d["total_bytes"]) for d in disks)
    used_b = sum(int(d["used_bytes"]) for d in disks)
    free_b = sum(int(d["free_bytes"]) for d in disks)

    payload: Dict[str, Any] = {
        "username": username,
        "role": "admin" if is_admin else "user",
        "is_admin": is_admin,
        "cpu": {
            "percent": round(float(cpu_pct), 1),
            "cores": int(os.cpu_count() or 1),
            "temperature_c": round(float(temp_c), 1) if temp_c is not None else None,
        },
        "mem": {
            "percent": round(float(mem.get("usedPercent", 0.0)), 1),
            "total_bytes": int(mem.get("total", 0)),
            "used_bytes": int(mem.get("used", 0)),
            "free_bytes": int(mem.get("free", 0)),
        },
        "storage": {
            "total_bytes": total_b,
            "used_bytes": used_b,
            "free_bytes": free_b,
            "percent": round((used_b / total_b) * 100.0, 1) if total_b > 0 else 0.0,
            "disk_count": len(disks),
        },
        "network": {
            "bytes_recv": int(net.get("bytes_recv", 0)),
            "bytes_sent": int(net.get("bytes_sent", 0)),
            "timestamp": time.time(),
        },
        "disks": disks,
    }

    if is_admin:
        smb = get_smb_status(db_path=target_db, storage_dir=target_storage, live=False)
        payload["services"] = {
            "uptime_seconds": _read_uptime_seconds(started_at),
            "smb": {
                "mode": str(smb.get("mode", "zimaos")),
                "running": bool(smb.get("running", False)),
                "backend_smbd_running": bool(smb.get("backend_smbd_running", False)),
                "zimaos_smbd_running": bool(smb.get("zimaos_smbd_running", False)),
            },
            "devices": _query_devices_summary(target_db),
            "backups": _query_backups_summary(target_db),
            "vms": _query_vms_summary(target_db),
        }
    else:
        payload["shared_summary"] = _query_user_shared_summary(target_db, username)

    return payload


def build_pwa_manifest() -> Dict[str, Any]:
    """Return canonical Web App Manifest payload matching 14-UI-SPEC.md."""
    return {
        "name": "MyServer",
        "short_name": "MyServer",
        "description": "MyServer Web Home Dashboard and File Manager",
        "display": "standalone",
        "start_url": "/",
        "scope": "/",
        "theme_color": "#F5F7F4",
        "background_color": "#F5F7F4",
        "icons": [
            {
                "src": "/static/icons/icon-192.png",
                "sizes": "192x192",
                "type": "image/png",
                "purpose": "any",
            },
            {
                "src": "/static/icons/icon-512.png",
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "any",
            },
            {
                "src": "/static/icons/icon-maskable-512.png",
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "maskable",
            },
        ],
    }


def build_service_worker_js(version: Optional[str] = None) -> str:
    """Return canonical Service Worker script with strict network-only bypass on /api/* and /s/*."""
    ver = str(version or getattr(_app_config, "SERVER_VERSION", SERVER_VERSION) or "2.2.9").strip()
    cache_name = f"myserver-shell-v{ver}"
    return (
        f"const CACHE_NAME = {json.dumps(cache_name)};\n"
        "const SHELL_ASSETS = [\n"
        "  '/manifest.webmanifest',\n"
        "  '/static/icons/icon-192.png',\n"
        "  '/static/icons/icon-512.png',\n"
        "  '/static/icons/icon-maskable-512.png',\n"
        "  '/static/icons/logo-dark-mark.svg',\n"
        "  '/static/pdfjs/pdf.min.mjs',\n"
        "  '/static/pdfjs/pdf.worker.min.mjs',\n"
        "  '/static/vendor/uqr.mjs',\n"
        "];\n"
        "\n"
        "self.addEventListener('install', (event) => {\n"
        "  event.waitUntil(\n"
        "    caches.open(CACHE_NAME)\n"
        "      .then((cache) => cache.addAll(SHELL_ASSETS))\n"
        "      .catch(() => undefined)\n"
        "  );\n"
        "  self.skipWaiting();\n"
        "});\n"
        "\n"
        "self.addEventListener('activate', (event) => {\n"
        "  event.waitUntil(\n"
        "    caches.keys()\n"
        "      .then((keys) => Promise.all(\n"
        "        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))\n"
        "      ))\n"
        "      .then(() => self.clients.claim())\n"
        "  );\n"
        "});\n"
        "\n"
        "self.addEventListener('fetch', (event) => {\n"
        "  const req = event.request;\n"
        "  if (req.method !== 'GET') return;\n"
        "  if (req.headers.has('Authorization') || req.headers.has('Range')) return;\n"
        "  if ((req.headers.get('Accept') || '').includes('text/event-stream')) return;\n"
        "\n"
        "  const url = new URL(req.url);\n"
        "  if (url.origin !== self.location.origin) return;\n"
        "  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/s/')) return;\n"
        "\n"
        "  if (req.mode === 'navigate' || url.pathname === '/') {\n"
        "    event.respondWith(fetch(req));\n"
        "    return;\n"
        "  }\n"
        "\n"
        "  if (SHELL_ASSETS.includes(url.pathname)) {\n"
        "    event.respondWith(\n"
        "      caches.match(req).then((cached) => cached || fetch(req).then((res) => {\n"
        "        if (res && res.ok) {\n"
        "          const copy = res.clone();\n"
        "          caches.open(CACHE_NAME).then((c) => c.put(req, copy));\n"
        "        }\n"
        "        return res;\n"
        "      }))\n"
        "    );\n"
        "  }\n"
        "});\n"
    )
