"""
Shared OTA Update Utilities for MyServer Native Backend (FastAPI & Standalone).
Handles safe staged extraction, atomic-like clean directory sync with rollback,
dependency rebuild detection, backup retention pruning, and process boot tracking.
"""

import os
import shutil
import tempfile
import uuid
import zipfile
from datetime import datetime
from typing import Any, Dict, List, Optional

PROCESS_BOOT_ID = str(uuid.uuid4())


def get_process_boot_id() -> str:
    """Mengembalikan UUID unik proses aktif untuk verifikasi restart nyata pasca-OTA."""
    return PROCESS_BOOT_ID


def _read_normalized_bytes(file_path: str) -> bytes:
    """Membaca berkas dengan normalisasi CRLF/LF dan spasi ujung agar komparasi lintas-OS akurat."""
    with open(file_path, "rb") as f:
        return f.read().replace(b"\r\n", b"\n").strip()


def _safe_zip_rel_path(raw_name: str) -> Optional[str]:
    """Memvalidasi dan menormalkan path anggota ZIP guna mencegah Zip-Slip / traversal."""
    cleaned = (raw_name or "").replace("\\", "/").strip("/")
    if not cleaned or cleaned == ".":
        return None
    if os.path.isabs(cleaned) or ":" in cleaned.split("/")[0]:
        return None
    parts = [p for p in cleaned.split("/") if p and p != "."]
    if not parts or any(p == ".." for p in parts):
        return None
    return "/".join(parts)


def detect_zip_version(app_dir: str, fallback_version: str) -> str:
    """Mendeteksi nilai SERVER_VERSION dari app/config.py hasil ekstraksi."""
    config_file_path = os.path.join(app_dir, "config.py")
    if not os.path.exists(config_file_path):
        return fallback_version
    try:
        with open(config_file_path, "r", encoding="utf-8") as cf:
            for line in cf:
                stripped = line.strip()
                if stripped.startswith("SERVER_VERSION") and "=" in stripped:
                    val = stripped.split("=", 1)[1].split("#", 1)[0].strip().strip('"').strip("'")
                    if val:
                        return val
    except Exception:
        pass
    return fallback_version


def prune_old_backups(data_dir: str, keep: int = 3) -> int:
    """Menghapus direktori backup_app_* lama di DATA_DIR sambil menyisakan `keep` terbaru."""
    if not data_dir or not os.path.isdir(data_dir) or keep < 0:
        return 0
    candidates: List[str] = []
    for entry in os.listdir(data_dir):
        if entry.startswith("backup_app_"):
            full_path = os.path.join(data_dir, entry)
            if os.path.isdir(full_path):
                candidates.append(full_path)

    candidates.sort(
        key=lambda p: (os.path.getmtime(p), os.path.basename(p)),
        reverse=True,
    )
    pruned = 0
    for old_dir in candidates[keep:]:
        try:
            shutil.rmtree(old_dir)
            pruned += 1
        except Exception:
            pass
    return pruned


def _is_pycache_rel(rel_path: str) -> bool:
    parts = rel_path.replace("\\", "/").split("/")
    return "__pycache__" in parts or rel_path.endswith((".pyc", ".pyo"))


def sync_directory_clean(src_dir: str, dst_dir: str) -> Dict[str, Any]:
    """
    Menyinkronkan isi `src_dir` ke `dst_dir` secara bersih:
    - Menghapus berkas usang di `dst_dir` yang tidak ada di `src_dir`
    - Membersihkan bytecode `__pycache__` usang
    - Menyalin seluruh berkas baru dari `src_dir` ke `dst_dir`
    """
    os.makedirs(dst_dir, exist_ok=True)

    src_files: List[str] = []
    for root, dirs, files in os.walk(src_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fname in files:
            if fname.endswith((".pyc", ".pyo")):
                continue
            abs_src = os.path.join(root, fname)
            rel = os.path.relpath(abs_src, src_dir).replace("\\", "/")
            src_files.append(rel)

    src_file_set = set(src_files)
    src_dir_set = set()
    for rel in src_files:
        parent = os.path.dirname(rel).replace("\\", "/")
        while parent and parent != ".":
            src_dir_set.add(parent)
            parent = os.path.dirname(parent).replace("\\", "/")

    files_removed = 0
    for root, dirs, files in os.walk(dst_dir, topdown=False):
        rel_root = os.path.relpath(root, dst_dir).replace("\\", "/")
        if rel_root == ".":
            rel_root = ""

        # Hapus berkas usang maupun bytecode cache lama
        for fname in files:
            rel_file = f"{rel_root}/{fname}" if rel_root else fname
            abs_dst = os.path.join(root, fname)
            if _is_pycache_rel(rel_file):
                try:
                    os.remove(abs_dst)
                except Exception:
                    pass
                continue
            if rel_file not in src_file_set:
                os.remove(abs_dst)
                files_removed += 1

        # Hapus direktori __pycache__ atau subdirektori usang yang kosong
        if rel_root and (os.path.basename(root) == "__pycache__" or rel_root not in src_dir_set):
            try:
                if not os.listdir(root):
                    os.rmdir(root)
            except Exception:
                pass

    for rel in src_files:
        abs_src = os.path.join(src_dir, *rel.split("/"))
        abs_dst = os.path.join(dst_dir, *rel.split("/"))
        os.makedirs(os.path.dirname(abs_dst), exist_ok=True)
        shutil.copy2(abs_src, abs_dst)

    return {
        "extracted_files": sorted(src_files),
        "files_extracted": len(src_files),
        "files_removed": files_removed,
    }


def apply_ota_zip(
    temp_zip: str,
    app_dir: str,
    base_dir: str,
    data_dir: str,
    current_version: str,
    keep_backups: int = 3,
) -> Dict[str, Any]:
    """
    Mengekstrak paket OTA ZIP ke direktori staging sementara, mendeteksi perubahan
    dependensi container (Dockerfile/requirements.txt), mencadangkan app/ lama,
    menyinkronkan modul app/ baru secara bersih (rollback jika gagal), dan memangkas
    cadangan lama agar disk tidak membengkak.
    """
    os.makedirs(data_dir, exist_ok=True)
    stage_dir = tempfile.mkdtemp(prefix="ota_stage_", dir=data_dir)
    stage_real = os.path.realpath(stage_dir)

    try:
        with zipfile.ZipFile(temp_zip, "r") as zf:
            safe_members = []
            for member in zf.infolist():
                if member.is_dir():
                    continue
                rel = _safe_zip_rel_path(member.filename)
                if not rel or _is_pycache_rel(rel):
                    continue
                safe_members.append((member, rel))

            has_app_prefix = any(rel == "app" or rel.startswith("app/") for _, rel in safe_members)
            for member, rel in safe_members:
                target_path = os.path.join(stage_dir, *rel.split("/"))
                if os.path.commonpath([stage_real, os.path.realpath(target_path)]) != stage_real:
                    continue
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                with zf.open(member) as source, open(target_path, "wb") as target:
                    shutil.copyfileobj(source, target)

        staged_app_dir = os.path.join(stage_dir, "app") if has_app_prefix else stage_dir
        has_app_files = False
        if os.path.isdir(staged_app_dir):
            for _, dirs, files in os.walk(staged_app_dir):
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                if any(not f.endswith((".pyc", ".pyo")) for f in files):
                    has_app_files = True
                    break

        if not has_app_files:
            raise ValueError("Paket OTA ZIP tidak mengandung berkas modul aplikasi yang valid.")

        # Cek apakah Dockerfile atau requirements.txt berubah dibanding instalasi berjalan
        rebuild_required = False
        for dep_fname in ("requirements.txt", "Dockerfile"):
            staged_dep = os.path.join(stage_dir, dep_fname)
            current_dep = os.path.join(base_dir, dep_fname)
            if os.path.isfile(staged_dep) and os.path.isfile(current_dep):
                if _read_normalized_bytes(staged_dep) != _read_normalized_bytes(current_dep):
                    rebuild_required = True
                    break

        # Buat direktori cadangan sebelum menyinkronkan app/
        ts_str = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup_target_dir = os.path.join(data_dir, f"backup_app_{ts_str}")
        backup_created = False
        if os.path.exists(app_dir):
            shutil.copytree(
                app_dir,
                backup_target_dir,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
            )
            backup_created = True

        try:
            sync_stats = sync_directory_clean(staged_app_dir, app_dir)
        except Exception:
            if backup_created and os.path.isdir(backup_target_dir):
                try:
                    sync_directory_clean(backup_target_dir, app_dir)
                except Exception:
                    pass
            raise

        new_version = detect_zip_version(app_dir, current_version)
        backups_pruned = prune_old_backups(data_dir, keep=keep_backups)

        return {
            "new_version": new_version,
            "backup_dir": backup_target_dir if backup_created else None,
            "extracted_files": sync_stats["extracted_files"],
            "files_extracted": sync_stats["files_extracted"],
            "files_removed": sync_stats["files_removed"],
            "rebuild_required": rebuild_required,
            "backups_pruned": backups_pruned,
            "boot_id": PROCESS_BOOT_ID,
        }
    finally:
        shutil.rmtree(stage_dir, ignore_errors=True)
