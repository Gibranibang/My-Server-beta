"""
Standalone SMB Engine Service (smbd) & Port 445 Mutual Exclusion Manager.
Synchronizes SQLite users, encrypted SMB passwords, and allowed_disks ACLs
to /app/data/samba/smb.conf and passdb.tdb deterministically.
"""

import html
import logging
import os
import re
import shutil
import signal
import socket
import subprocess
import tempfile
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import app.config
from app.config import is_admin_username
from app.database import (
    decrypt_smb_password,
    get_system_setting,
    list_all_users,
    list_users_with_smb_secrets,
    set_system_setting,
)

logger = logging.getLogger("myserver.smb")

_SMB_SYNC_LOCK = threading.RLock()
_USERNAME_RE = re.compile(r"^[a-z0-9_.-]+$")
_EXCLUDED_SMB_SHARE_NAMES = {"global", "homes", "printers", "ipc$", "pc_backups"}
DANGEROUS_INLINE_STREAM_EXTENSIONS = {".svg", ".svgz", ".html", ".htm", ".xhtml", ".xml", ".js", ".mjs"}


def _get_data_dir() -> str:
    return str(getattr(app.config, "DATA_DIR", app.config.DATA_DIR))


def _get_storage_dir() -> str:
    return str(getattr(app.config, "STORAGE_DIR", app.config.STORAGE_DIR))


def _get_db_path(db_path: Optional[str] = None) -> str:
    return db_path or str(getattr(app.config, "DB_PATH", app.config.DB_PATH))


def get_samba_paths() -> Dict[str, str]:
    """Resolve persistent Samba directories under DATA_DIR dynamically."""
    base = os.path.join(_get_data_dir(), "samba")
    return {
        "base": base,
        "private": os.path.join(base, "private"),
        "run": os.path.join(base, "run"),
        "lock": os.path.join(base, "lock"),
        "state": os.path.join(base, "state"),
        "cache": os.path.join(base, "cache"),
        "conf": os.path.join(base, "smb.conf"),
        "pid": os.path.join(base, "run", "smbd.pid"),
        "passdb": os.path.join(base, "private", "passdb.tdb"),
    }


def ensure_samba_dirs() -> Dict[str, str]:
    """Ensure all Samba persistence/runtime subdirectories exist."""
    paths = get_samba_paths()
    for key in ("base", "private", "run", "lock", "state", "cache"):
        os.makedirs(paths[key], exist_ok=True)
    try:
        os.chmod(paths["private"], 0o700)
    except OSError:
        pass
    return paths


def validate_smb_username(username: str) -> str:
    """Validate and normalize SMB/UNIX username against strict allowlist regex."""
    if not isinstance(username, str):
        raise ValueError("Username harus berupa string.")
    clean_u = username.strip().lower()
    if (
        not clean_u
        or len(clean_u) > 64
        or clean_u in (".", "..")
        or not _USERNAME_RE.match(clean_u)
    ):
        raise ValueError(f"Username '{username}' mengandung karakter tidak diizinkan.")
    return clean_u


def resolve_safe_storage_target(storage_root: str, raw_rel: Optional[str]) -> Tuple[str, str]:
    """
    Kanonalisasi jalur relatif terhadap os.path.realpath(storage_root) sebelum cek ACL.
    Menolak path traversal ('..') atau symlink escape keluar storage_root dengan ValueError.
    """
    if not storage_root:
        raise ValueError("Akses path tidak diizinkan")
    root_real = os.path.realpath(storage_root)
    raw_str = "" if raw_rel is None else str(raw_rel)
    if "\x00" in raw_str:
        raise ValueError("Akses path tidak diizinkan")
    cleaned = raw_str.strip().replace("\\", "/").lstrip("/")
    if cleaned and any(seg == ".." for seg in cleaned.split("/")):
        raise ValueError("Akses path tidak diizinkan")
    if cleaned and ":" in cleaned.split("/")[0]:
        raise ValueError("Akses path tidak diizinkan")
    candidate_real = os.path.realpath(os.path.join(root_real, cleaned)) if cleaned else root_real
    if os.path.commonpath([root_real, candidate_real]) != root_real:
        raise ValueError("Akses path tidak diizinkan")
    canonical_rel = "" if candidate_real == root_real else os.path.relpath(candidate_real, root_real).replace("\\", "/")
    return canonical_rel, candidate_real


def _normalize_allowed_disk_norms(allowed_disks: Optional[list]) -> set:
    allowed_norms = set()
    if allowed_disks is None:
        return allowed_norms
    for a in allowed_disks:
        clean_a = str(a).lower().replace("/media/", "").replace("/data/", "").strip("/").replace(" ", "_")
        root_a = clean_a.split("/")[0] if clean_a else ""
        if root_a:
            allowed_norms.add(root_a)
        if clean_a:
            allowed_norms.add(clean_a)
    return allowed_norms


def is_storage_path_forbidden(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """
    Pemeriksaan ACL multi-user & multi-disk (fail-closed):
    - Menolak segmen '..' pada semua peran sebagai pertahanan berlapis.
    - Menolak jika username kosong/None dan is_admin=False.
    - Memeriksa parts[0] terhadap allowed_disks SEBELUM aturan pc_backups bila parts[0] != 'pc_backups'.
    """
    raw_parts = [p for p in (rel_path or "").replace("\\", "/").strip("/").split("/") if p and p != "."]
    if any(p == ".." for p in raw_parts):
        return True
    if is_admin:
        return False
    clean_u = (username or "").strip()
    if not clean_u:
        return True
    if is_admin_username(clean_u):
        return False

    parts = [p.lower() for p in raw_parts]
    if not parts:
        return False

    allowed_norms = _normalize_allowed_disk_norms(allowed_disks)
    root_part = parts[0].replace(" ", "_")

    if root_part != "pc_backups":
        if allowed_disks is None or root_part not in allowed_norms:
            return True
        if "pc_backups" in parts:
            idx = parts.index("pc_backups")
            if len(parts) > idx + 1:
                return parts[idx + 1] != clean_u.lower()
            return "pc_backups" not in allowed_norms
        return False

    if len(parts) > 1:
        owner = parts[1]
        return owner != clean_u.lower()
    return "pc_backups" not in allowed_norms


def build_stream_security_headers(full_path: str) -> Dict[str, str]:
    """Bangun header keamanan respons streaming (anti-XSS SVG/HTML & nosniff)."""
    headers: Dict[str, str] = {
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
    }
    ext = os.path.splitext(full_path)[1].lower()
    if ext in DANGEROUS_INLINE_STREAM_EXTENSIONS:
        safe_name = os.path.basename(full_path).replace('"', "_").replace("\r", "").replace("\n", "")
        headers["Content-Disposition"] = f'attachment; filename="{safe_name}"'
    return headers


def _safe_url_attr(url: str) -> str:
    return (
        str(url)
        .replace('"', "%22")
        .replace("'", "%27")
        .replace("<", "%3C")
        .replace(">", "%3E")
        .replace("\r", "")
        .replace("\n", "")
    )


def render_media_player_html(filename: str, rel_req: str, stream_url: str, download_url: str) -> str:
    """Render HTML5 Media Player bersama dengan escaping HTML penuh untuk mencegah XSS."""
    ext = os.path.splitext(filename)[1].lower()
    safe_filename = html.escape(filename)
    safe_rel = html.escape(rel_req)
    safe_ext = html.escape(ext)
    safe_stream_url = _safe_url_attr(stream_url)
    safe_download_url = _safe_url_attr(download_url)

    is_video = ext in (".mp4", ".mkv", ".webm", ".mov", ".avi", ".ts")
    is_audio = ext in (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".wma")
    is_image = ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg")

    if is_video:
        media_tag = f"""<video id="player" controls autoplay playsinline preload="metadata">
            <source src="{safe_stream_url}">
            Peramban Anda tidak mendukung pemutaran video HTML5.
        </video>"""
    elif is_audio:
        media_tag = f"""<div class="audio-card">
            <div class="audio-icon">🎵</div>
            <div class="audio-title">{safe_filename}</div>
            <div class="audio-path">{safe_rel}</div>
            <audio id="player" controls autoplay preload="metadata" src="{safe_stream_url}"></audio>
        </div>"""
    elif is_image:
        media_tag = f"""<div class="img-container">
            <img id="imgViewer" src="{safe_stream_url}" alt="{safe_filename}" />
        </div>"""
    else:
        media_tag = f"""<div class="fallback-card">
            <div class="icon">📄</div>
            <h2>{safe_filename}</h2>
            <p>Format berkas ini ({safe_ext}) tidak dapat diputar langsung di pemutar web.</p>
            <a href="{safe_download_url}" class="btn-download" download>Unduh Berkas</a>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyServer Media Player - {safe_filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background-color: #0b0f19;
            color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
            user-select: none;
        }}
        .header {{
            background-color: #111827;
            border-bottom: 1px solid #1f2937;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 52px;
            z-index: 10;
        }}
        .brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 600;
            color: #38bdf8;
        }}
        .file-info {{
            display: flex;
            flex-direction: column;
            max-width: 60%;
            overflow: hidden;
        }}
        .file-title {{
            font-size: 14px;
            font-weight: 600;
            color: #f1f5f9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .file-sub {{
            font-size: 11px;
            color: #94a3b8;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .actions {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .btn {{
            background-color: #1f2937;
            border: 1px solid #374151;
            color: #e2e8f0;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            text-decoration: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }}
        .btn:hover {{
            background-color: #374151;
            color: #ffffff;
        }}
        .player-viewport {{
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #030712;
            position: relative;
            overflow: hidden;
        }}
        video {{
            width: 100%;
            height: 100%;
            max-width: 100vw;
            max-height: calc(100vh - 52px);
            outline: none;
            background: #000;
        }}
        .audio-card {{
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 16px;
            padding: 36px 44px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
            max-width: 480px;
            width: 90%;
        }}
        .audio-icon {{
            font-size: 48px;
            background: #1e293b;
            width: 90px;
            height: 90px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(56, 189, 248, 0.2);
        }}
        .audio-title {{
            font-size: 17px;
            font-weight: 600;
            color: #f8fafc;
            text-align: center;
            word-break: break-all;
        }}
        .audio-path {{
            font-size: 12px;
            color: #64748b;
            text-align: center;
        }}
        audio {{
            width: 320px;
            outline: none;
            margin-top: 10px;
        }}
        .img-container {{
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        .img-container img {{
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 4px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.7);
        }}
        .fallback-card {{
            background: #111827;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            max-width: 420px;
        }}
        .fallback-card .icon {{ font-size: 48px; margin-bottom: 12px; }}
        .fallback-card h2 {{ font-size: 16px; margin-bottom: 8px; }}
        .fallback-card p {{ font-size: 13px; color: #94a3b8; margin-bottom: 20px; }}
        .btn-download {{
            background: #0284c7;
            color: white;
            padding: 8px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">
            <span>⚡ MyServer Player</span>
        </div>
        <div class="file-info">
            <span class="file-title">{safe_filename}</span>
            <span class="file-sub">{safe_rel}</span>
        </div>
        <div class="actions">
            <a href="{safe_download_url}" class="btn" title="Unduh berkas">⬇️ Unduh</a>
            <button class="btn" onclick="toggleFullscreen()" title="Layar Penuh (F)">⛶ Layar Penuh</button>
        </div>
    </div>
    <div class="player-viewport">
        {media_tag}
    </div>
    <script>
        const p = document.getElementById('player');
        function toggleFullscreen() {{
            if (!document.fullscreenElement) {{
                document.documentElement.requestFullscreen().catch(() => {{}});
            }} else {{
                document.exitFullscreen().catch(() => {{}});
            }}
        }}
        window.addEventListener('keydown', (e) => {{
            if (!p) return;
            if (e.key === ' ' || e.code === 'Space') {{
                e.preventDefault();
                p.paused ? p.play() : p.pause();
            }} else if (e.key === 'ArrowRight') {{
                p.currentTime = Math.min(p.duration || 0, p.currentTime + 5);
            }} else if (e.key === 'ArrowLeft') {{
                p.currentTime = Math.max(0, p.currentTime - 5);
            }} else if (e.key === 'ArrowUp') {{
                e.preventDefault();
                p.volume = Math.min(1, p.volume + 0.1);
            }} else if (e.key === 'ArrowDown') {{
                e.preventDefault();
                p.volume = Math.max(0, p.volume - 0.1);
            }} else if (e.key.toLowerCase() === 'f') {{
                toggleFullscreen();
            }} else if (e.key.toLowerCase() === 'm') {{
                p.muted = !p.muted;
            }}
        }});
    </script>
</body>
</html>"""


def _is_forbidden_for_user_fallback(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """Stdlib mirror of app.routers.storage.is_forbidden_for_user when pydantic/fastapi is unavailable."""
    return is_storage_path_forbidden(rel_path, username, allowed_disks, is_admin=is_admin)


def _is_disk_forbidden_for_user(
    rel_path: str,
    username: Optional[str],
    allowed_disks: Optional[list] = None,
    is_admin: bool = False,
) -> bool:
    """
    Lazy-delegate disk ACL check to app.routers.storage.is_forbidden_for_user without
    requiring top-level pydantic/fastapi import on host Python environments.
    """
    if is_admin:
        return False
    try:
        from app.routers.storage import is_forbidden_for_user as storage_is_forbidden

        return bool(storage_is_forbidden(rel_path, username, allowed_disks, is_admin=is_admin))
    except ImportError:
        return _is_forbidden_for_user_fallback(
            rel_path, username, allowed_disks, is_admin=is_admin
        )


def _atomic_write_text(target_path: str, content: str) -> None:
    """Write file atomically using temp file in the same directory + os.replace."""
    parent_dir = os.path.dirname(os.path.abspath(target_path))
    os.makedirs(parent_dir, exist_ok=True)
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=parent_dir,
            prefix=".tmp_smb_",
            delete=False,
        ) as tf:
            tmp_path = tf.name
            tf.write(content)
            tf.flush()
            try:
                os.fsync(tf.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target_path)
    except Exception:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise


def _mirror_system_smb_conf(content: str) -> None:
    """Mirror generated smb.conf to /etc/samba/smb.conf when running inside root container."""
    try:
        is_root = hasattr(os, "geteuid") and os.geteuid() == 0
    except Exception:
        is_root = False
    if is_root and os.path.isdir("/etc/samba") and os.access("/etc/samba", os.W_OK):
        try:
            _atomic_write_text("/etc/samba/smb.conf", content)
        except OSError as exc:
            logger.warning(f"Gagal menyalin smb.conf ke /etc/samba/smb.conf: {exc}")


def _is_valid_smb_share_name(disk_name: str) -> bool:
    if not disk_name or disk_name.startswith("."):
        return False
    if disk_name.lower() in _EXCLUDED_SMB_SHARE_NAMES:
        return False
    if any(c in disk_name for c in ("[", "]", "\n", "\r")):
        return False
    return True


def _compute_shares_inventory(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Compute share list and authorized SQLite valid_users per immediate directory under STORAGE_DIR."""
    target_storage = storage_dir or _get_storage_dir()
    target_db = _get_db_path(db_path)
    os.makedirs(target_storage, exist_ok=True)
    storage_real = os.path.realpath(target_storage)

    users = list_all_users(target_db)
    shares: List[Dict[str, Any]] = []

    try:
        entries = [e for e in os.scandir(target_storage) if e.is_dir()]
    except OSError as exc:
        logger.warning(f"Gagal memindai STORAGE_DIR '{target_storage}': {exc}")
        entries = []

    entries.sort(key=lambda e: e.name.lower())

    for entry in entries:
        disk_name = entry.name
        if not _is_valid_smb_share_name(disk_name):
            continue
        try:
            if os.path.commonpath([storage_real, os.path.realpath(entry.path)]) != storage_real:
                continue
        except OSError:
            continue
        valid_users: List[str] = []
        seen_users = set()
        for user in users:
            raw_uname = str(user.get("username") or "")
            try:
                clean_u = validate_smb_username(raw_uname)
            except ValueError:
                continue
            if clean_u in seen_users:
                continue
            role_str = str(user.get("role") or "staff").strip().lower()
            user_is_admin = bool(role_str in ("admin", "root") or is_admin_username(clean_u))
            allowed_disks = user.get("allowed_disks")
            if not isinstance(allowed_disks, list):
                allowed_disks = []
            if user_is_admin or not _is_disk_forbidden_for_user(
                disk_name, clean_u, allowed_disks, is_admin=user_is_admin
            ):
                seen_users.add(clean_u)
                valid_users.append(clean_u)

        shares.append(
            {
                "name": disk_name,
                "path": os.path.abspath(entry.path),
                "valid_users": valid_users,
                "writable": True,
            }
        )

    return shares


def generate_smb_conf(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
) -> str:
    """
    Generate /app/data/samba/smb.conf atomically from STORAGE_DIR subdirectories
    and SQLite users/role/allowed_disks ACLs. Returns path to generated smb.conf.
    """
    with _SMB_SYNC_LOCK:
        paths = ensure_samba_dirs()
        shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=db_path)

        lines = [
            "[global]",
            "   workgroup = WORKGROUP",
            "   server string = MyServer Backend SMB Engine",
            "   security = user",
            "   map to guest = Never",
            f"   passdb backend = tdbsam:{paths['passdb']}",
            f"   private dir = {paths['private']}",
            f"   lock directory = {paths['lock']}",
            f"   state directory = {paths['state']}",
            f"   cache directory = {paths['cache']}",
            f"   pid directory = {paths['run']}",
            "   smb ports = 445",
            "   disable netbios = yes",
            "   server min protocol = SMB2",
            "   load printers = no",
            "   printing = bsd",
            "   printcap name = /dev/null",
            "   disable spoolss = yes",
            "",
        ]

        for share in shares:
            valid_list = share["valid_users"]
            lines.append(f"[{share['name']}]")
            lines.append(f"   path = {share['path']}")
            if valid_list:
                lines.append("   browseable = yes")
                lines.append("   read only = no")
                lines.append("   writable = yes")
                lines.append("   guest ok = no")
                lines.append(f"   valid users = {', '.join(valid_list)}")
            else:
                lines.append("   browseable = no")
                lines.append("   read only = yes")
                lines.append("   writable = no")
                lines.append("   guest ok = no")
                lines.append("   valid users = __myserver_nobody__")
                lines.append("   invalid users = *")
            lines.append("   force user = root")
            lines.append("   force group = root")
            lines.append("   create mask = 0664")
            lines.append("   directory mask = 0775")
            lines.append("")

        conf_text = "\n".join(lines)
        _atomic_write_text(paths["conf"], conf_text)
        _mirror_system_smb_conf(conf_text)
        return paths["conf"]


def sync_unix_and_samba_user(
    username: str,
    password: Optional[str] = None,
    uid_hint: Optional[int] = None,
    db_path: Optional[str] = None,
) -> bool:
    """
    Ensure UNIX account exists with deterministic UID (10000 + user_id) and sync
    Samba passdb credentials via safe list-based subprocess without shell=True.
    """
    clean_u = validate_smb_username(username)
    smbpasswd_bin = shutil.which("smbpasswd")
    if not smbpasswd_bin:
        return False

    with _SMB_SYNC_LOCK:
        paths = ensure_samba_dirs()
        if not os.path.isfile(paths["conf"]):
            generate_smb_conf(db_path=db_path)

        try:
            res_id = subprocess.run(
                ["id", "-u", clean_u],
                shell=False,
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            if res_id.returncode != 0:
                cmd = ["useradd", "-M", "-s", "/usr/sbin/nologin"]
                if uid_hint is not None:
                    try:
                        uid_val = 10000 + int(uid_hint)
                        if uid_val >= 10000:
                            cmd.extend(["-u", str(uid_val), "-o"])
                    except (TypeError, ValueError):
                        pass
                cmd.append(clean_u)
                res_add = subprocess.run(
                    cmd,
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=5.0,
                )
                if res_add.returncode != 0:
                    res_recheck = subprocess.run(
                        ["id", "-u", clean_u],
                        shell=False,
                        capture_output=True,
                        text=True,
                        timeout=3.0,
                    )
                    if res_recheck.returncode != 0:
                        logger.warning(f"Gagal membuat akun UNIX '{clean_u}': {res_add.stderr}")
                        return False

            if password:
                proc = subprocess.run(
                    ["smbpasswd", "-c", paths["conf"], "-a", "-s", clean_u],
                    input=f"{password}\n{password}\n",
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=5.0,
                )
                if proc.returncode != 0:
                    logger.warning(f"smbpasswd gagal untuk '{clean_u}': {proc.stderr}")
                    return False
                proc_en = subprocess.run(
                    ["smbpasswd", "-c", paths["conf"], "-e", clean_u],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=3.0,
                )
                if proc_en.returncode != 0:
                    logger.warning(f"smbpasswd -e gagal untuk '{clean_u}': {proc_en.stderr}")
                    return False
                return True
            return True
        except Exception as exc:
            logger.warning(f"Gagal sinkronisasi akun Samba '{clean_u}': {exc}")
            return False


def remove_unix_and_samba_user(username: str) -> bool:
    """Remove a user from Samba passdb safely without shell=True."""
    clean_u = validate_smb_username(username)
    if not shutil.which("smbpasswd"):
        return False

    with _SMB_SYNC_LOCK:
        paths = get_samba_paths()
        if not os.path.isfile(paths["conf"]):
            return True
        try:
            proc = subprocess.run(
                ["smbpasswd", "-c", paths["conf"], "-x", clean_u],
                shell=False,
                capture_output=True,
                text=True,
                timeout=5.0,
            )
            return proc.returncode == 0
        except Exception as exc:
            logger.warning(f"Gagal menghapus akun Samba '{clean_u}': {exc}")
            return False


def _read_pid_file(pid_path: str) -> Optional[int]:
    if not os.path.isfile(pid_path):
        return None
    try:
        with open(pid_path, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        return int(raw) if raw else None
    except Exception:
        return None


def _is_pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _is_backend_smbd_running() -> bool:
    paths = get_samba_paths()
    pid = _read_pid_file(paths["pid"])
    return bool(pid and _is_pid_alive(pid))


def _is_zimaos_smbd_running(current_mode: str) -> bool:
    if not shutil.which("nsenter"):
        return current_mode == "zimaos"
    try:
        res = subprocess.run(
            [
                "nsenter",
                "-t",
                "1",
                "-m",
                "-u",
                "-n",
                "-i",
                "sh",
                "-c",
                "systemctl is-active --quiet smbd || service smbd status >/dev/null 2>&1",
            ],
            shell=False,
            capture_output=True,
            text=True,
            timeout=3.0,
        )
        return res.returncode == 0
    except Exception:
        return current_mode == "zimaos"


def _wait_port_445_free(timeout_sec: float = 2.0) -> bool:
    """Poll TCP 127.0.0.1:445 until released or timeout expires."""
    deadline = time.monotonic() + timeout_sec
    while True:
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.15)
            err = sock.connect_ex(("127.0.0.1", 445))
            if err != 0:
                return True
        except OSError:
            return True
        finally:
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.1)


def _reload_running_smbd(conf_path: str) -> None:
    """Reload smbd configuration via smbcontrol or SIGHUP if active."""
    paths = get_samba_paths()
    pid = _read_pid_file(paths["pid"])
    if not (pid and _is_pid_alive(pid)):
        return
    if shutil.which("smbcontrol"):
        try:
            subprocess.run(
                ["smbcontrol", "-s", conf_path, "smbd", "reload-config"],
                shell=False,
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            return
        except Exception:
            pass
    try:
        os.kill(pid, signal.SIGHUP)
    except OSError:
        pass


def sync_samba_configuration(
    storage_dir: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Atomically regenerate smb.conf, synchronize all SQLite users (UNIX UID 10000+id
    + smbpasswd from encrypted smb_password_enc), and reload smbd if running.
    """
    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        ensure_samba_dirs()
        conf_path = generate_smb_conf(storage_dir=storage_dir, db_path=target_db)
        users = list_users_with_smb_secrets(target_db)

        has_smbpasswd = bool(shutil.which("smbpasswd"))
        has_smbd = bool(shutil.which("smbd"))
        simulation_mode = not bool(has_smbd and has_smbpasswd)

        synced_users: List[str] = []
        skipped_users: List[str] = []
        failed_users: List[str] = []
        for u in users:
            raw_name = str(u.get("username") or "")
            try:
                clean_u = validate_smb_username(raw_name)
            except ValueError:
                logger.warning(f"Melewati sinkronisasi user SMB dengan username tidak valid: {raw_name!r}")
                skipped_users.append(raw_name)
                continue
            plain_pw = decrypt_smb_password(u.get("smb_password_enc") or "")
            ok = sync_unix_and_samba_user(
                clean_u,
                password=plain_pw or None,
                uid_hint=u.get("id"),
                db_path=target_db,
            )
            if has_smbpasswd and not ok:
                failed_users.append(clean_u)
            else:
                synced_users.append(clean_u)

        _reload_running_smbd(conf_path)
        shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=target_db)
        return {
            "success": len(failed_users) == 0,
            "conf_path": conf_path,
            "synced_users": synced_users,
            "users_count": len(synced_users),
            "skipped_users": skipped_users,
            "failed_users": failed_users,
            "shares_count": len(shares),
            "simulation_mode": simulation_mode,
        }


def stop_backend_smbd() -> bool:
    """Stop standalone Backend smbd gracefully via PID file and targeted pkill fallback."""
    with _SMB_SYNC_LOCK:
        paths = get_samba_paths()
        pid = _read_pid_file(paths["pid"])
        if pid and _is_pid_alive(pid):
            try:
                os.kill(pid, signal.SIGTERM)
                deadline = time.monotonic() + 1.0
                while time.monotonic() < deadline and _is_pid_alive(pid):
                    time.sleep(0.05)
            except OSError:
                pass
        if os.path.isfile(paths["pid"]):
            try:
                os.remove(paths["pid"])
            except OSError:
                pass
        if shutil.which("pkill"):
            try:
                pattern = f"^([^ ]*/)?smbd( .*)? -s {re.escape(paths['conf'])}( |$)"
                subprocess.run(
                    ["pkill", "-f", pattern],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=3.0,
                )
            except Exception:
                pass
        return True


def get_smb_status(
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Return current SMB engine status, mode, port 445 owner, and share inventory."""
    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        paths = get_samba_paths()
        mode = get_system_setting("smb_mode", default="zimaos", db_path=target_db).strip().lower()
        if mode not in ("zimaos", "backend"):
            mode = "zimaos"

        has_smbd = bool(shutil.which("smbd"))
        simulation_mode = not has_smbd
        if simulation_mode:
            backend_running = mode == "backend"
            zimaos_running = mode == "zimaos"
        else:
            backend_running = _is_backend_smbd_running()
            zimaos_running = _is_zimaos_smbd_running(mode)

        shares = _compute_shares_inventory(storage_dir=storage_dir, db_path=target_db)
        users = list_all_users(target_db)

        return {
            "mode": mode,
            "backend_smbd_running": backend_running,
            "zimaos_smbd_running": zimaos_running,
            "port_445_owner": mode,
            "simulation_mode": simulation_mode,
            "conf_path": paths["conf"],
            "shares_count": len(shares),
            "shares": shares,
            "users_count": len(users),
            "message": (
                "Mode simulasi dev aktif (binary smbd tidak terpasang di host)."
                if simulation_mode
                else f"Port 445 aktif pada mode '{mode}'."
            ),
        }


def set_smb_mode(
    mode: str,
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Switch Port 445 SMB owner deterministically between 'zimaos' and 'backend'.
    Persists mode in SQLite system_settings for container restart recovery.
    """
    mode_clean = str(mode or "").strip().lower()
    if mode_clean not in ("zimaos", "backend"):
        raise ValueError("Mode SMB harus 'zimaos' atau 'backend'.")

    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        paths = ensure_samba_dirs()
        has_smbd = bool(shutil.which("smbd"))
        has_nsenter = bool(shutil.which("nsenter"))

        if mode_clean == "backend":
            sync_samba_configuration(storage_dir=storage_dir, db_path=target_db)
            if has_nsenter:
                try:
                    subprocess.run(
                        [
                            "nsenter",
                            "-t",
                            "1",
                            "-m",
                            "-u",
                            "-n",
                            "-i",
                            "sh",
                            "-c",
                            "systemctl stop smbd nmbd samba 2>/dev/null || service smbd stop 2>/dev/null || true",
                        ],
                        shell=False,
                        capture_output=True,
                        text=True,
                        timeout=8.0,
                    )
                except Exception as exc:
                    logger.warning(f"Gagal menghentikan smbd host ZimaOS via nsenter: {exc}")

            if has_smbd and not _is_backend_smbd_running():
                if not _wait_port_445_free(timeout_sec=2.0):
                    raise RuntimeError(
                        "Port 445 masih digunakan oleh layanan SMB host ZimaOS; gagal mengaktifkan mode Backend."
                    )
                proc = subprocess.run(
                    ["smbd", "-D", "-s", paths["conf"]],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=5.0,
                )
                if proc.returncode != 0:
                    err_detail = (proc.stderr or proc.stdout or "").strip()
                    raise RuntimeError(
                        f"smbd Backend gagal dijalankan (kode {proc.returncode}): {err_detail}"
                    )

            set_system_setting("smb_mode", "backend", db_path=target_db)
        else:
            stop_backend_smbd()
            if has_nsenter:
                try:
                    subprocess.run(
                        [
                            "nsenter",
                            "-t",
                            "1",
                            "-m",
                            "-u",
                            "-n",
                            "-i",
                            "sh",
                            "-c",
                            "systemctl restart smbd nmbd samba 2>/dev/null || systemctl start smbd nmbd samba 2>/dev/null || service smbd restart 2>/dev/null || service smbd start 2>/dev/null || true",
                        ],
                        shell=False,
                        capture_output=True,
                        text=True,
                        timeout=8.0,
                    )
                except Exception as exc:
                    logger.warning(f"Gagal menyalakan kembali smbd host ZimaOS via nsenter: {exc}")

            set_system_setting("smb_mode", "zimaos", db_path=target_db)

        status_data = get_smb_status(db_path=target_db, storage_dir=storage_dir)
        status_data["success"] = True
        return status_data


def get_smb_shares_for_user(
    username: str,
    role: str = "staff",
    allowed_disks: Optional[List[str]] = None,
    storage_dir: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Return authorized SMB shares for the given user using SQLite role & allowed_disks ACL."""
    clean_u = (username or "").strip().lower()
    role_clean = str(role or "staff").strip().lower()
    user_is_admin = bool(role_clean in ("admin", "root") or is_admin_username(clean_u))

    target_storage = storage_dir or _get_storage_dir()
    os.makedirs(target_storage, exist_ok=True)
    storage_real = os.path.realpath(target_storage)

    try:
        entries = [e for e in os.scandir(target_storage) if e.is_dir()]
    except OSError:
        entries = []
    entries.sort(key=lambda e: e.name.lower())

    result: List[Dict[str, Any]] = []
    for entry in entries:
        disk_name = entry.name
        if not _is_valid_smb_share_name(disk_name):
            continue
        try:
            if os.path.commonpath([storage_real, os.path.realpath(entry.path)]) != storage_real:
                continue
        except OSError:
            continue
        if user_is_admin or not _is_disk_forbidden_for_user(
            disk_name, clean_u, allowed_disks, is_admin=user_is_admin
        ):
            result.append(
                {
                    "name": disk_name,
                    "path": os.path.abspath(entry.path),
                    "valid_users": [clean_u] if clean_u else [],
                    "writable": True,
                }
            )
    return result


def initialize_smb_on_startup(
    db_path: Optional[str] = None,
    storage_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Restore UNIX/Samba users and smb.conf from SQLite on container startup and apply
    the persisted smb_mode ('zimaos' default or 'backend').
    """
    with _SMB_SYNC_LOCK:
        target_db = _get_db_path(db_path)
        sync_samba_configuration(storage_dir=storage_dir, db_path=target_db)
        mode = get_system_setting("smb_mode", default="", db_path=target_db).strip().lower()
        if mode not in ("zimaos", "backend"):
            mode = "zimaos"
            set_system_setting("smb_mode", "zimaos", db_path=target_db)
        if mode == "backend":
            return set_smb_mode("backend", db_path=target_db, storage_dir=storage_dir)
        stop_backend_smbd()
        return get_smb_status(db_path=target_db, storage_dir=storage_dir)
