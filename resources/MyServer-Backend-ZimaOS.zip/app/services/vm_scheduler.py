"""
Background VM Scheduler Daemon for MyServer Native Backend (v2.2.1)
Executes 24/7 automations on ZimaOS even when laptop/client devices are shut down:
1. Always-On (Anti-Sleep for InstaBox Cloud VMs) with live cloud polling
2. Smart Reset 8h (Prevents InstaBox cooldown before runtime limit)
3. Auto-On (Clock & Delay After Off)
4. Auto-Restart (Interval & Clock)
5. Live Telemetry & Metrics Sync from https://api.instabox.sh/v1/machines/{id}/metrics
"""

import asyncio
import json
import logging
import random
import shlex
import threading
import urllib.request
import urllib.error
import urllib.parse
import uuid
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional, List
try:
    import httpx
except ImportError:  # pragma: no cover
    httpx = None
try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

from app.database import (
    get_all_managed_vms,
    get_managed_vm,
    update_vm_runtime_and_status,
    log_activity,
    get_db,
    DB_PATH,
)

logger = logging.getLogger("myserver.vm_scheduler")

_scheduler_running = False
_scheduler_task: Optional[asyncio.Task] = None
_scheduler_loop: Optional[asyncio.AbstractEventLoop] = None

_HTTP_CLIENT_LOCK = threading.Lock()
_SHARED_HTTPX_CLIENT = None
_CB_LOCK = threading.Lock()
_HOST_CIRCUIT_BREAKERS: Dict[str, Dict[str, Any]] = {}


def _get_shared_httpx_client():
    global _SHARED_HTTPX_CLIENT
    if httpx is None:
        return None
    with _HTTP_CLIENT_LOCK:
        if _SHARED_HTTPX_CLIENT is None:
            limits = httpx.Limits(max_keepalive_connections=16, max_connections=32, keepalive_expiry=60.0)
            _SHARED_HTTPX_CLIENT = httpx.Client(limits=limits, follow_redirects=True)
        return _SHARED_HTTPX_CLIENT


def _cb_is_open(host: str) -> bool:
    if not host:
        return False
    with _CB_LOCK:
        entry = _HOST_CIRCUIT_BREAKERS.get(host)
        if not entry:
            return False
        open_until = float(entry.get("open_until") or 0.0)
        if open_until > time.monotonic():
            return True
        if open_until > 0.0:
            entry["open_until"] = 0.0
            entry["failures"] = 0
        return False


def _cb_record_success(host: str) -> None:
    if not host:
        return
    with _CB_LOCK:
        _HOST_CIRCUIT_BREAKERS.pop(host, None)


def _cb_record_failure(host: str) -> None:
    if not host:
        return
    with _CB_LOCK:
        entry = _HOST_CIRCUIT_BREAKERS.setdefault(host, {"failures": 0, "open_until": 0.0})
        entry["failures"] = int(entry.get("failures", 0)) + 1
        if entry["failures"] >= 5:
            entry["open_until"] = time.monotonic() + 30.0
            logger.warning(f"[vm_scheduler] Circuit breaker terbuka 30s untuk host {host} setelah {entry['failures']} kegagalan.")


def _make_http_request(url: str, method: str = "GET", headers: Optional[dict] = None, data: Optional[dict] = None, timeout: float = 10.0, bypass_circuit_breaker: bool = False) -> Optional[dict]:
    """HTTP client resilien dengan connection pooling (httpx), retry + exponential backoff + jitter, dan circuit breaker."""
    host = urllib.parse.urlparse(url).netloc.lower()
    if not bypass_circuit_breaker and _cb_is_open(host):
        logger.debug(f"[vm_scheduler] Melewati {url} karena circuit breaker host {host} terbuka.")
        return None

    req_headers = {
        "User-Agent": "MyServer-Daemon/2.2.1",
    }
    if headers:
        req_headers.update(headers)

    if method in ("POST", "PUT", "DELETE") and "Idempotency-Key" not in req_headers:
        req_headers["Idempotency-Key"] = str(uuid.uuid4())

    body_bytes = None
    if data is not None:
        body_bytes = json.dumps(data).encode("utf-8")
        req_headers["Content-Type"] = "application/json"
    elif method in ("POST", "PUT"):
        body_bytes = b"{}"
        req_headers["Content-Type"] = "application/json"

    max_attempts = 2 if method == "GET" else 2
    client = _get_shared_httpx_client()

    for attempt in range(max_attempts):
        try:
            if client is not None:
                resp = client.request(method, url, content=body_bytes, headers=req_headers, timeout=timeout)
                status_code = resp.status_code
                resp_body = resp.text or ""
                if 200 <= status_code < 300:
                    _cb_record_success(host)
                    return json.loads(resp_body) if resp_body.strip() else {"status": "ok"}
                if status_code == 409 and "/resume" in url:
                    _cb_record_success(host)
                    return {"status": "ok", "conflict": True, "running": True}
                if status_code == 404 and method == "DELETE" and "/activity-leases/" in url:
                    _cb_record_success(host)
                    return {"status": "ok", "already_released": True}
                if status_code in (429, 500, 502, 503, 504) and attempt + 1 < max_attempts:
                    _cb_record_failure(host)
                    time.sleep((0.35 * (2 ** attempt)) + random.uniform(0.0, 0.25))
                    continue
                if status_code >= 500:
                    _cb_record_failure(host)
                logger.warning(f"[vm_scheduler] HTTP Error {status_code} for {url}")
                return None

            urllib_headers = dict(req_headers)
            urllib_headers.setdefault("Connection", "close")
            req = urllib.request.Request(url, data=body_bytes, headers=urllib_headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_body = resp.read().decode("utf-8", errors="replace")
                _cb_record_success(host)
                if resp_body.strip():
                    return json.loads(resp_body)
                return {"status": "ok"}
        except urllib.error.HTTPError as he:
            if he.code == 409 and "/resume" in url:
                _cb_record_success(host)
                logger.info(f"[vm_scheduler] HTTP 409 Conflict pada {url}: mesin sudah aktif atau sedang proses wake.")
                return {"status": "ok", "conflict": True, "running": True}
            if he.code == 404 and method == "DELETE" and "/activity-leases/" in url:
                _cb_record_success(host)
                return {"status": "ok", "already_released": True}
            if he.code in (429, 500, 502, 503, 504) and attempt + 1 < max_attempts:
                _cb_record_failure(host)
                time.sleep((0.35 * (2 ** attempt)) + random.uniform(0.0, 0.25))
                continue
            if he.code >= 500:
                _cb_record_failure(host)
            logger.warning(f"[vm_scheduler] HTTP Error {he.code} for {url}: {he.reason}")
            return None
        except Exception as e:
            _cb_record_failure(host)
            if attempt + 1 < max_attempts:
                time.sleep((0.35 * (2 ** attempt)) + random.uniform(0.0, 0.25))
                continue
            logger.warning(f"[vm_scheduler] Request failed for {url}: {e}")
            return None
    return None


def _resolve_machine_id(api_key: str, machine_id: Optional[str], vm_name: Optional[str]) -> Optional[str]:
    """Helper pencarian ID microVM InstaBox berbasis nama jika machine_id kosong."""
    if machine_id and str(machine_id).strip():
        return str(machine_id).strip()
    if not api_key:
        return None

    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    res = _make_http_request("https://api.instabox.sh/v1/machines", "GET", headers)
    if not res or not isinstance(res, dict):
        return None

    machines = res.get("machines", [])
    if not machines:
        return None

    if vm_name:
        import re
        norm_target = re.sub(r"[^a-z0-9]", "", vm_name.lower())
        for m in machines:
            m_name = m.get("name", "")
            if m_name and re.sub(r"[^a-z0-9]", "", m_name.lower()) == norm_target:
                return m.get("id")
        for m in machines:
            m_name = m.get("name", "")
            if m_name and (norm_target in re.sub(r"[^a-z0-9]", "", m_name.lower()) or re.sub(r"[^a-z0-9]", "", m_name.lower()) in norm_target):
                return m.get("id")

    return machines[0].get("id")


import time

_vm_transition_locks: Dict[str, Dict[str, Any]] = {}
_last_auto_on_trigger: Dict[str, float] = {}
_last_auto_restart_trigger: Dict[str, float] = {}
_last_lease_renew: Dict[str, float] = {}
_last_exec_keepalive: Dict[str, float] = {}
_TRANSITION_GRACE_SEC = 20.0

_INSTABOX_LEASE_TASK_ID = "myserver-always-on"
_INSTABOX_LEASE_TTL_SEC = 600
_INSTABOX_LEASE_RENEW_SEC = 120.0
_INSTABOX_EXEC_KEEPALIVE_SEC = 180.0


def clear_instabox_keepalive_cache(vm_id: Optional[str]) -> None:
    """Menghapus jadwal throttle lease & exec keepalive agar siklus berikutnya dieksekusi segar."""
    if not vm_id:
        return
    _last_lease_renew.pop(vm_id, None)
    _last_exec_keepalive.pop(vm_id, None)


def _resolve_vm_max_runtime_minutes(vm: Dict[str, Any]) -> int:
    """Mengembalikan batas runtime presisi VM dalam menit (-1 berarti unlimited)."""
    raw_mrm = vm.get("max_runtime_minutes")
    if raw_mrm is None:
        raw_mrm = vm.get("maxRuntimeMinutes")
    if raw_mrm is not None:
        try:
            mrm = int(raw_mrm)
            if mrm < 0:
                return -1
            if mrm > 0:
                return mrm
        except Exception:
            pass
    raw_rlh = vm.get("runtime_limit_hours")
    if raw_rlh is not None:
        try:
            rlh = int(raw_rlh)
            return -1 if rlh < 0 else (480 if rlh == 0 else rlh * 60)
        except Exception:
            pass
    return 480


def renew_instabox_activity_lease(api_key: str, machine_id: str, ttl_seconds: int = _INSTABOX_LEASE_TTL_SEC) -> bool:
    """Mengakuisisi / memperbarui Activity Lease resmi InstaBox agar autoSuspendAfterSeconds tidak memicu sleep."""
    if not api_key or not machine_id:
        return False
    ttl = max(30, min(3600, int(ttl_seconds)))
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/activity-leases/{_INSTABOX_LEASE_TASK_ID}"
    res = _make_http_request(endpoint, "PUT", headers, {"ttlSeconds": ttl}, timeout=8.0, bypass_circuit_breaker=True)
    return bool(res)


def release_instabox_activity_lease(api_key: str, machine_id: str) -> bool:
    """Melepaskan Activity Lease InstaBox saat Always-On dimatikan atau VM ditidurkan manual."""
    if not api_key or not machine_id:
        return False
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/activity-leases/{_INSTABOX_LEASE_TASK_ID}"
    res = _make_http_request(endpoint, "DELETE", headers, timeout=6.0, bypass_circuit_breaker=True)
    return bool(res)


def send_instabox_exec_keepalive(api_key: str, machine_id: str) -> bool:
    """Mengirim perintah ringan nyata (`true`) di dalam VM InstaBox melalui endpoint /exec resmi."""
    if not api_key or not machine_id:
        return False
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/exec"
    res = _make_http_request(endpoint, "POST", headers, {"cmd": "true"}, timeout=10.0, bypass_circuit_breaker=True)
    return bool(res)


def maintain_instabox_keepalive(vm: Dict[str, Any], force: bool = False) -> Dict[str, bool]:
    """Mempertahankan VM InstaBox tetap non-idle lewat kombinasi Activity Lease & eksekusi perintah berkala."""
    result = {"lease_sent": False, "exec_sent": False}
    if not isinstance(vm, dict) or vm.get("provider", "instabox") != "instabox":
        return result
    vm_id = str(vm.get("id") or "")
    api_key = str(vm.get("api_key") or vm.get("apiKey") or "").strip()
    if not vm_id or not api_key:
        return result

    resolved_mid = _resolve_machine_id(api_key, vm.get("machine_id") or vm.get("machineId"), vm.get("name"))
    if not resolved_mid:
        return result

    now_mono = time.monotonic()
    if force or (now_mono - _last_lease_renew.get(vm_id, 0.0) >= _INSTABOX_LEASE_RENEW_SEC):
        if renew_instabox_activity_lease(api_key, resolved_mid):
            _last_lease_renew[vm_id] = now_mono
            result["lease_sent"] = True

    if force or (now_mono - _last_exec_keepalive.get(vm_id, 0.0) >= _INSTABOX_EXEC_KEEPALIVE_SEC):
        if send_instabox_exec_keepalive(api_key, resolved_mid):
            _last_exec_keepalive[vm_id] = now_mono
            result["exec_sent"] = True

    return result


async def sync_instabox_keepalive_toggle(vm: Optional[Dict[str, Any]], prev_keep_alive: Optional[bool] = None) -> None:
    """Segera mengakuisisi atau melepaskan Activity Lease InstaBox saat Always-On diubah lewat API."""
    if not isinstance(vm, dict) or vm.get("provider", "instabox") != "instabox":
        return
    vm_id = str(vm.get("id") or "")
    api_key = str(vm.get("api_key") or vm.get("apiKey") or "").strip()
    if not vm_id or not api_key:
        return
    new_ka = bool(vm.get("keep_alive_enabled"))
    if prev_keep_alive is not None and bool(prev_keep_alive) == new_ka:
        return
    if new_ka:
        clear_instabox_keepalive_cache(vm_id)
        if str(vm.get("status") or "").lower() == "running":
            await asyncio.to_thread(maintain_instabox_keepalive, vm, True)
    else:
        clear_instabox_keepalive_cache(vm_id)
        mid = vm.get("machine_id") or vm.get("machineId")
        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, mid, vm.get("name"))
        if resolved_mid:
            await asyncio.to_thread(release_instabox_activity_lease, api_key, resolved_mid)


def _parse_iso_or_sqlite_utc(ts_str: Any) -> Optional[datetime]:
    """Mem-parsing timestamp ISO-8601 atau format CURRENT_TIMESTAMP SQLite menjadi datetime UTC."""
    if not ts_str:
        return None
    s = str(ts_str).strip()
    if not s:
        return None
    try:
        clean_ts = s.replace("Z", "+00:00")
        dt = datetime.fromisoformat(clean_ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _get_vm_local_now(vm: Dict[str, Any], now_utc: Optional[datetime] = None) -> datetime:
    """Mengembalikan waktu lokal VM berdasarkan timezone IANA atau offset menit UTC klien."""
    utc_now = now_utc or datetime.now(timezone.utc)
    tz_name = str(vm.get("schedule_timezone") or vm.get("scheduleTimezone") or "").strip()
    if tz_name and ZoneInfo is not None:
        try:
            return utc_now.astimezone(ZoneInfo(tz_name))
        except Exception:
            pass
    raw_offset = vm.get("tz_offset_minutes")
    if raw_offset is None:
        raw_offset = vm.get("tzOffsetMinutes")
    if raw_offset is not None and str(raw_offset).strip() != "":
        try:
            offset_mins = int(raw_offset)
            return utc_now.astimezone(timezone(timedelta(minutes=offset_mins)))
        except Exception:
            pass
    return datetime.now()


def _compute_manual_runtime_minutes(vm: Dict[str, Any], now_utc: Optional[datetime] = None, max_run_mins: int = 480) -> int:
    """Menghitung durasi runtime berjalan (menit) untuk VM non-InstaBox dari last_wake_time / last_reset_time."""
    utc_now = now_utc or datetime.now(timezone.utc)
    wake_dt = _parse_iso_or_sqlite_utc(vm.get("last_wake_time"))
    reset_dt = _parse_iso_or_sqlite_utc(vm.get("last_reset_time"))
    effective_start = None
    if wake_dt and reset_dt:
        effective_start = max(wake_dt, reset_dt)
    else:
        effective_start = reset_dt or wake_dt
    if effective_start:
        diff_secs = max(0.0, (utc_now - effective_start).total_seconds())
        raw_mins = max(0, int(diff_secs // 60))
        return min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
    return int(vm.get("runtime_minutes") or 0)


def _probe_tcp_host(host: str, port: int, timeout: float = 3.0) -> bool:
    """Memeriksa keterjangkauan socket TCP (SSH/layanan) secara riil."""
    if not host or not str(host).strip():
        return False
    import socket
    try:
        with socket.create_connection((str(host).strip(), int(port or 22)), timeout=timeout):
            return True
    except Exception:
        return False


def _attempt_ssh_poweroff(host: str, port: int, user: str, password: Optional[str] = None) -> bool:
    """Mencoba mengirim perintah poweroff via SSH jika kredensial dan paramiko tersedia."""
    if not host or not user or not password:
        return False
    try:
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=host, port=int(port or 22), username=user, password=password, timeout=5.0)
        try:
            cmd = f"printf '%s\\n' {shlex.quote(password)} | sudo -S poweroff || sudo -n poweroff || poweroff"
            client.exec_command(cmd, timeout=5.0)
            return True
        finally:
            client.close()
    except Exception as e:
        logger.warning(f"[vm_scheduler] SSH poweroff gagal untuk {host}:{port}: {e}")
        return False


def inspect_and_sync_vm(vm_id: str) -> Optional[Dict[str, Any]]:
    """
    Sinkronisasi komprehensif VM InstaBox dari Cloud atau probe TCP untuk VM Manual:
    1. Status & DesiredState dari GET /machines/{id} dengan menghormati grace period transisi power
    2. Runtime riil dihitung dari selisih runStartedAt/currentRunSeconds vs UTC now (proteksi anti-reset 0)
    3. Live telemetry (CPU %, RAM, Disk, Net) dari GET /machines/{id}/metrics
    4. Info koneksi SSH resmi dari GET /machines/{id}/connection-info
    Semua disimpan ke database SQLite server (backup_meta.db).
    """
    vm = get_managed_vm(vm_id)
    if not vm:
        return None

    if vm.get("provider") != "instabox":
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        if not ssh_host:
            return vm
        is_reachable = _probe_tcp_host(ssh_host, ssh_port, timeout=3.0)
        real_status = "running" if is_reachable else "sleeping"
        now_ts = time.time()
        lock_info = _vm_transition_locks.get(vm_id)
        if lock_info and now_ts < lock_info.get("expires_at", 0):
            target_status = lock_info.get("target_status")
            if target_status in ("running", "sleeping"):
                real_status = target_status
        if real_status == "running":
            max_limit = _resolve_vm_max_runtime_minutes(vm)
            run_mins = _compute_manual_runtime_minutes(vm, datetime.now(timezone.utc), max_run_mins=max_limit)
        else:
            run_mins = 0
        update_vm_runtime_and_status(vm_id, status=real_status, runtime_minutes=run_mins)
        return get_managed_vm(vm_id) or vm

    if not vm.get("api_key"):
        return vm

    api_key = vm.get("api_key")
    mid = vm.get("machine_id")
    resolved_mid = _resolve_machine_id(api_key, mid, vm.get("name"))
    if not resolved_mid:
        return vm

    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}

    # 1. Fetch Machine Detail (State & runStartedAt)
    info = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}", "GET", headers)
    if not info or not isinstance(info, dict):
        return vm

    machine_obj = info.get("machine") if isinstance(info.get("machine"), dict) else info
    state = str(machine_obj.get("state") or machine_obj.get("status") or "").lower()
    desired = str(machine_obj.get("desiredState") or "").lower()
    if state in ("running", "active") and desired != "suspended":
        is_running = True
    elif desired == "running" and state in ("starting", "resuming", "waking", "provisioning"):
        is_running = True
    else:
        is_running = False
    real_status = "running" if is_running else "sleeping"

    # Hormati grace period transisi power (wake/sleep/smart_reset) agar status tidak mental kembali
    now_ts = time.time()
    lock_info = _vm_transition_locks.get(vm_id)
    if lock_info and now_ts < lock_info.get("expires_at", 0):
        target_status = lock_info.get("target_status")
        if target_status == "running" and not is_running:
            is_running = True
            real_status = "running"
        elif target_status == "sleeping" and is_running:
            is_running = False
            real_status = "sleeping"

    raw_max_run = machine_obj.get("maxRunMinutes")
    if raw_max_run is not None:
        try:
            raw_max_int = int(raw_max_run)
            if raw_max_int < 0:
                max_run_mins = -1
            elif raw_max_int > 0:
                max_run_mins = raw_max_int
            else:
                max_run_mins = _resolve_vm_max_runtime_minutes(vm)
        except Exception:
            max_run_mins = _resolve_vm_max_runtime_minutes(vm)
    else:
        max_run_mins = _resolve_vm_max_runtime_minutes(vm)

    run_started_at = machine_obj.get("runStartedAt") or machine_obj.get("startedAt")
    current_run_secs = (
        machine_obj.get("currentRunSeconds")
        if machine_obj.get("currentRunSeconds") is not None
        else (machine_obj.get("uptimeSeconds") if machine_obj.get("uptimeSeconds") is not None else machine_obj.get("runDurationSeconds"))
    )

    last_reset_dt = _parse_iso_or_sqlite_utc(vm.get("last_reset_time"))
    if lock_info and lock_info.get("reset_at"):
        reset_dt_mem = datetime.fromtimestamp(float(lock_info["reset_at"]), tz=timezone.utc)
        if not last_reset_dt or reset_dt_mem > last_reset_dt:
            last_reset_dt = reset_dt_mem

    run_mins = 0
    if is_running:
        if lock_info and lock_info.get("reset_at") and (now_ts - float(lock_info["reset_at"]) < 25.0):
            run_mins = 0
        elif run_started_at:
            dt = _parse_iso_or_sqlite_utc(run_started_at)
            if dt:
                effective_start = max(dt, last_reset_dt) if last_reset_dt else dt
                diff_secs = (datetime.now(timezone.utc) - effective_start).total_seconds()
                raw_mins = max(0, int(diff_secs / 60))
                run_mins = min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
            else:
                existing_mins = int(vm.get("runtime_minutes") or 0)
                wake_mins = _compute_manual_runtime_minutes(vm, datetime.now(timezone.utc), max_run_mins=max_run_mins)
                run_mins = max(existing_mins, wake_mins)
        elif current_run_secs is not None:
            try:
                secs = float(current_run_secs)
                if last_reset_dt:
                    since_reset = (datetime.now(timezone.utc) - last_reset_dt).total_seconds()
                    if 0 <= since_reset < secs:
                        secs = since_reset
                raw_mins = max(0, int(secs / 60))
                run_mins = min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
            except Exception:
                existing_mins = int(vm.get("runtime_minutes") or 0)
                wake_mins = _compute_manual_runtime_minutes(vm, datetime.now(timezone.utc), max_run_mins=max_run_mins)
                run_mins = max(existing_mins, wake_mins)
        else:
            # Pertahankan runtime_minutes yang sudah ada, atau hitung dari last_wake_time bila lebih besar
            existing_mins = int(vm.get("runtime_minutes") or 0)
            wake_mins = _compute_manual_runtime_minutes(vm, datetime.now(timezone.utc), max_run_mins=max_run_mins)
            run_mins = max(existing_mins, wake_mins)

    # 2. Fetch Live Metrics (/metrics)
    m_raw = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}/metrics", "GET", headers)
    telemetry = None
    if m_raw and isinstance(m_raw, dict):
        samples = m_raw.get("metrics", [])
        if samples and is_running:
            latest = samples[-1]
            telemetry = {
                "cpuPct": round(float(latest.get("cpuUsedPct") or 0.0), 1),
                "ramUsedBytes": latest.get("memUsed"),
                "ramTotalBytes": latest.get("memTotal"),
                "diskTotalBytes": latest.get("diskTotal"),
                "diskUsedBytes": latest.get("diskUsed"),
                "netInBytesPerSec": latest.get("netInBytesPerSec"),
                "netOutBytesPerSec": latest.get("netOutBytesPerSec"),
            }
        elif not is_running:
            latest = samples[-1] if samples else {}
            existing_tel = vm.get("telemetry") if isinstance(vm.get("telemetry"), dict) else {}
            telemetry = {
                "cpuPct": None,
                "ramUsedBytes": None,
                "ramTotalBytes": latest.get("memTotal") or existing_tel.get("ramTotalBytes"),
                "diskTotalBytes": latest.get("diskTotal") or existing_tel.get("diskTotalBytes"),
                "diskUsedBytes": None,
                "netInBytesPerSec": 0,
                "netOutBytesPerSec": 0,
            }

    # 3. Fetch Official Connection Info
    ci_data = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}/connection-info", "GET", headers)
    ssh_host = vm.get("ssh_host") or "ssh.instabox.sh"
    ssh_port = int(vm.get("ssh_port") or 2222)
    ssh_user = vm.get("ssh_user") or resolved_mid
    if ci_data and isinstance(ci_data, dict):
        ssh_host = ci_data.get("host") or ssh_host
        ssh_port = int(ci_data.get("port") or ssh_port)
        ssh_user = ci_data.get("user") or ssh_user

    # 4. Simpan ke database server
    stored_limit_hours = -1 if max_run_mins < 0 else max(1, max_run_mins // 60)
    update_vm_runtime_and_status(
        vm_id,
        status=real_status,
        runtime_minutes=run_mins,
        telemetry=telemetry,
        machine_id=resolved_mid,
        ssh_host=ssh_host,
        ssh_port=ssh_port,
        ssh_user=ssh_user,
        runtime_limit_hours=stored_limit_hours,
        max_runtime_minutes=max_run_mins,
    )

    return get_managed_vm(vm_id) or vm


async def wake_vm_provider(vm: Dict[str, Any]) -> bool:
    """Membangunkan (wake/resume) VM sesuai provider (InstaBox atau Manual SSH)."""
    provider = vm.get("provider", "instabox")
    vm_id = vm.get("id")

    if provider == "instabox":
        api_key = vm.get("api_key")
        machine_id = vm.get("machine_id")
        if not api_key:
            logger.warning(f"[vm_scheduler] VM {vm_id} tidak memiliki API key InstaBox")
            return False

        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, machine_id, vm.get("name"))
        if not resolved_mid:
            logger.warning(f"[vm_scheduler] Gagal menemukan Machine ID InstaBox untuk VM {vm_id}")
            return False

        headers = {"Authorization": f"Bearer {api_key}"}
        endpoint = f"https://api.instabox.sh/v1/machines/{resolved_mid}/resume"
        res = await asyncio.to_thread(_make_http_request, endpoint, "POST", headers, {}, bypass_circuit_breaker=True)
        if res:
            logger.info(f"[vm_scheduler] Berhasil mengirim sinyal resume untuk InstaBox VM {vm_id} ({resolved_mid})")
            prev_reset = _vm_transition_locks.get(vm_id, {}).get("reset_at")
            _vm_transition_locks[vm_id] = {
                "target_status": "running",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": prev_reset,
            }
            await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="running", machine_id=resolved_mid)
            if vm.get("keep_alive_enabled"):
                await asyncio.to_thread(renew_instabox_activity_lease, api_key, resolved_mid)
                _last_lease_renew[vm_id] = time.monotonic()
                _last_exec_keepalive.pop(vm_id, None)
            await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_WAKE", message=f"VM {vm.get('name')} dinyalakan otomatis oleh daemon 24/7.")
            return True
        return False
    else:
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        if not ssh_host:
            logger.warning(f"[vm_scheduler] VM Manual {vm_id} tidak memiliki ssh_host untuk diverifikasi.")
            return False

        is_reachable = await asyncio.to_thread(_probe_tcp_host, ssh_host, ssh_port, 3.0)
        if is_reachable:
            _vm_transition_locks[vm_id] = {
                "target_status": "running",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="running")
            await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_WAKE", message=f"VM Manual {vm.get('name')} ({ssh_host}:{ssh_port}) terverifikasi aktif.")
            return True

        await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="sleeping")
        logger.warning(f"[vm_scheduler] VM Manual {vm_id} ({ssh_host}:{ssh_port}) tidak merespons koneksi TCP.")
        return False


async def sleep_vm_provider(vm: Dict[str, Any]) -> bool:
    """Menidurkan (suspend/pause) VM sesuai provider."""
    provider = vm.get("provider", "instabox")
    vm_id = vm.get("id")

    if provider == "instabox":
        api_key = vm.get("api_key")
        machine_id = vm.get("machine_id")
        if not api_key:
            return False

        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, machine_id, vm.get("name"))
        if not resolved_mid:
            return False

        clear_instabox_keepalive_cache(vm_id)
        await asyncio.to_thread(release_instabox_activity_lease, api_key, resolved_mid)

        headers = {"Authorization": f"Bearer {api_key}"}
        endpoint = f"https://api.instabox.sh/v1/machines/{resolved_mid}/suspend"
        res = await asyncio.to_thread(_make_http_request, endpoint, "POST", headers, {}, bypass_circuit_breaker=True)
        if res:
            _vm_transition_locks[vm_id] = {
                "target_status": "sleeping",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="sleeping", runtime_minutes=0, machine_id=resolved_mid)
            await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_SLEEP", message=f"VM {vm.get('name')} ditidurkan oleh daemon server.")
            return True
        return False
    else:
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        ssh_user = (vm.get("ssh_user") or "").strip()
        ssh_pass = vm.get("ssh_pass") or vm.get("password")

        if ssh_host and ssh_user and ssh_pass:
            sent_off = await asyncio.to_thread(_attempt_ssh_poweroff, ssh_host, ssh_port, ssh_user, ssh_pass)
            if sent_off:
                _vm_transition_locks[vm_id] = {
                    "target_status": "sleeping",
                    "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                    "reset_at": None,
                }
                await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="sleeping", runtime_minutes=0)
                await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_SLEEP", message=f"VM Manual {vm.get('name')} dimatikan via SSH.")
                return True

        # Jika tidak ada kredensial SSH, cek apakah host memang sudah mati/offline
        is_reachable = await asyncio.to_thread(_probe_tcp_host, ssh_host, ssh_port, 3.0) if ssh_host else False
        if not is_reachable:
            _vm_transition_locks[vm_id] = {
                "target_status": "sleeping",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="sleeping", runtime_minutes=0)
            return True

        logger.warning(f"[vm_scheduler] VM Manual {vm_id} ({ssh_host}:{ssh_port}) masih aktif dan tidak ada kredensial SSH untuk poweroff.")
        return False


async def execute_smart_reset(vm: Dict[str, Any]) -> bool:
    """
    Mengeksekusi Smart Reset / Auto-Restart:
    Tidurkan mesin (suspend) selama beberapa detik lalu bangunkan kembali (resume)
    untuk me-reset hitungan batas runtime InstaBox atau menjalankan restart terjadwal.
    """
    vm_id = vm.get("id")
    cycle = str(vm.get("smart_reset_cycle") or "sleep_2s").strip().lower()
    pause_wait_sec = 5 if cycle in ("cold_restart", "full_reboot") else 3
    logger.info(f"[vm_scheduler] Menjalankan Smart Reset cycle ({cycle}, tunggu {pause_wait_sec}s) untuk VM {vm_id}")

    # Langkah 1: Tidurkan / Suspend
    slept = await sleep_vm_provider(vm)
    if not slept:
        logger.warning(f"[vm_scheduler] Smart Reset dibatalkan: sleep_vm_provider gagal untuk VM {vm_id}")
        await asyncio.to_thread(
            log_activity,
            device_id="server_zimaos",
            task_id=vm_id,
            action="VM_SMART_RESET_FAILED",
            message=f"Smart Reset gagal menidurkan VM {vm.get('name')} (suspend ditolak/gagal).",
        )
        return False
    # Langkah 2: Tunggu jeda siklus agar state terkonfirmasi
    await asyncio.sleep(pause_wait_sec)
    # Langkah 3: Bangunkan kembali / Resume (dengan 1x retry jika gagal sesaat)
    woke = await wake_vm_provider(vm)
    if not woke:
        logger.warning(f"[vm_scheduler] Wake pertama Smart Reset gagal untuk VM {vm_id}; mencoba ulang 2s...")
        await asyncio.sleep(2)
        woke = await wake_vm_provider(vm)

    now_ts = time.time()
    now_mono = time.monotonic()
    _vm_transition_locks[vm_id] = {
        "target_status": "running" if woke else "sleeping",
        "expires_at": now_ts + 25.0,
        "reset_at": now_ts if woke else None,
    }
    _last_auto_restart_trigger[vm_id] = now_mono
    if woke:
        await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="running", runtime_minutes=0, mark_reset=True)
        await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_SMART_RESET", message=f"Smart Reset berhasil dieksekusi untuk VM {vm.get('name')}. Timer runtime di-reset ke 0 menit.")
    else:
        await asyncio.to_thread(update_vm_runtime_and_status, vm_id, status="sleeping", runtime_minutes=0)
        await asyncio.to_thread(log_activity, device_id="server_zimaos", task_id=vm_id, action="VM_SMART_RESET_FAILED", message=f"Smart Reset gagal membangunkan VM {vm.get('name')} setelah suspend.")
    return woke


def _prune_scheduler_state(active_vm_ids: set) -> None:
    """Membersihkan cache in-memory untuk VM yang sudah dihapus dari database."""
    for store in (_last_auto_on_trigger, _last_auto_restart_trigger, _last_lease_renew, _last_exec_keepalive):
        for stale_id in [k for k in list(store.keys()) if k not in active_vm_ids]:
            store.pop(stale_id, None)
    now_ts = time.time()
    for stale_id in [
        k for k, v in list(_vm_transition_locks.items())
        if k not in active_vm_ids and float((v or {}).get("expires_at") or 0) < now_ts
    ]:
        _vm_transition_locks.pop(stale_id, None)


async def _process_single_vm_cycle(
    sem: asyncio.Semaphore,
    raw_vm: Dict[str, Any],
    now_utc: datetime,
    now_mono: float,
) -> None:
    async with sem:
        vm_id = raw_vm.get("id")
        if (raw_vm.get("provider") == "instabox" and raw_vm.get("api_key")) or (raw_vm.get("provider") != "instabox" and raw_vm.get("ssh_host")):
            synced_vm = await asyncio.to_thread(inspect_and_sync_vm, vm_id)
            vm = synced_vm if synced_vm else raw_vm
        else:
            vm = raw_vm

        status = vm.get("status", "sleeping")
        runtime_min = int(vm.get("runtime_minutes") or 0)
        max_run_mins = _resolve_vm_max_runtime_minutes(vm)
        local_now = _get_vm_local_now(vm, now_utc)
        current_hhmm = local_now.strftime("%H:%M")
        day_abbr = local_now.strftime("%a")

        if status == "running" and max_run_mins > 0 and (vm.get("keep_alive_enabled") or vm.get("auto_restart_enabled")):
            threshold_min = (max_run_mins - 5) if max_run_mins > 30 else max(1, max_run_mins - max(1, min(5, max_run_mins // 5)))
            if runtime_min >= threshold_min and (now_mono - _last_auto_restart_trigger.get(vm_id, 0.0) > 65.0):
                logger.info(f"[vm_scheduler] VM {vm_id} mendekati batas {max_run_mins}m ({runtime_min}m). Memicu Smart Reset.")
                await execute_smart_reset(vm)
                return

        if vm.get("keep_alive_enabled"):
            if status != "running":
                logger.info(f"[vm_scheduler] Always-On aktif pada VM {vm_id} yang berstatus '{status}'. Mengirim sinyal wake.")
                await wake_vm_provider(vm)
                return
            elif vm.get("provider", "instabox") == "instabox" and vm.get("api_key"):
                await asyncio.to_thread(maintain_instabox_keepalive, vm)

        if vm.get("auto_on_enabled") and status != "running" and (now_mono - _last_auto_on_trigger.get(vm_id, 0.0) > 65.0):
            mode = vm.get("auto_on_mode", "clock")
            if mode == "clock":
                active_days = vm.get("auto_on_days") or ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
                target_time = vm.get("auto_on_time", "07:00")
                if day_abbr in active_days and current_hhmm == target_time:
                    _last_auto_on_trigger[vm_id] = now_mono
                    logger.info(f"[vm_scheduler] Jadwal Auto-On (Clock: {current_hhmm} {day_abbr}) terpenuhi untuk VM {vm_id}.")
                    await wake_vm_provider(vm)
                    return
            elif mode == "after_off":
                delay_val = max(1, int(vm.get("auto_on_delay_min") or 60))
                delay_unit = str(vm.get("auto_on_delay_unit") or "minutes").lower()
                delay_secs = (
                    delay_val * 3600
                    if delay_unit == "hours"
                    else (delay_val if delay_unit == "seconds" else delay_val * 60)
                )
                last_sleep_dt = _parse_iso_or_sqlite_utc(vm.get("last_sleep_time") or vm.get("updated_at"))
                if last_sleep_dt and (now_utc - last_sleep_dt).total_seconds() >= delay_secs:
                    _last_auto_on_trigger[vm_id] = now_mono
                    logger.info(f"[vm_scheduler] Jadwal Auto-On (After Off: {delay_val} {delay_unit}) terpenuhi untuk VM {vm_id}.")
                    await wake_vm_provider(vm)
                    return

        if vm.get("auto_restart_enabled") and status == "running":
            if now_mono - _last_auto_restart_trigger.get(vm_id, 0.0) > 65.0:
                restart_mode = vm.get("auto_restart_mode", "interval")
                if restart_mode == "clock":
                    target_time = vm.get("auto_restart_time", "03:00")
                    if current_hhmm == target_time:
                        _last_auto_restart_trigger[vm_id] = now_mono
                        logger.info(f"[vm_scheduler] Jadwal Auto-Restart (Jam Tertentu: {current_hhmm}) untuk VM {vm_id}.")
                        await execute_smart_reset(vm)
                        return
                elif restart_mode == "interval":
                    val = max(1, int(vm.get("auto_restart_val") or 6))
                    unit = str(vm.get("auto_restart_unit") or "hours").lower()
                    interval_min = val * 60 if unit == "hours" else (val if unit == "minutes" else max(1, val // 60))
                    if runtime_min >= interval_min:
                        _last_auto_restart_trigger[vm_id] = now_mono
                        logger.info(f"[vm_scheduler] Jadwal Auto-Restart Interval ({val} {unit}) terpenuhi untuk VM {vm_id}.")
                        await execute_smart_reset(vm)
                        return


async def vm_scheduler_worker_loop():
    """Worker loop utama yang mem-poll seluruh VM secara paralel (asyncio.Semaphore) setiap 25 detik."""
    global _scheduler_running
    logger.info("[vm_scheduler] Background Daemon 24/7 MyServer VM Scheduler aktif (v2.2.1 Parallel + Circuit Breaker).")
    poll_sem = asyncio.Semaphore(4)

    while _scheduler_running:
        try:
            vms = await asyncio.to_thread(get_all_managed_vms)
            now_utc = datetime.now(timezone.utc)
            now_mono = time.monotonic()
            active_ids = {str(v.get("id")) for v in vms if v.get("id")}
            _prune_scheduler_state(active_ids)

            if vms:
                results = await asyncio.gather(
                    *[_process_single_vm_cycle(poll_sem, v, now_utc, now_mono) for v in vms],
                    return_exceptions=True,
                )
                for res in results:
                    if isinstance(res, Exception):
                        logger.warning(f"[vm_scheduler] Error pada polling paralel VM: {res}")

        except Exception as e:
            logger.error(f"[vm_scheduler] Error pada siklus worker: {e}", exc_info=True)

        await asyncio.sleep(25)


def start_vm_scheduler():
    """Memulai background scheduler daemon."""
    global _scheduler_running, _scheduler_task, _scheduler_loop
    if not _scheduler_running:
        _scheduler_running = True
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        _scheduler_loop = loop
        _scheduler_task = loop.create_task(vm_scheduler_worker_loop())
        logger.info("[vm_scheduler] Daemon berhasil dimulai.")


def stop_vm_scheduler():
    """Menghentikan background scheduler daemon secara aman lintas-thread."""
    global _scheduler_running, _scheduler_task, _scheduler_loop
    _scheduler_running = False
    task = _scheduler_task
    loop = _scheduler_loop
    _scheduler_task = None
    _scheduler_loop = None
    if task is not None:
        try:
            if loop is not None and not loop.is_closed():
                try:
                    current_loop = asyncio.get_running_loop()
                except RuntimeError:
                    current_loop = None
                if current_loop is loop:
                    task.cancel()
                else:
                    loop.call_soon_threadsafe(task.cancel)
            else:
                task.cancel()
        except Exception as e:
            logger.warning(f"[vm_scheduler] Peringatan saat membatalkan task scheduler: {e}")
    logger.info("[vm_scheduler] Daemon dihentikan.")

