"""
Background VM Scheduler Daemon for MyServer Native Backend (v1.2.8)
Executes 24/7 automations on ZimaOS even when laptop/client devices are shut down:
1. Always-On (Anti-Sleep for InstaBox Cloud VMs) with live cloud polling
2. Smart Reset 8h (Prevents InstaBox cooldown before runtime limit)
3. Auto-On (Clock & Delay After Off)
4. Auto-Restart (Interval & Clock)
5. Live Telemetry & Metrics Sync from https://api.instabox.sh/v1/machines/{id}/metrics
"""

import asyncio
import json
import logging
import urllib.request
import urllib.error
import uuid
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional
try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

from app.database import (
    get_all_managed_vms,
    get_managed_vm,
    update_vm_runtime_and_status,
    log_activity,
    get_db,
    DB_PATH,
)

logger = logging.getLogger("myserver.vm_scheduler")

_scheduler_running = False
_scheduler_task: Optional[asyncio.Task] = None
_scheduler_loop: Optional[asyncio.AbstractEventLoop] = None


def _make_http_request(url: str, method: str = "GET", headers: Optional[dict] = None, data: Optional[dict] = None, timeout: float = 10.0) -> Optional[dict]:
    """Helper untuk melakukan HTTP request standar tanpa dependensi pihak ketiga."""
    req_headers = {
        "User-Agent": "MyServer-Daemon/1.2.8",
        "Connection": "close",
    }
    if headers:
        req_headers.update(headers)

    if method in ("POST", "PUT", "DELETE") and "Idempotency-Key" not in req_headers:
        req_headers["Idempotency-Key"] = str(uuid.uuid4())

    body_bytes = None
    if data is not None:
        body_bytes = json.dumps(data).encode("utf-8")
        req_headers["Content-Type"] = "application/json"
    elif method in ("POST", "PUT"):
        body_bytes = b"{}"
        req_headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=body_bytes, headers=req_headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp_body = resp.read().decode("utf-8", errors="replace")
            if resp_body.strip():
                return json.loads(resp_body)
            return {"status": "ok"}
    except urllib.error.HTTPError as he:
        # Penanganan khusus: HTTP 409 Conflict saat /resume menandakan mesin sudah/sedang running
        if he.code == 409 and "/resume" in url:
            logger.info(f"[vm_scheduler] HTTP 409 Conflict pada {url}: mesin sudah aktif atau sedang proses wake.")
            return {"status": "ok", "conflict": True, "running": True}
        if he.code == 404 and method == "DELETE" and "/activity-leases/" in url:
            return {"status": "ok", "already_released": True}
        logger.warning(f"[vm_scheduler] HTTP Error {he.code} for {url}: {he.reason}")
        return None
    except Exception as e:
        logger.warning(f"[vm_scheduler] Request failed for {url}: {e}")
        return None


def _resolve_machine_id(api_key: str, machine_id: Optional[str], vm_name: Optional[str]) -> Optional[str]:
    """Helper pencarian ID microVM InstaBox berbasis nama jika machine_id kosong."""
    if machine_id and str(machine_id).strip():
        return str(machine_id).strip()
    if not api_key:
        return None

    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    res = _make_http_request("https://api.instabox.sh/v1/machines", "GET", headers)
    if not res or not isinstance(res, dict):
        return None

    machines = res.get("machines", [])
    if not machines:
        return None

    if vm_name:
        import re
        norm_target = re.sub(r"[^a-z0-9]", "", vm_name.lower())
        for m in machines:
            m_name = m.get("name", "")
            if m_name and re.sub(r"[^a-z0-9]", "", m_name.lower()) == norm_target:
                return m.get("id")
        for m in machines:
            m_name = m.get("name", "")
            if m_name and (norm_target in re.sub(r"[^a-z0-9]", "", m_name.lower()) or re.sub(r"[^a-z0-9]", "", m_name.lower()) in norm_target):
                return m.get("id")

    return machines[0].get("id")


import time

_vm_transition_locks: Dict[str, Dict[str, Any]] = {}
_last_auto_on_trigger: Dict[str, float] = {}
_last_auto_restart_trigger: Dict[str, float] = {}
_last_lease_renew: Dict[str, float] = {}
_last_exec_keepalive: Dict[str, float] = {}
_TRANSITION_GRACE_SEC = 20.0

_INSTABOX_LEASE_TASK_ID = "myserver-always-on"
_INSTABOX_LEASE_TTL_SEC = 600
_INSTABOX_LEASE_RENEW_SEC = 120.0
_INSTABOX_EXEC_KEEPALIVE_SEC = 180.0


def clear_instabox_keepalive_cache(vm_id: Optional[str]) -> None:
    """Menghapus jadwal throttle lease & exec keepalive agar siklus berikutnya dieksekusi segar."""
    if not vm_id:
        return
    _last_lease_renew.pop(vm_id, None)
    _last_exec_keepalive.pop(vm_id, None)


def _resolve_vm_max_runtime_minutes(vm: Dict[str, Any]) -> int:
    """Mengembalikan batas runtime presisi VM dalam menit (-1 berarti unlimited)."""
    raw_mrm = vm.get("max_runtime_minutes")
    if raw_mrm is None:
        raw_mrm = vm.get("maxRuntimeMinutes")
    if raw_mrm is not None:
        try:
            mrm = int(raw_mrm)
            return -1 if mrm < 0 else max(1, mrm)
        except Exception:
            pass
    raw_rlh = vm.get("runtime_limit_hours")
    if raw_rlh is not None:
        try:
            rlh = int(raw_rlh)
            return -1 if rlh < 0 else (480 if rlh == 0 else rlh * 60)
        except Exception:
            pass
    return 480


def renew_instabox_activity_lease(api_key: str, machine_id: str, ttl_seconds: int = _INSTABOX_LEASE_TTL_SEC) -> bool:
    """Mengakuisisi / memperbarui Activity Lease resmi InstaBox agar autoSuspendAfterSeconds tidak memicu sleep."""
    if not api_key or not machine_id:
        return False
    ttl = max(30, min(3600, int(ttl_seconds)))
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/activity-leases/{_INSTABOX_LEASE_TASK_ID}"
    res = _make_http_request(endpoint, "PUT", headers, {"ttlSeconds": ttl}, timeout=8.0)
    return bool(res)


def release_instabox_activity_lease(api_key: str, machine_id: str) -> bool:
    """Melepaskan Activity Lease InstaBox saat Always-On dimatikan atau VM ditidurkan manual."""
    if not api_key or not machine_id:
        return False
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/activity-leases/{_INSTABOX_LEASE_TASK_ID}"
    res = _make_http_request(endpoint, "DELETE", headers, timeout=6.0)
    return bool(res)


def send_instabox_exec_keepalive(api_key: str, machine_id: str) -> bool:
    """Mengirim perintah ringan nyata (`true`) di dalam VM InstaBox melalui endpoint /exec resmi."""
    if not api_key or not machine_id:
        return False
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    endpoint = f"https://api.instabox.sh/v1/machines/{machine_id}/exec"
    res = _make_http_request(endpoint, "POST", headers, {"cmd": "true"}, timeout=10.0)
    return bool(res)


def maintain_instabox_keepalive(vm: Dict[str, Any], force: bool = False) -> Dict[str, bool]:
    """Mempertahankan VM InstaBox tetap non-idle lewat kombinasi Activity Lease & eksekusi perintah berkala."""
    result = {"lease_sent": False, "exec_sent": False}
    if not isinstance(vm, dict) or vm.get("provider", "instabox") != "instabox":
        return result
    vm_id = str(vm.get("id") or "")
    api_key = str(vm.get("api_key") or vm.get("apiKey") or "").strip()
    if not vm_id or not api_key:
        return result

    resolved_mid = _resolve_machine_id(api_key, vm.get("machine_id") or vm.get("machineId"), vm.get("name"))
    if not resolved_mid:
        return result

    now_ts = time.time()
    if force or (now_ts - _last_lease_renew.get(vm_id, 0.0) >= _INSTABOX_LEASE_RENEW_SEC):
        if renew_instabox_activity_lease(api_key, resolved_mid):
            _last_lease_renew[vm_id] = now_ts
            result["lease_sent"] = True

    if force or (now_ts - _last_exec_keepalive.get(vm_id, 0.0) >= _INSTABOX_EXEC_KEEPALIVE_SEC):
        if send_instabox_exec_keepalive(api_key, resolved_mid):
            _last_exec_keepalive[vm_id] = now_ts
            result["exec_sent"] = True

    return result


async def sync_instabox_keepalive_toggle(vm: Optional[Dict[str, Any]], prev_keep_alive: Optional[bool] = None) -> None:
    """Segera mengakuisisi atau melepaskan Activity Lease InstaBox saat Always-On diubah lewat API."""
    if not isinstance(vm, dict) or vm.get("provider", "instabox") != "instabox":
        return
    vm_id = str(vm.get("id") or "")
    api_key = str(vm.get("api_key") or vm.get("apiKey") or "").strip()
    if not vm_id or not api_key:
        return
    new_ka = bool(vm.get("keep_alive_enabled"))
    if prev_keep_alive is not None and bool(prev_keep_alive) == new_ka:
        return
    if new_ka:
        clear_instabox_keepalive_cache(vm_id)
        if str(vm.get("status") or "").lower() == "running":
            await asyncio.to_thread(maintain_instabox_keepalive, vm, True)
    else:
        clear_instabox_keepalive_cache(vm_id)
        mid = vm.get("machine_id") or vm.get("machineId")
        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, mid, vm.get("name"))
        if resolved_mid:
            await asyncio.to_thread(release_instabox_activity_lease, api_key, resolved_mid)


def _parse_iso_or_sqlite_utc(ts_str: Any) -> Optional[datetime]:
    """Mem-parsing timestamp ISO-8601 atau format CURRENT_TIMESTAMP SQLite menjadi datetime UTC."""
    if not ts_str:
        return None
    s = str(ts_str).strip()
    if not s:
        return None
    try:
        clean_ts = s.replace("Z", "+00:00")
        dt = datetime.fromisoformat(clean_ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _get_vm_local_now(vm: Dict[str, Any], now_utc: Optional[datetime] = None) -> datetime:
    """Mengembalikan waktu lokal VM berdasarkan timezone IANA atau offset menit UTC klien."""
    utc_now = now_utc or datetime.now(timezone.utc)
    tz_name = str(vm.get("schedule_timezone") or vm.get("scheduleTimezone") or "").strip()
    if tz_name and ZoneInfo is not None:
        try:
            return utc_now.astimezone(ZoneInfo(tz_name))
        except Exception:
            pass
    raw_offset = vm.get("tz_offset_minutes")
    if raw_offset is None:
        raw_offset = vm.get("tzOffsetMinutes")
    if raw_offset is not None and str(raw_offset).strip() != "":
        try:
            offset_mins = int(raw_offset)
            return utc_now.astimezone(timezone(timedelta(minutes=offset_mins)))
        except Exception:
            pass
    return datetime.now()


def _compute_manual_runtime_minutes(vm: Dict[str, Any], now_utc: Optional[datetime] = None, max_run_mins: int = 480) -> int:
    """Menghitung durasi runtime berjalan (menit) untuk VM non-InstaBox dari last_wake_time / last_reset_time."""
    utc_now = now_utc or datetime.now(timezone.utc)
    wake_dt = _parse_iso_or_sqlite_utc(vm.get("last_wake_time"))
    reset_dt = _parse_iso_or_sqlite_utc(vm.get("last_reset_time"))
    effective_start = None
    if wake_dt and reset_dt:
        effective_start = max(wake_dt, reset_dt)
    else:
        effective_start = reset_dt or wake_dt
    if effective_start:
        diff_secs = max(0.0, (utc_now - effective_start).total_seconds())
        raw_mins = max(0, int(diff_secs // 60))
        return min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
    return int(vm.get("runtime_minutes") or 0)


def _probe_tcp_host(host: str, port: int, timeout: float = 3.0) -> bool:
    """Memeriksa keterjangkauan socket TCP (SSH/layanan) secara riil."""
    if not host or not str(host).strip():
        return False
    import socket
    try:
        with socket.create_connection((str(host).strip(), int(port or 22)), timeout=timeout):
            return True
    except Exception:
        return False


def _attempt_ssh_poweroff(host: str, port: int, user: str, password: Optional[str] = None) -> bool:
    """Mencoba mengirim perintah poweroff via SSH jika kredensial dan paramiko tersedia."""
    if not host or not user or not password:
        return False
    try:
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname=host, port=int(port or 22), username=user, password=password, timeout=5.0)
        try:
            cmd = f"printf '%s\\n' {json.dumps(password)} | sudo -S poweroff || sudo -n poweroff || poweroff"
            client.exec_command(cmd, timeout=5.0)
            return True
        finally:
            client.close()
    except Exception as e:
        logger.warning(f"[vm_scheduler] SSH poweroff gagal untuk {host}:{port}: {e}")
        return False


def inspect_and_sync_vm(vm_id: str) -> Optional[Dict[str, Any]]:
    """
    Sinkronisasi komprehensif VM InstaBox dari Cloud atau probe TCP untuk VM Manual:
    1. Status & DesiredState dari GET /machines/{id} dengan menghormati grace period transisi power
    2. Runtime riil dihitung dari selisih runStartedAt/currentRunSeconds vs UTC now (proteksi anti-reset 0)
    3. Live telemetry (CPU %, RAM, Disk, Net) dari GET /machines/{id}/metrics
    4. Info koneksi SSH resmi dari GET /machines/{id}/connection-info
    Semua disimpan ke database SQLite server (backup_meta.db).
    """
    vm = get_managed_vm(vm_id)
    if not vm:
        return None

    if vm.get("provider") != "instabox":
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        if not ssh_host:
            return vm
        is_reachable = _probe_tcp_host(ssh_host, ssh_port, timeout=3.0)
        real_status = "running" if is_reachable else "sleeping"
        now_ts = time.time()
        lock_info = _vm_transition_locks.get(vm_id)
        if lock_info and now_ts < lock_info.get("expires_at", 0):
            target_status = lock_info.get("target_status")
            if target_status in ("running", "sleeping"):
                real_status = target_status
        if real_status == "running":
            max_limit = _resolve_vm_max_runtime_minutes(vm)
            run_mins = _compute_manual_runtime_minutes(vm, datetime.now(timezone.utc), max_run_mins=max_limit)
        else:
            run_mins = 0
        update_vm_runtime_and_status(vm_id, status=real_status, runtime_minutes=run_mins)
        return get_managed_vm(vm_id) or vm

    if not vm.get("api_key"):
        return vm

    api_key = vm.get("api_key")
    mid = vm.get("machine_id")
    resolved_mid = _resolve_machine_id(api_key, mid, vm.get("name"))
    if not resolved_mid:
        return vm

    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}

    # 1. Fetch Machine Detail (State & runStartedAt)
    info = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}", "GET", headers)
    if not info or not isinstance(info, dict):
        return vm

    machine_obj = info.get("machine") if isinstance(info.get("machine"), dict) else info
    state = str(machine_obj.get("state") or machine_obj.get("status") or "").lower()
    desired = str(machine_obj.get("desiredState") or "").lower()
    if state in ("running", "active") and desired != "suspended":
        is_running = True
    elif desired == "running" and state in ("starting", "resuming", "waking", "provisioning"):
        is_running = True
    else:
        is_running = False
    real_status = "running" if is_running else "sleeping"

    # Hormati grace period transisi power (wake/sleep/smart_reset) agar status tidak mental kembali
    now_ts = time.time()
    lock_info = _vm_transition_locks.get(vm_id)
    if lock_info and now_ts < lock_info.get("expires_at", 0):
        target_status = lock_info.get("target_status")
        if target_status == "running" and not is_running:
            is_running = True
            real_status = "running"
        elif target_status == "sleeping" and is_running:
            is_running = False
            real_status = "sleeping"

    raw_max_run = machine_obj.get("maxRunMinutes")
    if raw_max_run is not None:
        try:
            raw_max_int = int(raw_max_run)
            if raw_max_int < 0:
                max_run_mins = -1
            elif raw_max_int > 0:
                max_run_mins = raw_max_int
            else:
                max_run_mins = _resolve_vm_max_runtime_minutes(vm)
        except Exception:
            max_run_mins = _resolve_vm_max_runtime_minutes(vm)
    else:
        existing_mrm = vm.get("max_runtime_minutes")
        existing_limit_hours = int(vm.get("runtime_limit_hours") or 8)
        if existing_mrm is None and 0 < existing_limit_hours <= 2:
            existing_limit_hours = 8
        max_run_mins = -1 if existing_limit_hours < 0 else (480 if existing_limit_hours == 0 else existing_limit_hours * 60)

    run_started_at = machine_obj.get("runStartedAt") or machine_obj.get("startedAt")
    current_run_secs = (
        machine_obj.get("currentRunSeconds")
        if machine_obj.get("currentRunSeconds") is not None
        else (machine_obj.get("uptimeSeconds") if machine_obj.get("uptimeSeconds") is not None else machine_obj.get("runDurationSeconds"))
    )

    last_reset_dt = _parse_iso_or_sqlite_utc(vm.get("last_reset_time"))
    if lock_info and lock_info.get("reset_at"):
        reset_dt_mem = datetime.fromtimestamp(float(lock_info["reset_at"]), tz=timezone.utc)
        if not last_reset_dt or reset_dt_mem > last_reset_dt:
            last_reset_dt = reset_dt_mem

    run_mins = 0
    if is_running:
        if lock_info and lock_info.get("reset_at") and (now_ts - float(lock_info["reset_at"]) < 25.0):
            run_mins = 0
        elif run_started_at:
            dt = _parse_iso_or_sqlite_utc(run_started_at)
            if dt:
                effective_start = max(dt, last_reset_dt) if last_reset_dt else dt
                diff_secs = (datetime.now(timezone.utc) - effective_start).total_seconds()
                raw_mins = max(0, int(diff_secs / 60))
                run_mins = min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
            else:
                run_mins = int(vm.get("runtime_minutes") or 0)
        elif current_run_secs is not None:
            try:
                secs = float(current_run_secs)
                if last_reset_dt:
                    since_reset = (datetime.now(timezone.utc) - last_reset_dt).total_seconds()
                    if 0 <= since_reset < secs:
                        secs = since_reset
                raw_mins = max(0, int(secs / 60))
                run_mins = min(max_run_mins, raw_mins) if max_run_mins > 0 else raw_mins
            except Exception:
                run_mins = int(vm.get("runtime_minutes") or 0)
        else:
            # Pertahankan runtime_minutes yang sudah ada jika API provider tidak menyertakan runStartedAt
            run_mins = int(vm.get("runtime_minutes") or 0)

    # 2. Fetch Live Metrics (/metrics)
    m_raw = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}/metrics", "GET", headers)
    telemetry = None
    if m_raw and isinstance(m_raw, dict):
        samples = m_raw.get("metrics", [])
        if samples and is_running:
            latest = samples[-1]
            telemetry = {
                "cpuPct": round(float(latest.get("cpuUsedPct") or 0.0), 1),
                "ramUsedBytes": latest.get("memUsed"),
                "ramTotalBytes": latest.get("memTotal"),
                "diskTotalBytes": latest.get("diskTotal"),
                "diskUsedBytes": latest.get("diskUsed"),
                "netInBytesPerSec": latest.get("netInBytesPerSec"),
                "netOutBytesPerSec": latest.get("netOutBytesPerSec"),
            }
        elif not is_running:
            latest = samples[-1] if samples else {}
            existing_tel = vm.get("telemetry") if isinstance(vm.get("telemetry"), dict) else {}
            telemetry = {
                "cpuPct": None,
                "ramUsedBytes": None,
                "ramTotalBytes": latest.get("memTotal") or existing_tel.get("ramTotalBytes"),
                "diskTotalBytes": latest.get("diskTotal") or existing_tel.get("diskTotalBytes"),
                "diskUsedBytes": None,
                "netInBytesPerSec": 0,
                "netOutBytesPerSec": 0,
            }

    # 3. Fetch Official Connection Info
    ci_data = _make_http_request(f"https://api.instabox.sh/v1/machines/{resolved_mid}/connection-info", "GET", headers)
    ssh_host = vm.get("ssh_host") or "ssh.instabox.sh"
    ssh_port = int(vm.get("ssh_port") or 2222)
    ssh_user = vm.get("ssh_user") or resolved_mid
    if ci_data and isinstance(ci_data, dict):
        ssh_host = ci_data.get("host") or ssh_host
        ssh_port = int(ci_data.get("port") or ssh_port)
        ssh_user = ci_data.get("user") or ssh_user

    # 4. Simpan ke database server
    stored_limit_hours = -1 if max_run_mins < 0 else max(1, max_run_mins // 60)
    update_vm_runtime_and_status(
        vm_id,
        status=real_status,
        runtime_minutes=run_mins,
        telemetry=telemetry,
        machine_id=resolved_mid,
        ssh_host=ssh_host,
        ssh_port=ssh_port,
        ssh_user=ssh_user,
        runtime_limit_hours=stored_limit_hours,
        max_runtime_minutes=max_run_mins,
    )

    return get_managed_vm(vm_id) or vm


async def wake_vm_provider(vm: Dict[str, Any]) -> bool:
    """Membangunkan (wake/resume) VM sesuai provider (InstaBox atau Manual SSH)."""
    provider = vm.get("provider", "instabox")
    vm_id = vm.get("id")

    if provider == "instabox":
        api_key = vm.get("api_key")
        machine_id = vm.get("machine_id")
        if not api_key:
            logger.warning(f"[vm_scheduler] VM {vm_id} tidak memiliki API key InstaBox")
            return False

        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, machine_id, vm.get("name"))
        if not resolved_mid:
            logger.warning(f"[vm_scheduler] Gagal menemukan Machine ID InstaBox untuk VM {vm_id}")
            return False

        headers = {"Authorization": f"Bearer {api_key}"}
        endpoint = f"https://api.instabox.sh/v1/machines/{resolved_mid}/resume"
        res = await asyncio.to_thread(_make_http_request, endpoint, "POST", headers, {})
        if res:
            logger.info(f"[vm_scheduler] Berhasil mengirim sinyal resume untuk InstaBox VM {vm_id} ({resolved_mid})")
            prev_reset = _vm_transition_locks.get(vm_id, {}).get("reset_at")
            _vm_transition_locks[vm_id] = {
                "target_status": "running",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": prev_reset,
            }
            update_vm_runtime_and_status(vm_id, status="running", machine_id=resolved_mid)
            if vm.get("keep_alive_enabled"):
                await asyncio.to_thread(renew_instabox_activity_lease, api_key, resolved_mid)
                _last_lease_renew[vm_id] = time.time()
                _last_exec_keepalive.pop(vm_id, None)
            log_activity(device_id="server_zimaos", task_id=vm_id, action="VM_WAKE", message=f"VM {vm.get('name')} dinyalakan otomatis oleh daemon 24/7.")
            return True
        return False
    else:
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        if not ssh_host:
            logger.warning(f"[vm_scheduler] VM Manual {vm_id} tidak memiliki ssh_host untuk diverifikasi.")
            return False

        is_reachable = await asyncio.to_thread(_probe_tcp_host, ssh_host, ssh_port, 3.0)
        if is_reachable:
            _vm_transition_locks[vm_id] = {
                "target_status": "running",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            update_vm_runtime_and_status(vm_id, status="running")
            log_activity(device_id="server_zimaos", task_id=vm_id, action="VM_WAKE", message=f"VM Manual {vm.get('name')} ({ssh_host}:{ssh_port}) terverifikasi aktif.")
            return True

        update_vm_runtime_and_status(vm_id, status="sleeping")
        logger.warning(f"[vm_scheduler] VM Manual {vm_id} ({ssh_host}:{ssh_port}) tidak merespons koneksi TCP.")
        return False


async def sleep_vm_provider(vm: Dict[str, Any]) -> bool:
    """Menidurkan (suspend/pause) VM sesuai provider."""
    provider = vm.get("provider", "instabox")
    vm_id = vm.get("id")

    if provider == "instabox":
        api_key = vm.get("api_key")
        machine_id = vm.get("machine_id")
        if not api_key:
            return False

        resolved_mid = await asyncio.to_thread(_resolve_machine_id, api_key, machine_id, vm.get("name"))
        if not resolved_mid:
            return False

        clear_instabox_keepalive_cache(vm_id)
        await asyncio.to_thread(release_instabox_activity_lease, api_key, resolved_mid)

        headers = {"Authorization": f"Bearer {api_key}"}
        endpoint = f"https://api.instabox.sh/v1/machines/{resolved_mid}/suspend"
        res = await asyncio.to_thread(_make_http_request, endpoint, "POST", headers, {})
        if res:
            _vm_transition_locks[vm_id] = {
                "target_status": "sleeping",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            update_vm_runtime_and_status(vm_id, status="sleeping", runtime_minutes=0, machine_id=resolved_mid)
            log_activity(device_id="server_zimaos", task_id=vm_id, action="VM_SLEEP", message=f"VM {vm.get('name')} ditidurkan oleh daemon server.")
            return True
        return False
    else:
        ssh_host = (vm.get("ssh_host") or "").strip()
        ssh_port = int(vm.get("ssh_port") or 22)
        ssh_user = (vm.get("ssh_user") or "").strip()
        ssh_pass = vm.get("ssh_pass") or vm.get("password")

        if ssh_host and ssh_user and ssh_pass:
            sent_off = await asyncio.to_thread(_attempt_ssh_poweroff, ssh_host, ssh_port, ssh_user, ssh_pass)
            if sent_off:
                _vm_transition_locks[vm_id] = {
                    "target_status": "sleeping",
                    "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                    "reset_at": None,
                }
                update_vm_runtime_and_status(vm_id, status="sleeping", runtime_minutes=0)
                log_activity(device_id="server_zimaos", task_id=vm_id, action="VM_SLEEP", message=f"VM Manual {vm.get('name')} dimatikan via SSH.")
                return True

        # Jika tidak ada kredensial SSH, cek apakah host memang sudah mati/offline
        is_reachable = await asyncio.to_thread(_probe_tcp_host, ssh_host, ssh_port, 3.0) if ssh_host else False
        if not is_reachable:
            _vm_transition_locks[vm_id] = {
                "target_status": "sleeping",
                "expires_at": time.time() + _TRANSITION_GRACE_SEC,
                "reset_at": None,
            }
            update_vm_runtime_and_status(vm_id, status="sleeping", runtime_minutes=0)
            return True

        logger.warning(f"[vm_scheduler] VM Manual {vm_id} ({ssh_host}:{ssh_port}) masih aktif dan tidak ada kredensial SSH untuk poweroff.")
        return False


async def execute_smart_reset(vm: Dict[str, Any]) -> bool:
    """
    Mengeksekusi Smart Reset / Auto-Restart:
    Tidurkan mesin (suspend) selama beberapa detik lalu bangunkan kembali (resume)
    untuk me-reset hitungan batas runtime InstaBox atau menjalankan restart terjadwal.
    """
    vm_id = vm.get("id")
    cycle = str(vm.get("smart_reset_cycle") or "sleep_2s").strip().lower()
    pause_wait_sec = 5 if cycle in ("cold_restart", "full_reboot") else 3
    logger.info(f"[vm_scheduler] Menjalankan Smart Reset cycle ({cycle}, tunggu {pause_wait_sec}s) untuk VM {vm_id}")

    # Langkah 1: Tidurkan / Suspend
    await sleep_vm_provider(vm)
    # Langkah 2: Tunggu jeda siklus agar state terkonfirmasi
    await asyncio.sleep(pause_wait_sec)
    # Langkah 3: Bangunkan kembali / Resume
    woke = await wake_vm_provider(vm)

    # Langkah 4: Reset runtime_minutes ke 0 dan catat waktu reset
    now_ts = time.time()
    _vm_transition_locks[vm_id] = {
        "target_status": "running" if woke else "sleeping",
        "expires_at": now_ts + 25.0,
        "reset_at": now_ts,
    }
    _last_auto_restart_trigger[vm_id] = now_ts
    update_vm_runtime_and_status(vm_id, status="running" if woke else "sleeping", runtime_minutes=0, mark_reset=True)
    log_activity(device_id="server_zimaos", task_id=vm_id, action="VM_SMART_RESET", message=f"Smart Reset berhasil dieksekusi untuk VM {vm.get('name')}. Timer runtime di-reset ke 0 menit.")
    return woke


async def vm_scheduler_worker_loop():
    """Worker loop utama yang mengecek jadwal dan status riil seluruh VM setiap 25 detik."""
    global _scheduler_running
    logger.info("[vm_scheduler] Background Daemon 24/7 MyServer VM Scheduler aktif (v1.2.8 Live Cloud Polling & Keepalive).")

    while _scheduler_running:
        try:
            vms = get_all_managed_vms()
            now_utc = datetime.now(timezone.utc)
            now_ts = time.time()

            for raw_vm in vms:
                vm_id = raw_vm.get("id")
                # 1. Live Cloud Polling untuk VM InstaBox atau TCP Probe untuk VM Manual
                if (raw_vm.get("provider") == "instabox" and raw_vm.get("api_key")) or (raw_vm.get("provider") != "instabox" and raw_vm.get("ssh_host")):
                    synced_vm = await asyncio.to_thread(inspect_and_sync_vm, vm_id)
                    vm = synced_vm if synced_vm else raw_vm
                else:
                    vm = raw_vm

                status = vm.get("status", "sleeping")
                runtime_min = int(vm.get("runtime_minutes") or 0)
                max_run_mins = _resolve_vm_max_runtime_minutes(vm)
                local_now = _get_vm_local_now(vm, now_utc)
                current_hhmm = local_now.strftime("%H:%M")
                day_abbr = local_now.strftime("%a")

                # 2. Smart Reset Runtime Limit Check (HANYA bila VM punya batas maxRunMinutes positif > 0 dan Always-On / Auto-Restart aktif)
                if status == "running" and max_run_mins > 0 and (vm.get("keep_alive_enabled") or vm.get("auto_restart_enabled")):
                    threshold_min = max(30, max_run_mins - 5)
                    if runtime_min >= threshold_min and (now_ts - _last_auto_restart_trigger.get(vm_id, 0) > 65.0):
                        logger.info(f"[vm_scheduler] VM {vm_id} mendekati batas {max_run_mins}m ({runtime_min}m). Memicu Smart Reset.")
                        await execute_smart_reset(vm)
                        continue

                # 3. Always-On (Anti-Sleep & Active Anti-Idle Keepalive)
                if vm.get("keep_alive_enabled"):
                    if status != "running":
                        logger.info(f"[vm_scheduler] Always-On aktif pada VM {vm_id} yang berstatus '{status}'. Mengirim sinyal wake.")
                        await wake_vm_provider(vm)
                        continue
                    elif vm.get("provider", "instabox") == "instabox" and vm.get("api_key"):
                        await asyncio.to_thread(maintain_instabox_keepalive, vm)

                # 4. Auto-On Schedule Check (Clock & Delay After Off)
                if vm.get("auto_on_enabled") and status != "running" and (now_ts - _last_auto_on_trigger.get(vm_id, 0) > 65.0):
                    mode = vm.get("auto_on_mode", "clock")
                    if mode == "clock":
                        active_days = vm.get("auto_on_days") or ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
                        target_time = vm.get("auto_on_time", "07:00")
                        if day_abbr in active_days and current_hhmm == target_time:
                            _last_auto_on_trigger[vm_id] = now_ts
                            logger.info(f"[vm_scheduler] Jadwal Auto-On (Clock: {current_hhmm} {day_abbr}) terpenuhi untuk VM {vm_id}.")
                            await wake_vm_provider(vm)
                            continue
                    elif mode == "after_off":
                        delay_val = max(1, int(vm.get("auto_on_delay_min") or 60))
                        delay_unit = str(vm.get("auto_on_delay_unit") or "minutes").lower()
                        delay_secs = (
                            delay_val * 3600
                            if delay_unit == "hours"
                            else (delay_val if delay_unit == "seconds" else delay_val * 60)
                        )
                        last_sleep_dt = _parse_iso_or_sqlite_utc(vm.get("last_sleep_time") or vm.get("updated_at"))
                        if last_sleep_dt and (now_utc - last_sleep_dt).total_seconds() >= delay_secs:
                            _last_auto_on_trigger[vm_id] = now_ts
                            logger.info(f"[vm_scheduler] Jadwal Auto-On (After Off: {delay_val} {delay_unit}) terpenuhi untuk VM {vm_id}.")
                            await wake_vm_provider(vm)
                            continue

                # 5. Auto-Restart Schedule Check
                if vm.get("auto_restart_enabled") and status == "running":
                    if now_ts - _last_auto_restart_trigger.get(vm_id, 0) > 65.0:
                        restart_mode = vm.get("auto_restart_mode", "interval")
                        if restart_mode == "clock":
                            target_time = vm.get("auto_restart_time", "03:00")
                            if current_hhmm == target_time:
                                _last_auto_restart_trigger[vm_id] = now_ts
                                logger.info(f"[vm_scheduler] Jadwal Auto-Restart (Jam Tertentu: {current_hhmm}) untuk VM {vm_id}.")
                                await execute_smart_reset(vm)
                                continue
                        elif restart_mode == "interval":
                            val = max(1, int(vm.get("auto_restart_val") or 6))
                            unit = str(vm.get("auto_restart_unit") or "hours").lower()
                            interval_min = val * 60 if unit == "hours" else (val if unit == "minutes" else max(1, val // 60))
                            if runtime_min >= interval_min:
                                _last_auto_restart_trigger[vm_id] = now_ts
                                logger.info(f"[vm_scheduler] Jadwal Auto-Restart Interval ({val} {unit}) terpenuhi untuk VM {vm_id}.")
                                await execute_smart_reset(vm)
                                continue

        except Exception as e:
            logger.error(f"[vm_scheduler] Error pada siklus worker: {e}", exc_info=True)

        await asyncio.sleep(25)


def start_vm_scheduler():
    """Memulai background scheduler daemon."""
    global _scheduler_running, _scheduler_task, _scheduler_loop
    if not _scheduler_running:
        _scheduler_running = True
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        _scheduler_loop = loop
        _scheduler_task = loop.create_task(vm_scheduler_worker_loop())
        logger.info("[vm_scheduler] Daemon berhasil dimulai.")


def stop_vm_scheduler():
    """Menghentikan background scheduler daemon secara aman lintas-thread."""
    global _scheduler_running, _scheduler_task, _scheduler_loop
    _scheduler_running = False
    task = _scheduler_task
    loop = _scheduler_loop
    _scheduler_task = None
    _scheduler_loop = None
    if task is not None:
        try:
            if loop is not None and not loop.is_closed():
                try:
                    current_loop = asyncio.get_running_loop()
                except RuntimeError:
                    current_loop = None
                if current_loop is loop:
                    task.cancel()
                else:
                    loop.call_soon_threadsafe(task.cancel)
            else:
                task.cancel()
        except Exception as e:
            logger.warning(f"[vm_scheduler] Peringatan saat membatalkan task scheduler: {e}")
    logger.info("[vm_scheduler] Daemon dihentikan.")

