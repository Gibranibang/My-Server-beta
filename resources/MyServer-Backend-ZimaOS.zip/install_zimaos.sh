#!/usr/bin/env bash
# ==============================================================================
# MyServer Native Backend - Smart Dual-Mode Installer (v1.2.7)
# Mendukung Fresh Install (Instalasi Baru) & Update OTA (Pembaruan)
# Dilengkapi Proteksi Rollback Otomatis dan Proteksi Persistensi Data
# ==============================================================================

set -e

# ANSI Color Codes
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}======================================================${NC}"
echo -e "${CYAN}     MyServer Native Backend - ZimaOS Deployment      ${NC}"
echo -e "${CYAN}            v1.2.7 (Smart Dual-Mode & Rollback)       ${NC}"
echo -e "${CYAN}======================================================${NC}"

# ZimaOS Immutable Rootfs Compatibility: redirect docker config to writable /tmp
export DOCKER_CONFIG="/tmp/.docker"
export TMPDIR="/tmp"
mkdir -p "$DOCKER_CONFIG"

# Direktori sumber skrip dijalankan
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="/DATA/AppData/myserver-backend"
DATA_DIR="$TARGET_DIR/data"
STORAGE_DIR="/DATA/Backups"

echo -e "\n${YELLOW}[1/5] Memeriksa Lingkungan Docker & Hak Akses...${NC}"

if ! command -v docker &> /dev/null; then
    echo -e "${RED}[ERROR] Docker tidak terdeteksi! Pastikan ZimaOS terpasang dengan benar.${NC}"
    exit 1
fi

DOCKER_COMPOSE_CMD=""
if docker compose version &> /dev/null; then
    DOCKER_COMPOSE_CMD="docker compose"
elif command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE_CMD="docker-compose"
else
    echo -e "${RED}[ERROR] docker compose tidak ditemukan!${NC}"
    exit 1
fi

SUDO=""
if [ "$EUID" -ne 0 ]; then
    if command -v sudo &> /dev/null; then
        SUDO="sudo"
    fi
fi

echo -e "${GREEN}✓ Docker & Compose terdeteksi ($DOCKER_COMPOSE_CMD).${NC}"

# 2. Deteksi Mode: Fresh Install vs Update OTA
echo -e "\n${YELLOW}[2/5] Mendeteksi Mode Instalasi...${NC}"

MODE="fresh"
if [ -d "$DATA_DIR" ] && [ -f "$DATA_DIR/backup_meta.db" ]; then
    MODE="update"
    echo -e "${CYAN}✓ Mode Terdeteksi: UPDATE OTA (Database & data persistensi ditemukan).${NC}"
else
    echo -e "${CYAN}✓ Mode Terdeteksi: FRESH INSTALL (Instalasi awal backend baru).${NC}"
fi

$SUDO mkdir -p "$DATA_DIR" "$STORAGE_DIR"

# Jika dijalankan dari luar TARGET_DIR (misal dari /tmp/staging):
if [ "$SCRIPT_DIR" != "$TARGET_DIR" ]; then
    if [ "$MODE" = "update" ]; then
        echo -e "${YELLOW}[Backup] Membuat cadangan app lama (app.bak)...${NC}"
        $SUDO rm -rf "$TARGET_DIR/app.bak"
        if [ -d "$TARGET_DIR/app" ]; then
            $SUDO cp -r "$TARGET_DIR/app" "$TARGET_DIR/app.bak"
        fi
        echo -e "${YELLOW}[Sync] Menyinkronkan modul app/ baru secara bersih ke direktori produksi...${NC}"
        $SUDO rm -rf "$TARGET_DIR/app"
        $SUDO cp -r "$SCRIPT_DIR/app" "$TARGET_DIR/app"
        $SUDO cp "$SCRIPT_DIR/Dockerfile" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/docker-compose.yml" "$TARGET_DIR/" 2>/dev/null || true
        $SUDO cp "$SCRIPT_DIR/requirements.txt" "$TARGET_DIR/" 2>/dev/null || true
    else
        echo -e "${YELLOW}[Setup] Menyalin seluruh paket instalasi ke $TARGET_DIR...${NC}"
        $SUDO cp -r "$SCRIPT_DIR"/* "$TARGET_DIR/" 2>/dev/null || true
    fi
fi

cd "$TARGET_DIR"

# 3. Membersihkan Container Sebelumnya
echo -e "\n${YELLOW}[3/5] Menyiapkan Container Docker...${NC}"
$SUDO $DOCKER_COMPOSE_CMD down 2>/dev/null || true

# 4. Membangun Citra Docker (Tanpa Cache untuk Menjamin Kode Terkini)
echo -e "\n${YELLOW}[4/5] Membangun Image Docker (myserver-backend:latest)...${NC}"
$SUDO $DOCKER_COMPOSE_CMD build --no-cache

echo -e "\n${YELLOW}[5/5] Menjalankan Container di Latar Belakang...${NC}"
$SUDO $DOCKER_COMPOSE_CMD up -d

# 5. Uji Kesehatan Layanan (Healthcheck Verification)
echo -e "\n${YELLOW}Memverifikasi respons server (Healthcheck)...${NC}"
SERVER_READY=0
for i in {1..20}; do
    if curl -s -f http://127.0.0.1:8080/health > /dev/null 2>&1; then
        SERVER_READY=1
        break
    fi
    echo -n "."
    sleep 2
done
echo ""

HOST_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
if [ -z "$HOST_IP" ]; then
    HOST_IP="127.0.0.1"
fi

if [ $SERVER_READY -eq 1 ]; then
    if [ "$MODE" = "update" ]; then
        $SUDO rm -rf "$TARGET_DIR/app.bak"
    fi
    HEALTH_RESP=$(curl -s http://127.0.0.1:8080/health 2>/dev/null || echo "{}")
    echo -e "\n${GREEN}======================================================${NC}"
    echo -e "${GREEN}   ✓ BERHASIL: MyServer Backend v1.2.7 Aktif!         ${NC}"
    echo -e "${GREEN}======================================================${NC}"
    echo -e "Status Layanan:"
    echo -e "  - Respons Health : ${CYAN}${HEALTH_RESP}${NC}"
    echo -e "  - Mode Selesai   : ${GREEN}${MODE^^}${NC}"
    echo -e "  - URL Akses      : ${CYAN}http://${HOST_IP}:8080${NC}"
    echo -e "  - API Docs       : ${CYAN}http://${HOST_IP}:8080/docs${NC}"
    echo -e "${GREEN}======================================================${NC}"
    exit 0
else
    echo -e "\n${RED}======================================================${NC}"
    echo -e "${RED}[GALAT] Layanan belum merespons dalam 40 detik!${NC}"
    if [ "$MODE" = "update" ] && [ -d "$TARGET_DIR/app.bak" ]; then
        echo -e "${YELLOW}[ROLLBACK] Mengaktifkan pemulihan otomatis ke versi sebelumnya...${NC}"
        $SUDO rm -rf "$TARGET_DIR/app"
        $SUDO mv "$TARGET_DIR/app.bak" "$TARGET_DIR/app"
        $SUDO $DOCKER_COMPOSE_CMD up -d
        echo -e "${YELLOW}[ROLLBACK] Versi lama berhasil dipulihkan.${NC}"
    fi
    echo -e "Periksa log container dengan perintah:"
    echo -e "  ${YELLOW}$DOCKER_COMPOSE_CMD logs --tail 50${NC}"
    echo -e "${RED}======================================================${NC}"
    exit 1
fi
