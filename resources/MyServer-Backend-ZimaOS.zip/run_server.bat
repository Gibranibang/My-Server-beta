@echo off
title MyServer Native Backend Engine
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================================
echo [MyServer Native Backend] Memulai Server Mandiri (Zero Third-Party)
echo ==============================================================================
echo.
where python >nul 2>nul && python dev_server.py || py dev_server.py
pause
